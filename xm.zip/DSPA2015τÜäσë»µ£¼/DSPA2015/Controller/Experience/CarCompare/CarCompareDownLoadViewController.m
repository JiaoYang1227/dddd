//
//  CarCompareDownLoadViewController.m
//  DSPA2015
//
//  Created by Cluy on 15/12/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarCompareDownLoadViewController.h"
#import "CarCompareDownLoadCell.h"
#import "CarCompare.h"
#import "TMDiskCache.h"
#import "AFDownloadItem.h"
#import "UILabel+AFDownloadRequestOperation.h"
#import "ZipManager.h"
#import "MBProgressHUD.h"
#import "FileManager.h"
#import "KeychainManager.h"
#define CARCOMPARE_DOWNLOAD_FINDER_NAME @"/upload/picture/"
#define COMPETITIONBRAND_FINDER_NAME_TEMP @"/competitionBrandTEMP"

#define CARCOMPARE_DOWNLOAD_FILE_PATH [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],CARCOMPARE_DOWNLOAD_FINDER_NAME]
#define COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],COMPETITIONBRAND_FINDER_NAME_TEMP]

#define COMPETITIONBRAND_DOWNLOAD_OVER @"competitionBrand_download_over"


@interface CarCompareDownLoadViewController ()

@end

@implementation CarCompareDownLoadViewController
#pragma mark notification tableview reload
- (void)notificationUIRefresh{
    [self.downLoadTableView reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    isNewPage = YES;
    _downloadList = [[NSMutableArray alloc]init];
    [[NSNotificationCenter  defaultCenter] addObserver:self  selector:@selector(notificationUIRefresh) name:COMPETITIONBRAND_DOWNLOAD_OVER object:nil];
    
    if([[FileManager sharedManager]createDirectoryAtPath:[NSString stringWithFormat:@"%@/upload",[FileManager documentsPath]]])
     [[FileManager sharedManager]createDirectoryAtPath:CARCOMPARE_DOWNLOAD_FILE_PATH];
    [[FileManager sharedManager] createDirectoryAtPath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP];
    self.title = @"竞品对比资源管理";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)loadData{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CarCompare getCarCompareDownloadList:nil Success:^(NSMutableArray *arrList){
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        _downloadList = arrList;
        [_downLoadTableView reloadData];
       
    } Failure:^(NSError *error) {
      [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}
#pragma mark -
#pragma mark Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 120;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_downloadList count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
    
    UINib * nib = [UINib nibWithNibName:@"CarCompareDownLoadCell" bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:CellIdentifier];
    CarCompareDownLoadCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[CarCompareDownLoadCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    CarCompare *carCompare =[_downloadList objectWithIndex:indexPath.row];
    cell.cellName.text = carCompare.name;
    
    if ([[TMDiskCache sharedCache] objectForKey:carCompare.downLoadPath]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:carCompare.downLoadPath];
        cell.cellProgress.progress = [item.progrees floatValue];
        cell.downloadState = [item.state integerValue];
    }
    
    if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carCompare.downLoadPath]  && isNewPage) {
        [self updateBackMainUI:carCompare withUIProgrees:cell];
    }
    
    switch (cell.downloadState) {
        case NOTDOWNLOAD:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_no"];
            cell.cellRatio.hidden = NO;
            cell.cellRatio.text = @"0";
            cell.cellSpeed.text = @"未下载";
            cell.cellProgress.hidden = NO;
            cell.cellProgress.progress = 0;
            break;
        case DOWNLOADING:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_ing"];
            break;
        case DOWNLOADPAUSE:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_pause"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f"@"%@",cell.cellProgress.progress*100,@"%"];
            cell.cellSpeed.text = @"0";
            break;
        case DOWNLOADOVER:
        {
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_over"];
            cell.cellRatio.hidden = YES;
            cell.cellSpeed.text = @"下载完成";
            cell.cellProgress.hidden = YES;
            
        }
            break;
        default:
            break;
    }
    
    [cell.carCompareDownLoadBtn addTarget:self action:@selector(cellDownloadAction:) forControlEvents:UIControlEventTouchDown];
    cell.carCompareDownLoadBtn.indexPath = indexPath;
    return cell;
}
#pragma mark cell button action
- (void)cellDownloadAction:(CellButton *) sender{
    CarCompareDownLoadCell *cell = [_downLoadTableView cellForRowAtIndexPath:sender.indexPath];
    __weak __typeof(self)weakSelf = self;
    NSIndexPath *index = [_downLoadTableView indexPathForCell:cell];
    CarCompare *carcompare = [_downloadList objectAtIndex:index.row];
    NSLog(@"下载地址 = %@",carcompare.downLoadPath);
    isNewPage = NO;
//    如果下载数据库有值且不是在下在完成的状态下
    if(cell.downloadState == NOTDOWNLOAD){
//        NSString *fileUrl =[carcompare.downLoadPath stringByReplacingOccurrencesOfString:@".zip" withString:@""];
//        //服务器地址
//        NSString *IpUrl =[NSString stringWithFormat:@"%@/dspa_crmserver/",[KeychainManager getBaseURL]];
//        fileUrl = [fileUrl stringByReplacingOccurrencesOfString:IpUrl withString:@""];
//        fileUrl = [FileManager documentsPath:fileUrl];
        NSString *fileUrl = [NSString stringWithFormat:@"%@/%@",COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP,carcompare.name];
  
        if ([[FileManager sharedManager] fileExistsAtPath:fileUrl]) {
            [[FileManager sharedManager] removeFileAtPath:fileUrl];
        }
    }
    switch (cell.downloadState) {
        case NOTDOWNLOAD: // prepareing
        {
            AFDownloadRequestOperation *carShowOperation;
            
            [[AFDownloadManager sharedDownloadManager] downloadQueueTask:carcompare.name
                                                         withDownloadURL:carcompare.downLoadPath
                                                    withDownloadSavePath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP
                                                      withUIProgressView:cell.cellProgress
                                              withAFHTTPRequestOperation:carShowOperation
                                                         downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                             
                                                             [weakSelf saveDownloadItem:state withUrl:carcompare.downLoadPath withProgrees:@"1" withMD5:nil];
                                                             [_downLoadTableView  reloadData];
                                                             [weakSelf zipFileRelease:operation.responseObject];
                                                             
                                                         } downloadError:^(AFHTTPRequestOperation *operation, NSError *error, NSString *filePath) {
                                                             cell.downloadState = NOTDOWNLOAD;
                                                             [weakSelf showErrorMessage:error];
                                                             [_downLoadTableView  reloadData];

                                                             
                                                         } downloadInfo:^(NSString *speedInfo ,  float ratio) {
                                                             cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                             cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                         }];
            cell.downloadState = DOWNLOADING;
            [_downLoadTableView reloadData];

        }
            break;
            
        case DOWNLOADING:// downloading
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carcompare.downLoadPath]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carcompare.downLoadPath];
                [[AFDownloadManager sharedDownloadManager] pauseDownload:operation];
                cell.downloadState = DOWNLOADPAUSE;
                
                [weakSelf saveDownloadItem:DOWNLOADPAUSE withUrl:carcompare.downLoadPath withProgrees:[NSString stringWithFormat:@"%f",cell.cellProgress.progress] withMD5:nil];
            }
            [_downLoadTableView reloadData];
        }
            break;
            
        case DOWNLOADPAUSE: // pauseing
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carcompare.downLoadPath]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carcompare.downLoadPath];
                [[AFDownloadManager sharedDownloadManager] resumeDownload:operation];
                [weakSelf updateBackMainUI:carcompare withUIProgrees:cell];
            }else{
                AFDownloadRequestOperation *operation;
                
                [[AFDownloadManager sharedDownloadManager] downloadQueueTask:carcompare.name
                                                             withDownloadURL:carcompare.downLoadPath
                                                        withDownloadSavePath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP
                                                          withUIProgressView:cell.cellProgress
                                                  withAFHTTPRequestOperation:operation
                                                             downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                                 [weakSelf saveDownloadItem:state withUrl:carcompare.downLoadPath withProgrees:@"1" withMD5:nil];
                                                                 [_downLoadTableView  reloadData];

                                                                 [weakSelf zipFileRelease:operation.responseObject];
            
                                                                 
                                                             } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                                 [_downLoadTableView  reloadData];

                                                                 cell.downloadState = NOTDOWNLOAD;
                                                                 [weakSelf showErrorMessage:error];
                                                                 
                                                             } downloadInfo:^(NSString *speedInfo , float ratio) {
                                                                 cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                                 cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                             }];
            }
            [[TMDiskCache sharedCache] removeObjectForKey:carcompare.downLoadPath];
            cell.downloadState = DOWNLOADING;
            [_downLoadTableView reloadData];
        }
            break;
        case DOWNLOADOVER:
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"资源已经下载完成" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
            break;
        default:
            break;
    }

}
// edit video tableview
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    CarCompare *carCompare =[_downloadList objectWithIndex:indexPath.row];
    if ([[TMDiskCache sharedCache] objectForKey:carCompare.downLoadPath]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:carCompare.downLoadPath];
        if ([item.state integerValue] == DOWNLOADOVER) {
            return YES;
        }
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    dispatch_queue_t concurrentQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(concurrentQueue, ^{
        
        dispatch_sync(concurrentQueue, ^{
            CarCompare *carCompare =[_downloadList objectWithIndex:indexPath.row];
            if (editingStyle == UITableViewCellEditingStyleDelete && [[TMDiskCache sharedCache] objectForKey:carCompare.downLoadPath]) {
                AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:carCompare.downLoadPath];
                if ([item.state integerValue] == DOWNLOADOVER) {
                    [[TMDiskCache sharedCache] removeObjectForKey:carCompare.downLoadPath];
                    NSString *fileName = [CARCOMPARE_DOWNLOAD_FILE_PATH stringByAppendingPathComponent:carCompare.brandId];
                    [[FileManager sharedManager] removeFileAtPath:fileName];
                    CarCompareDownLoadCell *cell = (CarCompareDownLoadCell *)[tableView cellForRowAtIndexPath:indexPath];
                    cell.downloadState = NOTDOWNLOAD;
                }
            }
        });
        
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self.downLoadTableView reloadData];
        });
    });
    
    
}

#pragma mark back view refresh main view
- (void)updateBackMainUI:(CarCompare *)carCompare withUIProgrees:(UITableViewCell *)tbCell{
    CarCompareDownLoadCell *cell = (CarCompareDownLoadCell *)tbCell;
    AFHTTPRequestOperation *op = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carCompare.downLoadPath];
    if (![op isPaused]) {
        
        [cell.cellSpeed setUILabelWithDownloadUILabelOfOperation:(AFDownloadRequestOperation*)op downloadInfo:^(NSString *speedInfo, float ratio) {
            cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
            
        } currDownloadSpeed:^(float currRatio) {
            cell.cellProgress.progress = currRatio;
        }];
        cell.downloadState = DOWNLOADING;
    }
}
#pragma mark download over save item
- (void)saveDownloadItem:(NSInteger )state withUrl:(NSString *)url withProgrees:(NSString *)progrees withMD5:(NSString *)md5{
    AFDownloadItem *item = [[AFDownloadItem alloc] init];
    item.url = url;
    item.progrees = progrees;
    item.state = [NSString stringWithFormat:@"%zd",state];
    [[TMDiskCache sharedCache] setObject:item forKey:url];
}
#pragma mark show error message
- (void)showErrorMessage:(NSError *)error{
    NSString *errorStr = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:errorStr delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [al show];
}

#pragma mark zip file
- (void)zipFileRelease:(NSString *)filePath{
//    NSString *fileName = [filePath stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    [ZipManager unZip:filePath withZipToFilePath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP unZipSuccess:^(NSString *filePath, NSString *toFilePath) {
         [[FileManager sharedManager] moveItems:toFilePath toDir:CARCOMPARE_DOWNLOAD_FILE_PATH];
    }];
}




/**
 *  下载全部
 */
- (IBAction)downloadAllButtonAction:(id)sender {
    __weak __typeof(self)weakSelf = self;
    for (int i = 0; i < _downloadList.count; i++) {
        CarCompare *carcompare = [_downloadList objectWithIndex:i];
        // 判断文件夹是否存在
//        [[FileManager sharedManager] createDirectoryAtPath:[CARCOMPARE_DOWNLOAD_FILE_PATH stringByAppendingPathComponent:carcompare.name]];
        
        if ([[TMDiskCache sharedCache] objectForKey:carcompare.downLoadPath]) {
            //            AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
            //            cell.cellProgress.progress = [item.progrees floatValue];
            //            cell.downloadState = [item.state integerValue];
            continue;
        }
        
        
        if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carcompare.downLoadPath]) {
            
            
            AFHTTPRequestOperation *operationTemp = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carcompare.downLoadPath];
            
            if ([operationTemp isPaused]) {
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carcompare.downLoadPath];
                [[AFDownloadManager sharedDownloadManager] resumeDownload:operation];
                //                [weakSelf updateBackMainUI:videoModel withUIProgrees:cell];
                
            }
            continue;
        }
        
        AFDownloadRequestOperation *carShowOperation;
        
        [[AFDownloadManager sharedDownloadManager] downloadQueueTask:carcompare.name
                                                     withDownloadURL:carcompare.downLoadPath
                                                withDownloadSavePath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP
                                                  withUIProgressView:nil
                                          withAFHTTPRequestOperation:carShowOperation
                                                     downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                         
                                                         [weakSelf saveDownloadItem:state withUrl:carcompare.downLoadPath withProgrees:@"1" withMD5:nil];
                                                         [_downLoadTableView  reloadData];
                                                         [weakSelf zipFileRelease:operation.responseObject];
                                                         
                                                     } downloadError:^(AFHTTPRequestOperation *operation, NSError *error, NSString *filePath) {
//                                                         cell.downloadState = NOTDOWNLOAD;
                                                         [weakSelf showErrorMessage:error];
                                                         [_downLoadTableView  reloadData];
                                                         
                                                         
                                                     } downloadInfo:^(NSString *speedInfo ,  float ratio) {
//                                                         cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
//                                                         cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                     }];

    }
    
    [_downLoadTableView reloadData];
    
}



@end
