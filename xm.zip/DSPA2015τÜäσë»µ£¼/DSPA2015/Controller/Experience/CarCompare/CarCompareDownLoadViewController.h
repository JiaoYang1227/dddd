//
//  CarCompareDownLoadViewController.h
//  DSPA2015
//
//  Created by Cluy on 15/12/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ResourcesBaseTableViewController.h"
#import "AFDownloadManager.h"
@interface CarCompareDownLoadViewController : ResourcesBaseTableViewController<UITableViewDataSource,UITableViewDelegate>{
      AFHTTPRequestOperation *_videoOperation;      //创建请求管理（用于上传和下载）
      BOOL isNewPage;
}

@property (strong, nonatomic) NSMutableArray *downloadList;
@property (weak, nonatomic) IBOutlet UITableView *downLoadTableView;

@end
