//
//  ZongheViewController.h
//  DSPA2015
//
//  Created by Cluy on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "PopoverController.h"
#import "LevelMenuTableView.h"
#import "BasicTableView.h"
#import "Car.h"
@interface ZongheViewController : BaseViewController<UIPopoverPresentationControllerDelegate,GetDataDelegate,CompareScrollDelegate,UIScrollViewDelegate>{
    LevelMenuTableView *levelMenuTableView;
    PopoverController *pop;
}
//车型1

@property (weak, nonatomic) IBOutlet UIWebView *car1Web;
@property (weak, nonatomic) IBOutlet UIImageView *car1ImgView;
@property (weak, nonatomic) IBOutlet UIButton *compareCar1;
//车型2
@property (weak, nonatomic) IBOutlet UIWebView *car2Web;
@property (weak, nonatomic) IBOutlet UIImageView *car2ImgView;
@property (weak, nonatomic) IBOutlet SelectButton *compareCar2;

//yes本品对比  no 为为竞品对比
@property (nonatomic)BOOL isFromCarShow;
//本品对比传来的车型数据
@property(strong,nonatomic)Car *modelInfo;

@property (strong, nonatomic) NSDictionary *car1Data;
@property (strong, nonatomic) NSDictionary *car2Data;

-(instancetype)initWithModel:(Car*)modelInfo andCar1Data:(NSDictionary *)car1Data andCar2Data:(NSDictionary *)car2Data andisFromCarShow:(BOOL)isFromCarShow;
@end
