//
//  ZongheViewController.m
//  DSPA2015
//
//  Created by Cluy on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ZongheViewController.h"
#import "CarCompare.h"

@interface ZongheViewController ()

@end

@implementation ZongheViewController
-(instancetype)initWithModel:(Car*)modelInfo andCar1Data:(NSDictionary *)car1Data andCar2Data:(NSDictionary *)car2Data andisFromCarShow:(BOOL)isFromCarShow
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _car1Data = car1Data;
        _car2Data = car2Data;
        _modelInfo = modelInfo;
        _isFromCarShow = isFromCarShow;
     
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    _car1Web.scrollView.delegate = self;
    _car2Web.scrollView.delegate = self;
    [_car1Web setBackgroundColor:[UIColor clearColor]];
    [_car1Web setOpaque:NO];
    [_car2Web setBackgroundColor:[UIColor clearColor]];
    [_car2Web setOpaque:NO];
    [self.compareCar1 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar1 setImage:nil forState:UIControlStateNormal];
    
    [self.compareCar2 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar2 setImage:nil forState:UIControlStateNormal];
    
    levelMenuTableView = [[LevelMenuTableView alloc]init];
    levelMenuTableView.getDataDelegate = self;
    pop = [[PopoverController alloc]initWithContentView:levelMenuTableView];
    pop.popoverPresentationController.delegate = self;


    if(self.isFromCarShow){
        
        //todo
        _car1Data = [CarCompare loadFromCarShowDataWithBrandId:self.modelInfo.key andModelId:self.modelInfo.modelKey];
    }
    [self initView:_car1Data withBool:YES];
    [self initView:_car2Data withBool:NO];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark 获取车型车系二级菜单值
-(void)loadLevelMenuData{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]initWithArray:[CarCompare loadCarBrandList]];
    NSLog(@"brandListArr = %@",brandListArr);
    [brandListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic stringForKey:@"bName"];
        firstItem.paramDic = tempDic;
        firstItem.subItems = [[NSMutableArray alloc]init];
        NSArray *modelListArr = [CarCompare loadCarModelList:[tempDic stringForKey:@"brandId"]];
        NSLog(@"modelListArr = %@",modelListArr);
        [modelListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic stringForKey:@"mName"];
            seconditem.paramDic = tempDic;
            [firstItem.subItems addObject:seconditem];
        }];
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }];
    [levelMenuTableView reloadData];
    
}

-(void)loadLevelMenuDataFromCompare:(BOOL)isFromCar1{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]init];
    NSString *bNameKey;
    NSString *brindidKey;
    NSString *mNameKey;
    
    if (isFromCar1) {
        bNameKey = @"bName";
        brindidKey = @"brandId";
        mNameKey = @"mName";
        brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListFromCompare];
        
    }else{
        bNameKey = @"cbName";
        brindidKey = @"cBrandId";
        mNameKey = @"cmName";
        brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListWithBrandId:[_car1Data stringForKey:@"brandId"]];
    }
    
    NSLog(@"brandListArr = %@",brandListArr);
    [brandListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic stringForKey:bNameKey];
        firstItem.paramDic = tempDic;
        firstItem.subItems = [[NSMutableArray alloc]init];
        NSArray *modelListArr = [[NSMutableArray alloc]init];
        if (isFromCar1) {
//            modelListArr = [CarCompare loadCarModelListFromCompare:[tempDic stringForKey:brindidKey]];
        }else{
//            modelListArr = [CarCompare loadCarModelListFromWithBrandId:[tempDic stringForKey:brindidKey]];
        }
        NSLog(@"modelListArr = %@",modelListArr);
        [modelListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic stringForKey:mNameKey];
            seconditem.paramDic = tempDic;
            if (!isFromCar1) {
                [seconditem.paramDic setValue:[tempDic stringForKey:@"cBrandId"] forKey:@"brandId"];
                [seconditem.paramDic setValue:[tempDic stringForKey:@"cbName"] forKey:@"bName"];
                [seconditem.paramDic setValue:[tempDic stringForKey:@"cModelId"] forKey:@"modelId"];
                [seconditem.paramDic setValue:[tempDic stringForKey:@"cmName"] forKey:@"mName"];
                [seconditem.paramDic setValue:[tempDic stringForKey:@"cPicUrl"] forKey:@"picUrl"];
                [seconditem.paramDic setValue:[tempDic stringForKey:@"cPrice"] forKey:@"price"];
            }
            [firstItem.subItems addObject:seconditem];
        }];
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }];
    [levelMenuTableView reloadData];
    
}
- (IBAction)selectCar1:(id)sender {
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }else{
        [self loadLevelMenuDataFromCompare:YES];
    }
    
    // 清空车型2的数据
    _car2Data = [[NSDictionary alloc]init];
    [_compareCar2 reset];
    _car2ImgView.image = [UIImage imageNamed:@"compare_car_normal.png"];
    

    
    UIButton *btn = _compareCar1;
    levelMenuTableView.frame =  CGRectMake(btn.frame.origin.x,btn.frame.origin.y+btn.frame.size.height, 500, 200);
    levelMenuTableView.tagForComaprCar = YES;
    pop.popoverPresentationController.sourceView = btn;
    pop.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:pop animated:YES completion:nil];
    
}
- (IBAction)selectCar2:(id)sender {
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }else{
        [self loadLevelMenuDataFromCompare:NO];
    }
    UIButton *btn = _compareCar2;
    levelMenuTableView.frame =  CGRectMake(btn.frame.origin.x,btn.frame.origin.y+btn.frame.size.height, 500, 200);
    levelMenuTableView.tagForComaprCar = NO;
    pop.popoverPresentationController.sourceView = btn;
    pop.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:pop animated:YES completion:nil];
}

#pragma mark getDataDelegate
-(void)initView:(NSDictionary *)data withBool:(BOOL)iscar1{
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *imagUrl = [data stringForKey:@"picUrl"];
    if (imagUrl!=nil && ![imagUrl isEqualToString:@"<null>"] && ![imagUrl isEqualToString:@""]) {
        imagUrl = [NSString stringWithFormat:@"%@/%@",documentUrl,imagUrl];
    }else{
        imagUrl =nil;
    }
    
    NSString *title = [NSString stringWithFormat:@"%@ %@",[data stringForKey:@"bName"]?:@"",[data stringForKey:@"mName"]?:@""];
    if ([title isEqualToString:@" "]) {
        title = @"请选择对比车辆";
    }
    
    //对比车型1
    if (iscar1) {
        _car1Data = data;
        if (imagUrl!=nil) {
            _car1ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        
        [_compareCar1 setTitle:title forState:UIControlStateNormal];
        //todo show pdf
        NSString *realPath = [CarCompare GEtPDFPath:[_car1Data stringForKey:@"brandId"]];
        [_car1Web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:realPath]]];
        
    }else{
        if ([_compareCar1.titleLabel.text isEqualToString:title] && ![_compareCar1.titleLabel.text isEqualToString:@"请选择对比车辆"]) {
            [JKAlert showMessage:@"不能选择同一款车型进行比较！"];
            _car2Data =nil;
            return;
        }
        _car2Data = data;
        if (imagUrl!=nil) {
            _car2ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        [_compareCar2 setTitle:title forState:UIControlStateNormal];
        //todo show pdf
        NSString *realPath =[CarCompare GEtPDFPath:[_car2Data stringForKey:@"brandId"]];
         [_car2Web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:realPath]]];
    }
    
    
}
-(void)getDidCellData:(NSDictionary *)data withTableView:(UITableView*)tableView{
    NSLog(@"%@",data);
    if (levelMenuTableView.tagForComaprCar) {
        _car1Data = data;
        [self initView:_car1Data withBool:YES];
    }else{
        _car2Data = data;
        [self initView:_car2Data withBool:NO];
    }
}

#pragma mark webviewDelegate

-(void)scrollViewDidScroll:(UIScrollView*)scrollView{
    _car2Web.scrollView.contentOffset =CGPointMake(_car2Web.scrollView.contentOffset.x,scrollView.contentOffset.y);

    _car1Web.scrollView.contentOffset =CGPointMake(_car1Web.scrollView.contentOffset.x, scrollView.contentOffset.y);

}
@end
