//
//  PictureViewController.m
//  DSPA2015
//
//  Created by Cluy on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "PictureViewController.h"
#import "CarCompare.h"

@interface PictureViewController ()

@end

@implementation PictureViewController
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(instancetype)initWithModel:(Car*)modelInfo andCar1Data:(NSDictionary *)car1Data andCar2Data:(NSDictionary *)car2Data andisFromCarShow:(BOOL)isFromCarShow
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _car1Data = car1Data;
        _car2Data = car2Data;
        _modelInfo = modelInfo;
        _isFromCarShow = isFromCarShow;
        self.pictureCompareTableView.backgroundView.backgroundColor = [UIColor clearColor];
        self.pictureCompareTableView.backgroundColor = [UIColor clearColor];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    _sectionListTV.hidden = YES;
    _sectionListTV.sectionTVDelegate = self;
    _pictureList1 =[[NSMutableArray alloc]init];
    _pictureList2 =[[NSMutableArray alloc]init];
    
    [self.compareCar1 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar1 setImage:nil forState:UIControlStateNormal];
    
    [self.compareCar2 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar2 setImage:nil forState:UIControlStateNormal];
    
    levelMenuTableView = [[LevelMenuTableView alloc]init];
    levelMenuTableView.getDataDelegate = self;
    pop = [[PopoverController alloc]initWithContentView:levelMenuTableView];
    pop.popoverPresentationController.delegate = self;
    
    if(self.isFromCarShow){
        
        //todo
        _car1Data = [CarCompare loadFromCarShowDataWithBrandId:self.modelInfo.key andModelId:self.modelInfo.modelKey];
    }
    [self initView:_car1Data withBool:YES];
    [self initView:_car2Data withBool:NO];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"竞品对比_图片对比"];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"竞品对比_图片对比"];
}
#pragma mark 获取车型车系二级菜单值
-(void)loadLevelMenuData{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]initWithArray:[CarCompare loadCarBrandList]];
    NSLog(@"brandListArr = %@",brandListArr);
    [brandListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic stringForKey:@"bName"];
        firstItem.paramDic = tempDic;
        firstItem.subItems = [[NSMutableArray alloc]init];
        NSArray *modelListArr = [CarCompare loadCarModelList:[tempDic stringForKey:@"brandId"]];
        NSLog(@"modelListArr = %@",modelListArr);
        [modelListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic stringForKey:@"mName"];
            seconditem.paramDic = tempDic;
            [firstItem.subItems addObject:seconditem];
        }];
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }];
    [levelMenuTableView reloadData];
    
}

-(void)loadLevelMenuDataFromCompare:(BOOL)isFromCar1{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]init];
    NSString *bNameKey;
    NSString *brindidKey;
    NSString *mNameKey;
    bNameKey = @"brandName";
    brindidKey = @"brandId";
    mNameKey = @"modelName";
    brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListFromCompare];
    NSLog(@"brandListArr = %@",brandListArr);
    for (NSDictionary *tempDic in brandListArr) {
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic objectForKey:bNameKey];
        firstItem.paramDic = tempDic;
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }
    [levelMenuTableView reloadData];
    
}
- (IBAction)selectCar1:(id)sender {
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }else{
        [self loadLevelMenuDataFromCompare:YES];
    }
    
    // 清空车型2的数据
    _car2Data = [[NSDictionary alloc]init];
    [_compareCar2 reset];
    _car2ImgView.image = [UIImage imageNamed:@"compare_car_normal.png"];
    
    _pictureList2 = [[NSMutableArray alloc]init];
    [_pictureCompareTableView reloadData];
    
    UIButton *btn = _compareCar1;
    levelMenuTableView.frame =  CGRectMake(btn.frame.origin.x,btn.frame.origin.y+btn.frame.size.height, 500, 200);
    levelMenuTableView.tagForComaprCar = YES;
    pop.popoverPresentationController.sourceView = btn;
    pop.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:pop animated:YES completion:nil];
    
}
- (IBAction)selectCar2:(id)sender {
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }
    UIButton *btn = _compareCar2;
    carCompar2View = [[CarCompareBtnPopViewController alloc]init];
    carCompar2View.car2SelectDataDelegate = self;
    carCompar2View.car1brandId =[_car1Data objectForKey:@"brandId"];
    carCompar2View.popoverPresentationController.sourceView = btn;
    carCompar2View.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:carCompar2View animated:YES completion:nil];
}

#pragma mark getDataDelegate
-(void)initView:(NSDictionary *)data withBool:(BOOL)iscar1{
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *imagUrl = [data stringForKey:@"picUrl"];
    if (imagUrl!=nil && ![imagUrl isEqualToString:@"<null>"] && ![imagUrl isEqualToString:@""]) {
        imagUrl = [NSString stringWithFormat:@"%@/%@",documentUrl,imagUrl];
    }else{
        imagUrl =nil;
    }
    
    NSString *title = [NSString stringWithFormat:@"%@ %@",[data stringForKey:@"brandName"]?:@"",[data stringForKey:@"modelName"]?:@""];
    if ([title isEqualToString:@" "]) {
        title = @"请选择对比车辆";
    }
    
    //对比车型1
    if (iscar1) {
        _car1Data = data;
        if (imagUrl!=nil) {
            _car1ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        
        [_compareCar1 setTitle:title forState:UIControlStateNormal];
        [self loadPictureItemsWithBool:iscar1  withDictionary:_car1Data];
    }else{
        if ([_compareCar1.titleLabel.text isEqualToString:title] && ![_compareCar1.titleLabel.text isEqualToString:@"请选择对比车辆"]) {
            [JKAlert showMessage:@"不能选择同一款车型进行比较！"];
            _car2Data =nil;
            return;
        }
        _car2Data = data;
        if (imagUrl!=nil) {
            _car2ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        [_compareCar2 setTitle:title forState:UIControlStateNormal];
        [self loadPictureItemsWithBool:iscar1 withDictionary:_car2Data];
    }
    
    
}
-(void)loadPictureItemsWithBool:(BOOL)iscar1 withDictionary:(NSDictionary *)temp{
    NSArray *pictureItemList = [CarCompare GetTitleList];
    // 设置目录导航
    NSMutableArray *sectionList = [[NSMutableArray alloc]init];
    [pictureItemList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *item = obj;
        [sectionList addObject:[item stringForKey:@"itemname"]];
    }];
    _sectionListTV.hidden = NO;
    _sectionListTV.listArr =sectionList;
    _sectionListTV.tagNo = 0;
    [_sectionListTV reloadData];
    NSMutableArray *titleList =[[NSMutableArray alloc]init];
    if (iscar1) {
        _pictureList1 =[[NSMutableArray alloc]init];
        
    }else{
        _pictureList2 =[[NSMutableArray alloc]init];
    }
    NSArray *picUrlList = [CarCompare GetURLListWithModelID:[temp stringForKey:@"modelId"]];
    [picUrlList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [titleList addObject:[obj stringForKey:@"itemname"]];
    }];
    [pictureItemList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        
        //中间少了如果没有这个类型图片怎么办
        
        [picUrlList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            if ([[obj stringForKey:@"itemid"]isEqualToString:[tempDic stringForKey:@"itemid"]]) {
                NSString *picUrl = [obj stringForKey:@"fileRealpath"];
                if (iscar1) {
                    //todo:找到具体项值
                    [_pictureList1 addObject:picUrl?:@""];
                }else{
                    [_pictureList2 addObject:picUrl?:@""];
                }
            }
        }];
        
    }];
    //tableView load
    _pictureCompareTableView.titleArr = titleList;
    _pictureCompareTableView.pictureList1 = _pictureList1;
    _pictureCompareTableView.pictureList2 = _pictureList2;
    [_pictureCompareTableView reloadData];
}

//-(void)loadPictureItemsWithBool:(BOOL)iscar1 withDictionary:(NSDictionary *)temp{
//    NSArray *pictureItemList = [CarCompare GetTitleList];
//    // 设置目录导航
//    NSMutableArray *sectionList = [[NSMutableArray alloc]init];
//    [pictureItemList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        NSDictionary *item = obj;
//        [sectionList addObject:[item stringForKey:@"itemname"]];
//    }];
//    _sectionListTV.hidden = NO;
//    _sectionListTV.listArr =sectionList;
//    _sectionListTV.tagNo = 0;
//    [_sectionListTV reloadData];
//
//    if (iscar1) {
//        _pictureList1 =[[NSMutableArray alloc]init];
//
//    }else{
//        _pictureList2 =[[NSMutableArray alloc]init];
//    }
//    NSArray *picUrlList = [CarCompare GetURLListWithModelID:[temp stringForKey:@"modelId"]];
//    [picUrlList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//                NSString *picUrl = [obj stringForKey:@"fileRealpath"];
//                if (iscar1) {
//                    //todo:找到具体项值
//                    [_pictureList1 addObject:picUrl?:@""];
//                }else{
//                    [_pictureList2 addObject:picUrl?:@""];
//                }
//        }];
//    //tableView load
//    _pictureCompareTableView.titleArr = sectionList;
//    _pictureCompareTableView.pictureList1 = _pictureList1;
//    _pictureCompareTableView.pictureList2 = _pictureList2;
//    [_pictureCompareTableView reloadData];
//}

-(void)getDidCellData:(NSDictionary *)data withTableView:(UITableView*)tableView{
    NSLog(@"%@",data);
    _car1Data = data;
    [self initView:_car1Data withBool:YES];
}
-(void)Car2SelectData:(NSDictionary *)data{
    _car2Data = data;
    [self initView:_car2Data withBool:NO];
    
}
#pragma mark ----------------------------------------------------------
#pragma mark sectionTV Delegate
- (void)reloadTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    _sectionListTV.tagNo =(int)indexPath.row;
    [_sectionListTV reloadData];
    
    NSLog(@"indexPath.row:%zd",indexPath.row);
    if(_pictureCompareTableView.titleArr.count <= indexPath.row){
        return;
    }
    [_pictureCompareTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
    _sectionListTV.isReload = NO;
}
#pragma mark getDataDelegate
-(void)loadModels:(NSDictionary *)data withIndex:(NSIndexPath *)indexPath withTableView:(UITableView *)tableView{
    NSArray *modelListArr = [CarCompare loadCarModelListFromCompare:[data objectForKey:@"brandId"]];
    LevelItem *firstitem = [levelMenuTableView.menuData.tableViewData objectAtIndex:indexPath.row];
    firstitem.subItems = [[NSMutableArray alloc]init];
    for (NSDictionary *obj in modelListArr) {
        if ([[data objectForKey:@"brandId"] isEqualToString:[obj objectForKey:@"brandId"]]) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic objectForKey:@"modelName"];
            seconditem.paramDic = tempDic;
            [firstitem.subItems addObject:seconditem];
        }
    }
    [levelMenuTableView.menuData.tableViewData replaceObjectAtIndex:indexPath.row withObject:firstitem];
    MenuItemCell * cell;
    cell = (MenuItemCell *)[tableView cellForRowAtIndexPath:indexPath];
    NSArray * arr;
    arr = [levelMenuTableView.menuData insertMenuIndexPaths:cell.item];
    if ([arr count] >0) {
        [tableView insertRowsAtIndexPaths:arr withRowAnimation:UITableViewRowAnimationBottom];
    }
    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
}
@end
