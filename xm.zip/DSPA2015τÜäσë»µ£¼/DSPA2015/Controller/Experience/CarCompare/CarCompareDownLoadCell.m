//
//  CarCompareDownLoadCell.m
//  DSPA2015
//
//  Created by Cluy on 15/12/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarCompareDownLoadCell.h"

@implementation CarCompareDownLoadCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)configCell:(NSDictionary*)item{
    
}
@end
