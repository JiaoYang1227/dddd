//
//  CarComapreMainViewController.h
//  DSPA2015
//
//  Created by Cluy on 15/11/17.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "PopoverController.h"
#import "LevelMenuTableView.h"
#import "CarCompareBtnPopViewController.h"

@interface CarComapreMainViewController : BaseViewController<UIPopoverPresentationControllerDelegate,GetDataDelegate,Car2SelectDataDelegate>
{
    PopoverController *pop;
    LevelMenuTableView *levelMenuTableView;
    CarCompareBtnPopViewController *carCompar2View;
    
    
    NSDictionary *car1Data;
    NSDictionary *car2Data;
    
}
@property(nonatomic)  BOOL isFromCarShow;// yes来自车辆展示即本品对比  no来自主页竟品对比
@property (weak, nonatomic) IBOutlet UILabel *car1Price;
@property (weak, nonatomic) IBOutlet UIImageView *car1ImgView;
@property (weak, nonatomic) IBOutlet SelectButton *compareCar1;

@property (weak, nonatomic) IBOutlet UIImageView *car2ImgView;
@property (weak, nonatomic) IBOutlet UILabel *car2Price;
@property (weak, nonatomic) IBOutlet SelectButton *compareCar2;

@end
