//
//  CarcompareDetailViewController.m
//  DSPA2015
//
//  Created by Cluy on 15/11/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarcompareDetailViewController.h"
#import "CarCompare.h"
#import "FileManager.h"
@interface CarcompareDetailViewController ()

@end

@implementation CarcompareDetailViewController
//-(void)createPictureTable{
//    [CarCompare LoadPictureItemsSucces];
//    [CarCompare LoadPictureItemsValue];
//}
- (void)viewDidLoad {
    [super viewDidLoad];
    //    [self createPictureTable];
    _compareCar1List = [[NSArray alloc]init];
    _compareCar2List = [[NSArray alloc]init];
    _pictureList1 =[[NSMutableArray alloc]init];
    _pictureList2 =[[NSMutableArray alloc]init];
    [self.compareCar1 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar1 setImage:nil forState:UIControlStateNormal];
    
    [self.compareCar2 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar2 setImage:nil forState:UIControlStateNormal];
    //    _categoryItemsTable.scrolldelegate = self;
    _carCompareTable.scrolldelegate = self;
    levelMenuTableView = [[LevelMenuTableView alloc]init];
    levelMenuTableView.getDataDelegate = self;
    pop = [[PopoverController alloc]initWithContentView:levelMenuTableView];
    pop.popoverPresentationController.delegate = self;
    NSLog(@"loadTitleList = %@",_car1Data);
    if(self.isFromCarShow){
        _titleLabel.text = @"本品对比";
        //todo
        _car1Data = [CarCompare loadFromCarShowDataWithBrandId:self.modelInfo.key andModelId:self.modelInfo.modelKey];
    }
    [self initViewFromData];
    self.title = @"竞品对比详情";
}

-(void)initViewFromData{
    [_hightShow setSelected:YES];
    [_differentShow setSelected:NO];
    [_pictureShow setSelected:NO];
    
    [self initView:_car1Data withBool:YES];
    [self initView:_car2Data withBool:NO];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark 获取车型车系二级菜单值
-(void)loadLevelMenuData{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]initWithArray:[CarCompare loadCarBrandList]];
    NSLog(@"brandListArr = %@",brandListArr);
    [brandListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic stringForKey:@"bName"];
        firstItem.paramDic = tempDic;
        firstItem.subItems = [[NSMutableArray alloc]init];
        NSArray *modelListArr = [CarCompare loadCarModelList:[tempDic stringForKey:@"brandId"]];
        NSLog(@"modelListArr = %@",modelListArr);
        [modelListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic stringForKey:@"mName"];
            seconditem.paramDic = tempDic;
            [firstItem.subItems addObject:seconditem];
        }];
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }];
    [levelMenuTableView reloadData];
    
}

-(void)loadLevelMenuDataFromCompare:(BOOL)isFromCar1{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]init];
    NSString *bNameKey;
    NSString *brindidKey;
    NSString *mNameKey;
    
    if (isFromCar1) {
        bNameKey = @"bName";
        brindidKey = @"brandId";
        mNameKey = @"mName";
        brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListFromCompare];
        
    }else{
        bNameKey = @"cbName";
        brindidKey = @"cBrandId";
        mNameKey = @"cmName";
        brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListWithBrandId:[_car1Data stringForKey:@"brandId"]];
    }
    
    NSLog(@"brandListArr = %@",brandListArr);
    [brandListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic stringForKey:bNameKey];
        firstItem.paramDic = tempDic;
        firstItem.subItems = [[NSMutableArray alloc]init];
        NSArray *modelListArr = [[NSMutableArray alloc]init];
        modelListArr = [CarCompare loadCarModelListFromCompare:[tempDic stringForKey:brindidKey]];
        
        NSLog(@"modelListArr = %@",modelListArr);
        [modelListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic stringForKey:mNameKey];
            seconditem.paramDic = tempDic;
            [firstItem.subItems addObject:seconditem];
        }];
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }];
    [levelMenuTableView reloadData];
    
}
- (IBAction)selectCar1:(id)sender {
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }else{
        [self loadLevelMenuDataFromCompare:YES];
    }
    
    // 清空车型2的数据
    _car2Data = [[NSDictionary alloc]init];
    [_compareCar2 reset];
    _car2ImgView.image = [UIImage imageNamed:@"compare_car_normal.png"];
    _compareCar2List = [[NSArray alloc]init];
    [_carCompareTable reloadData];
    _pictureList2 = [[NSMutableArray alloc]init];
    [_pictureCompareTableView reloadData];
    
    UIButton *btn = _compareCar1;
    levelMenuTableView.frame =  CGRectMake(btn.frame.origin.x,btn.frame.origin.y+btn.frame.size.height, 500, 200);
    levelMenuTableView.tagForComaprCar = YES;
    pop.popoverPresentationController.sourceView = btn;
    pop.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:pop animated:YES completion:nil];
    
}
- (IBAction)selectCar2:(id)sender {
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }else{
        [self loadLevelMenuDataFromCompare:NO];
    }
    UIButton *btn = _compareCar2;
    levelMenuTableView.frame =  CGRectMake(btn.frame.origin.x,btn.frame.origin.y+btn.frame.size.height, 500, 200);
    levelMenuTableView.tagForComaprCar = NO;
    [_carCompareTable reloadData];
    pop.popoverPresentationController.sourceView = btn;
    pop.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:pop animated:YES completion:nil];
}
#pragma mark getDataDelegate
-(void)initView:(NSDictionary *)data withBool:(BOOL)iscar1{
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *imagUrl = [data stringForKey:@"picUrl"];
    if (imagUrl!=nil && ![imagUrl isEqualToString:@"<null>"] && ![imagUrl isEqualToString:@""]) {
        imagUrl = [NSString stringWithFormat:@"%@/%@",documentUrl,imagUrl];
    }else{
        imagUrl =nil;
    }
    
    NSString *title = [NSString stringWithFormat:@"%@ %@",[data stringForKey:@"bName"]?:@"",[data stringForKey:@"mName"]?:@""];
    if ([title isEqualToString:@" "]) {
        title = @"请选择对比车辆";
    }
    
    //对比车型1
    if (iscar1) {
        _car1Data = data;
        if (imagUrl!=nil) {
            _car1ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        
        [_compareCar1 setTitle:title forState:UIControlStateNormal];
        [self loadCategoryItemswithBool:iscar1 withDictionary:_car1Data];
        [self loadPictureItemsWithBool:iscar1  withDictionary:_car1Data];
    }else{
        if ([_compareCar1.titleLabel.text isEqualToString:title] && ![_compareCar1.titleLabel.text isEqualToString:@"请选择对比车辆"]) {
            [JKAlert showMessage:@"不能选择同一款车型进行比较！"];
            _car2Data =nil;
            return;
        }
        _car2Data = data;
        if (imagUrl!=nil) {
            _car2ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        [_compareCar2 setTitle:title forState:UIControlStateNormal];
        [self loadCategoryItemswithBool:iscar1 withDictionary:_car2Data];
        [self loadPictureItemsWithBool:iscar1 withDictionary:_car2Data];
    }
    
    
}
-(void)loadPictureItemsWithBool:(BOOL)iscar1 withDictionary:(NSDictionary *)temp{
    NSArray *pictureItemList = [CarCompare GetTitleList];
    NSMutableArray *titleList =[[NSMutableArray alloc]init];
    if (iscar1) {
        _pictureList1 =[[NSMutableArray alloc]init];
        
    }else{
        _pictureList2 =[[NSMutableArray alloc]init];
    }
    [pictureItemList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        [titleList addObject:[tempDic stringForKey:@"itemname"]];
        NSString *itemid = [tempDic stringForKey:@"itemid"];
        NSString *modelid = [temp stringForKey:@"modelId"];
        if (modelid == nil) {
            modelid = [temp stringForKey:@"cModelId"];
        }
        NSString *picUrl = [CarCompare GetURLListWithModelID:modelid] ;
        if (iscar1) {
            //todo:找到具体项值
            [_pictureList1 addObject:picUrl?:@""];
        }else{
            [_pictureList2 addObject:picUrl?:@""];
        }
        
    }];
    
    //tableView load
    _pictureCompareTableView.titleArr = titleList;
    _pictureCompareTableView.pictureList1 = _pictureList1;
    _pictureCompareTableView.pictureList2 = _pictureList2;
    [_pictureCompareTableView reloadData];
}
-(void)loadCategoryItemswithBool:(BOOL)iscar1 withDictionary:(NSDictionary *)temp{
    //    //todo 获取item值
    //    NSArray *categoryArr;
    //    //todo 获取item子项值title
    //    NSArray *itemsArr;
    if (iscar1) {
        categoryArr =[CarCompare loadTitleList];
        itemsArr = [CarCompare loadTitleItemsWithcpctname:categoryArr];
        NSLog(@"itemsArr = %@",itemsArr);
        _compareCar1List = [CarCompare loadItemsValue:categoryArr andModelId:[temp stringForKey:@"modelId"]];
        ;
    }else{
        _compareCar2List = [CarCompare loadItemsValue:categoryArr andModelId:[temp stringForKey:@"modelId"]];;
        
    }
    BOOL isHighlight = NO;
    if(self.hightShow.selected == YES){
        isHighlight = YES;
    }
    self.carCompareTable.sectionArr = categoryArr;
    self.carCompareTable.listArr = itemsArr;
    self.carCompareTable.carList1 =_compareCar1List;
    self.carCompareTable.carList2 =_compareCar2List;
    self.carCompareTable.isHighLight = isHighlight;
    if ([_compareCar2.titleLabel.text isEqualToString:@"请选择对比车辆"]) {
        self.carCompareTable.car2Selected =NO;
    }else{
        self.carCompareTable.car2Selected =YES;
    }
    
    [self.carCompareTable reloadData];
    
    //    self.categoryItemsTable.sectionArr = categoryArr;
    //    self.categoryItemsTable.listArr = itemsArr;
    //    self.categoryItemsTable.isHighLight = isHighlight;
    //    [self.categoryItemsTable reloadData];
    
}

-(void)getDidCellData:(NSDictionary *)data withTableView:(UITableView*)tableView{
    NSLog(@"%@",data);
    if (levelMenuTableView.tagForComaprCar) {
        _car1Data = data;
        [self initView:_car1Data withBool:YES];
    }else{
        _car2Data = data;
        [self initView:_car2Data withBool:NO];
    }
}
#pragma mark Btn Actions
//高亮
- (IBAction)ShowHightAction:(id)sender {
    
    _showPictureView.hidden = YES;
    [_hightShow setSelected:YES];
    [_differentShow setSelected:NO];
    [_pictureShow setSelected:NO];
    _carCompareTable.isHighLight = YES;
    [_carCompareTable reloadData];
    //    _categoryItemsTable.isHighLight = YES;
    //    [_categoryItemsTable reloadData];
    //    if ([_carCompareTable.sectionArr count]> 0) {
    //        [_carCompareTable scrollToRowAtIndexPath: [NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    //    }
    //    if ([_categoryItemsTable.sectionArr count]> 0) {
    //        [_categoryItemsTable scrollToRowAtIndexPath: [NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    //    }
}
//不同项
- (IBAction)ShowDifferentAction:(id)sender {
    
    _showPictureView.hidden = YES;
    [_hightShow setSelected:NO];
    [_differentShow setSelected:YES];
    [_pictureShow setSelected:NO];
    _carCompareTable.isHighLight = NO;
    [_carCompareTable reloadData];
    //    _categoryItemsTable.isHighLight = NO;
    //    [_categoryItemsTable reloadData];
    //    if ([_carCompareTable.sectionArr count]> 0) {
    //        [_carCompareTable scrollToRowAtIndexPath: [NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    //    }
    //    if ([_categoryItemsTable.sectionArr count]> 0) {
    //        [_categoryItemsTable scrollToRowAtIndexPath: [NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    //    }
}
//图片
- (IBAction)ShowPictureAction:(id)sender {
    
    _showPictureView.hidden = NO;
    [_hightShow setSelected:NO];
    [_differentShow setSelected:NO];
    [_pictureShow setSelected:YES];
}
//#pragma mark compare Scroller Delegate
//- (void)tableViewDidScroll:(UIScrollView *)scrollView{
//    //    NSLog(@"tableViewDidScroll contentOffset begin:%@",NSStringFromCGPoint(scrollView.contentOffset));
//    if (scrollView == _categoryItemsTable) {
//        _carCompareTable.contentOffset = CGPointMake(_carCompareTable.contentOffset.x, _categoryItemsTable.contentOffset.y);
//    }
//
//    if (scrollView == _carCompareTable) {
//        _categoryItemsTable.contentOffset=  CGPointMake(_categoryItemsTable.contentOffset.x, _carCompareTable.contentOffset.y);
//    }
//    NSLog(@"tableViewDidScroll contentOffset end:%@",NSStringFromCGPoint(scrollView.contentOffset));
//
//}
//- (float)tableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
//    float cellHeight = 40;
//    if (tableView == _categoryItemsTable && [_carCompareTable.sectionArr count]>0) {
//        NSLog(@"_carCompareTable.sectionArr  =%@",_carCompareTable.sectionArr );
//        UITableViewCell *cell = [_carCompareTable cellForRowAtIndexPath:indexPath];
//        cellHeight = cell.frame.size.height;
//    }
//    return cellHeight;
//}
@end
