//
//  CarCompareListViewController.m
//  DSPA2015
//
//  Created by Cluy on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "CarCompareListViewController.h"
#import "CarCompare.h"
@interface CarCompareListViewController ()

@end

@implementation CarCompareListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    if(self.isFromCarShow){
        _titleLabel.text = @"本品对比";
    }else{
        self.title = @"竞品对比详情";
    }
    self.paramBtn.selected = YES;
    self.zongheBtn.selected = NO;
    self.pictureBtn.selected = NO;
    
    self.paramVC= [[ParamViewController alloc]initWithModel:self.modelInfo andCar1Data:_car1Data andCar2Data:_car2Data andisFromCarShow:self.isFromCarShow];
    self.paramVC.view.frame = self.contentView.frame;
    [self addChildViewController:self.paramVC];
    
    [self.view addSubview:self.paramVC.view];
    self.currentViewController = self.paramVC;
    //进来默认加载参数对比，此时也计算点击量，所以在这统计一次
    [CBTracking trackEvent:@"竞品对比_参数对比"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//参数对比
- (IBAction)paramAction:(id)sender {
    if(self.currentViewController == self.paramVC){
        return;
    }
    [CBTracking trackEvent:@"竞品对比_参数对比"];
    self.paramBtn.selected = YES;
    self.zongheBtn.selected = NO;
    self.pictureBtn.selected = NO;
    [self transitionFromViewController:self.currentViewController toViewController:self.paramVC duration:0.1 options:UIViewAnimationOptionTransitionNone animations:^{
    } completion:^(BOOL finished) {
        self.currentViewController = self.paramVC;
    }];
}
//综合对比
- (IBAction)zongheCompareAction:(id)sender {
    [self addChildViewController:self.zongheVC];
    if(self.currentViewController == self.zongheVC){
        return;
    }
    self.paramBtn.selected = NO;
    self.zongheBtn.selected = YES;
    self.pictureBtn.selected = NO;
    [self transitionFromViewController:self.currentViewController toViewController:self.zongheVC duration:0.1 options:UIViewAnimationOptionTransitionNone animations:^{
        
    } completion:^(BOOL finished) {
        self.currentViewController = self.zongheVC;
    }];
}
//图片对比
- (IBAction)pictureCompareAction:(id)sender {
    [CBTracking trackEvent:@"竞品对比_图片对比"];
    if (!self.pictureVC) {
        self.pictureVC = [[PictureViewController alloc]initWithModel:self.modelInfo andCar1Data:_car1Data andCar2Data:_car2Data andisFromCarShow:self.isFromCarShow];
        self.pictureVC.view.frame = self.contentView.frame;
    }
    
     [self addChildViewController:self.pictureVC];
    if(self.currentViewController == self.pictureVC){
        return;
    }
    self.paramBtn.selected = NO;
    self.zongheBtn.selected = NO;
    self.pictureBtn.selected = YES;
    [self transitionFromViewController:self.currentViewController toViewController:self.pictureVC duration:0.1 options:UIViewAnimationOptionTransitionNone animations:^{
        
        
        
    } completion:^(BOOL finished) {
        self.currentViewController = self.pictureVC;
    }];
}
@end
