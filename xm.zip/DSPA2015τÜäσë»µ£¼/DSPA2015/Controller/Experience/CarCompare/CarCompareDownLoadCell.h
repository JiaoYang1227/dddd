//
//  CarCompareDownLoadCell.h
//  DSPA2015
//
//  Created by Cluy on 15/12/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellButton.h"

@interface CarCompareDownLoadCell : UITableViewCell
//下载的包名称
@property (weak, nonatomic) IBOutlet UILabel *cellName;
@property (weak, nonatomic) IBOutlet UIProgressView *cellProgress;
//下载速度
@property (weak, nonatomic) IBOutlet UILabel *cellSpeed;
//下载进度 %
@property (weak, nonatomic) IBOutlet UILabel *cellRatio;
//下载状态
@property (weak, nonatomic) IBOutlet UIImageView *cellDownloadState;
//下载btn
@property (weak, nonatomic) IBOutlet CellButton *carCompareDownLoadBtn;



@property (nonatomic ) NSInteger downloadState;


-(void)configCell:(NSDictionary*)item;
@end
