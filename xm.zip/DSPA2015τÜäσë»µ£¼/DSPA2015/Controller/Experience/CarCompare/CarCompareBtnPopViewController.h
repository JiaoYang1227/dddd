//
//  CarCompareBtnPopViewController.h
//  DSPA2015
//
//  Created by Cluy on 16/10/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "PopoverController.h"
#import "LevelMenuTableView.h"
#import "JKSearchBar.h"
#import "BaseViewController.h"
@protocol Car2SelectDataDelegate
-(void)Car2SelectData:(NSDictionary *)data;
@end
@interface CarCompareBtnPopViewController : BaseViewController<JKSearchBarDelegate,GetDataDelegate>
@property (strong,nonatomic)NSMutableArray *brandListArr;
@property (strong,nonatomic)NSString *car1brandId;
@property (weak, nonatomic) IBOutlet LevelMenuTableView *compareCarTable;
@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet LevelMenuTableView *searchTable;
@property (assign)id <Car2SelectDataDelegate>car2SelectDataDelegate;
@end
