//
//  CarcompareDetailViewController.h
//  DSPA2015
//
//  Created by Cluy on 15/11/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "PopoverController.h"
#import "LevelMenuTableView.h"
#import "BasicTableView.h"
#import "CompareTableView.h"
#import "Car.h"
#import "ComparePictureTableView.h"
@interface CarcompareDetailViewController : BaseViewController<UIPopoverPresentationControllerDelegate,GetDataDelegate,CompareScrollDelegate>{
    LevelMenuTableView *levelMenuTableView;
    PopoverController *pop;
    //todo 获取item值
    NSArray *categoryArr;
    //todo 获取item子项值title
    NSArray *itemsArr;
}
@property (strong, nonatomic)NSMutableArray *pictureList1;
@property (strong, nonatomic) NSMutableArray *pictureList2;

@property(strong,nonatomic) Car *modelInfo;
@property (weak, nonatomic) IBOutlet UIView *showPictureView;

@property (nonatomic)BOOL isFromCarShow;//yes本品对比  no 为为竞品对比
@property (strong, nonatomic) NSDictionary *car1Data;
@property (strong, nonatomic) NSDictionary *car2Data;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *car1ImgView;
@property (weak, nonatomic) IBOutlet UIButton *compareCar1;

@property (weak, nonatomic) IBOutlet UIImageView *car2ImgView;
@property (weak, nonatomic) IBOutlet SelectButton *compareCar2;

@property (weak, nonatomic) IBOutlet UIButton *hightShow; //显示高亮
@property (weak, nonatomic) IBOutlet UIButton *differentShow;//显示不同项
@property (weak, nonatomic) IBOutlet UIButton *pictureShow;//显示图片

//@property (weak, nonatomic) IBOutlet BasicTableView *categoryItemsTable;
@property (weak, nonatomic) IBOutlet CompareTableView *carCompareTable;
@property (strong, nonatomic) NSArray *compareCar1List;
@property (strong, nonatomic) NSArray *compareCar2List;

@property (weak, nonatomic) IBOutlet ComparePictureTableView *pictureCompareTableView;

@end
