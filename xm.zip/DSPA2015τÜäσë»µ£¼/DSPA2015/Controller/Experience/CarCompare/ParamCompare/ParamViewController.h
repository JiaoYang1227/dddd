//
//  ParamViewController.h
//  DSPA2015
//
//  Created by Cluy on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "PopoverController.h"
#import "LevelMenuTableView.h"
#import "BasicTableView.h"
#import "CompareTableView.h"
#import "Car.h"
#import "SectionListTableView.h"
#import "CarCompareBtnPopViewController.h"
@interface ParamViewController : BaseViewController<UIPopoverPresentationControllerDelegate,GetDataDelegate,CompareScrollDelegate,SectionTVDelegate,Car2SelectDataDelegate>{
    LevelMenuTableView *levelMenuTableView;
    PopoverController *pop;
    CarCompareBtnPopViewController *carCompar2View;
    //todo 获取item值
    NSArray *categoryArr;
    //todo 获取item子项值title
    NSArray *itemsArr;
    
}
//yes本品对比  no 为为竞品对比
@property (nonatomic)BOOL isFromCarShow;
//Yes 是本页面选择的车型并非其他页面带过来的数据
@property (nonatomic)BOOL isSelectLocal;
//本品对比传来的车型数据
@property(strong,nonatomic)Car *modelInfo;
@property (strong, nonatomic) NSDictionary *car1Data;
@property (strong, nonatomic) NSDictionary *car2Data;
@property (strong, nonatomic) NSArray *compareCar1List;
@property (strong, nonatomic) NSArray *compareCar2List;

//车型1
@property (weak, nonatomic) IBOutlet UIImageView *car1ImgView;
@property (weak, nonatomic) IBOutlet UIButton *compareCar1;
//车型2
@property (weak, nonatomic) IBOutlet UIImageView *car2ImgView;
@property (weak, nonatomic) IBOutlet SelectButton *compareCar2;

@property (weak, nonatomic) IBOutlet UIButton *hightShow; //显示高亮
@property (weak, nonatomic) IBOutlet UIButton *differentShow;//显示不同项
@property (weak, nonatomic) IBOutlet CompareTableView *carCompareTable;
//对比item
@property (weak, nonatomic) IBOutlet SectionListTableView *sectionListTV;


-(instancetype)initWithModel:(Car*)modelInfo andCar1Data:(NSDictionary *)car1Data andCar2Data:(NSDictionary *)car2Data andisFromCarShow:(BOOL)isFromCarShow;
@end
