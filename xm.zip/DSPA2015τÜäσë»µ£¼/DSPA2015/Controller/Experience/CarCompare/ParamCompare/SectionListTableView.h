//
//  SectionLsitTableView.h
//  D-CARS
//
//  Created by Cluy on 15/7/21.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

@protocol SectionTVDelegate
//高度
- (void)reloadTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath;
@end
@interface SectionListTableView : UITableView<UITableViewDataSource,UITableViewDelegate>
@property (strong,nonatomic)NSArray *listArr;
@property (assign)int tagNo;//标记选中的cell
@property (assign)BOOL isReload; //是否需要重新reload
@property (assign)id <SectionTVDelegate>sectionTVDelegate;

@end
