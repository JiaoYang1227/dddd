//
//  ParamViewController.m
//  DSPA2015
//
//  Created by Cluy on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ParamViewController.h"
#import "CarCompare.h"
@interface ParamViewController ()

@end

@implementation ParamViewController
-(instancetype)initWithModel:(Car*)modelInfo andCar1Data:(NSDictionary *)car1Data andCar2Data:(NSDictionary *)car2Data andisFromCarShow:(BOOL)isFromCarShow
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _car1Data = car1Data;
        _car2Data = car2Data;
        _modelInfo = modelInfo;
        _isFromCarShow = isFromCarShow;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    _sectionListTV.hidden = YES;
    _sectionListTV.sectionTVDelegate = self;
    _compareCar1List = [[NSArray alloc]init];
    _compareCar2List = [[NSArray alloc]init];
    [self.compareCar1 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar1 setImage:nil forState:UIControlStateNormal];
    
    [self.compareCar2 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar2 setImage:nil forState:UIControlStateNormal];
    _carCompareTable.scrolldelegate = self;
    levelMenuTableView = [[LevelMenuTableView alloc]init];
    levelMenuTableView.getDataDelegate = self;
    pop = [[PopoverController alloc]initWithContentView:levelMenuTableView];
    pop.popoverPresentationController.delegate = self;
    
    //     if(self.isFromCarShow){
    //         //todo
    //         _car1Data = [CarCompare loadFromCarShowDataWithBrandId:self.modelInfo.key andModelId:self.modelInfo.modelKey];
    //     }
    [_hightShow setSelected:YES];
    [_differentShow setSelected:NO];
    [self initView:_car1Data withBool:YES];
    [self initView:_car2Data withBool:NO];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"竞品对比_参数对比"];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"竞品对比_参数对比"];
}
#pragma mark 获取车型车系二级菜单值
-(void)loadLevelMenuData{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]initWithArray:[CarCompare loadCarBrandList]];
    NSLog(@"brandListArr = %@",brandListArr);
    [brandListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *tempDic = obj;
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic stringForKey:@"bName"];
        firstItem.paramDic = tempDic;
        firstItem.subItems = [[NSMutableArray alloc]init];
        NSArray *modelListArr = [CarCompare loadCarModelList:[tempDic stringForKey:@"brandId"]];
        NSLog(@"modelListArr = %@",modelListArr);
        [modelListArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic stringForKey:@"mName"];
            seconditem.paramDic = tempDic;
            [firstItem.subItems addObject:seconditem];
        }];
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }];
    [levelMenuTableView reloadData];
    
}

-(void)loadLevelMenuDataFromCompare:(BOOL)isFromCar1{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]init];
    NSString *bNameKey;
    NSString *brindidKey;
    NSString *mNameKey;
    bNameKey = @"brandName";
    brindidKey = @"brandId";
    mNameKey = @"modelName";
    brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListFromCompare];
    NSLog(@"brandListArr = %@",brandListArr);
    for (NSDictionary *tempDic in brandListArr) {
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic objectForKey:bNameKey];
        firstItem.paramDic = tempDic;
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }
    [levelMenuTableView reloadData];
}
- (IBAction)selectCar1:(id)sender {
    _isSelectLocal = YES;
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }else{
        [self loadLevelMenuDataFromCompare:YES];
    }
    // 清空车型2的数据
    _car2Data = [[NSDictionary alloc]init];
    _compareCar2List = [[NSArray alloc]init];
    
    UIButton *btn = _compareCar1;
    levelMenuTableView.frame =  CGRectMake(btn.frame.origin.x,btn.frame.origin.y+btn.frame.size.height, 500, 200);
    levelMenuTableView.tagForComaprCar = YES;
    pop.popoverPresentationController.sourceView = btn;
    pop.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:pop animated:YES completion:nil];
    
}
- (IBAction)selectCar2:(id)sender {
    if (self.isFromCarShow) {
        [self loadLevelMenuData];
    }
    UIButton *btn = _compareCar2;
    carCompar2View = [[CarCompareBtnPopViewController alloc]init];
    carCompar2View.car2SelectDataDelegate = self;
    carCompar2View.car1brandId =[_car1Data objectForKey:@"brandId"];
    carCompar2View.popoverPresentationController.sourceView = btn;
    carCompar2View.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:carCompar2View animated:YES completion:nil];
    
}
#pragma mark getDataDelegate
-(void)initView:(NSDictionary *)data withBool:(BOOL)iscar1{
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *imagUrl = [data stringForKey:@"picUrl"];
    if (imagUrl!=nil && ![imagUrl isEqualToString:@"<null>"] && ![imagUrl isEqualToString:@""]) {
        imagUrl = [NSString stringWithFormat:@"%@/%@",documentUrl,imagUrl];
    }else{
        imagUrl =nil;
    }
    
    NSString *title = [NSString stringWithFormat:@"%@ %@",[data stringForKey:@"brandName"]?:@"",[data stringForKey:@"modelName"]?:@""];
    if ([title isEqualToString:@" "]) {
        title = @"请选择对比车辆";
    }
    
    //对比车型1
    if (iscar1) {
        _car1Data = data;
        if (imagUrl!=nil) {
            _car1ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        
        [_compareCar1 setTitle:title forState:UIControlStateNormal];
        [self loadCategoryItemswithBool:iscar1 withDictionary:_car1Data];
    }else{
        if ([_compareCar1.titleLabel.text isEqualToString:title] && ![_compareCar1.titleLabel.text isEqualToString:@"请选择对比车辆"]) {
            [JKAlert showMessage:@"不能选择同一款车型进行比较！"];
            _car2Data =nil;
            return;
        }
        _car2Data = data;
        if (imagUrl!=nil) {
            _car2ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
        }
        [_compareCar2 setTitle:title forState:UIControlStateNormal];
        [self loadCategoryItemswithBool:iscar1 withDictionary:_car2Data];;
    }
    
    
}
-(void)loadCategoryItemswithBool:(BOOL)iscar1 withDictionary:(NSDictionary *)temp{
    //    //todo 获取item值
    //    NSArray *categoryArr;
    //    //todo 获取item子项值title
    //    NSArray *itemsArr;
    if (iscar1) {
        if (_isSelectLocal) {
            [_compareCar2 reset];
            _car2ImgView.image = [UIImage imageNamed:@"compare_car_normal.png"];
            _car2Data = [[NSDictionary alloc]init];
            _compareCar2List = [[NSArray alloc]init];
        }
        categoryArr =[CarCompare loadTitleList];
        itemsArr = [CarCompare loadTitleItemsWithcpctname:categoryArr];
        NSLog(@"itemsArr = %@",itemsArr);
        _compareCar1List = [CarCompare loadItemsValue:categoryArr andModelId:[temp stringForKey:@"modelId"]];
    }else{
        _compareCar2List = [CarCompare loadItemsValue:categoryArr andModelId:[temp stringForKey:@"modelId"]];
        
    }
    BOOL isHighlight = NO;
    if(self.hightShow.selected == YES){
        isHighlight = YES;
    }
    // 设置目录导航
    _sectionListTV.hidden = NO;
    _sectionListTV.listArr =categoryArr;
    _sectionListTV.tagNo = 0;
    [_sectionListTV reloadData];
    
    self.carCompareTable.sectionArr = categoryArr;
    self.carCompareTable.listArr = itemsArr;
    self.carCompareTable.carList1 =_compareCar1List;
    self.carCompareTable.carList2 =_compareCar2List;
    self.carCompareTable.isHighLight = isHighlight;
    if ([_compareCar2.titleLabel.text isEqualToString:@"请选择对比车辆"]) {
        self.carCompareTable.car2Selected =NO;
    }else{
        self.carCompareTable.car2Selected =YES;
    }
    
    [self.carCompareTable reloadData];
    
}
-(void)getDidCellData:(NSDictionary *)data withTableView:(UITableView*)tableView{
    NSLog(@"%@",data);
    _car1Data = data;
    [self initView:_car1Data withBool:YES];
}
-(void)Car2SelectData:(NSDictionary *)data{
    _car2Data = data;
    [self initView:_car2Data withBool:NO];
    
}
#pragma mark Btn Actions
//高亮
- (IBAction)ShowHightAction:(id)sender {
    [_hightShow setSelected:YES];
    [_differentShow setSelected:NO];
    
    _carCompareTable.isHighLight = YES;
    [_carCompareTable reloadData];
}
//不同项
- (IBAction)ShowDifferentAction:(id)sender {
    [_hightShow setSelected:NO];
    [_differentShow setSelected:YES];
    
    _carCompareTable.isHighLight = NO;
    [_carCompareTable reloadData];
}


#pragma mark ----------------------------------------------------------
#pragma mark sectionTV Delegate
- (void)reloadTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    _sectionListTV.tagNo =(int)indexPath.row;
    [_sectionListTV reloadData];
    
    NSLog(@"indexPath.row:%zd",indexPath.row);
    [_carCompareTable scrollToRowAtIndexPath: [NSIndexPath indexPathForRow:0 inSection: indexPath.row] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    _sectionListTV.isReload = NO;
}
-(void)loadModels:(NSDictionary *)data withIndex:(NSIndexPath *)indexPath withTableView:(UITableView *)tableView{
    NSArray *modelListArr = [CarCompare loadCarModelListFromCompare:[data objectForKey:@"brandId"]];
    LevelItem *firstitem = [levelMenuTableView.menuData.tableViewData objectAtIndex:indexPath.row];
    firstitem.subItems = [[NSMutableArray alloc]init];
    for (NSDictionary *obj in modelListArr) {
        if ([[data objectForKey:@"brandId"] isEqualToString:[obj objectForKey:@"brandId"]]) {
            NSDictionary *tempDic = obj;
            LevelItem *seconditem;
            seconditem = [[LevelItem alloc]init];
            seconditem.level = 1;
            seconditem.title =[tempDic objectForKey:@"modelName"];
            seconditem.paramDic = tempDic;
            [firstitem.subItems addObject:seconditem];
        }
    }
    [levelMenuTableView.menuData.tableViewData replaceObjectAtIndex:indexPath.row withObject:firstitem];
    MenuItemCell * cell;
    cell = (MenuItemCell *)[tableView cellForRowAtIndexPath:indexPath];
    NSArray * arr;
    arr = [levelMenuTableView.menuData insertMenuIndexPaths:cell.item];
    if ([arr count] >0) {
        [tableView insertRowsAtIndexPaths:arr withRowAnimation:UITableViewRowAnimationBottom];
    }
    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
}
@end
