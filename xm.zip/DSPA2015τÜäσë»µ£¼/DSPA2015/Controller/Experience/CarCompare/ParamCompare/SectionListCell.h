//
//  SectionListCell.h
//  D-CARS
//
//  Created by Cluy on 15/7/21.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *sectionText;

@property (weak, nonatomic) IBOutlet UIImageView *selectedImg;
@end
