//
//  CarCompareBtnPopViewController.m
//  DSPA2015
//
//  Created by Cluy on 16/10/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "CarCompareBtnPopViewController.h"
#import "CarCompare.h"
@interface CarCompareBtnPopViewController ()

@end

@implementation CarCompareBtnPopViewController
-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nib{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        self.modalPresentationStyle = UIModalPresentationPopover;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _brandListArr = [[NSMutableArray alloc]init];
    _compareCarTable.getDataDelegate = self;
    _searchTable.getDataDelegate = self;
     NSLog(@"start................")
    [self loadData];
     NSLog(@"end................")
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)loadData{
    [self loadDataWithCar1BrandID:_car1brandId];
    [self loadAllData:_searchBar.text];
}
-(void)loadDataWithCar1BrandID:(NSString *)brandId{
    _compareCarTable.tagForComaprCar = NO;
    _compareCarTable.tag = 9001;
    _compareCarTable.menuData.tableViewData =[[NSMutableArray alloc]init];
    NSString *bNameKey;
    NSString *mNameKey;
    bNameKey = @"brandName";
    mNameKey = @"modelName";
    _brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListWithBrandId:brandId];
    for (NSDictionary *tempDic in _brandListArr) {
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic objectForKey:bNameKey];
        firstItem.paramDic = tempDic;
        [_compareCarTable.menuData.tableViewData addObject:firstItem];
    }
    [_compareCarTable reloadData];
}

-(void)loadAllData:(NSString *)searchWord{
    //todo 获取所有车型数据
    _searchTable.tagForComaprCar = NO;
    _searchTable.menuData.tableViewData =[[NSMutableArray alloc]init];
    NSString *bNameKey;
    NSString *brindidKey;
    NSString *mNameKey;
    
    bNameKey = @"brandName";
    brindidKey = @"brandId";
    mNameKey = @"modelName";
    _brandListArr = (NSMutableArray *)[CarCompare loadAllBrandWithSearchStr:searchWord];

    for (NSDictionary *tempDic in _brandListArr) {
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic objectForKey:bNameKey];
        firstItem.paramDic = tempDic;
        [_searchTable.menuData.tableViewData addObject:firstItem];
    }

    [_searchTable reloadData];

}
#pragma -mark searchbar Delegate
-(void)searchBarCancelButtonClicked:(JKSearchBar *)searchBar{
    
    [self loadData];
    
}
- (void)searchBar:(JKSearchBar *)searchBar textDidChange:(NSString *)searchText{
}
-(void)searchBarSearchButtonClicked:(JKSearchBar *)searchBar{
    [self loadData];
    
}

#pragma mark getDataDelegate
-(void)getDidCellData:(NSDictionary *)data  withTableView:(UITableView*)tableView{
    [self.car2SelectDataDelegate Car2SelectData:data];
}
-(void)loadModels:(NSDictionary *)data withIndex:(NSIndexPath *)indexPath withTableView:(UITableView*)tableView{
    LevelMenuTableView *temp = (LevelMenuTableView *)tableView;
    if(temp.tag == 9001){
       NSArray *modellist =[CarCompare loadCarModelListFromWithBrandId:[data objectForKey:@"brandId"]];
        LevelItem *firstitem = [_compareCarTable.menuData.tableViewData objectAtIndex: indexPath.row];
        firstitem.subItems = [[NSMutableArray alloc]init];
        for (NSDictionary *obj in modellist) {
            if ([[data objectForKey:@"brandId"] isEqualToString:[obj objectForKey:@"brandId"]]) {
                NSDictionary *temp = obj;
                LevelItem *seconditem;
                seconditem = [[LevelItem alloc]init];
                seconditem.level = 1;
                seconditem.title =[temp objectForKey:@"modelName"];
                seconditem.paramDic = temp;
                [firstitem.subItems addObject:seconditem];
                
            }
            
            
        }
        [_compareCarTable.menuData.tableViewData replaceObjectAtIndex:indexPath.row withObject:firstitem];
        MenuItemCell * cell;
        cell = (MenuItemCell *)[tableView cellForRowAtIndexPath:indexPath];
        NSArray * arr;
        arr = [_compareCarTable.menuData insertMenuIndexPaths:cell.item];
        if ([arr count] >0) {
            [tableView insertRowsAtIndexPaths:arr withRowAnimation:UITableViewRowAnimationBottom];
        }
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    }else{
        NSArray *modelListArr = [CarCompare loadAllCarWithSearchBrandId:[data objectForKey:@"brandId"]];
        LevelItem *firstitem = [_searchTable.menuData.tableViewData objectAtIndex: indexPath.row];
        firstitem.subItems = [[NSMutableArray alloc]init];
        for (NSDictionary *obj in modelListArr) {
            if ([[data objectForKey:@"brandId"] isEqualToString:[obj objectForKey:@"brandId"]]) {
                NSDictionary *temp = obj;
                LevelItem *seconditem;
                seconditem = [[LevelItem alloc]init];
                seconditem.level = 1;
                seconditem.title =[temp objectForKey:@"modelName"];
                seconditem.paramDic = temp;
                [firstitem.subItems addObject:seconditem];

            }
        }
         [_searchTable.menuData.tableViewData replaceObjectAtIndex:indexPath.row withObject:firstitem];
        MenuItemCell * cell;
        cell = (MenuItemCell *)[tableView cellForRowAtIndexPath:indexPath];
        NSArray * arr;
        arr = [_searchTable.menuData insertMenuIndexPaths:cell.item];
        if ([arr count] >0) {
            [tableView insertRowsAtIndexPaths:arr withRowAnimation:UITableViewRowAnimationBottom];
        }
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    }
}

@end
