//
//  CarCompareListViewController.h
//  DSPA2015
//
//  Created by Cluy on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "ParamViewController.h"
#import "PictureViewController.h"
#import "ZongheViewController.h"
#import "Car.h"
@interface CarCompareListViewController : BaseViewController
@property (strong, nonatomic) ParamViewController *paramVC;
@property (strong, nonatomic) PictureViewController *pictureVC;
@property (strong, nonatomic) ZongheViewController *zongheVC;
@property (strong, nonatomic)UIViewController *currentViewController;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (strong, nonatomic) NSDictionary *car1Data;
@property (strong, nonatomic) NSDictionary *car2Data;
//yes本品对比  no 为为竞品对比
@property (nonatomic)BOOL isFromCarShow;
@property(strong,nonatomic)Car *modelInfo;

@property (weak, nonatomic) IBOutlet UIButton *paramBtn;
@property (weak, nonatomic) IBOutlet UIButton *zongheBtn;
@property (weak, nonatomic) IBOutlet UIButton *pictureBtn;

@end
