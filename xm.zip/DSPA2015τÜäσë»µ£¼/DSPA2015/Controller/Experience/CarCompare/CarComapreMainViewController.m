//
//  CarComapreMainViewController.m
//  DSPA2015
//
//  Created by Cluy on 15/11/17.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarComapreMainViewController.h"
#import "CarCompare.h"
#import "CarCompareListViewController.h"
#import "MBProgressHUD.H"

@interface CarComapreMainViewController ()
@end

@implementation CarComapreMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建数据表
    //    [CarCompare createCompareTable];
    // Do any additional setup after loading the view from its nib.
    [self.compareCar1 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar1 setImage:nil forState:UIControlStateNormal];
    [self.compareCar2 setBackgroundImage:[UIImage imageNamed:@"compare_btn.png"] forState:UIControlStateNormal];
    [self.compareCar2 setImage:nil forState:UIControlStateNormal];
    car1Data = [[NSDictionary alloc]init];
    
    levelMenuTableView = [[LevelMenuTableView alloc]init];
    levelMenuTableView.getDataDelegate = self;
    pop = [[PopoverController alloc]initWithContentView:levelMenuTableView];
    pop.popoverPresentationController.delegate = self;
    
    car2Data = [[NSDictionary alloc]init];
    self.title = @"竞品对比";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)loadDataWithCar1:(BOOL)isFromCar1{
    levelMenuTableView.menuData.tableViewData = [[NSMutableArray alloc]init];
    NSMutableArray *brandListArr = [[NSMutableArray alloc]init];
    NSString *bNameKey;
    NSString *brindidKey;
    NSString *mNameKey;
    bNameKey = @"brandName";
    brindidKey = @"brandId";
    mNameKey = @"modelName";
    brandListArr = (NSMutableArray *)[CarCompare loadCarBrandListFromCompare];
    //    NSLog(@"brandListArr = %@",brandListArr);
    for (NSDictionary *tempDic in brandListArr) {
        LevelItem *firstItem;
        firstItem = [[LevelItem alloc]init];
        firstItem.level = 0;
        firstItem.title =[tempDic objectForKey:bNameKey];
        firstItem.paramDic = tempDic;
        [levelMenuTableView.menuData.tableViewData addObject:firstItem];
    }
    [levelMenuTableView reloadData];
}

- (IBAction)selectCar1:(id)sender {
    //清空car2数据
    _car2Price.text = @"您可以添加对比车辆";
    _car2Price.textColor = [[UIColor alloc]initWithRed:83/255.0 green:83/255.0 blue:83/255.0 alpha:1.0];
    _car2ImgView.image = nil;
    [_compareCar2 reset];
    car2Data = nil;
    [self loadDataWithCar1:YES];
    UIButton *btn = _compareCar1;
    levelMenuTableView.frame =  CGRectMake(btn.frame.origin.x,btn.frame.origin.y+btn.frame.size.height, 500, 200);
    levelMenuTableView.tagForComaprCar = YES;
    pop.popoverPresentationController.sourceView = btn;
    pop.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:pop animated:YES completion:nil];
    
}
- (IBAction)selectCar2:(id)sender {
    UIButton *btn = _compareCar2;
    carCompar2View = [[CarCompareBtnPopViewController alloc]init];
    carCompar2View.car2SelectDataDelegate = self;
    carCompar2View.car1brandId =[car1Data objectForKey:@"brandId"];
    carCompar2View.popoverPresentationController.sourceView = btn;
    carCompar2View.popoverPresentationController.sourceRect = btn.bounds;
    [self presentViewController:carCompar2View animated:YES completion:nil];
}

//开始对比
- (IBAction)compareAction:(id)sender {
    NSLog(@"start.....");
    [MBProgressHUD  showHUDAddedTo:self.view animated:YES];
    CarCompareListViewController *carCompareDetailVC = [[CarCompareListViewController alloc]init];
    carCompareDetailVC.car1Data = car1Data;
    carCompareDetailVC.car2Data = car2Data;
    [self.navigationController pushViewController:carCompareDetailVC animated:YES];
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    NSLog(@"end.....");
}
#pragma mark getDataDelegate
-(void)getDidCellData:(NSDictionary *)data withTableView:(UITableView*)tableView{
    NSLog(@"%@",data);
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *imagUrl = [data objectForKey:@"picUrl"];
    
    if (imagUrl!=nil) {
        imagUrl = [NSString stringWithFormat:@"%@/%@",documentUrl,imagUrl];
    }else{
        imagUrl =nil;
    }
    NSString *price = [data objectForKey:@"price"];
    NSString *title = [NSString stringWithFormat:@"%@ %@",[data objectForKey:@"brandName"],[data objectForKey:@"modelName"]];
    
    //对比车型1
    car1Data = data;
    _car1ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
    if (price == nil ||[price isEqual:[NSNull null]] || [price isEqualToString:@"<null>"]) {
        _car1Price.text = @"您可以添加对比车辆";
        _car1Price.textColor = [[UIColor alloc]initWithRed:83/255.0 green:83/255.0 blue:83/255.0 alpha:1.0];
    }else{
        _car1Price.text = [NSString stringWithFormat:@"价格：RMB %@起",price];
        _car1Price.textColor = [[UIColor alloc]initWithRed:171/255.0 green:21/255.0 blue:43/255.0 alpha:1.0];
    }
    [_compareCar1 setTitle:title forState:UIControlStateNormal];
}
-(void)Car2SelectData:(NSDictionary *)data{
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *imagUrl = [data objectForKey:@"picUrl"];
    
    if (imagUrl!=nil) {
        imagUrl = [NSString stringWithFormat:@"%@/%@",documentUrl,imagUrl];
    }else{
        imagUrl =nil;
    }
    NSString *price = [data objectForKey:@"price"];
    NSString *title = [NSString stringWithFormat:@"%@ %@",[data objectForKey:@"brandName"],[data objectForKey:@"modelName"]];
    
    car2Data = data;
    _car2ImgView.image = [UIImage imageWithContentsOfFile:imagUrl];
    if (price == nil ||[price isEqual:[NSNull null]]|| [price isEqualToString:@"<null>"]) {
        _car2Price.text = @"您可以添加对比车辆";
        _car2Price.textColor = [[UIColor alloc]initWithRed:83/255.0 green:83/255.0 blue:83/255.0 alpha:1.0];
    }else{
        _car2Price.text = [NSString stringWithFormat:@"价格：RMB %@起",price];
        _car2Price.textColor = [[UIColor alloc]initWithRed:171/255.0 green:21/255.0 blue:43/255.0 alpha:1.0];
    }
    [_compareCar2 setTitle:title forState:UIControlStateNormal];
    
}
-(void)loadModels:(NSDictionary *)data withIndex:(NSIndexPath *)indexPath withTableView:(UITableView *)tableView{
        NSArray *modelListArr = [CarCompare loadCarModelListFromCompare:[data objectForKey:@"brandId"]];
        LevelItem *firstitem = [levelMenuTableView.menuData.tableViewData objectAtIndex:indexPath.row];
        firstitem.subItems = [[NSMutableArray alloc]init];
        for (NSDictionary *obj in modelListArr) {
            if ([[data objectForKey:@"brandId"] isEqualToString:[obj objectForKey:@"brandId"]]) {
                NSDictionary *tempDic = obj;
                LevelItem *seconditem;
                seconditem = [[LevelItem alloc]init];
                seconditem.level = 1;
                seconditem.title =[tempDic objectForKey:@"modelName"];
                seconditem.paramDic = tempDic;
                [firstitem.subItems addObject:seconditem];
            }
        }
        [levelMenuTableView.menuData.tableViewData replaceObjectAtIndex:indexPath.row withObject:firstitem];
        MenuItemCell * cell;
        cell = (MenuItemCell *)[tableView cellForRowAtIndexPath:indexPath];
        NSArray * arr;
        arr = [levelMenuTableView.menuData insertMenuIndexPaths:cell.item];
        if ([arr count] >0) {
            [tableView insertRowsAtIndexPaths:arr withRowAnimation:UITableViewRowAnimationBottom];
        }
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
}
@end
