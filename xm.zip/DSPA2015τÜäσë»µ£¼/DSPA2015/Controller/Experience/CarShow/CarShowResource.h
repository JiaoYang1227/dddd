//
//  CarShowResource.h
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CarShowResource : NSObject
+ (CarShowResource *)sharedResource;
/**
 *获取车系列表
 **/
- (void)getBrandList:(void (^)(NSArray*brandList))completion;
/**
 * 根据车系ID，获取已经存在的车型信息的列表
 **/
- (NSArray*)getExistModelsWithBrandId:(NSString*)branchId;
-(NSArray*)getResoureces:(NSString*)folder;
-(NSDictionary*)getInnerResoureces:(NSString*)folder;
@end
