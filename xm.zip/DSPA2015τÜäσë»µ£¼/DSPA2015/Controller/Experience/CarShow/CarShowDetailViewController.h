//
//  CarShowDetailViewController.h
//  CarShow
//
//  Created by Jakey on 15/6/24.
//  Copyright © 2015年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HotspotItem.h"
#import <MediaPlayer/MediaPlayer.h>

@class AVPlayer;
@interface DSPAMediaPlayer : UIView
{
    UIButton    *buttonPlay_;
    NSURL       *videoUrl_;
}
@property (nonatomic, strong) AVPlayer * player;

- (void) setURL:(NSURL*)url;

- (void) play;
- (void) pause;
@end


@interface CarShowDetailViewController : UIViewController
{
    HotspotItem *_item;
    NSString *_baseDir;
    __weak IBOutlet UIScrollView *_scrollView;
    DSPAMediaPlayer *mediaPlayer_;
    __weak IBOutlet UIImageView *_bgImageView;
}
@property(nonatomic,strong) NSString *typeDir;;

-(void)setInnerPoint:(HotspotItem *)innerPoint withBaseDir:(NSString*)baseDir;
@property (weak, nonatomic) IBOutlet UITextView *detailView;
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
- (IBAction)closeTouched:(id)sender;

@end
