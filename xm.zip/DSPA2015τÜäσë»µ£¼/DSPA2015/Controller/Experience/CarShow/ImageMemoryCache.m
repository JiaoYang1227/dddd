//
//  ImageMemoryCache.m
//  DSPA2015
//
//  Created by runlin on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ImageMemoryCache.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonHMAC.h>

static ImageMemoryCache *instance = nil;
static dispatch_once_t onceToken;

@implementation ImageMemoryCache

+ (ImageMemoryCache *)sharedMemoryCache
{
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

- (id)init
{
    if ((self = [super init]))
    {
        _memoryCache = [[NSMutableDictionary alloc] init];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(clearMemory)
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
    }
    
    return self;
}

- (void)dealloc
{
    _memoryCache = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

/*
 *保存图片到内存上，不保存到物理存储上
 */
- (void)storeImage:(UIImage *)image forKey:(NSString *)key
{
    if (!image || !key)
    {
        return;
    }
    
    //缓存图片到内存上
    [_memoryCache setObject:image forKey:key];
}

/*
 *通过key返回指定图片
 */
- (UIImage *)imageFromKey:(NSString *)key
{
    if (key == nil)
    {
        return nil;
    }
    UIImage *image = [_memoryCache objectForKey:key];
    return image;
}


/*
 *从内存和物理存储上移除指定图片
 */
- (void)removeImageForKey:(NSString *)key
{
    if (key == nil)
    {
        return;
    }
    
    [_memoryCache removeObjectForKey:key];
}
/*
 *清除内存缓存区的图片
 */
- (void)clearMemory
{
    [_memoryCache removeAllObjects];
}


@end
