//
//  CarShowPlayer.m
//  DSPA2015
//
//  Created by runlin on 16/7/19.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "CarShowPlayer.h"

@implementation CarShowPlayer
+ (CarShowPlayer *)player
{
    static CarShowPlayer *player = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        player = [[CarShowPlayer alloc] init];
    });
    
    return player;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"carshow" ofType:@"mp3"]] error:nil];//使用本地URL创建
        self.player.numberOfLoops = -1;
        self.player.volume = 0;
        self.volume = self.player.volume;
    }
    return self;
}
-(void)play{
    self.player.volume = 1;
    [_player prepareToPlay];//分配播放所需的资源，并将其加入内部播放队列
    [_player play];//播放
}
-(void)stop{
    if ([_player isPlaying]) {
        [_player stop];
    }
}
-(BOOL)isPlay{
    return [_player isPlaying];
}
-(void)setVolume:(CGFloat)volume{
    _volume = volume;
    _player.volume = _volume;
}

@end
