//
//  CarShowPlayer.h
//  DSPA2015
//
//  Created by runlin on 16/7/19.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface CarShowPlayer : NSObject
@property(nonatomic,strong) AVAudioPlayer *player;
@property(nonatomic,assign) CGFloat volume;
@property(nonatomic,assign) BOOL isPlay;

+ (CarShowPlayer *)player;
-(void)play;
-(void)stop;

@end
