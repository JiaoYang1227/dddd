//
//  CarInnerShowViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/12.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "Car.h"
#import "FlashMenuButton.h"
#import "CarShowColorView.h"
#import "CarShowDetailViewController.h"
#import "ConfigurationSelector.h"
#import "HotspotList.h"

#import "JAPanoView.h"
#import "VolumeButton.h"
@interface CarInnerShowViewController : BaseViewController<JAPanoViewDelegate>
 
@property(strong,nonatomic)Car *car;
@property(strong,nonatomic) ModelDetail *modelDetail;

@property(strong,nonatomic) ConfigurationSelector *configurationSelector;

//@property (weak, nonatomic) IBOutlet PLView *showView;
@property (weak, nonatomic) IBOutlet JAPanoView *showView;
@property (weak, nonatomic) IBOutlet UIView *indicateView;

@property (weak, nonatomic) IBOutlet CarShowColorView *carShowColorView;
//@property (weak, nonatomic) IBOutlet UITableView *configurationTableView;
@property (weak, nonatomic) IBOutlet UICollectionView *modelGroupCollection;

@property (weak, nonatomic) IBOutlet FlashMenuButton *carOuterButton;
@property (weak, nonatomic) IBOutlet FlashMenuButton *carInnderButton;
@property (weak, nonatomic) IBOutlet FlashMenuButton *carComparisonButton;
- (IBAction)carOuterTouched:(id)sender;
- (IBAction)carInnerTouched:(id)sender;
- (IBAction)carComparisonTouched:(id)sender;

- (IBAction)showConfigButtonTouched:(id)sender;
- (IBAction)showLightTouched:(UIButton*)sender;


@property (weak, nonatomic) IBOutlet VolumeButton *volumeButton;

@property (weak, nonatomic) IBOutlet UIButton *hotspotButton; //亮点菜单按钮
@property (weak, nonatomic) IBOutlet UIButton *configButton;

- (IBAction)volumeButtonTouched:(id)sender;
- (IBAction)exportButtonTouched:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *exportButton;
@end
