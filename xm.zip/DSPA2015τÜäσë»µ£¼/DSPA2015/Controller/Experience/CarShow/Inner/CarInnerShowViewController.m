//
//  CarInnerShowViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/12.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarInnerShowViewController.h"
#import "FileManager.h"

#import "UIViewController+MJPopupViewController.h"
#import "FlashMenuButtonSubMenu.h"
#import "CarShowResource.h"
#import "CarcompareDetailViewController.h"

#import "ConfigurationCell.h"
#import "CarOuterShowViewController.h"
#import "ModelGroupCell.h"
#import "HotspotList.h"

#import "UIViewController+DSPAPopup.h"
#import "MBProgressHUD.h"

#import "OrderedDictionary.h"
#import "JKToast.h"


#import <Photos/Photos.h>
#define HOT_POINT_VIEDO_TYPE 0
#define HOT_POINT_PIC_TYPE 1
@interface CarInnerShowViewController ()
{
    int _currentConfigIndex;   //当前选中的选配菜单坐标
    ConfigurationMenu *_configurationMenu;
    MutableOrderedDictionary *_backUPConfigs;
    NSInteger _currentColorIndex;  //当前底图颜色
    //    PLCubicPanorama *_cubicPanorama;
    HotspotList *_hotspotList;
}
@end

@implementation CarInnerShowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    [self.carOuterButton setTitle:@"外 观"];
    [self.carOuterButton setChecked:NO];
    
    [self.carInnderButton setTitle:@"内 饰"];
    [self.carInnderButton setChecked:NO];

    
    [self.carComparisonButton setTitle:@"对 比"];
    [self.carComparisonButton setChecked:NO];

    self.showView.delegate = self;
//    self.showView.isAccelerometerEnabled = NO;
//    self.showView.isScrollingEnabled = YES;
//   self.showView.isInertiaEnabled = NO;

    self.title = @"车辆展厅内饰";
    _currentColorIndex = 0;
    _currentConfigIndex = -1;
    
#ifdef DEMO
    
#else
    self.volumeButton.hidden = YES;
#endif
}
-(void)leftPanelTouched:(id)sender{
    [self.showView forceStop];
    [super leftPanelTouched:sender];
}
-(void)backButtonTouched:(id)sender{
    [self.showView forceStop];
    [super backButtonTouched:sender];
}
-(void)backHomeButtonTouched:(id)sender{
    [self.showView forceStop];
    [super backHomeButtonTouched:sender];
    [[CarShowPlayer player] stop];

}
-(void)dealloc{
    [[CarShowPlayer player] stop];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [CBTracking startTracResource:self.car.name withModuleName:@"车辆展厅_内饰"];
    [CBTracking startTracPage:@"车辆展厅_内饰"];
    [self.carInnderButton setButtonSelected:YES animated:YES];
    [self initData];

    if ([CarShowPlayer player].isPlay) {
        self.volumeButton.selected = YES;
        [[CarShowPlayer player] play];
    }else{
        self.volumeButton.selected = NO;
        [[CarShowPlayer player] stop];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracResource:self.car.name withModuleName:@"车辆展厅_内饰"];
    [CBTracking endTracPage:@"车辆展厅_内饰"];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

}
-(void)initData{
    //根据goup id 反显
    NSInteger index = 0;
//    for (Folder *f in self.car.modelGroup.items) {
//        if ([f.key isEqualToString:self.modelGroupKey]) {
//            index = [self.car.modelGroup.items indexOfObject:f];
//        }
//    }
    for (int i=0; i<[self.car.models count]; i++) {
        ModelDetail *detail = [self.car.models objectWithIndex:i];
        if ([detail.key isEqualToString:self.modelDetail.key]) {
            index = i;
        }
    }
    
    [self collectionView:self.modelGroupCollection didSelectItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    [self.modelGroupCollection selectItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] animated:YES scrollPosition:UICollectionViewScrollPositionNone];
}

//根据当前型号分组
-(void)filterWithModelGroupItem:(ModelDetail*)modelDetail{
    self.modelDetail = modelDetail;
//插入内饰颜色为选配
    
//    NSMutableArray *configurations = [self.modelDetail.interiorConfigurations mutableCopy]?:[@[]mutableCopy];
//    BOOL haveAppearances = NO;
//    for (Configuration *config in self.modelDetail.interiorConfigurations) {
//        if ([config.key isEqualToString:@"interiors"]) {
//            haveAppearances = YES;
//        }
//    }
//    if (!haveAppearances && self.modelDetail.interiors) {
//        self.modelDetail.interiors.key  =@"interiors";
//        [configurations insertObject:self.modelDetail.interiors atIndex:0];
//        self.modelDetail.interiorConfigurations = [configurations copy];
//    }
    //选配弹出框隐藏
    [self.configurationSelector show:NO animate:YES completion:^{
        
    }];
    _currentConfigIndex = -1;

//    [self.configurationTableView reloadData];
    _configurationMenu.items =  self.modelDetail.interiorConfigurations;
    //清空所有旧选配
    [_backUPConfigs removeAllObjects];
    //选择所有第一个选配并且合并
    [self selectedAllConfigrationFirst];

}
//选择所有第一个选配并且合并
-(void)selectedAllConfigrationFirst{

    for (Configuration *config in self.modelDetail.interiorConfigurations) {
        if(![config.key isEqualToString:@"modelGroup"])
        {
            if ([config.key isEqualToString:@"interiors"])
            {
                config.baseDir = @"interiors";
            }else
            {
                //过滤除车身颜色的选配
                config.baseDir = @"interiorConfigurations";
                Folder *item = [config.items firstObject];
                if (item) {
                    [self addConfiguration:config item:item];
                }
            }
        }
    }
    //选中内饰颜色第一个
    
    _currentColorIndex = 0;

    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(apply) object:nil];
    [self performSelector:@selector(apply) withObject:nil];
}
//合并内饰720选配为一张图
-(void)loadMerge720:(Folder*)oneInnerShow{
    [MBProgressHUD showHUDAddedTo:self.indicateView animated:YES];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        clock_t start = clock();
        NSMutableDictionary *resultCombine = [NSMutableDictionary dictionary];
        NSMutableDictionary *allImagesForDirection = [self readAllImagesForDirection];
        
        NSDictionary *bodyImages = [[CarShowResource sharedResource]getInnerResoureces:[oneInnerShow.baseDir stringByAppendingPathComponent:oneInnerShow.folder]];
        
        NSArray *keys =  @[@"front",@"back",@"left",@"right",@"up",@"down"];
        
        for (NSString *key in keys){
            NSString *bodyName = [bodyImages objectForKey:key];
            NSArray *imagesInOneDirection = [allImagesForDirection objectForKey:key];
            
            UIImage *bodyImageOneDirection;
            
            if (![resultCombine objectForKey:key])
            {
                bodyImageOneDirection = [UIImage imageWithContentsOfFile:bodyName];
                [resultCombine setObject:bodyImageOneDirection?:[[UIImage alloc]init] forKey:key];
            }else
            {
                bodyImageOneDirection= [resultCombine objectForKey:key];
            }
            
            bodyImageOneDirection =  [self mergedMainImage:bodyImageOneDirection imageArray:imagesInOneDirection];
            if (bodyImageOneDirection)
            {
                [resultCombine setObject:bodyImageOneDirection forKey:key];
            }
        }
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            double executionTime = (double)(clock()-start) / CLOCKS_PER_SEC;
            NSLog(@"duration -> %.3lf", executionTime);
            [MBProgressHUD  hideAllHUDsForView:self.indicateView animated:YES];
            UIImage *frontimage =  [resultCombine objectForKey:@"front"];
            UIImage *backimage =  [resultCombine objectForKey:@"back"];
            UIImage *leftimage =  [resultCombine objectForKey:@"left"];
            UIImage *rightimage =  [resultCombine objectForKey:@"right"];
            UIImage *upimage =  [resultCombine objectForKey:@"up"];
            UIImage *downimage =  [resultCombine objectForKey:@"down"];
            
            [self.showView setFrontImage:frontimage
                              rightImage:rightimage
                               backImage:backimage
                               leftImage:leftimage
                                topImage:upimage
                             bottomImage:downimage];
            
            self.showView.zoomFactor = 1.3;
            self.showView.minZoomFactor = 1.3;
        });
        
    });
}

//-(void)loadMerge720:(Folder*)oneInnerShow{
//    [MBProgressHUD showHUDAddedTo:self.indicateView animated:YES];
//    NSMutableDictionary *resultCombine = [NSMutableDictionary dictionary];
//    NSMutableDictionary *allImagesForDirection = [self readAllImagesForDirection];
//    NSDictionary *bodyImages = [[CarShowResource sharedResource]getInnerResoureces:[oneInnerShow.baseDir stringByAppendingPathComponent:oneInnerShow.folder]];
//
//    clock_t start = clock();
//
//    dispatch_queue_t concurrentQueue = dispatch_queue_create("com.runlin.carshow.concurrentqueue",DISPATCH_QUEUE_CONCURRENT);
//    dispatch_group_t group = dispatch_group_create();
//    //
//    NSArray *keys =  @[@"front",@"back",@"left",@"right",@"up",@"down"];
//    for (NSString *key in keys){
//        dispatch_group_async(group, concurrentQueue, ^{
//
//            NSString *bodyName = [bodyImages objectForKey:key];
//            NSArray *imagesInOneDirection = [allImagesForDirection objectForKey:key];
//
//            UIImage *bodyImageOneDirection;
//
//            if (![resultCombine objectForKey:key])
//            {
//                bodyImageOneDirection = [UIImage imageWithContentsOfFile:bodyName];
//                [resultCombine setObject:bodyImageOneDirection?:[[UIImage alloc]init] forKey:key];
//            }else
//            {
//                bodyImageOneDirection= [resultCombine objectForKey:key];
//            }
//
//            bodyImageOneDirection =  [self mergedMainImage:bodyImageOneDirection imageArray:imagesInOneDirection];
//            if (bodyImageOneDirection)
//            {
//                [resultCombine setObject:bodyImageOneDirection forKey:key];
//            }
//            NSLog(@"%@",key);
//        });
//    }
//    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
//        double executionTime = (double)(clock()-start) / CLOCKS_PER_SEC;
//        NSLog(@"duration -> %.3lf", executionTime);
//        NSLog(@"currentThread ->%@", [NSThread currentThread]);
//
//        [MBProgressHUD  hideAllHUDsForView:self.indicateView animated:YES];
//        UIImage *frontimage =  [resultCombine objectForKey:@"front"];
//        UIImage *backimage =  [resultCombine objectForKey:@"back"];
//        UIImage *leftimage =  [resultCombine objectForKey:@"left"];
//        UIImage *rightimage =  [resultCombine objectForKey:@"right"];
//        UIImage *upimage =  [resultCombine objectForKey:@"up"];
//        UIImage *downimage =  [resultCombine objectForKey:@"down"];
//
//        [self.showView setFrontImage:frontimage
//                          rightImage:rightimage
//                           backImage:backimage
//                           leftImage:leftimage
//                            topImage:upimage
//                         bottomImage:downimage];
//
//        self.showView.zoomFactor = 1.3;
//        self.showView.minZoomFactor = 1.3;
//        NSLog(@"end");
//    });
//
//}
//返回每个方向上的所有图片
-(NSMutableDictionary*)readAllImagesForDirection{
    NSMutableDictionary *resultSixDirection = [NSMutableDictionary dictionary];
    NSArray *directionKeys =  @[@"front",@"back",@"left",@"right",@"up",@"down"];
    for (NSString *directionKey in directionKeys)
    {
        //plist文件中没有配置显示层级。。醉了
        NSMutableArray *imagesInOneDirection = [NSMutableArray array];
        for (Folder *config in [_backUPConfigs allValues])
        {
            //排除座椅与方向盘
            if([config.baseDir rangeOfString:@"seat"].location ==NSNotFound
               && [config.baseDir rangeOfString:@"SteeringWheel"].location ==NSNotFound
               && [config.baseDir rangeOfString:@"touzhen"].location ==NSNotFound
               && [config.baseDir rangeOfString:@"houpaizuoyimianban"].location ==NSNotFound
               && [config.baseDir rangeOfString:@"a8_metal_decoration_bar"].location ==NSNotFound
               && [config.baseDir rangeOfString:@"fanban"].location ==NSNotFound
               && [config.baseDir rangeOfString:@"a8_"].location ==NSNotFound
               && [config.baseDir rangeOfString:@"neishitiaoquanbu"].location ==NSNotFound
                && [config.baseDir rangeOfString:@"haohuajiyikongzhikaiguan"].location ==NSNotFound){
                
                
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
            }
        }
        //单独增加座椅 人为干预z轴位置
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"seat"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //单独增加翻板
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"fanban"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //单独增加头枕 人为干预z轴位置
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"touzhen"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //a8的内饰条比较特殊 要在座椅上边，后排座椅面板下。 a8座椅比较特殊带内饰条，所以不同形状座椅要对应不同的内饰条
        //人为干预z轴位置
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"a8_metal_decoration_bar"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //后排座椅面板 人为干预z轴位置
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"houpaizuoyimianban"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //单独增加方向盘
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"SteeringWheel"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //整体大内饰条放在顶部 neishitiaoquanbu
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"neishitiaoquanbu"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //q5 的记忆控制开关
        for (Folder *config in [_backUPConfigs allValues])
        {
            if([config.baseDir rangeOfString:@"haohuajiyikongzhikaiguan"].location !=NSNotFound){
                NSDictionary *configImages = [[CarShowResource sharedResource]getInnerResoureces:[config.baseDir stringByAppendingPathComponent:config.folder]];
                if ([configImages hasKey:directionKey]) {
                    [imagesInOneDirection addObject:[configImages objectForKey:directionKey]];
                }
                
            }
        }
        //每个方向上所有的图
        if (imagesInOneDirection) {
            [resultSixDirection setObject:imagesInOneDirection forKey:directionKey];
        }
    }
    return resultSixDirection;
}

- (UIImage*)jk_mergeImage:(UIImage*)firstImage withImage:(UIImage*)secondImage {
    CGImageRef firstImageRef = firstImage.CGImage;
    CGFloat firstWidth = CGImageGetWidth(firstImageRef);
    CGFloat firstHeight = CGImageGetHeight(firstImageRef);
//    CGImageRef secondImageRef = secondImage.CGImage;
//    CGFloat secondWidth = CGImageGetWidth(secondImageRef);
//    CGFloat secondHeight = CGImageGetHeight(secondImageRef);
    CGFloat secondWidth = firstWidth;
    CGFloat secondHeight = firstHeight;
    CGSize mergedSize = CGSizeMake(MAX(firstWidth, secondWidth), MAX(firstHeight, secondHeight));
    UIGraphicsBeginImageContext(mergedSize);
    [firstImage drawInRect:CGRectMake(0, 0, firstWidth, firstHeight)];
    [secondImage drawInRect:CGRectMake(0, 0, secondWidth, secondHeight)];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}
- (UIImage*)mergedMainImage:(UIImage *)mainImage
                 imageArray:(NSArray *)imageArray
{
    
    UIGraphicsBeginImageContext(mainImage.size);
    [mainImage drawInRect:CGRectMake(0, 0, mainImage.size.width, mainImage.size.height)];
    for (int i=0;i<[imageArray count];i++) {
        UIImage *image =[UIImage imageWithContentsOfFile:[imageArray objectWithIndex:i]];
        [image drawInRect:CGRectMake(0,0, mainImage.size.width, mainImage.size.height)];
    }
    
    CGImageRef mergeImageRef = CGImageCreateWithImageInRect(UIGraphicsGetImageFromCurrentImageContext().CGImage,
                                                          CGRectMake(0, 0, mainImage.size.width, mainImage.size.height));
    
    UIGraphicsEndImageContext();
    UIImage *result = [UIImage imageWithCGImage:mergeImageRef];
    CGImageRelease(mergeImageRef);
    return result;

}


#pragma mark -- delegate
-(void)dismissWhenTouched{
    [_configurationSelector removeFromSuperview];
    [_configurationMenu show:NO animate:YES];
    [_hotspotList show:NO animate:YES];
    self.hotspotButton.selected = NO;
    self.configButton.selected = NO;
    [self.volumeButton hiddenSlider];
}
-(void)panoViewWillBeginTouched:(JAPanoView *)panoView{
    [self dismissWhenTouched];
}

//-(void)view:(UIView<PLIView> *)pView touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    [_configurationSelector removeFromSuperview];
//    [_hotspotList show:NO animate:YES];
//
//}
//
//-(void)view:(UIView<PLIView> *)pView didClickHotspot:(PLHotspot *)hotspot screenPoint:(CGPoint)point scene3DPoint:(PLPosition)position
//{
//    HotspotItem *innerPoint =[self.car.hotspots.inner objectWithIndex:(int)hotspot.identifier];
// 
//    CarShowDetailViewController *detail = [[CarShowDetailViewController alloc]init];
//    detail.typeDir = @"inner";
//    [detail setInnerPoint:innerPoint withBaseDir:self.car.baseDir];
//    [self presentPopupViewController:detail animationType:MJPopupViewAnimationSlideBottomTop];
//}


- (IBAction)carOuterTouched:(FlashMenuButton*)sender {
    CarOuterShowViewController *outter = [self.tabBarController.viewControllers objectAtIndex:0];
    outter.modelDetail = [self.modelDetail copy];
    
    self.tabBarController.selectedIndex = 0;
}

- (IBAction)carInnerTouched:(FlashMenuButton*)sender {
    [CBTracking trackEvent:@"车辆展厅_内饰"];
    [sender setButtonSelected:YES animated:YES];
}


#pragma -mark TableView Delegate


-(void)configMenuSelect:(ConfigurationCell *)cell index:(NSInteger)index{
    Configuration *config= [self.modelDetail.interiorConfigurations objectWithIndex:index];
    config.baseDir = @"interiorConfigurations";
    
    if (_currentConfigIndex>=0 && self.configurationSelector && _currentConfigIndex == index) {
        [self.configurationSelector show:NO animate:YES completion:^{
            
        }];
        _currentConfigIndex = -1;
        return;
    }
    _currentConfigIndex = (int)index;
    [self.configurationSelector removeFromSuperview];
    
    CGRect cellFrame = [cell.superview convertRect:cell.frame toView:self.view];
    self.configurationSelector = [ConfigurationSelector selector];
    CGRect frame =CGRectMake(cellFrame.origin.x, cellFrame.origin.y-2, 0, self.configurationSelector.frame.size.height);
    self.configurationSelector.frame = frame;
    //根据_modelGroupKey 筛选匹配的选配列表
    self.configurationSelector.items = config.items;

    
    [self.configurationSelector titleForConfigurationSelectorItem:^NSString *(ConfigurationSelectorCell *cell, NSInteger index, Folder *item) {
        return item.name;
    }];
    [self.configurationSelector imageForConfigurationSelectorItem:^NSString *(ConfigurationSelectorCell *cell, NSInteger index, Folder *item) {
        if([config.key isEqualToString:@"interiors"])
        {
            item.baseDir =  [self.car.baseDir  stringByAppendingPathComponent:@"interiors"];
        }else{
            NSString *path = [NSString pathWithComponents:@[self.car.baseDir?:@"",config.baseDir?:@"",config.folder?:@""]];
            item.baseDir =  path;
        }
        return [item.baseDir stringByAppendingPathComponent:item.icon];
    }];
    [self.configurationSelector didSelectConfigurationSelectorItem:^(ConfigurationSelectorCell *cell, NSInteger index, Folder *item) {
        [self.configurationSelector show:NO animate:YES completion:^{
            self.hotspotButton.selected = NO;
            
            _currentConfigIndex = -1;
            
            if ([config.key isEqualToString:@"interiors"]) {
                _currentColorIndex = index;
                item.baseDir =  [self.car.baseDir stringByAppendingPathComponent:@"interiors"];
                [self apply];
            }else{
                [self addConfiguration:config item:item];
                [self apply];
            }
        }];
      
    }];
    
    [self.view insertSubview:self.configurationSelector belowSubview:_configurationMenu];
    
    [self.configurationSelector show:YES animate:YES completion:^{
        
    }];

}
//增加选配
-(void)addConfiguration:(Configuration*)config item:(Folder*)item{
    NSString *path = [NSString pathWithComponents:@[self.car.baseDir?:@"",config.baseDir?:@"",config.folder?:@""]];
    item.baseDir =  path;
    //备份不同类型的选配 用于拼图
    if (!_backUPConfigs) {
        _backUPConfigs = [MutableOrderedDictionary dictionary];
    }
    //选配item中保留选配信息
    item.config = [config copy];
    // 座椅 a8内饰条 用key区分不同类型
    if(config.key.length>0 &&( [config.key isEqualToString:@"seat"]||  [config.folder isEqualToString:@"a8_metal_decoration_bar"])){
        [_backUPConfigs setObject:[item copy] forKey:config.key?:config.folder];
    }else{
        [_backUPConfigs setObject:[item copy] forKey:config.folder];
    }
    
    //a3的天窗要与顶棚要互斥，哎。。。
    for(NSString *c in [_backUPConfigs allKeys]){
        if ([config.name isEqualToString:@"顶棚"] && [c isEqualToString:@"a3tianchuang"]) {
            [_backUPConfigs removeObjectForKey:c];
        }
    }
}
//a8   独立座椅 联动 面板和内饰条后部
-(void)filterBackUPConfigsIfNeedA8{
    BOOL wuDulizuoyin = YES;
    for (Folder *folder in [_backUPConfigs allValues]) {
        if ([folder.config.key isEqualToString:@"dulizuoyi"] && [folder.key isEqualToString:@"youdulizuoyi"]) {
            wuDulizuoyin = NO;
        }
        
    }
    if (wuDulizuoyin) {
        for (Folder *folder in [_backUPConfigs allValues]) {
            //            Folder *folder = [_backUPConfigs valueForKey:configKey];
            NSString *configKey =   (folder.config.key.length>0?folder.config.key:folder.config.folder);
            if ([configKey isEqualToString:@"houpaizuoyimianban"] || [configKey isEqualToString:@"neishitiaohoubu"]) {
                [_backUPConfigs removeObjectForKey:configKey];
            }
            
        }
        
    }
}
-(void)apply{
    Folder *oneInnerShow = [self.modelDetail.interiors.items objectWithIndex:_currentColorIndex];
    oneInnerShow.baseDir =  [self.car.baseDir stringByAppendingPathComponent:@"interiors"];
    [self filterBackUPConfigsIfNeedA8];
    [self loadMerge720:oneInnerShow];
}
- (IBAction)showConfigButtonTouched:(UIButton*)sender {
    [self.configurationSelector show:NO animate:NO completion:^{
        
    }];
    _currentConfigIndex = -1;

    sender.selected = !sender.selected;
    if(sender.selected)
    {
        _configurationMenu = [ConfigurationMenu menu];
        _configurationMenu.backgroundColor = [UIColor clearColor];
        CGRect frame = _configurationMenu.frame;
        frame.origin.x =CGRectGetMaxX(self.view.frame);
        frame.origin.y =70;
        frame.size.width =0;
        _configurationMenu.frame = frame;
        _configurationMenu.items = self.modelDetail.interiorConfigurations;
        
        [_configurationMenu didSelectConfigurationMenuItem:^(ConfigurationCell *cell, NSInteger index, id item) {
            [self configMenuSelect:cell index:index];
        }];
        [_configurationMenu titleForConfigurationMenuItem:^NSString *(ConfigurationCell *cell, NSInteger index, Configuration *item) {
            Configuration *config = [self.modelDetail.interiorConfigurations objectWithIndex:index];
            config.baseDir = @"interiorConfigurations";
            [cell configCell:config];
            return item.name;
            
        }];
        [_configurationMenu imageForConfigurationMenuItem:^NSString *(ConfigurationCell *cell, NSInteger index, Configuration *config) {
            NSString *path;
            if ([config.key isEqualToString:@"interiors"]) {
                path = [NSString pathWithComponents:@[self.car.baseDir?:@"",config.icon?:@""]];
            }else{
                path = [NSString pathWithComponents:@[self.car.baseDir?:@"",config.baseDir?:@"",config.icon?:@""]];
            }
            return path;
        }];
        
        [self.view insertSubview:_configurationMenu belowSubview:sender];
        [_configurationMenu show:YES animate:YES];
        
    }else{
        [_configurationMenu show:NO animate:YES];
        
    }

    
}

- (IBAction)showLightTouched:(UIButton*)sender {
    sender.selected = !sender.selected;
    if(sender.selected){
        _hotspotList = [HotspotList hotspotList];
        CGRect frame = _hotspotList.frame;
        frame.origin.x =0;
        frame.origin.y =70;
        frame.size.width =0;
        _hotspotList.frame = frame;
        [self.view insertSubview:_hotspotList belowSubview:sender];
        
        [_hotspotList show:YES animate:YES];
        [self.volumeButton moveRight:_hotspotList.size.width];

        _hotspotList.items = self.car.hotspots.inner;
        [_hotspotList titleForHotspotListItem:^NSString *(UITableViewCell *cell, NSInteger index, HotspotItem *item) {
            return item.title;
        }];
        [_hotspotList didSelectHotspotListItem:^(UITableViewCell *cell, NSInteger index, id item) {
            CarShowDetailViewController *detail = [[CarShowDetailViewController alloc]init];
            [detail setInnerPoint:item withBaseDir:self.car.baseDir];
            detail.typeDir = @"inner";
            [self presentDSPAPopup:detail parentViewController:self touchCallBack:^{
                [detail dismissDSPAPopup:nil];
            } haveMask:YES includeNavgation:YES alignTop:NO];
        }];
    }else{
        [self.volumeButton moveRight:-_hotspotList.size.width];
        [_hotspotList show:NO animate:YES];
        
    }
    
}
- (IBAction)carComparisonTouched:(FlashMenuButton*)sender{
//    self.tabBarController.selectedIndex = 2;
    CarcompareDetailViewController *carcompareVC = [[CarcompareDetailViewController alloc]init];
    carcompareVC.isFromCarShow = YES;
    self.car.modelKey = self.modelDetail.key;
    carcompareVC.modelInfo = self.car;

    [self.navigationController pushViewController:carcompareVC animated:YES];
}

#pragma mark -
#pragma mark Collection view data source  Model Group Select
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.car.models count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"ModelGroupCell";
    [collectionView registerNib:[UINib nibWithNibName:CellIdentifier bundle:nil] forCellWithReuseIdentifier:CellIdentifier];
    ModelGroupCell *cell = (ModelGroupCell *)[collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    ModelDetail *item = [self.car.models objectWithIndex:indexPath.row];
    [cell configCell:item];
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //过滤对应分组的选配
    ModelDetail *item = [self.car.models objectWithIndex:indexPath.row];
    [self filterWithModelGroupItem:item];

}
- (IBAction)volumeButtonTouched:(VolumeButton*)sender {
    sender.selected = !sender.selected;
 
    if (sender.selected) {
        [[CarShowPlayer player] play];
    }else{
        [[CarShowPlayer player] stop];
    }
}
#pragma --mark 导出资源到相册
- (IBAction)exportButtonTouched:(id)sender {
    NSDictionary *images =    self.showView.images;
    
    @autoreleasepool {
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            //写入图片到相册
            for (int i=0; i<[images.allValues count]; i++) {
                UIImage *image = [images.allValues objectAtIndex:i];
                NSData *imageData = UIImagePNGRepresentation(image);

                PHAssetResourceCreationOptions *options = [[PHAssetResourceCreationOptions alloc] init];
                [[PHAssetCreationRequest creationRequestForAsset] addResourceWithType:PHAssetResourceTypePhoto data:imageData options:options];
                
//                [PHAssetChangeRequest creationRequestForAssetFromImage:image];
            }
        } completionHandler:^(BOOL success, NSError * _Nullable error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if(!success){
                    [JKToast toastWithText:@"保存失败" bottomOffset:200];
                }else{
                    [JKToast toastWithText:@"保存成功" bottomOffset:200];
                }
            });
            
        }];
    }
    
    
  
}


@end
