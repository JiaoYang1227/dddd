//
//  CarShowViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "ModelDisplayView.h"
@interface CarShowViewController : BaseViewController
{
    NSArray *_brandList;
    NSMutableArray *_allFlashButtons;
}
@property (nonatomic,assign)CGFloat totolDegrees;
@property (nonatomic,assign)CGFloat totolArc;
@property (weak, nonatomic) IBOutlet UIImageView *circleImageView;
@property (weak, nonatomic) IBOutlet ModelDisplayView *modelDisplayView;
@end
