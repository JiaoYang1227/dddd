//
//  ImageMemoryCache.h
//  DSPA2015
//
//  Created by runlin on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageMemoryCache : UILabel
{
    NSMutableDictionary *_memoryCache;
}
+ (ImageMemoryCache *)sharedMemoryCache;

- (void)storeImage:(UIImage *)image forKey:(NSString *)key;
/*
 *通过key返回指定图片
 */
- (UIImage *)imageFromKey:(NSString *)key;
/*
 *从内存和物理存储上移除指定图片
 */
- (void)removeImageForKey:(NSString *)key;
/*
 *清除内存缓存区的图片
 */
- (void)clearMemory;
@end
