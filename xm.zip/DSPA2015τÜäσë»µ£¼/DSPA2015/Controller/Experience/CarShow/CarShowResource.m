//
//  CarShowResource.m
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarShowResource.h"
#import "Car.h"
#import "APIManager.h"
#import "FileManager.h"
#import "NSString+DictionaryValue.h"
#import "CarBrandInfo.h"
#define DOCUMENT_BRNAD_JSON_NAME  @"brands.json" //documents/model/brands.json
#define APP_BRNAD_JSON_NAME  @"carshowBrands.json"

@implementation CarShowResource
+ (CarShowResource *)sharedResource
{
    static CarShowResource *carShowResource = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        carShowResource = [[CarShowResource alloc] init];
    });
    
    return carShowResource;
}
/**
 *获取车系列表
 **/
- (void)getBrandList:(void (^)(NSArray*))completion{
//    NSDictionary *result =   [[APIManager sharedClient]sendSynchRequest:INTERFACE_OFFLINE_BRAND_LIST_URI parameters:nil];
    //读取缓存的车系
//    if ([[FileManager sharedManager] fileExistsAtPath:[self getBaseDir:DOCUMENT_BRNAD_JSON_NAME]] && [FileManager loadJSON:[self getBaseDir:DOCUMENT_BRNAD_JSON_NAME]]) {
//        completion([self loadBrandList:[FileManager loadJSON:[self getBaseDir:DOCUMENT_BRNAD_JSON_NAME]]]);
//        return;
//    }
//    [[APIManager sharedClient]POST:INTERFACE_OFFLINE_BRAND_LIST_URI parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
//        NSDictionary *result = responseObject;
//        //缓存到本地
//        if (result && [result arrayForKey:KEY_RESULT] && [[result arrayForKey:KEY_RESULT] count]>0) {
//            //创建model文件夹
//            [[FileManager sharedManager] createDirectoryAtPath:[self basePath]];
//            [FileManager writeToJSON:result path:[self getBaseDir:DOCUMENT_BRNAD_JSON_NAME]];
//            completion([self loadBrandList:result]);
//        }
//        //读取app死的车系
//        if ((![result arrayForKey:KEY_RESULT] || [[result arrayForKey:KEY_RESULT] count]<=0)) {
//            NSString *appBrandPath = [[NSBundle mainBundle] pathForResource:APP_BRNAD_JSON_NAME ofType:nil];
//            completion([self loadBrandList:[FileManager loadJSON:appBrandPath]]);
//        }
//
//    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
//       NSString *appBrandPath = [[NSBundle mainBundle] pathForResource:APP_BRNAD_JSON_NAME ofType:nil];
//        completion([self loadBrandList:[FileManager loadJSON:appBrandPath]]);
//    }];
    
    NSString *appBrandPath = [[NSBundle mainBundle] pathForResource:APP_BRNAD_JSON_NAME ofType:nil];
    completion([self loadBrandList:[FileManager loadJSON:appBrandPath]]);
   
}
-(NSArray*)loadBrandList:(NSDictionary*)serverResult{
    NSArray *branchArrayDic = [serverResult arrayForKey:KEY_RESULT];
    
    NSMutableArray *branchInfoList = [NSMutableArray array];
    [branchArrayDic enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSMutableDictionary *jsonDict = (NSMutableDictionary *)obj;
        //加载所有车型 插入数据库 缓存
        CarBrandInfo *item = [CarBrandInfo objectFromDictionary:jsonDict];
        

        [branchInfoList addObject:item];
        
    }];
    return branchInfoList;
}
/**
 *  @author Jakey, 15-11-17 13:11:31
 *
 *  @brief  根据车系id 获取存在的车型列表
 *
 *  @param branchId 车系id
 *
 *  @return 车型列表
 */
- (NSArray*)getExistModelsWithBrandId:(NSString*)branchId{
//    NSString *brandDir = [[self basePath:branchId] stringByAppendingString:branchId];
//       NSArray *brandsModels = [self getModelListFromServerByBranchId:branchId];
    
//        NSArray *dirList = [[NSFileManager defaultManager] subpathsAtPath:[self basePath]];
        NSArray *dirList = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[self basePath] error:nil];
    
        NSMutableArray *modelArray = [NSMutableArray array];
        for (NSString *string in dirList)
        {
            if (![string isEqualToString:@".DS_Store"] && ![string hasPrefix:@"."])
            {
                NSString *modleFileDirPath = [self basePath:string];
                //丫的 解压为嘛有时候两层有时候一层
                
//                modleFileDirPath = [modleFilePath stringByAppendingPathComponent:string];
                if ([[FileManager sharedManager] fileExistsAtPath:modleFileDirPath])
                {
                    NSError *error;
                    NSArray *fileList  =[[[NSFileManager defaultManager] contentsOfDirectoryAtPath:modleFileDirPath error:&error] pathsMatchingExtensions:@[@"plist",@"PLIST"]];
                    
                    NSString *plistName = [fileList firstObject];
                    for (NSString *plist in fileList) {
                        if (![plist isEqualToString:@".DS_Store"] && ![plist hasPrefix:@"."]){
                            plistName = plist;
                        }
                        
                    }

                    NSString *modelPlistPath = [modleFileDirPath stringByAppendingPathComponent:plistName?:[NSString stringWithFormat:@"%@.plist",string]];
                    NSDictionary *modelInfoDic = [FileManager loadPlist:modelPlistPath];
                    
                    
                    if ([[modelInfoDic stringForKey:@"key"] isEqualToString:branchId])
                    {
                        Car *model = [Car objectFromDictionary:modelInfoDic];
                        model.baseDir = modleFileDirPath;
                        [modelArray addObject:model];

                    }
                }
            }
        }
    
    //过滤存在的车系
    //model/062DCA3D-A36E-42F4-856B-135AE89457C4/062DCA3D-A36E-42F4-856B-135AE89457C4/model.json
//
//    NSMutableArray *modelArray = [[NSMutableArray alloc] init];
//    for (NSDictionary *modelDic in brandsModels) {
//        //zip 包 解压后有两层目录 醉了
//        NSString *modleFilePath = [self basePath:[modelDic stringForKey:@"modelId"]];
//        NSString *modleFileDirPath = [modleFilePath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", [modelDic stringForKey:@"modelId"]]];
//        
//        if (![[FileManager sharedManager] fileExistsAtPath:modleFileDirPath]) {
//            continue;
//        }
//        
////
//        NSString *modelJSONPath = [modleFileDirPath stringByAppendingPathComponent:@"model.json"];
//        NSDictionary *modelInfoDic = [FileManager loadJSON:modelJSONPath];
//        ModelInfo *model = [ModelInfo objectFromDictionary:modelInfoDic];
//        model.basePath = modleFileDirPath;
//        [modelArray addObject:model];
//    }
//
    return modelArray;
}
/**
 *  @author Jakey, 15-11-17 13:11:05
 *
 *  @brief  从服务器获取车系下所有车型
 *
 *  @param branchId 车系id
 *
 *  @return 车型列表
 */
- (NSArray *)getModelListFromServerByBranchId:(NSString *)branchId
{
    NSMutableDictionary *parmDic = [NSMutableDictionary dictionary];
    [parmDic setValue:branchId forKey:@"brandId"];
    NSDictionary *result =   [[APIManager sharedClient]sendSynchRequest:INTERFACE_OFFLINE_MODEL_LIST_URI parameters:parmDic];
    
    return  [result arrayForKey:@"result"];;
}

-(NSArray*)getResoureces:(NSString*)folder{
    NSString *bodyPath = folder;
    NSError *error;
    
    NSArray *fileList  =[[[NSFileManager defaultManager] contentsOfDirectoryAtPath:bodyPath error:&error] pathsMatchingExtensions:@[@"png",@"jpg",@"bmp",@"jpeg",@"gif"]];
    
    NSMutableArray *dirArray = [NSMutableArray array];
    for (NSString *file in fileList) {
        if (![file isEqualToString:@".DS_Store"] && ![file hasPrefix:@"."])
        {
            NSString *path = [bodyPath stringByAppendingPathComponent:file];
            [dirArray addObject:path];
        }
        
    }
    
    NSArray *sortedArray = [dirArray sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2){
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
    
    return sortedArray;
    
}
-(NSDictionary*)getInnerResoureces:(NSString*)folder{
    NSString *bodyPath = folder;
    NSError *error;
    
    NSArray *fileList  =[[[NSFileManager defaultManager] contentsOfDirectoryAtPath:bodyPath error:&error] pathsMatchingExtensions:@[@"png",@"jpg",@"bmp",@"jpeg",@"gif"]];
    
    NSMutableDictionary *dicts = [NSMutableDictionary dictionary];
    for (NSString *file in fileList) {
        if (![file isEqualToString:@".DS_Store"] && ![file hasPrefix:@"."])
        {
            NSString *path = [bodyPath stringByAppendingPathComponent:file];
            [dicts setObject:path forKey:[file stringByDeletingPathExtension]];
        }
        
    }
    return dicts;
    
}
#pragma --commom helper method
-(NSString*)getBaseDir:(NSString*)key{
    return [self basePath:key];
}
//#warning  升级数据结构后 要更换文件夹 删除老的文件夹
- (NSString *)basePath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return [[paths objectAtIndex:0] stringByAppendingString:@"/model"];
}
-(NSString *)basePath:(NSString *)fileName{
    return [[self  basePath] stringByAppendingPathComponent:fileName];
}
//document文件的路径
+(NSString *)basePath:(NSString *)fileName {
    return [[self sharedResource] basePath:fileName];
}
@end
