//
//  CarOuterPointViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarOuterPointViewController.h"
#import "CarShowPoint.h"
#import "CarShowResource.h"
#import "CarShowDetailViewController.h"
#import "UIViewController+MJPopupViewController.h"
#import "OuterHotspotButton.h"
#define BUTTON_HOTPOINT_UNSELECT    @"carshow_button_hotpoint_unselect.png"
#define BUTTON_HOTPOINT_SELECTED    @"carshow_button_hotpoint_selected.png"
#define HOT_POINT_VIEDO_TYPE 0
#define HOT_POINT_PIC_TYPE 1
@interface CarOuterPointViewController ()

@end

@implementation CarOuterPointViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.showView.userInteractionEnabled = YES;
    self.title = @"车辆展厅外饰亮点";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [TalkingData trackPageEnd:self.title];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [TalkingData trackPageBegin:self.title];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)setShow:(CarOuterShow *)show{
    _show = show;
    [self updateHighLightViewWithAngle:45];

}
-(void)setCarModelInfo:(CarModelInfo *)carModelInfo{
    _carModelInfo = carModelInfo;
    [self updateHighLightViewWithAngle:45];

}
- (void) updateHighLightViewWithAngle:(int)angle
{
//    [self selectAngle:angle];
    
    NSArray *hotPointArray = [self getHighLightArrayWithAngle:angle];
                              
    if (hotPointArray == nil || hotPointArray.count == 0)
    {
        //return;
    }
    
    [self.showView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    
    NSString *imagePath = [self getHighLightImagePathWithdAngle:angle bodyColorKey:[_show.currentBodyDic stringForKey:@"colorKey"]];
    
    UIImage *image = [UIImage imageWithContentsOfFile:imagePath];
    if (image == nil)
    {
        image = [UIImage imageNamed:@"carshow_image_load_fail.png"];
    }
    else
    {
        
        UIImage *image_n = [UIImage imageNamed:BUTTON_HOTPOINT_UNSELECT];
        UIImage *image_h = [UIImage imageNamed:BUTTON_HOTPOINT_SELECTED];
        int count = (int)hotPointArray.count;
        for (int i = 0; i < count; i++)
        {
            OuterHotspotButton *button = [OuterHotspotButton buttonWithType:UIButtonTypeCustom];
            [button setImage:image_n forState:UIControlStateNormal];
            [button setImage:image_h forState:UIControlStateHighlighted];
            
            CarShowPoint *point = [hotPointArray objectAtIndex:i];
            CGRect buttonRect = CGRectMake(point.xPos.floatValue,
                                           point.yPos.floatValue,
                                           36, 35);
            button.frame = buttonRect;
            [button addTarget:self
                       action:@selector(touchHotPointButton:)
             forControlEvents:UIControlEventTouchUpInside];
            button.tag = i;
            [button setExclusiveTouch:YES];
            button.pointDic = [point toDictionary];
            [self.showView addSubview:button];
        }
    }
    
    self.showView.image = image;
}



-(NSArray*)getHighLightArrayWithAngle:(int)angle{
    if (_show.hotPointInfoList == nil || [_show.hotPointInfoList count] == 0) {
        return nil;
    }
    
    NSMutableArray *hotPointArray = [[NSMutableArray alloc] init];
    for (NSDictionary *item in _show.hotPointInfoList) {
        if (item == nil) {
            continue;
        }
        CarShowPoint *hotPoint = [CarShowPoint objectFromDictionary:item];
        
        if ([hotPoint.angle intValue] == angle)
        {
            NSString *dir = [_show.baseDir stringByAppendingPathComponent:hotPoint.mediaPath];
            if ([hotPoint.showType intValue] == HOT_POINT_VIEDO_TYPE) {
                NSString *mediaName = [dir stringByAppendingPathComponent:hotPoint.videoName];
                hotPoint.videoName = mediaName;
            }
            
            if ([hotPoint.showType intValue] == HOT_POINT_PIC_TYPE)
            {
                NSMutableArray *picArray = [[NSMutableArray alloc] init];
                
                NSArray *tmpPicArray = hotPoint.imgArray;
                for (NSString *item in tmpPicArray) {
                    NSString *picName = [dir stringByAppendingPathComponent:item];
                    [picArray addObject:picName];
                }
                hotPoint.imgArray = picArray;
            }
            [hotPointArray addObject:hotPoint];
        }
      
    }
    
    return hotPointArray;

}

-(NSString*)getHighLightImagePathWithdAngle:(int)angle  bodyColorKey:(NSString*)bodyColorKey{
//    if (!_carModelInfo) {
//        return @"";
//    }
    NSArray *img360Array =[[CarShowResource sharedResource] find360ImagesWithColorKey:bodyColorKey basePath:_carModelInfo.basePath img360InfoList:_show.img360InfoList];
    NSString *imgPath = @"";
    
    
    if (img360Array == nil || [img360Array count] == 0) {
        return imgPath;
    }
    //正45 index 4
    if (angle == 45) {
        if ([img360Array count] >= 21) {
            imgPath = [img360Array objectAtIndex:21];
        }
    }
    
    //正车头 index 0
    if (angle == 0)
    {
        if ([img360Array count] >= 18) {
            imgPath = [img360Array objectAtIndex:18];
        }
    }
    
    //后车尾 index 18
    if (angle == 180)
    {
        imgPath = [img360Array objectAtIndex:0];
    }
    
    return imgPath;
}

- (void)touchHotPointButton:(OuterHotspotButton*)sender
{
    CarShowPoint *point = [CarShowPoint objectFromDictionary:sender.pointDic];
    CarShowDetailViewController *detail = [[CarShowDetailViewController alloc]init];
    [detail setInnerPoint:point withBaseDir:_show.baseDir];
    [self presentPopupViewController:detail animationType:MJPopupViewAnimationSlideBottomTop];
}

- (IBAction)headTouched:(id)sender {
    [self updateHighLightViewWithAngle:0];
}

- (IBAction)car45Touched:(id)sender {
    [self updateHighLightViewWithAngle:45];
}

- (IBAction)tailTouched:(id)sender {
    [self updateHighLightViewWithAngle:180];
}
@end
