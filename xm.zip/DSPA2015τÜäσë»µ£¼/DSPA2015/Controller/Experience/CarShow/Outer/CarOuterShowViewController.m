//
//  CarOuterShowViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/12.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarOuterShowViewController.h"
#import "FileManager.h"
#import "FlashMenuButtonSubMenu.h"

#import "JKToast.h"
#import "CarShowResource.h"
#import "CarcompareDetailViewController.h"

#import "ConfigurationCell.h"
#import "configurationSelector.h"

#import "Folder.h"

#import "CarInnerShowViewController.h"
#import "ModelGroupCell.h"

#import "HotspotList.h"
#import "CarShowDetailViewController.h"

#import "UIViewController+DSPAPopup.h"

#import <Photos/Photos.h>

@interface CarOuterShowViewController ()
{
    HotspotList *_hotspotList;
    ConfigurationMenu *_configurationMenu;
    int _currentConfigIndex;
}
@end

@implementation CarOuterShowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"车辆展厅外观";
    _currentConfigIndex = -1;
    
    self.showView.backgroundColor = [UIColor clearColor];
    [self.carOuterButton setTitle:@"外 观"];
    [self.carOuterButton setChecked:NO];
    
    [self.carInnderButton setTitle:@"内 饰"];
    [self.carInnderButton setChecked:NO];
    
    [self.carComparisonButton setTitle:@"对 比"];
    [self.carComparisonButton setChecked:NO];
#ifdef DEMO
    [[CarShowPlayer player] stop];
#else
    self.volumeButton.hidden = YES;
#endif
    
}
-(void)backButtonTouched:(id)sender{
    [super backButtonTouched:sender];
    [[CarShowPlayer player] stop];
}
-(void)backHomeButtonTouched:(id)sender{
    [super backHomeButtonTouched:sender];
    [[CarShowPlayer player] stop];
}

-(void)dealloc{
    [[CarShowPlayer player] stop];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([CarShowPlayer player].isPlay) {
        self.volumeButton.selected = YES;
        [[CarShowPlayer player] play];
    }else{
        self.volumeButton.selected = NO;
        [[CarShowPlayer player] stop];
    } 

    [CBTracking startTracResource:self.car.name withModuleName:@"车辆展厅_外饰"];
    [CBTracking startTracPage:@"车辆展厅_外饰"];
    [self.carOuterButton setButtonSelected:YES animated:YES];
    [CBTracking trackEvent:@"车辆展厅_外饰"];
    NSInteger index = 0;
    for (int i=0; i<[self.car.models count]; i++) {
        ModelDetail *detail = [self.car.models objectWithIndex:i];
        if ([detail.key isEqualToString:self.modelDetail.key]) {
            index = i;
        }
    }
  
    [self collectionView:self.modelGroupCollection didSelectItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    [self.modelGroupCollection selectItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] animated:YES scrollPosition:UICollectionViewScrollPositionNone];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracResource:self.car.name withModuleName:@"车辆展厅_外饰"];
    [CBTracking endTracPage:@"车辆展厅_外饰"];
}

//根据当前型号分组
-(void)filterWithModelGroupItem:(ModelDetail*)modelDetail{
    self.modelDetail = modelDetail;
    //清除所有选配
    [self.showView clear];
    
    NSMutableArray *configurations = [self.modelDetail.configurations mutableCopy]?:[@[]mutableCopy];
    BOOL haveAppearances = NO;
    for (Configuration *config in self.modelDetail.configurations) {
        if ([config.key isEqualToString:@"appearances"]) {
            haveAppearances = YES;
        }
    }
    if (!haveAppearances && self.modelDetail.appearances) {
        self.modelDetail.appearances.key  =@"appearances";
        [configurations insertObject:self.modelDetail.appearances atIndex:0];
        self.modelDetail.configurations = [configurations copy];
    }
    [self.configurationSelector show:NO animate:YES completion:^{
        
    }];
    _currentConfigIndex = -1;
//    [self.configurationTableView reloadData];
    _configurationMenu.items = self.modelDetail.configurations;
    [self selectedAllConfigrationFirst];

}
-(void)selectedAllConfigrationFirst{
    for (Configuration *config in self.modelDetail.configurations) {
        if(![config.key isEqualToString:@"modelGroup"])
        {
            Folder *item = [config.items firstObject];
            if (item) {
                [self applayConfiguration:config item:item];
            }
            
        }
      
    }
}


/**
 *  @author Jakey, 15-11-16 12:11:19
 *
 *  @brief  外饰按钮按下
 *
 *  @param sender <#sender description#>
 */
- (IBAction)carOuterTouched:(FlashMenuButton*)sender {
    [CBTracking trackEvent:@"车辆展厅_外饰"];
    [sender setButtonSelected:YES animated:YES];
}

- (IBAction)carInnerTouched:(FlashMenuButton*)sender {
    [CBTracking trackEvent:@"车辆展厅_内饰"];
    CarInnerShowViewController *inner = [self.tabBarController.viewControllers objectAtIndex:1];
    inner.modelDetail = [self.modelDetail copy];

    self.tabBarController.selectedIndex = 1;
}
- (IBAction)carComparisonTouched:(FlashMenuButton*)sender{
//    self.tabBarController.selectedIndex = 2;
    CarcompareDetailViewController *carcompareVC = [[CarcompareDetailViewController alloc]init];
    carcompareVC.isFromCarShow = YES;
    self.car.modelKey = self.modelDetail.key;
    carcompareVC.modelInfo = self.car;

    [self.navigationController pushViewController:carcompareVC animated:YES];
}

#pragma -mark Light Select
- (IBAction)showLightTouched:(UIButton*)sender {
    sender.selected = !sender.selected;
    if(sender.selected)
    {

        _hotspotList = [HotspotList hotspotList];
        CGRect frame = _hotspotList.frame;
        frame.origin.x =0;
        frame.origin.y =70;
        frame.size.width =0;
        _hotspotList.frame = frame;
        [self.view insertSubview:_hotspotList belowSubview:sender];
        
        [_hotspotList show:YES animate:YES];
        [self.volumeButton moveRight:_hotspotList.size.width];

        _hotspotList.items = self.car.hotspots.outter;
        [_hotspotList titleForHotspotListItem:^NSString *(UITableViewCell *cell, NSInteger index, HotspotItem *item) {
            return item.title;
        }];
        [_hotspotList didSelectHotspotListItem:^(UITableViewCell *cell, NSInteger index, id item) {
            CarShowDetailViewController *detail = [[CarShowDetailViewController alloc]init];
            [detail setInnerPoint:item withBaseDir:self.car.baseDir];
            detail.typeDir = @"outter";
            [self presentDSPAPopup:detail parentViewController:self touchCallBack:^{
                [detail dismissDSPAPopup:nil];
            } haveMask:YES includeNavgation:YES alignTop:NO];
        }];
        
    }else
    {
        [self.volumeButton moveRight:-_hotspotList.size.width];
        [_hotspotList show:NO animate:YES];

    }
    
}

#pragma -mark Config Select

- (IBAction)showConfigButtonTouched:(UIButton*)sender {
    [self.configurationSelector show:NO animate:NO completion:^{
        
    }];
    _currentConfigIndex = -1;
    
    sender.selected = !sender.selected;
    if(sender.selected)
    {
        _configurationMenu = [ConfigurationMenu menu];
        _configurationMenu.backgroundColor = [UIColor clearColor];
        CGRect frame = _configurationMenu.frame;
        frame.origin.x =CGRectGetMaxX(self.view.frame);
        frame.origin.y =70;
        frame.size.width =0;
        _configurationMenu.frame = frame;
        _configurationMenu.items = self.modelDetail.configurations;
        
        [_configurationMenu didSelectConfigurationMenuItem:^(ConfigurationCell *cell, NSInteger index, id item) {
            [self configMenuSelect:cell index:index];
        }];
        [_configurationMenu titleForConfigurationMenuItem:^NSString *(ConfigurationCell *cell, NSInteger index, Configuration *item) {
            return item.name;
            
        }];
        [_configurationMenu imageForConfigurationMenuItem:^NSString *(ConfigurationCell *cell, NSInteger index, Configuration *config) {
            NSString *path;
            if ([config.key isEqualToString:@"appearances"]) {
                path = [NSString pathWithComponents:@[self.car.baseDir?:@"",config.icon?:@""]];
            }else{
                path = [NSString pathWithComponents:@[self.car.baseDir?:@"",config.baseDir?:@"",config.icon?:@""]];
            }
            return path;
        }];
        
        [self.view insertSubview:_configurationMenu belowSubview:sender];
        [_configurationMenu show:YES animate:YES];
        
    }else{
        [_configurationMenu show:NO animate:YES];
        
    }
}
-(void)configMenuSelect:(ConfigurationCell *)cell index:(NSInteger)index{
    Configuration *config= self.modelDetail.configurations[index];
    config.baseDir = @"configurations";
    __weak typeof(self) weakSelf = self;
    
    if (_currentConfigIndex>=0 && self.configurationSelector && _currentConfigIndex == index) {
        [self.configurationSelector show:NO animate:YES completion:^{
            
        }];
        _currentConfigIndex = -1;
        return;
    }
    if([config.name isEqualToString:@"尾标"]){
        return;
    }
    _currentConfigIndex = (int)index;
    [self.configurationSelector removeFromSuperview];
    
    CGRect cellFrame = [cell.superview convertRect:cell.frame toView:self.view];
    self.configurationSelector = [ConfigurationSelector selector];
    CGRect frame =CGRectMake(_configurationMenu.origin.x, cellFrame.origin.y-2, 0, self.configurationSelector.frame.size.height);
    self.configurationSelector.items = config.items;
    self.configurationSelector.frame = frame;
    
    
    [self.configurationSelector titleForConfigurationSelectorItem:^NSString *(ConfigurationSelectorCell *cell, NSInteger index, Folder *item) {
        return item.name;

    }];
    [self.configurationSelector imageForConfigurationSelectorItem:^NSString *(ConfigurationSelectorCell *cell, NSInteger index, Folder *item) {
        if([config.key isEqualToString:@"appearances"])
        {
            item.baseDir =  [self.car.baseDir  stringByAppendingPathComponent:@"appearances"];
        }else{
            NSString *path = [NSString pathWithComponents:@[self.car.baseDir?:@"",config.baseDir?:@"",config.folder?:@""]];
            item.baseDir =  path;
        }
        return [item.baseDir stringByAppendingPathComponent:item.icon?:@""];

    }];
    [self.configurationSelector didSelectConfigurationSelectorItem:^(ConfigurationSelectorCell *cell, NSInteger index, id item) {
        [self.configurationSelector show:NO animate:YES completion:^{
            
        }];
        _currentConfigIndex = -1;
        [weakSelf applayConfiguration:config item:item];
    }];

    [self.view insertSubview:self.configurationSelector belowSubview:_configurationMenu];
    
    [self.configurationSelector show:YES animate:YES completion:^{
        
    }];
}
#pragma -mark Config item Select
-(void)dismissWhenTouched{
    [self.configurationSelector show:NO animate:YES completion:^{
        
    }];
    [_hotspotList show:NO animate:YES];
    [_configurationSelector removeFromSuperview];
    [_configurationMenu show:NO animate:YES];
    self.configButton.selected = NO;
    self.hotspotButton.selected = NO;
    [self.volumeButton hiddenSlider];
}
-(void)applayConfiguration:(Configuration*)config item:(Folder*)item{
    
    if ([[config.key lowercaseString] isEqualToString:@"appearances"])
    {
        item.baseDir =  [self.car.baseDir  stringByAppendingPathComponent:@"appearances"];
        
        NSString *path = [NSString pathWithComponents:@[item.baseDir?:@"",item.folder?:@""]];
        self.modelDetail.currentAppearancePath  = path; //记录当前选中的车身颜色
        
        NSArray *images = [[CarShowResource sharedResource] getResoureces:path];
        self.showView.imagePaths = images;
        //转动的时候隐藏各种选择器
        [self.showView beginTouchedBlock:^(NSInteger index, CGFloat degress) {
            [self dismissWhenTouched];
        }];
        [self.showView didChangeBlock:^(NSInteger index, CGFloat degress) {
            [self.exportButton setTitle:[NSString stringWithFormat:@"生成:index:%zd,degress%.2lf",index,degress] forState:UIControlStateNormal];
            
            NSLog(@"didChangeindex:%zd",index);
        }];
        //q5的acc 非sline模式 显示ACC
        if([[self.car.name lowercaseString] isEqualToString:@"q5"]){
            [self.showView itemViewWithType:@"ACC"].hidden = NO;
        }
    }else if ([[config.key lowercaseString] isEqualToString:@"sline"])
    {
        
        //hava sline
        if ([item.key isEqualToString:@"sline"]) {
            self.modelDetail.currentAppearancePath =  [self.modelDetail.currentAppearancePath  stringByReplacingOccurrencesOfString:@"_sline" withString:@""];
            self.modelDetail.currentAppearancePath = [self.modelDetail.currentAppearancePath stringByAppendingString:@"_sline"];
            NSArray *images = [[CarShowResource sharedResource] getResoureces:self.modelDetail.currentAppearancePath];
            self.showView.imagePaths = images;
            //q5的acc sline模式 不显示ACC
            if([[self.car.name lowercaseString] isEqualToString:@"q5"]){
                [self.showView itemViewWithType:@"ACC"].hidden = YES;
            }
        }else{
            //no sline
            self.modelDetail.currentAppearancePath =  [self.modelDetail.currentAppearancePath  stringByReplacingOccurrencesOfString:@"_sline" withString:@""];//当前选择的内饰颜色
            NSArray *images = [[CarShowResource sharedResource] getResoureces:self.modelDetail.currentAppearancePath];
            self.showView.imagePaths = images;
            //q5的acc 非sline模式 显示ACC
            if([[self.car.name lowercaseString] isEqualToString:@"q5"]){
                [self.showView itemViewWithType:@"ACC"].hidden = NO;
            }
        }
        
    }
    else{
        
        if (item.folder.length>0) {
            NSString *path = [NSString pathWithComponents:@[self.car.baseDir,config.baseDir,config.folder,item.folder]];
            NSArray *images = [[CarShowResource sharedResource] getResoureces:path];
            ShowItem360 *view = [[ShowItem360 alloc]initWithFrame:self.showView.bounds];
            view.imagePaths = [images mutableCopy];
            view.userInteractionEnabled= NO;
            view.key = config.folder;
            if([config.key isEqualToString:@"yingzi"] || [config.folder isEqualToString:@"yingzi"]){
                [self.showView addSub360AtBottom:view];
            }else{
                [self.showView addSub360:view];
            }
            
            //插入到某个选配到底部  天窗一直放在行李架底部
            if([config.key isEqualToString:@"tianchuang"] || [config.folder isEqualToString:@"tianchuang"]){
                //提前行李架
                [self.showView insertSub360:view belowOther360:@"xinglijia"];
            }
            
            //sline模式隐藏acc
            if ([[self.car.name lowercaseString] isEqualToString:@"q5"] && [self.modelDetail.currentAppearancePath hasSuffix:@"sline"]){
                [self.showView itemViewWithType:@"ACC"].hidden = YES;
            }else{
                [self.showView itemViewWithType:@"ACC"].hidden = NO;
            }
        }else{
            [self.showView clearForType:config.folder];
        }
        
    }
    
}
#pragma mark -
#pragma mark Collection view data source  Model Group Select
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.car.models count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"ModelGroupCell";
    [collectionView registerNib:[UINib nibWithNibName:CellIdentifier bundle:nil] forCellWithReuseIdentifier:CellIdentifier];
    ModelGroupCell *cell = (ModelGroupCell *)[collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    ModelDetail *item = [self.car.models objectWithIndex:indexPath.row];
    [cell configCell:item];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //过滤对应分组的选配
    ModelDetail *modelDetail = [self.car.models objectWithIndex:indexPath.row];
    [self filterWithModelGroupItem:modelDetail];
}


- (IBAction)volumeButtonTouched:(VolumeButton*)sender {
    sender.selected = !sender.selected;
    if (sender.selected) {
        [[CarShowPlayer player] play];
    }else{
        [[CarShowPlayer player] stop];
    }
}
#pragma --mark 导出资源到相册
- (IBAction)exportButtonTouched:(id)sender {
    UIImage *image =   [self.showView currentScreenshot];
//
    NSData *imageData = UIImagePNGRepresentation(image);
//    // 获取沙盒目录
//    NSString * path =  [FileManager documentsPath:@"666.png"];
//    // 将图片写入文件
//    [imageData writeToFile:path atomically:NO];

    
    @autoreleasepool {
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            //写入图片到相册
//            [PHAssetChangeRequest creationRequestForAssetFromImage:image];

            PHAssetResourceCreationOptions *options = [[PHAssetResourceCreationOptions alloc] init];
            [[PHAssetCreationRequest creationRequestForAsset] addResourceWithType:PHAssetResourceTypePhoto data:imageData options:options];
            
        } completionHandler:^(BOOL success, NSError * _Nullable error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if(!success){
                    [JKToast toastWithText:@"保存失败" bottomOffset:200];
                }else{
                    [JKToast toastWithText:@"保存成功" bottomOffset:200];
                }
            });
            
        }];
    }
   

}
 

@end
