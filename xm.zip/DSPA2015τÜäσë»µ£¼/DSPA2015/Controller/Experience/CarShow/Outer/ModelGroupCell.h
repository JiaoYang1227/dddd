//
//  ModelGroupCell.h
//  DSPA2015
//
//  Created by runlin on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModelGroupCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *titileLabel;
-(void)configCell:(id)item;
@end
