//
//  CarOuterConfigViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarOuterConfigViewController.h"

@interface CarOuterConfigViewController ()

@end

@implementation CarOuterConfigViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    self.title = @"车辆展厅外饰选配";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [TalkingData trackPageEnd:self.title];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [TalkingData trackPageBegin:self.title];
}
-(void)setShow:(CarOuterShow *)show{
    _show = show;
    
    [self initColorPicker];
}


/**
 *  @author Jakey, 15-11-16 12:11:06
 *
 *  @brief  初始化选配选择控件
 */
-(void)initColorPicker{
    self.carShowColorView.items =  _show.wheelInfoList;
    
    [self.carShowColorView touchCarShowColorButton:^(UIButton *button, NSInteger index, NSDictionary *item) {
        //取topColorKeyList 第一个元素
       NSString *imagePath =  [self getImagePathWithBodyColorId:[_show.currentBodyDic stringForKey:@"colorKey"] andTopColorId:[[_show.currentBodyDic arrayForKey:@"topColorKeyList"] firstObject] andWheelId:[item stringForKey:@"wheelKey"]];
        self.imageView.image = [UIImage imageWithContentsOfFile:imagePath];
        
    }];
    [self.carShowColorView titleForCarShowColorItem:^NSString *(UIButton *button, NSInteger index, id  item) {
        return [item objectForKey:@"wheelValue"];
    }];
    [self.carShowColorView imageForCarShowColorItem:^NSString *(UIButton *button, NSInteger index, id item) {
        return [_show.baseDir stringByAppendingPathComponent:[item stringForKey:@"wheelImgPath"]];
        
    }];
    self.carShowColorView.scrollDirect = ColorHorizontalScroll;
}

//
// 返回外饰选配画面的车辆图片地址。
//
- (NSString*)getImagePathWithBodyColorId:(NSString*)bodyId
                           andTopColorId:(NSString*)topId
                              andWheelId:(NSString*)wheelId
{
    if (_show.additionalInfoList == nil) {
        return nil;
    }
    
    for (NSDictionary *item in _show.additionalInfoList) {
        
        NSString *bodyColorKey = [item valueForKey:@"bodyColorKey"];
        NSString *topColorKey = [item valueForKey:@"topColorKey"];
        NSString *wheelkey = [item valueForKey:@"wheelKey"];
        
        if ([bodyColorKey isEqualToString:bodyId] == YES
            && [wheelkey isEqualToString:wheelId] == YES
            && ((topId != nil && topColorKey != nil && [topColorKey isEqualToString:topId] == YES) || (topColorKey == nil && topId == nil))
            ) {
            return [_show.baseDir stringByAppendingPathComponent:[item valueForKey:@"imgPath"]];
        }
    }
    
    return nil;
}

@end
