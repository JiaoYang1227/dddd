//
//  ModelGroupCell.m
//  DSPA2015
//
//  Created by runlin on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ModelGroupCell.h"
#import "ModelDetail.h"
@implementation ModelGroupCell


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.titileLabel.adjustsFontSizeToFitWidth = YES;
}
-(void)configCell:(ModelDetail*)item{
    self.titileLabel.text = item.name;
    self.titileLabel.font = [self fontMinSize:4 maxSize:10 constrainedToSize:self.titileLabel.frame.size forText:item.name];
}
- (UIFont*)fontMinSize:(CGFloat)minSize maxSize:(CGFloat)maxSize constrainedToSize:(CGSize)labelSize forText:(NSString*)text {
    
    UIFont* font = [UIFont systemFontOfSize:maxSize];
    
    CGSize constraintSize = CGSizeMake(labelSize.width, MAXFLOAT);
    NSRange range = NSMakeRange(minSize, maxSize);
    
    int fontSize = 0;
    for (NSInteger i = maxSize; i > minSize; i--)
    {
        fontSize = ceil(((float)range.length + (float)range.location) / 2.0);
        
        font = [font fontWithSize:fontSize];
        NSMutableParagraphStyle *paragraph = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
        paragraph.lineBreakMode = NSLineBreakByWordWrapping;

        CGSize size =  [text boundingRectWithSize:constraintSize
                                          options:NSStringDrawingUsesLineFragmentOrigin
                                       attributes:@{ NSFontAttributeName:font, NSParagraphStyleAttributeName: paragraph }
                                          context:nil].size;
        
        if (size.height <= labelSize.height)
            range.location = fontSize;
        else
            range.length = fontSize - 1;
        
        if (range.length == range.location)
        {
            font = [font fontWithSize:range.location];
            break;
        }
    }
    
    return font;
}
@end
