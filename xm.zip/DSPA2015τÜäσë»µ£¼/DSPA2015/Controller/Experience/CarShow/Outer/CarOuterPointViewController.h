//
//  CarOuterPointViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "CarOuterShow.h"
#import "CarModelInfo.h"
@interface CarOuterPointViewController : BaseViewController
@property(nonatomic,strong) CarOuterShow *show;
@property(nonatomic,strong) CarModelInfo *carModelInfo;
@property (weak, nonatomic) IBOutlet UIImageView *showView;
- (IBAction)headTouched:(id)sender;
- (IBAction)car45Touched:(id)sender;
- (IBAction)tailTouched:(id)sender;
@end
