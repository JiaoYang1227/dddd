//
//  ConfigurationCell.m
//  DSPA2015
//
//  Created by runlin on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ConfigurationCell.h"
#import "Configuration.h"
@implementation ConfigurationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    self.icon.layer.cornerRadius = self.icon.frame.size.width/2.0;
//    self.icon.layer.masksToBounds = YES;
}
-(void)configCell:(Configuration*)item{
    self.nameLabel.text = item.name;
    self.nameLabel.font = [self fontMinSize:4 maxSize:10 constrainedToSize:self.nameLabel.frame.size forText:item.name];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (UIFont*)fontMinSize:(CGFloat)minSize maxSize:(CGFloat)maxSize constrainedToSize:(CGSize)labelSize forText:(NSString*)text {
    
    UIFont* font = [UIFont systemFontOfSize:maxSize];
    
    CGSize constraintSize = CGSizeMake(labelSize.width, MAXFLOAT);
    NSRange range = NSMakeRange(minSize, maxSize);
    
    int fontSize = 0;
    for (NSInteger i = maxSize; i > minSize; i--)
    {
        fontSize = ceil(((float)range.length + (float)range.location) / 2.0);
        
        font = [font fontWithSize:fontSize];
        NSMutableParagraphStyle *paragraph = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
        paragraph.lineBreakMode = NSLineBreakByWordWrapping;
        
        CGSize size =  [text boundingRectWithSize:constraintSize
                                          options:NSStringDrawingUsesLineFragmentOrigin
                                       attributes:@{ NSFontAttributeName:font, NSParagraphStyleAttributeName: paragraph }
                                          context:nil].size;
        
        if (size.height <= labelSize.height)
            range.location = fontSize;
        else
            range.length = fontSize - 1;
        
        if (range.length == range.location)
        {
            font = [font fontWithSize:range.location];
            break;
        }
    }
    
    return font;
}
@end
