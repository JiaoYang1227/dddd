//
//  CarOuterConfigViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "CarShowColorView.h"
#import "CarOuterShow.h"
@interface CarOuterConfigViewController : BaseViewController
@property (weak, nonatomic) IBOutlet CarShowColorView *carShowColorView;
@property(nonatomic,strong) CarOuterShow *show;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
