//
//  CarShowDetailViewController.m
//  CarShow
//
//  Created by Jakey on 15/6/24.
//  Copyright © 2015年 www.skyfox.org. All rights reserved.
//

#import "CarShowDetailViewController.h"
#import "UIViewController+DSPAPopup.h"

#import "AppDelegate.h"
#import <AVFoundation/AVFoundation.h>
#import "XTMoviePlayerController.h"
#define HOT_POINT_VIEDO_TYPE 0
#define HOT_POINT_PIC_TYPE 1
@interface CarShowDetailViewController ()

@end

@implementation CarShowDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    mediaPlayer_ = [[DSPAMediaPlayer alloc]initWithFrame:_bgImageView.bounds];
    [_bgImageView addSubview:mediaPlayer_];
    _bgImageView.userInteractionEnabled = YES;
    mediaPlayer_.userInteractionEnabled = YES;
   
    self.title = @"车辆展厅亮点";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

-(void)setInnerPoint:(HotspotItem *)innerPoint withBaseDir:(NSString*)baseDir{
    _item = innerPoint;
    _baseDir = baseDir;
}
-(BOOL)checkExhibitionVideo:(NSString*)path
{
    NSRange range;
    range.length = 0;
    range.location = 0;
    for(int i = (int)path.length - 1; i > 0; i--){
        if([path characterAtIndex:i] == '.'){
            range.length = i;
            break;
        }
    }
    if(range.length == 0)
        return NO;
    range.length += range.location;;
    range.location = 0;
    NSString*VideoPath =[NSString stringWithFormat:@"%@.mp4", [path substringWithRange:range]];
    const char *s = [VideoPath UTF8String];
    FILE *file = fopen(s, "rb");
    if(file != NULL){
        fclose(file);
        return YES;
    }
    return NO;
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 5;// 字体的行间距
    NSDictionary *attributes = @{
                                 NSFontAttributeName:[UIFont systemFontOfSize:13],
                                 NSParagraphStyleAttributeName:paragraphStyle,
                                 NSForegroundColorAttributeName:[UIColor whiteColor]
                                 };
    
    self.detailView.attributedText = [[NSAttributedString alloc] initWithString:_item.detailInfo attributes:attributes];
    
//    self.detailView.text = _item.detailInfo;
    self.titleLable.text = _item.title;
    [_scrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSString *base = [[_baseDir stringByAppendingPathComponent:@"hotspots"] stringByAppendingPathComponent:_typeDir];
    
    if (_item.videoName.length>0 && [self checkExhibitionVideo:[base stringByAppendingPathComponent:[_item.folder stringByAppendingPathComponent:_item.videoName]]]) {
        NSString *jpgPath = [base stringByAppendingPathComponent:[_item.folder stringByAppendingPathComponent:_item.videoName]];
        [self setHighLightVedioPath:jpgPath];
        
    }else
    {
        for(int i =0;i<[_item.imageList count];i++){
            UIImageView *imageView = [[UIImageView alloc]initWithFrame:_scrollView.bounds];
            NSString *imageName =   [_item.imageList objectWithIndex:i];
            imageView.image = [UIImage imageWithContentsOfFile:[base stringByAppendingPathComponent:[_item.folder stringByAppendingPathComponent:imageName?:@""]]];
            imageView.frame = CGRectMake(i*_scrollView.frame.size.width, 0, _scrollView.frame.size.width, _scrollView.frame.size.height);
            imageView.contentMode =  UIViewContentModeScaleAspectFit;
            _scrollView.pagingEnabled = YES;
            [_scrollView addSubview:imageView];
            
        }
        _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width*[_item.imageList count], _scrollView.frame.size.height);
        _bgImageView.hidden = YES;
        
    }

}
- (void) setHighLightVedioPath:(NSString*)path
{
    if (path == nil) {
        return;
    }
    _bgImageView.hidden = NO;
    NSURL    *url    = [NSURL fileURLWithPath:path];
    AVAsset *asset = [[AVURLAsset alloc] initWithURL:url options:nil];
    
    NSArray *assetKeysToLoadAndTest = [NSArray arrayWithObject:@"playable"];
    [asset loadValuesAsynchronouslyForKeys:assetKeysToLoadAndTest completionHandler:^{
        dispatch_async( dispatch_get_main_queue(),^{
            if ([asset isPlayable] == YES)
            {
                [mediaPlayer_ setURL:url];
            }
            else
            {
                _bgImageView.image = [UIImage imageNamed:@"carshow_vedio_load_fail"];
            }
        });
    }];
}





- (IBAction)closeTouched:(id)sender {
    [self dismissDSPAPopup:^{
        
    }];
}
@end
@implementation DSPAMediaPlayer
@synthesize player;

+ (Class)layerClass
{
    return [AVPlayerLayer class];
}

- (AVPlayer*)player
{
    return [(AVPlayerLayer*)[self layer] player];
}

- (void)setPlayer:(AVPlayer*)mPlayer
{
    [(AVPlayerLayer*)[self layer] setPlayer:mPlayer];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor blackColor];
        
        buttonPlay_ = [UIButton buttonWithType:UIButtonTypeCustom];
        
        float width = 80;
        buttonPlay_.frame = CGRectMake((CGRectGetWidth(frame)  - width) / 2,
                                       (CGRectGetHeight(frame) - width) / 2,
                                       width, width);
        [buttonPlay_ setImage:[UIImage imageNamed:@"carshow_bigPlay.png"]
                     forState:UIControlStateNormal];
        [buttonPlay_ addTarget:self
                        action:@selector(actionOnTouchPlayButton)
              forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:buttonPlay_];
      
    }
    return self;
}

- (void) actionOnTouchPlayButton
{
    XTMoviePlayerController *play = [[XTMoviePlayerController alloc] initWithContentURL:videoUrl_];
    [play startPlaying:[AppDelegate APP].rootViewController withBlock:^{
        NSLog(@"start play movie");
    }];
    [play didPlayFinished:^{
        NSLog(@"finished");
    }];
    NSLog(@"%f,%f",play.moviePlayer.endPlaybackTime,play.moviePlayer.duration);
    [play didplayField:^(NSError *error) {
        //
    }];
}

- (void)dealloc
{
    [[((AVPlayerLayer *)[self layer]) player] pause];
    self.player = nil;
}

- (void) play
{
    [[((AVPlayerLayer *)[self layer]) player] play];
}

- (void) pause
{
    [[((AVPlayerLayer *)[self layer]) player] pause];
}

#pragma mark -
#pragma mark interface

- (void) setURL:(NSURL*)url
{
    self.player = [[AVPlayer alloc] initWithURL:url];
    videoUrl_   = url;
}
@end
