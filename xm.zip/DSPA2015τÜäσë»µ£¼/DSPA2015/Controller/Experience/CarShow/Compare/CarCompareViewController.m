//
//  CarCompareViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarCompareViewController.h"

@interface CarCompareViewController ()

@end

@implementation CarCompareViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.carOuterButton setTitle:@"外 观"];
    [self.carOuterButton setChecked:NO];
    
    [self.carInnderButton setTitle:@"内 饰"];
    [self.carInnderButton setChecked:NO];
    
    
    [self.carComparisonButton setTitle:@"对 比"];
    [self.carComparisonButton setChecked:NO];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.carComparisonButton setButtonSelected:YES animated:YES];
}
- (IBAction)carOuterTouched:(FlashMenuButton*)sender {
    self.tabBarController.selectedIndex = 0;
}

- (IBAction)carInnerTouched:(FlashMenuButton*)sender {
    self.tabBarController.selectedIndex = 1;

}
- (IBAction)carComparisonTouched:(FlashMenuButton*)sender{
    [sender setButtonSelected:YES animated:YES];

}
@end
