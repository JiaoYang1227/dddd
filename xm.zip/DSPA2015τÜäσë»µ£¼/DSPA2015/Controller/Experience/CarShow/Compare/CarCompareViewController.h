//
//  CarCompareViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "Car.h"
#import "FlashMenuButton.h"
@interface CarCompareViewController : BaseViewController
@property(strong,nonatomic)Car *modelInfo;
@property (weak, nonatomic) IBOutlet FlashMenuButton *carOuterButton;
@property (weak, nonatomic) IBOutlet FlashMenuButton *carInnderButton;
@property (weak, nonatomic) IBOutlet FlashMenuButton *carComparisonButton;
- (IBAction)carOuterTouched:(id)sender;
- (IBAction)carInnerTouched:(id)sender;
- (IBAction)carComparisonTouched:(id)sender;

@end
