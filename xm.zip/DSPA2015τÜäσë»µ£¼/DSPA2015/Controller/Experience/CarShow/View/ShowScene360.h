//
//  ShowScene360.h
//  CarShow
//
//  Created by Jakey on 15/6/10.
//  Copyright (c) 2015年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShowItem360.h"
#import "OuterHotspotButton.h"
typedef NS_ENUM(NSUInteger,ShowDirection) {
    DirectionNone,
    Direction0,
    Direction180,
    Direction45

};

typedef void (^DidChangeBlock)(NSInteger index,CGFloat degress);
typedef void (^BeginTouchedBlock)(NSInteger index,CGFloat degress);

@interface ShowScene360 : UIView
{
    UIImageView *_imageView;
    DidChangeBlock _didChangeBlock;
    BeginTouchedBlock _beginTouchedBlock;

    UIView *_spotView;
    
    NSTimeInterval  _previousTouchTimestamp;
    
    NSMutableArray  *_360items;
    NSMutableArray  *_spots;
    
}
@property(nonatomic) NSInteger count;
@property(nonatomic) NSInteger currentIndex;

@property(nonatomic,assign) ShowDirection direction;
@property(nonatomic,strong)     UIImage *defaultImage;

@property (nonatomic,strong)	NSArray  *imagePaths;


-(void)didChangeBlock:(DidChangeBlock)didChangeBlock;
-(void)beginTouchedBlock:(BeginTouchedBlock)beginTouchedBlock;

///逐层添加ShowItem360
-(void)addSub360:(ShowItem360 *)item;
///在本360视图最底部插入ShowItem360
-(void)addSub360AtBottom:(ShowItem360 *)item;
//将选配插入到某一选配底部
-(void)insertSub360:(ShowItem360 *)item belowOther360:(NSString*)name;

-(void)addLightspot:(OuterHotspotButton *)spot;

//根据选配名称清除
-(void)clearForType:(NSString *)key;
//根据选配名称获取选配视图
-(ShowItem360 *)itemViewWithType:(NSString*)typeName;
-(void)clear;

//当前角度图片合成
-(UIImage*)currentScreenshot;
@end
