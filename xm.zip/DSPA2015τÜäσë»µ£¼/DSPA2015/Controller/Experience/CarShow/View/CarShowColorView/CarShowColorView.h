//
//  CarShowColorView.h
//  CarShow-Dcars
//
//  Created by Jakey on 15/10/28.
//  Copyright © 2015年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CarShowColorButton.h"
typedef void (^TouchCarShowColorButton)(UIButton *button,NSInteger index,id item);
typedef NSString*(^TitleForCarShowColorItem)(UIButton *button,NSInteger index,id item);
typedef NSString*(^ImageForCarShowColorItem)(UIButton *button,NSInteger index,id item);


typedef enum{
    ColorHorizontalScroll,
    ColorVerticalScroll
    
}ColorScrollDirect;
@interface CarShowColorView : UIView
{
    TouchCarShowColorButton _touchCarShowColorButton;
    TitleForCarShowColorItem _titleForCarShowColorItem;
    ImageForCarShowColorItem _imageForCarShowColorItem;
    UIScrollView *_scrollView;
}
-(void)touchCarShowColorButton:(TouchCarShowColorButton)touchCarShowColorButton;
-(void)titleForCarShowColorItem:(TitleForCarShowColorItem)titleForCarShowColorItem;
-(void)imageForCarShowColorItem:(ImageForCarShowColorItem)imageForCarShowColorItem;

@property (strong, nonatomic) NSArray *items;
@property (nonatomic) CGFloat itemWith;
@property (nonatomic) ColorScrollDirect scrollDirect;
@property (strong, nonatomic) NSString *baseName;
-(void)reloadData;
@end
