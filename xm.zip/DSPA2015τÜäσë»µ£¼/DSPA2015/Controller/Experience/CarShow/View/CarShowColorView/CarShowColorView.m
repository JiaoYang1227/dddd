//
//  CarShowColorView.m
//  CarShow-Dcars
//
//  Created by Jakey on 15/10/28.
//  Copyright © 2015年 www.skyfox.org. All rights reserved.
//

#import "CarShowColorView.h"

@implementation CarShowColorView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.itemWith = 40.0;
        
    }
    return self;
}
-(void)reloadData{
    NSArray *subViews = _scrollView.subviews;
    if([subViews count] != 0)
    {
        [subViews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds)-6)];
        _scrollView.directionalLockEnabled = YES;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.canCancelContentTouches = YES;
       _scrollView.clipsToBounds = NO;
        
        [self addSubview:_scrollView];
    }
  
    float contentSize = 0;
    
    for (int idx=0;idx<[self.items count];idx++)
    {
        id item = [self.items objectAtIndex:idx];
        
        CarShowColorButton *buttonItem = [CarShowColorButton buttonWithType:UIButtonTypeCustom];
        if (_imageForCarShowColorItem) {
            NSString *path = _imageForCarShowColorItem(buttonItem,idx,item);
            
            [buttonItem setImage:[UIImage imageWithContentsOfFile:path] forState:UIControlStateNormal];
        }else{
            if (_titleForCarShowColorItem) {
                NSString *title = _titleForCarShowColorItem(buttonItem,idx,item);
                
                [buttonItem setTitle:title forState:UIControlStateNormal];
            }
        }
        
        [buttonItem setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [buttonItem setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        buttonItem.titleLabel.textAlignment = NSTextAlignmentCenter;
        buttonItem.titleLabel.font = [UIFont systemFontOfSize:12.0];
        buttonItem.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        
        buttonItem.backgroundColor = [UIColor clearColor];
//        [buttonItem setBackgroundImage:[self createImageWithColor:[UIColor colorWithRed:0.925 green:0.906 blue:0.882 alpha:1.000]] forState:UIControlStateSelected];
        
        buttonItem.titleEdgeInsets = UIEdgeInsetsMake(5, 5, 5, 5);
        
        if (self.scrollDirect == ColorHorizontalScroll) {
            buttonItem.frame = CGRectMake(contentSize+11, 0.0, _scrollView.frame.size.height, _scrollView.frame.size.height);
            contentSize += _scrollView.frame.size.height;

        }else{
            buttonItem.frame = CGRectMake(0.0, contentSize, _scrollView.frame.size.width,_scrollView.frame.size.width );
            contentSize += _scrollView.frame.size.width;

        }
        contentSize += 11;
        
        buttonItem.tag = 20000 + idx;
        [buttonItem addTarget:self action:@selector(touchAction:) forControlEvents:UIControlEventTouchDown];
        [_scrollView addSubview:buttonItem];
        
        if (idx ==0) {
            [self touchAction:buttonItem];
        }

    }

    if (self.scrollDirect == ColorHorizontalScroll) {
        _scrollView.contentSize = CGSizeMake(contentSize, 0);
    }else{
        _scrollView.contentSize = CGSizeMake(0, contentSize);
    }
    
}
- (void)willMoveToSuperview:(UIView *)newSuperview;
{
    if (newSuperview)
    {
        self.backgroundColor = [UIColor clearColor];
        [self reloadData];
    }
}
-(void)touchCarShowColorButton:(TouchCarShowColorButton)touchCarShowColorButton{
    _touchCarShowColorButton = [touchCarShowColorButton copy];
    [self reloadData];
}
-(void)titleForCarShowColorItem:(TitleForCarShowColorItem)titleForCarShowColorItem{
    _titleForCarShowColorItem = [titleForCarShowColorItem copy];
    [self reloadData];
}
-(void)imageForCarShowColorItem:(ImageForCarShowColorItem)imageForCarShowColorItem{
    _imageForCarShowColorItem = [imageForCarShowColorItem copy];
    [self reloadData];
}
-(void)setItems:(NSArray *)items{
    _items = items;
    [self reloadData];
}
-(void)setScrollDirect:(ColorScrollDirect)scrollDirect{
    _scrollDirect = scrollDirect;
    [self reloadData];
}
- (void)touchAction:(UIButton*)sender{
    for (UIButton *button in _scrollView.subviews) {
        if (button.tag == sender.tag) {
            button.selected = YES;
        }else
        {
            button.selected = NO;
            button.backgroundColor = [UIColor clearColor];
        }
    }
    
    if (_touchCarShowColorButton) {
        _touchCarShowColorButton(sender,sender.tag-20000,self.items[sender.tag-20000]);
    }
}

- (UIImage *)createImageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return theImage;
}

@end
