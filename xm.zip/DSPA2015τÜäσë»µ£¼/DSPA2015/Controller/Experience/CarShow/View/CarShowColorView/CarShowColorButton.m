//
//  CarShowColorButton.m
//  DSPA2015
//
//  Created by Jakey on 15/11/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarShowColorButton.h"

@implementation CarShowColorButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setSelected:(BOOL)selected{
    [super setSelected:selected];
    [_cursorView removeFromSuperview];
    
    if (selected) {
        _cursorView = [[UIView alloc]initWithFrame:CGRectMake(self.width/2-15/2, CGRectGetHeight(self.bounds)+3, 15, 3)];
        _cursorView.backgroundColor = [UIColor colorWithRed:0.910 green:0.000 blue:0.075 alpha:1.000];
        [self addSubview:_cursorView];
    }
}
@end
