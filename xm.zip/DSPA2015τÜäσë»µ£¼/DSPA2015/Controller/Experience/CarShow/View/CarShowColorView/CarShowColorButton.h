//
//  CarShowColorButton.h
//  DSPA2015
//
//  Created by Jakey on 15/11/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarShowColorButton : UIButton
{
    UIView *_cursorView;
}
@end
