//
//  Show360.m
//  CarShow
//
//  Created by Jakey on 15/6/8.
//  Copyright (c) 2015年 www.skyfox.org. All rights reserved.
//

#import "ShowItem360.h"
#import "ImageMemoryCache.h"
@implementation ShowItem360
-(NSInteger)count{
    return [_imagePaths count];
}

-(void)setImagePaths:(NSMutableArray *)imagePaths{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:self.bounds];
        [self addSubview:_imageView];
    }
    _imagePaths = [imagePaths mutableCopy];
    [self setCurrentIndex:0];
}

- (void)setCurrentIndex:(NSInteger)currentIndex
{
    if (!_imagePaths || [_imagePaths count]<=0) {
        return;
    }
    
    _currentIndex = MIN(MAX(0, currentIndex), self.count - 1) ;
    
    NSString *path = [_imagePaths objectAtIndex:_currentIndex];
    //    NSAssert(image, @"image is nil");
    UIImage *image =  [[ImageMemoryCache sharedMemoryCache] imageFromKey:path];
    if (image) {
        
    }else{
        image = [UIImage imageWithContentsOfFile:path];
//                [[ImageMemoryCache sharedMemoryCache] storeImage:image forKey:path];
    }
    //
    [self.imageView setImage:image];
}

@end
