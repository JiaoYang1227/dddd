//
//  VolumeButton.m
//  DSPA2015
//
//  Created by runlin on 16/7/22.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "VolumeButton.h"

@implementation VolumeButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)awakeFromNib{
    [super awakeFromNib];
}
-(void)layoutSubviews{
    [super layoutSubviews];
    
}
-(void)moveRight:(CGFloat)right{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect frame =   self.frame;
        frame.origin.x +=right;
        _right = right;
        self.frame =frame;
        _slider.frame = CGRectMake(self.frame.origin.x-138/2, CGRectGetMaxY(self.frame), 173, 173);
    }];

}
//-(void)setVolumeValue:(CGFloat)volumeValue{
//    _volumeValue = volumeValue;
//    _slider.value = _volumeValue;
//}
//-(CGFloat)volumeValue{
//    return _slider.value;
//}
-(void)hiddenSlider{
    _slider.hidden = YES;
    if (self.frame.origin.x>165) {
        [self moveRight:-fabs(_right)];
    }
    _right = 0;
}
//-(void)showSlider:(CGFloat)value view:(UIView*)view completion:(void (^)(CGFloat value))completion
//{
//    _volumeButtonChange = [completion copy];
////    CGRect frame = [self.superview convertRect:self.frame toView:self.superview];
//    if (!_slider) {
//        _slider = [[UISlider alloc]initWithFrame:CGRectMake(self.frame.origin.x-138/2, CGRectGetMaxY(self.frame)+173/2, 173, 10)];
//        //滑块图片
////        UIImage *thumbImage = [UIImage imageNamed:@"volumebutton_red"];
////
////        [_slider setThumbImage:thumbImage forState:UIControlStateHighlighted];
////         [_slider setThumbImage:thumbImage forState:UIControlStateNormal];
//        //滑块拖动时的事件
//        [_slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
//        //设置旋转90度
//        _slider.hidden = YES;
//        _slider.value = value;
//        _slider.transform =CGAffineTransformMakeRotation(M_PI/2);
//        [view addSubview:_slider];
//    }
//    _slider.hidden = !_slider.hidden;
//}
//
//-(void)sliderValueChanged:(UISlider*)slider{
//    if (_volumeButtonChange) {
//        _volumeButtonChange(slider.value);
//    }
//}
@end
