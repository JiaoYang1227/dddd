//
//  VolumeButton.h
//  DSPA2015
//
//  Created by runlin on 16/7/22.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^VolumeButtonChange)(CGFloat value);

@interface VolumeButton : UIButton
{
    UISlider *_slider;
    VolumeButtonChange _volumeButtonChange;
    CGFloat _volumeValue;
    CGFloat _right;
}
//@property(nonatomic,assign)CGFloat volumeValue;
//-(void)showSlider:(CGFloat)value view:(UIView*)view completion:(void (^)(CGFloat value))completion;
-(void)moveRight:(CGFloat)right;
-(void)hiddenSlider;
@end
