//
//  ConfigurationSelectView.h
//  DSPA2015
//
//  Created by runlin on 16/7/7.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NSString*(^TitleForConfigurationSelectViewItem)(UIButton *button,NSInteger index,id item);
typedef NSString*(^ImageForConfigurationSelectViewItem)(UIButton *button,NSInteger index,id item);
typedef void (^DidSelectConfigurationSelectViewItem)(UIButton *button,NSInteger index,id item);


@interface ConfigurationSelectView : UIScrollView
{
    TitleForConfigurationSelectViewItem _titleForConfigurationSelectViewItem;
    ImageForConfigurationSelectViewItem _imageForConfigurationSelectViewItem;
    DidSelectConfigurationSelectViewItem _didSelectConfigurationSelectViewItem;
}
@property (strong, nonatomic) NSArray *items;

-(void)titleForConfigurationSelectViewItem:(TitleForConfigurationSelectViewItem)titleForConfigurationSelectViewItem;
-(void)imageForConfigurationSelectViewItem:(ImageForConfigurationSelectViewItem)imageForConfigurationSelectViewItem;
-(void)didSelectConfigurationSelectViewItem:(DidSelectConfigurationSelectViewItem)didSelectConfigurationSelectViewItem;

@end
