//
//  ConfigurationSelectView.m
//  DSPA2015
//
//  Created by runlin on 16/7/7.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ConfigurationSelectView.h"
#import "ConfigurationSelectViewItem.h"
@implementation ConfigurationSelectView

-(void)reloadData{
    NSArray *subViews = self.subviews;
    if([subViews count] != 0)
    {
        [subViews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    
    self.directionalLockEnabled = YES;
    self.showsVerticalScrollIndicator = NO;
    self.showsHorizontalScrollIndicator = NO;
    self.canCancelContentTouches = YES;
    self.clipsToBounds = NO;
    
    
    float contentSize = 0;
    
    for (int idx=0;idx<[self.items count];idx++)
    {
        id item = [self.items objectAtIndex:idx];
        
        ConfigurationSelectViewItem *buttonItem = [ConfigurationSelectViewItem buttonWithType:UIButtonTypeCustom];
        if (_imageForConfigurationSelectViewItem) {
            NSString *path = _imageForConfigurationSelectViewItem(buttonItem,idx,item);
            
            [buttonItem setImage:[UIImage imageWithContentsOfFile:path] forState:UIControlStateNormal];
        }else{
            if (_titleForConfigurationSelectViewItem) {
                NSString *title = _titleForConfigurationSelectViewItem(buttonItem,idx,item);
                [buttonItem setTitle:title forState:UIControlStateNormal];
            }
        }
        
        [buttonItem setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [buttonItem setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        buttonItem.titleLabel.textAlignment = NSTextAlignmentCenter;
        buttonItem.titleLabel.font = [UIFont systemFontOfSize:12.0];
        buttonItem.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        
        buttonItem.backgroundColor = [UIColor clearColor];
        //        [buttonItem setBackgroundImage:[self createImageWithColor:[UIColor colorWithRed:0.925 green:0.906 blue:0.882 alpha:1.000]] forState:UIControlStateSelected];
        
        buttonItem.titleEdgeInsets = UIEdgeInsetsMake(5, 5, 5, 5);
        
        buttonItem.frame = CGRectMake(contentSize, 0, self.frame.size.height,self.frame.size.height);
        contentSize += self.frame.size.height;
        
        contentSize += 11;
        
        buttonItem.tag = 20000 + idx;
        [buttonItem addTarget:self action:@selector(touchAction:) forControlEvents:UIControlEventTouchDown];
        [self addSubview:buttonItem];
        
        //        if (idx ==0) {
        //            [self touchAction:buttonItem];
        //        }
        
    }
    
    self.contentSize = CGSizeMake(contentSize,0 );
    
}
- (void)touchAction:(UIButton*)sender{
    for (UIButton *button in self.subviews) {
        if (button.tag == sender.tag) {
            button.selected = YES;
            if (_didSelectConfigurationSelectViewItem) {
                _didSelectConfigurationSelectViewItem(button,button.tag-20000,[self.items objectAtIndex:button.tag-20000]);
            }
        }else
        {
            button.selected = NO;
            button.backgroundColor = [UIColor clearColor];
        }
    }
    
    //    if (_touchCarShowColorButton) {
    //        _touchCarShowColorButton(sender,sender.tag-20000,self.items[sender.tag-20000]);
    //    }
}
-(void)titleForConfigurationSelectViewItem:(TitleForConfigurationSelectViewItem)titleForConfigurationSelectViewItem{
    _titleForConfigurationSelectViewItem = [titleForConfigurationSelectViewItem copy];
    [self reloadData];
}
-(void)imageForConfigurationSelectViewItem:(ImageForConfigurationSelectViewItem)imageForConfigurationSelectViewItem{
    _imageForConfigurationSelectViewItem = [imageForConfigurationSelectViewItem copy];
    [self reloadData];
}
-(void)didSelectConfigurationSelectViewItem:(DidSelectConfigurationSelectViewItem)didSelectConfigurationSelectViewItem{
    _didSelectConfigurationSelectViewItem = [didSelectConfigurationSelectViewItem copy];
    [self reloadData];
}
@end
