//
//  ConfigurationMenu.m
//  DSPA2015
//
//  Created by runlin on 16/7/21.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ConfigurationMenu.h"
#import "ConfigurationCell.h"
@implementation ConfigurationMenu
+(ConfigurationMenu*)menu{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ConfigurationMenu" owner:nil options:nil];
    return [nibView lastObject];
}
-(void)setItems:(NSArray *)items{
    _items = items;
    [self.myTableView reloadData];
}
-(void)awakeFromNib{
    [super awakeFromNib];
    self.myTableView.dataSource = self;
    self.myTableView.delegate = self;
    self.myTableView.backgroundColor = [UIColor clearColor];
}
-(void)titleForConfigurationMenuItem:(TitleForConfigurationMenuItem)titleForConfigurationMenuItem{
    _titleForConfigurationMenuItem = [titleForConfigurationMenuItem copy];
}
-(void)imageForConfigurationMenuItem:(ImageForConfigurationMenuItem)imageForConfigurationMenuItem{
    _imageForConfigurationMenuItem = [imageForConfigurationMenuItem copy];
}
-(void)didSelectConfigurationMenuItem:(DidSelectConfigurationMenuItem)didSelectConfigurationMenuItem{
    _didSelectConfigurationMenuItem = [didSelectConfigurationMenuItem copy];
}
#pragma -mark TableView Delegate  Config Select
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    id item = [self.items objectAtIndex:indexPath.row];
    if([[item valueForKey:@"hidden"] boolValue]){
        return 0.01;
    }else{
        return 93;
    }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.items count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"ConfigurationCell";
    
    [tableView registerNib:[UINib nibWithNibName:@"ConfigurationCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
    
    //[tableView registerClass:[NewsCell class] forCellReuseIdentifier:CellIdentifier];
    
    ConfigurationCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell.clipsToBounds = YES;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.contentView.backgroundColor = [UIColor clearColor];
    cell.backgroundColor = [UIColor clearColor];
    
    id item = [self.items objectAtIndex:indexPath.row];
    
    if (_imageForConfigurationMenuItem) {
        NSString *path = _imageForConfigurationMenuItem(cell,indexPath.row,item);
        cell.icon.image = [UIImage imageWithContentsOfFile:path];
        
    }
    if (_titleForConfigurationMenuItem) {
        NSString *title = _titleForConfigurationMenuItem(cell,indexPath.row,item);
        cell.nameLabel.text = title;
    }
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ConfigurationCell *cell = [tableView  cellForRowAtIndexPath:indexPath];
    id item = [self.items objectAtIndex:indexPath.row];
    if (_didSelectConfigurationMenuItem) {
        _didSelectConfigurationMenuItem(cell,indexPath.row,item);
    }
}

-(void)show:(BOOL)isShow animate:(BOOL)animate{
    //    CATransition *transition = [CATransition animation];
    //    transition.duration = .3f;
    //    transition.type = kCATransitionMoveIn;
    //    transition.subtype = kCATransitionFromRight;
    //    [self.configurationSelectView.layer addAnimation:transition forKey:nil];
    //    [self.view addSubview:self.configurationSelectView];
    //
    //    self.rightArrowView.hidden = !isShow;
    if (isShow) {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = self.frame;
            frame.size.width = 100;
            frame.origin.x -=100;
            self.frame = frame;
        } completion:^(BOOL finished) {
            
        }];
    }else{
        if (animate) {
            [UIView animateWithDuration:0.3 animations:^{
                CGRect frame =self.frame;
                frame.origin.x +=100;
                frame.size.width = 0;
                self.frame = frame;
            } completion:^(BOOL finished) {
                [self removeFromSuperview];
            }];
        }else{
            [self removeFromSuperview];
        }
        
    }
    [self.myTableView reloadData];
}
@end
