//
//  ConfigurationMenu.h
//  DSPA2015
//
//  Created by runlin on 16/7/21.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ConfigurationCell;
typedef NSString*(^TitleForConfigurationMenuItem)(ConfigurationCell *cell,NSInteger index,id item);
typedef NSString*(^ImageForConfigurationMenuItem)(ConfigurationCell *cell,NSInteger index,id item);
typedef void (^DidSelectConfigurationMenuItem)(ConfigurationCell *cell,NSInteger index,id item);


@interface ConfigurationMenu : UIView<UITableViewDelegate,UITableViewDataSource>
{
    TitleForConfigurationMenuItem _titleForConfigurationMenuItem;
    ImageForConfigurationMenuItem _imageForConfigurationMenuItem;
    DidSelectConfigurationMenuItem _didSelectConfigurationMenuItem;
}
+(ConfigurationMenu*)menu;
@property (strong, nonatomic) NSArray *items;

@property (weak, nonatomic) IBOutlet UITableView *myTableView;

-(void)titleForConfigurationMenuItem:(TitleForConfigurationMenuItem)titleForConfigurationMenuItem;
-(void)imageForConfigurationMenuItem:(ImageForConfigurationMenuItem)imageForConfigurationMenuItem;
-(void)didSelectConfigurationMenuItem:(DidSelectConfigurationMenuItem)didSelectConfigurationMenuItem;

-(void)show:(BOOL)isShow animate:(BOOL)animate;
@end
