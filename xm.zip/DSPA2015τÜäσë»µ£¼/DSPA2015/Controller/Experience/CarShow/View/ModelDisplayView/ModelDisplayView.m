//
//  ModelDisplayView.m
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ModelDisplayView.h"
#import "Car.h"
#import "ModelDisplayCell.h"
@implementation ModelDisplayView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setItems:(NSArray *)items{
    _items = items;
    
    if (!_modelScrollView) {
        _modelScrollView = [[UIScrollView alloc]initWithFrame:self.bounds];
        _modelScrollView.pagingEnabled = YES;
        _modelScrollView.bounces = NO;
        _modelScrollView.delegate =self;
        [self addSubview:_modelScrollView];
    }
    if (!_preButton) {
        _preButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_preButton setImage:[UIImage imageNamed:@"carshow_button_pre_car"] forState:UIControlStateNormal];
        _preButton.frame = CGRectMake(60, self.bounds.size.height/2-80, 60, 60);
        [self addSubview:_preButton];
    }
    if (!_nextButton) {
        _nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_nextButton setImage:[UIImage imageNamed:@"carshow_button_next_car"] forState:UIControlStateNormal];
        _nextButton.frame = CGRectMake(CGRectGetWidth(self.bounds)-60-30, self.bounds.size.height/2-80, 60, 60);
        [self addSubview:_nextButton];
    }
    if (!_nocarImageView) {
        _nocarImageView = [[UIImageView alloc]initWithFrame:self.bounds];
        
        _nocarImageView.frame = CGRectMake(self.edge.left, 0, CGRectGetWidth(self.bounds)-self.edge.left-self.edge.right, CGRectGetHeight(self.bounds));
        CGPoint center = _nocarImageView.center;
        center.y = self.frame.size.height/2+20;
        _nocarImageView.center = center;
        
        
        _nocarImageView.contentMode = UIViewContentModeScaleAspectFit;
        if (_nocarImageView.frame.size.height>400) {
            _nocarImageView.image = [UIImage imageNamed:@"carshow_nocar_new.png"];
            
        }else{
            _nocarImageView.image = [UIImage imageNamed:@"carshow_nocar_new.png"];
        }
        [self addSubview:_nocarImageView];
    }
    if (!_pageControl) {
        _pageControl = [[UIPageControl alloc]initWithFrame: CGRectMake(0, 0, 200, 60)];
        _pageControl.center = CGPointMake(self.frame.size.width/2, self.frame.size.height-60);
        [self addSubview:_pageControl];
    }
    _nocarImageView.hidden = ([_items count]==0) ?NO:YES;
    _nextButton.hidden = ([_items count]<=1)?YES:NO;
    _preButton.hidden = YES;
    _pageControl.hidden = ([_items count]<=1)?YES:NO;
    
    [_modelScrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];_modelScrollView.contentSize = CGSizeZero;
    [_items enumerateObjectsUsingBlock:^(Car *m, NSUInteger idx, BOOL *stop) {
        
        ModelDisplayCell *cell =[[ModelDisplayCell alloc] initWithFrame:CGRectMake((self.frame.size.width)*idx, 0,(self.frame.size.width), (self.frame.size.height))];
        cell.item = m;
        cell.edge = self.edge;
        cell.tag = idx;
        cell.userInteractionEnabled = YES;
        [cell addGestureRecognizer: [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(itemTap:)]];
        [_modelScrollView addSubview:cell];
    }];
    _modelScrollView.contentSize = CGSizeMake(self.frame.size.width*[_items count], self.frame.size.height);
    _pageControl.numberOfPages = [self.items count];
    NSLog(@"_modelScrollView.subviews count:%zd",[_modelScrollView.subviews count]);

}
-(void)itemTap:(UITapGestureRecognizer*)tap{
    Car *info = [_items objectWithIndex:tap.view.tag];
    if (_modelDisplayViewItemTouched) {
        _modelDisplayViewItemTouched(info);
    }

}
-(void)modelDisplayViewItemTouched:(ModelDisplayViewItemTouched)modelDisplayViewItemTouched{
    _modelDisplayViewItemTouched = [modelDisplayViewItemTouched copy];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat pageWidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    _pageControl.currentPage = page;
    _preButton.hidden  = NO;
    _nextButton.hidden = NO;
    
    if(page==0){
        _preButton.hidden  = YES;
        if ([_items count]>1) {
            _nextButton.hidden = NO;

        }
    }
    if (page==[_items count]-1) {
        _nextButton.hidden = YES;
        if ([_items count]>1) {
            _preButton.hidden  = NO;
        }
    }

    
}

@end
