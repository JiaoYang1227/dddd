//
//  ModelDisplayCell.h
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Car.h"
@interface ModelDisplayCell : UIView
@property(nonatomic,strong) UIImageView *imageView;
@property(nonatomic,strong) UILabel *nameLabel;
@property(nonatomic,strong) UIImageView *icon;
@property(nonatomic,strong) Car *item;
@property(nonatomic)UIEdgeInsets edge;
@property(nonatomic,strong) UIImageView *enterImageView;

@end
