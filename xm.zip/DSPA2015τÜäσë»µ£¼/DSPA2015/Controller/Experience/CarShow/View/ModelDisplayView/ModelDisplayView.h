//
//  ModelDisplayView.h
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^ModelDisplayViewItemTouched)(id item);
@interface ModelDisplayView : UIView<UIScrollViewDelegate>
{
    UIScrollView *_modelScrollView;
    ModelDisplayViewItemTouched _modelDisplayViewItemTouched;
    UIButton *_nextButton;
    UIButton *_preButton;
    UIImageView *_nocarImageView;
    UIPageControl *_pageControl;

}
@property(nonatomic,strong)NSArray *items;
@property(nonatomic)UIEdgeInsets edge;

-(void)modelDisplayViewItemTouched:(ModelDisplayViewItemTouched)modelDisplayViewItemTouched;
@end
