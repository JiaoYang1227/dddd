//
//  ModelDisplayCell.m
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ModelDisplayCell.h"
#import "Car.h"
@implementation ModelDisplayCell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setItem:(Car *)item{
    _item = item;
    self.imageView.image = [UIImage imageWithContentsOfFile:[item.baseDir stringByAppendingPathComponent:item.showImage]];
    self.nameLabel.text =   item.name;
//    self.imageView.userInteractionEnabled = YES;
    if (item) {
//        self.enterImageView.hidden = NO;
    }
    
}
-(void)setEdge:(UIEdgeInsets)edge{
    _edge = edge;
    self.imageView.frame = CGRectMake(self.edge.left, self.edge.top, CGRectGetWidth(self.bounds)-self.edge.left-self.edge.right, CGRectGetHeight(self.bounds)-self.edge.top-self.edge.bottom);
    
}
-(UIImageView *)imageView{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:self.bounds];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;

        [self addSubview:_imageView];
    }
    return _imageView;
}
-(UILabel *)nameLabel{
    if (!_nameLabel) {
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.bounds)-66-50, CGRectGetWidth(self.bounds), 50)];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
        _nameLabel.textColor = [UIColor whiteColor];
        [self addSubview:_nameLabel];
    }
    return _nameLabel;
}
-(UIImageView *)enterImageView{
    if (!_enterImageView) {
//        _enterImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.bounds)-16, CGRectGetWidth(self.bounds), 16)];
        _enterImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.bounds)-16-50, CGRectGetWidth(self.bounds), 16)];
        _enterImageView.image = [UIImage imageNamed:@"carshow_image_enter_mark.png"];
        _enterImageView.contentMode =  UIViewContentModeScaleAspectFit;
        [self addSubview:_enterImageView];
    }
    return _enterImageView;
}
@end
