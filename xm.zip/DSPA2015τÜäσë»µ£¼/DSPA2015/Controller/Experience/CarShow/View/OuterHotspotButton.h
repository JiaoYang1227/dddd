//
//  LightspotButton.h
//  CarShow
//
//  Created by Jakey on 15/6/23.
//  Copyright © 2015年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OuterHotspotButton;
typedef void (^HotspotButtonBlock)(OuterHotspotButton *spot);


@interface OuterHotspotButton : UIButton<CAAnimationDelegate>
{
    HotspotButtonBlock _hotspotButtonBlock;
    CAShapeLayer *_circleShape;

}
-(void)addActionHandler:(HotspotButtonBlock)touchHandler;
@property (nonatomic, strong) UIColor *flashColor;
@property (nonatomic, strong)NSDictionary *pointDic;
@end
