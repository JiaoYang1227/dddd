//
//  FlashMenuButton.h
//  DSPA2015
//
//  Created by Jakey on 15/11/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlashMenuButton : UIButton
{
    UILabel                 *labelTitle_;
    UIImageView             *imageView_;
    NSArray                 *imageArray_;
    NSArray                 *imageArray2_;
}
@property (nonatomic)        BOOL     check;
@property (nonatomic)  int currentIndex;

- (void) setTitle:(NSString*)title;
- (void) setArray:(NSArray*)array;
- (void) setButtonSelected:(BOOL)selected animated:(BOOL)animated;
- (void) setChecked:(BOOL)checked;
@end
