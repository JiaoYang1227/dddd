//
//  FlashMenuButtonSubMenu.m
//  DSPA2015
//
//  Created by Jakey on 15/11/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "FlashMenuButtonSubMenu.h"
#define BACKGROUND_BLACK_ALPHA      @"carshow_background_black_alpha.png"
#define BACKGROUND_MENU3_COLSE      @"carshow_flashSubMenu_close.png"
#define BACKGROUND_MENU3_ITEM       @"carshow_flashSubMenu_item.png"
#define BACKGROUND_MENU3_ITEM_H     @"carshow_flashSubMenu_item_h.png"

#define TITLE_MENU3_OVERALL_1       @"360"
#define TITLE_MENU3_OVERALL_2       @"全景"
#define TITLE_MENU3_CONFIG          @"选配"
#define TITLE_MENU3_HIGHLIGHT       @"亮点"

#define TITLE_MENU4_ANGLE_1         @"45度"
#define TITLE_MENU4_ANGLE_2         @"车头"
#define TITLE_MENU4_ANGLE_3         @"车尾"
@implementation FlashMenuButtonSubMenu


- (id)initWithOrigin:(CGPoint)origin;
{
    _origin = origin;
    CGRect frame = CGRectMake(0, 0, 1024, 768);
    self = [super initWithFrame:frame];
    if (self)
    {
        self.userInteractionEnabled = YES;
        self.image = [UIImage imageNamed:BACKGROUND_BLACK_ALPHA];
        
        parentMenuIndex_ = 0;
        [self initButtons];
    }
    
    return self;
}

- (void) initButtons
{
    UIImage *img = [UIImage imageNamed:BACKGROUND_MENU3_COLSE];
    buttonClose_ = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonClose_ setImage:img forState:UIControlStateNormal];
    [buttonClose_ addTarget:self
                     action:@selector(actionOnTouchCloseButton:)
           forControlEvents:UIControlEventTouchUpInside];
    
    float fontSize  = 14;
    UIImage  *imageN= [UIImage imageNamed:BACKGROUND_MENU3_ITEM];
    UIImage  *imageH= [UIImage imageNamed:BACKGROUND_MENU3_ITEM_H];
    NSString *title = TITLE_MENU3_OVERALL_1;
    buttonOverView_ = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonOverView_ setBackgroundImage:imageN forState:UIControlStateNormal];
    [buttonOverView_ setBackgroundImage:imageH forState:UIControlStateSelected];
    [buttonOverView_ setTitle:title forState:UIControlStateNormal];
    [buttonOverView_ setTitle:title forState:UIControlStateSelected];
    buttonOverView_.titleLabel.font = [UIFont boldSystemFontOfSize:fontSize];
    [buttonOverView_ addTarget:self
                        action:@selector(actionOnTouchOverViewButton:)
              forControlEvents:UIControlEventTouchUpInside];
    
    title = TITLE_MENU3_CONFIG;
    buttonConfigure_ = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonConfigure_ setBackgroundImage:imageN forState:UIControlStateNormal];
    [buttonConfigure_ setBackgroundImage:imageH forState:UIControlStateSelected];
    [buttonConfigure_ setTitle:title forState:UIControlStateNormal];
    [buttonConfigure_ setTitle:title forState:UIControlStateSelected];
    buttonConfigure_.titleLabel.font = [UIFont boldSystemFontOfSize:fontSize];
    [buttonConfigure_ addTarget:self
                         action:@selector(actionOnTouchConfigureButton:)
               forControlEvents:UIControlEventTouchUpInside];
    
    title = TITLE_MENU3_HIGHLIGHT;
    buttonHighLight_ = [UIButton buttonWithType:UIButtonTypeCustom];
    [buttonHighLight_ setBackgroundImage:imageN forState:UIControlStateNormal];
    [buttonHighLight_ setBackgroundImage:imageH forState:UIControlStateSelected];
    [buttonHighLight_ setTitle:title forState:UIControlStateNormal];
    [buttonHighLight_ setTitle:title forState:UIControlStateSelected];
    buttonHighLight_.titleLabel.font = [UIFont boldSystemFontOfSize:fontSize];
    [buttonHighLight_ addTarget:self
                         action:@selector(actionOnTouchHighLightButton:)
               forControlEvents:UIControlEventTouchUpInside];
}

- (void) actionOnTouchCloseButton:(id)sender
{
    [self removeFromSuperview];
    //1就是无选择关闭啦
    if (_didSelectFlashMenuItem) {
        _didSelectFlashMenuItem(-1,-1);
    }
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self removeFromSuperview];
    //-1就是无选择关闭啦
    if (_didSelectFlashMenuItem) {
        _didSelectFlashMenuItem(-1,-1);
    }
}
-(void)didSelectFlashMenuItem:(DidSelectFlashMenuItem)didSelectFlashMenuItem{
    _didSelectFlashMenuItem = [didSelectFlashMenuItem copy];
}
//360/720
- (void) actionOnTouchOverViewButton:(id)sender
{
    buttonOverView_.selected  = YES;
    buttonConfigure_.selected = NO;
    buttonHighLight_.selected = NO;
    
    [self removeFromSuperview];
    
    if (_didSelectFlashMenuItem) {
        _didSelectFlashMenuItem(-1,0);
    }
}
//选配
- (void) actionOnTouchConfigureButton:(id)sender
{
    buttonOverView_.selected  = NO;
    buttonConfigure_.selected = YES;
    buttonHighLight_.selected = NO;
    
    [self removeFromSuperview];
    if (_didSelectFlashMenuItem) {
        _didSelectFlashMenuItem(SubMenuTypeOuter,1);
    }

}
//亮点
- (void) actionOnTouchHighLightButton:(id)sender
{
    buttonOverView_.selected  = NO;
    buttonConfigure_.selected = NO;
    buttonHighLight_.selected = YES;
    
    [self removeFromSuperview];
    
    if (parentMenuIndex_ == SubMenuTypeOuter)
    {
        if (_didSelectFlashMenuItem) {
            _didSelectFlashMenuItem(SubMenuTypeOuter,2);
        }
    }
    
    if (parentMenuIndex_ == SubMenuTypeInner)
    {
        if (_didSelectFlashMenuItem) {
            _didSelectFlashMenuItem(SubMenuTypeInner,1);
        }
    }
}

- (void)showSubMenuWithType:(SubMenuType)type andSelectIndex:(int)selectIndex
{
    parentMenuIndex_ = type;
    
    float w = 40;
    float h = 40;
    
    if (type == SubMenuTypeOuter)
    {
        NSString *title = TITLE_MENU3_OVERALL_1;
        [buttonOverView_ setTitle:title forState:UIControlStateNormal];
        [buttonOverView_ setTitle:title forState:UIControlStateSelected];
        
        float x = _origin.x;
        float y = _origin.y;
        CGRect frame = CGRectMake(x, y, 0, 0);
        
        buttonOverView_.frame   = frame;
        [self addSubview:buttonOverView_];
        
        buttonConfigure_.frame  = frame;
        [self addSubview:buttonConfigure_];
        
        buttonHighLight_.frame  = frame;
        [self addSubview:buttonHighLight_];
        
        buttonClose_.frame      = CGRectMake(x - 3, y, 66, 52);
        [self addSubview:buttonClose_];
        
        if (selectIndex == 0 || selectIndex == -1)
        {
            buttonOverView_.selected  = YES;
            buttonConfigure_.selected = NO;
            buttonHighLight_.selected = NO;
        }
        
        if (selectIndex == 1)
        {
            buttonOverView_.selected  = NO;
            buttonConfigure_.selected = YES;
            buttonHighLight_.selected = NO;
        }
        
        if (selectIndex == 2)
        {
            buttonOverView_.selected  = NO;
            buttonConfigure_.selected = NO;
            buttonHighLight_.selected = YES;
        }
        
        [UIView animateWithDuration:0.25
                         animations:^{
                             
                             buttonOverView_.frame   = CGRectMake(frame.origin.x - 60,
                                                                  frame.origin.y - 9,
                                                                  w, h);
                             
                             buttonConfigure_.frame  = CGRectMake(frame.origin.x - 56.5,
                                                                  frame.origin.y + 40.5,
                                                                  w, h);
                             
                             buttonHighLight_.frame  = CGRectMake(frame.origin.x - 17.5,
                                                                  frame.origin.y + 74,
                                                                  w, h);
                             
                         } completion:^(BOOL finished) {
                             
                         }];
    }
    
    if (type == SubMenuTypeInner)
    {
        NSString *title = TITLE_MENU3_OVERALL_2;
        [buttonOverView_ setTitle:title forState:UIControlStateNormal];
        [buttonOverView_ setTitle:title forState:UIControlStateSelected];
        
        float x = _origin.x;
        float y = _origin.y;
        CGRect frame = CGRectMake(x, y, 0, 0);
        
        buttonOverView_.frame   = frame;
        [self addSubview:buttonOverView_];
        
        [buttonConfigure_ removeFromSuperview];
        
        buttonHighLight_.frame  = frame;
        [self addSubview:buttonHighLight_];
        
        buttonClose_.frame      = CGRectMake(x -3, y, 66, 52);
        [self addSubview:buttonClose_];
        
        if (selectIndex == 0  || selectIndex == -1)
        {
            buttonOverView_.selected  = YES;
            buttonHighLight_.selected = NO;
        }
        
        if (selectIndex == 1)
        {
            buttonOverView_.selected  = NO;
            buttonHighLight_.selected = YES;
        }
        
        [UIView animateWithDuration:0.25
                         animations:^{
                             
                             buttonOverView_.frame   = CGRectMake(frame.origin.x - 60,
                                                                  frame.origin.y - 9,
                                                                  w, h);
                             
                             buttonHighLight_.frame  = CGRectMake(frame.origin.x - 47.5,
                                                                  frame.origin.y + 40.5,
                                                                  w, h);
                             
                         } completion:^(BOOL finished) {
                             
                         }];
    }
    
    if (type == SubMenuTypeCompare)
    {
    
    
    }

}


@end
