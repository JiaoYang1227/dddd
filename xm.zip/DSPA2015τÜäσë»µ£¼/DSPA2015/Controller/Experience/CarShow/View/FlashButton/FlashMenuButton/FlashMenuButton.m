//
//  FlashMenuButton.m
//  DSPA2015
//
//  Created by Jakey on 15/11/13.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "FlashMenuButton.h"
#define MENU_ITEM_WIDTH         290 / 2
#define MENU_ITEM_HEIGHT        104 / 2
#define MENU_ITEM_SPACE         10

#define BACKGROUND_MENU2_CLOSE      @"carshow_flash_background_menu2_close.png"
#define BACKGROUND_MENU2_OPEN       @"carshow_flash_background_menu2_open.png"
@implementation FlashMenuButton

- (id) init
{
    self = [super init];
    if (self)
    {
        self.frame = CGRectMake(100, 0 + 20, 145, 52);
        
        CGRect rect = CGRectMake(MENU_ITEM_HEIGHT + 16,
                                 MENU_ITEM_HEIGHT - 14 - 15,
                                 46, 16);
        labelTitle_ = [[UILabel alloc]initWithFrame:rect];
        labelTitle_.backgroundColor = [UIColor clearColor];
        labelTitle_.textColor = [UIColor whiteColor];
        labelTitle_.font = [UIFont systemFontOfSize:16];
        labelTitle_.textAlignment = NSTextAlignmentCenter;
        [self addSubview:labelTitle_];
        
        imageView_  = [[UIImageView alloc]init];
        imageView_.frame = CGRectMake(0, 0, 145, 52);
        [self addSubview:imageView_];
    }
    
    return self;
}
-(void)willMoveToSuperview:(UIView *)newSuperview{
    if (newSuperview) {
//        self.frame = CGRectMake(100, 0 + 20, 145, 52);
        
        CGRect rect = CGRectMake(MENU_ITEM_HEIGHT + 16,
                                 MENU_ITEM_HEIGHT - 14 - 15,
                                 46, 16);
        labelTitle_ = [[UILabel alloc]initWithFrame:rect];
        labelTitle_.backgroundColor = [UIColor clearColor];
        labelTitle_.textColor = [UIColor whiteColor];
        labelTitle_.font = [UIFont systemFontOfSize:16];
        labelTitle_.textAlignment = NSTextAlignmentCenter;
        [self addSubview:labelTitle_];
        
        imageView_  = [[UIImageView alloc]init];
        imageView_.frame = CGRectMake(0, 0, 145, 52);
        [self addSubview:imageView_];
        self.backgroundColor = [UIColor clearColor];
        [self setArray:[self menuItemImages]];
    }
}
- (void) setTitle:(NSString*)title
{
    labelTitle_.text = title;
}

- (void) setArray:(NSArray*)array
{
    imageArray_ = array;
    
    if (imageArray_ != nil && imageArray_.count >= 38)
    {
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 37; i > 0; i--)
        {
            [array addObject:[imageArray_ objectAtIndex:i]];
        }
        imageArray2_ = array;
        
        imageView_.image = [imageArray_ objectAtIndex:0];
    }
}

- (void) setButtonSelected:(BOOL)selected animated:(BOOL)animated
{
    self.selected = selected;
    
    if (animated == YES)
    {
        if (selected == YES)
        {
            NSTimeInterval interval = 2.5;
            
            imageView_.animationImages = imageArray_;
            imageView_.animationRepeatCount = 1;
            imageView_.animationDuration = interval;
            if (imageArray_ != nil && imageArray_.count >= 38)
            {
                imageView_.image = [imageArray_ objectAtIndex:37];
            }
            labelTitle_.textColor = [UIColor colorWithRed:0.890 green:0.027 blue:0.145 alpha:1.000];

            [imageView_ startAnimating];
        }
        else
        {
            NSTimeInterval interval = 0.2;
            
            imageView_.animationImages = imageArray2_;
            imageView_.animationRepeatCount = 1;
            imageView_.animationDuration = interval;
            imageView_.image = [UIImage imageNamed:BACKGROUND_MENU2_CLOSE];
            labelTitle_.textColor = [UIColor whiteColor];

            [imageView_ startAnimating];
        }
    }
    else
    {
        [imageView_ stopAnimating];
        if (selected == YES)
        {
            imageView_.image = [UIImage imageNamed:BACKGROUND_MENU2_OPEN];
            labelTitle_.textColor = [UIColor colorWithRed:0.890 green:0.027 blue:0.145 alpha:1.000];

        }
        else
        {
            imageView_.image = [UIImage imageNamed:BACKGROUND_MENU2_CLOSE];
            labelTitle_.textColor = [UIColor whiteColor];

        }
    }
}

- (void) setChecked:(BOOL)checked
{
    self.check = checked;
    imageView_.image = [UIImage imageNamed:BACKGROUND_MENU2_CLOSE];

    if (checked == YES)
    {
        labelTitle_.textColor = [UIColor colorWithRed:227.0 / 255.0
                                                green:7.0 / 255.0
                                                 blue:37.0 / 255.0
                                                alpha:1.0];
    }
    else
    {
        labelTitle_.textColor = [UIColor whiteColor];
    }
}
- (NSArray*)menuItemImages
{
    NSMutableArray *array = [NSMutableArray array];
    for (int i = 0; i <= 37; i++)
    {
        NSString *imageName = nil;
        if (i <= 8)
        {
            imageName =[NSString stringWithFormat:@"carshow_flash_button_menu2_0%zd.png", i + 1];
        }
        else
        {
            imageName =[NSString stringWithFormat:@"carshow_flash_button_menu2_%zd.png", i + 1];
        }
        UIImage *image = [UIImage imageNamed:imageName];
        [array addObject:image];
    }
    return array;
    
}
@end
