//
//  FlashButton.m
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "FlashButton.h"
#define FONT_NAME_HEITI             @"STHeitiTC-Medium"
#define FONT_NAME_ARINL             @"ArialMT"

#define DEFAULT_FONT(size)          [UIFont systemFontOfSize:size]
@implementation FlashButton

- (id) initWithStyle:(CarBrandButtonStyle)style
{
    self = [super init];
    if (self)
    {
        self.frame = CGRectMake(100, 0, 113 + 44, 93);
        self.backgroundColor = [UIColor clearColor];
        
        CGRect rect1 = CGRectZero;
        CGRect rect2 = CGRectZero;
        if (style == CarBrandButtonStyleLeft)
        {
            //rect1 = CGRectMake(0, 34, 44, 44);
            rect1 = CGRectMake(60, 37, 44, 44);
            rect2 = CGRectMake(44, 0, 113, 93);
            [self setArray:[self leftImageArray]];
        }
        
        if (style == CarBrandButtonStyleRight)
        {
            rect1 = CGRectMake(55, 37, 44, 44);
            rect2 = CGRectMake(0, 0, 113, 93);
            [self setArray:[self rightImageArray]];

        }
        
        _labelTitle = [[UILabel alloc]initWithFrame:rect1];
        _labelTitle.backgroundColor = [UIColor clearColor];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        
        [self addSubview:_labelTitle];
        [self setChecked:NO animated:NO];
        
        _imageView  = [[UIImageView alloc]init];
        _imageView.frame = rect2;
        //imageView_.backgroundColor = [UIColor redColor];
        [self addSubview:_imageView];
        
        
        _style = style;
        _postion = CGPointZero;
    }
    
    return self;
}
-(NSArray*)leftImageArray{
    NSMutableArray *leftImageArray = [NSMutableArray array];
    for (int i = 0; i <= 34; i++)
    {
        NSString *imageName = nil;
        if (i <= 8)
        {
            imageName =[NSString stringWithFormat:@"carshow_flash_button_left_0%zd.png", i + 1];
        }
        else
        {
            imageName =[NSString stringWithFormat:@"carshow_flash_button_left_%zd.png", i + 1];
        }
        UIImage *image = [UIImage imageNamed:imageName];
        [leftImageArray addObject:image];
    }
    return leftImageArray;

}
-(NSArray*)rightImageArray{
    
    NSMutableArray *rightImageArray = [NSMutableArray array];
    for (int i = 0; i <= 34; i++)
    {
        NSString *imageName = nil;
        if (i <= 8)
        {
            imageName =[NSString stringWithFormat:@"carshow_flash_button_right_0%zd.png", i + 1];
        }
        else
        {
            imageName =[NSString stringWithFormat:@"carshow_flash_button_right_%zd.png", i + 1];
        }
        UIImage *image = [UIImage imageNamed:imageName];
        [rightImageArray addObject:image];
    }
    return rightImageArray;
}
- (void) setTitle:(NSString*)title
{
    _labelTitle.text = title;
}

- (void) setArray:(NSArray*)array
{
    _imageArray = array;
    
    if (_imageArray != nil && _imageArray.count >= 35)
    {
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 34; i > 0; i--)
        {
            [array addObject:[_imageArray objectAtIndex:i]];
        }
        _imageArray2 = array;
        
        _imageView.image = [_imageArray objectAtIndex:0];
    }
}

- (void) setPosition:(CGPoint)position
{
    self.frame = CGRectMake(position.x,
                            position.y,
                            self.bounds.size.width,
                            self.bounds.size.height);
}
- (void) setButtonSelected:(BOOL)selected{
    [self setButtonSelected:selected animated:NO];
}
- (void) setButtonSelected:(BOOL)selected animated:(BOOL)animated
{
    self.selected = selected;
    
    if (animated == YES)
    {
        if (selected == YES)
        {
            NSTimeInterval interval = 2.5;
            
            _imageView.animationImages = _imageArray;
            _imageView.animationRepeatCount = 1;
            _imageView.animationDuration = interval;
            if (_imageArray != nil && _imageArray.count >= 35)
            {
                _imageView.image = [_imageArray objectAtIndex:34];
            }
            
            [_imageView startAnimating];
        }
        else
        {
            NSTimeInterval interval = 0.3;
            
            _imageView.animationImages = _imageArray2;
            _imageView.animationRepeatCount = 1;
            _imageView.animationDuration = interval;
            if (_imageArray != nil && _imageArray.count >= 35)
            {
                _imageView.image = [_imageArray objectAtIndex:0];
            }
            
            [_imageView startAnimating];
        }
        
        [self setChecked:selected animated:YES];
    }
    else
    {
        [_imageView stopAnimating];
        if (selected == YES)
        {
            if (_imageArray != nil && _imageArray.count >= 35)
            {
                _imageView.image = [_imageArray objectAtIndex:34];
            }
        }
        else
        {
            if (_imageArray != nil && _imageArray.count >= 35)
            {
                _imageView.image = [_imageArray objectAtIndex:0];
            }
        }
        
        [self setChecked:selected animated:NO];
    }
}

- (void) setChecked:(BOOL)checked animated:(BOOL)animated
{
    self.check = checked;
    
    if (animated == YES)
    {
        if (checked == YES)
        {
            UIFont   *font      = [UIFont fontWithName:FONT_NAME_ARINL size:22];
            UIColor  *fontColor = [UIColor whiteColor];
            
            _labelTitle.textColor = fontColor;
            _labelTitle.font = font;
            
            CGRect rect  = CGRectZero;
            if (_style == CarBrandButtonStyleLeft)
            {
                rect = CGRectMake(0, 34, 44, 44);
            }
            
            if (_style == CarBrandButtonStyleRight)
            {
                rect = CGRectMake(113, 37, 44, 44);
            }
            
            NSTimeInterval duration = 0.25;
            
            [UIView animateWithDuration:duration
                             animations:^{
                                 
                                 _labelTitle.frame = rect;
                                 
                             } completion:^(BOOL finished) {
                                 
                             }];
        }
        else
        {
            UIFont   *font      = [UIFont fontWithName:FONT_NAME_ARINL size:16];
            //            UIColor  *fontColor = [UIColor colorWithRed:165.0 / 255.0
            //                                                  green:165.0 / 255.0
            //                                                   blue:165.0 / 255.0
            //                                                  alpha:1.0];
            
            
            UIColor  *fontColor = [UIColor whiteColor];
            
            _labelTitle.textColor = fontColor;
            _labelTitle.font = font;
            
            CGRect rect1 = CGRectZero;
            if (_style == CarBrandButtonStyleLeft)
            {
                rect1 = CGRectMake(60, 37, 44, 44);
            }
            
            if (_style == CarBrandButtonStyleRight)
            {
                rect1 = CGRectMake(55, 37, 44, 44);
            }
            
            NSTimeInterval duration = 0.5;
            
            [UIView animateWithDuration:duration
                             animations:^{
                                 
                                 _labelTitle.frame = rect1;
                                 
                             } completion:^(BOOL finished) {
                                 
                             }];
            
        }
    }
    else
    {
        if (checked == NO)
        {
            CGRect rect= CGRectZero;
            if (_style == CarBrandButtonStyleLeft)
            {
                rect = CGRectMake(60, 37, 44, 44);
            }
            
            if (_style == CarBrandButtonStyleRight)
            {
                rect = CGRectMake(55, 37, 44, 44);
            }
            
            _labelTitle.frame = rect;
            
            UIFont   *font      = [UIFont fontWithName:FONT_NAME_ARINL size:16];
            //            UIColor  *fontColor = [UIColor colorWithRed:165.0 / 255.0
            //                                                  green:165.0 / 255.0
            //                                                   blue:165.0 / 255.0
            //                                                  alpha:1.0];
            
            
            UIColor  *fontColor = [UIColor whiteColor];
            
            _labelTitle.textColor = fontColor;
            _labelTitle.font = font;
        }
        else
        {
            CGRect rect= CGRectZero;
            if (_style == CarBrandButtonStyleLeft)
            {
                rect = CGRectMake(0, 34, 44, 44);
            }
            
            if (_style == CarBrandButtonStyleRight)
            {
                rect = CGRectMake(113, 37, 44, 44);
            }
            
            _labelTitle.frame = rect;
            
            UIFont   *font      = [UIFont fontWithName:FONT_NAME_ARINL size:22];
            UIColor  *fontColor = [UIColor whiteColor];
            _labelTitle.textColor = fontColor;
            _labelTitle.font = font;
        }
    }
}



@end
