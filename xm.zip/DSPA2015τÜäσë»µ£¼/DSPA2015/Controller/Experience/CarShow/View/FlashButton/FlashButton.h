//
//  FlashButton.h
//  DSPA2015
//
//  Created by Jakey on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, CarBrandButtonStyle) {
    CarBrandButtonStyleLeft=0,
    CarBrandButtonStyleRight =1
};
@interface FlashButton : UIButton
{
    CarBrandButtonStyle    _style;
    UILabel                 *_labelTitle;
    UIImageView             *_imageView;
    CGPoint                 _postion;
    NSArray                 *_imageArray;
    NSArray                 *_imageArray2;
}
@property(nonatomic)NSInteger index;
@property(nonatomic,strong)NSString *brandID;
@property (nonatomic) BOOL check;

- (id) initWithStyle:(CarBrandButtonStyle)style;
- (void) setTitle:(NSString*)title;
- (void) setArray:(NSArray*)array;
- (void) setPosition:(CGPoint)position;
- (void) setButtonSelected:(BOOL)selected animated:(BOOL)animated;
- (void) setButtonSelected:(BOOL)selected;
@end
