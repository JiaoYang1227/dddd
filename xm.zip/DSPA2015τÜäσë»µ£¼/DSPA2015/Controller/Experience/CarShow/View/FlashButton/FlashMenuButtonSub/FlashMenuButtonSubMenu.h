//
//  FlashMenuButtonSubMenu.h
//  DSPA2015
//
//  Created by Jakey on 15/11/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSUInteger, SubMenuType) {
    SubMenuTypeOuter = 0,
    SubMenuTypeInner,
   SubMenuTypeCompare
};
typedef void(^DidSelectFlashMenuItem)(SubMenuType type,int index);




@interface FlashMenuButtonSubMenu : UIImageView
{
    DidSelectFlashMenuItem              _didSelectFlashMenuItem;
    UIButton                            *buttonClose_;
    UIButton                            *buttonOverView_;
    UIButton                            *buttonConfigure_;
    UIButton                            *buttonHighLight_;
    CGPoint                             _origin;
    int                                 parentMenuIndex_;
}

- (id)initWithOrigin:(CGPoint)origin;
- (void)showSubMenuWithType:(SubMenuType)type andSelectIndex:(int)selectIndex;
-(void)didSelectFlashMenuItem:(DidSelectFlashMenuItem)didSelectFlashMenuItem;
@end
