//
//  MediaPlayerView.m
//  DSPA2015
//
//  Created by Jakey on 15/11/16.
//  Copyright © 2015年 www.runln.cn. All rights reserved.
//

#import "MediaPlayerView.h"
#import <AVFoundation/AVFoundation.h>
#import "AppDelegate.h"
#import "XTMoviePlayerController.h"
@implementation MediaPlayerView

+ (Class)layerClass
{
    return [AVPlayerLayer class];
}

- (AVPlayer*)player
{
    return [(AVPlayerLayer*)[self layer] player];
}

- (void)setPlayer:(AVPlayer*)mPlayer
{
    [(AVPlayerLayer*)[self layer] setPlayer:mPlayer];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor blackColor];
        
        buttonPlay_ = [UIButton buttonWithType:UIButtonTypeCustom];
        
        float width = 80;
        buttonPlay_.frame = CGRectMake((CGRectGetWidth(frame)  - width) / 2,
                                       (CGRectGetHeight(frame) - width) / 2,
                                       width, width);
        [buttonPlay_ setImage:[UIImage imageNamed:@"bigPlay.png"]
                     forState:UIControlStateNormal];
        [buttonPlay_ addTarget:self
                        action:@selector(actionOnTouchPlayButton)
              forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:buttonPlay_];
    }
    return self;
}

- (void) actionOnTouchPlayButton
{
    //buttonPlay_.hidden = YES;
    //[self play];
    XTMoviePlayerController *player = [[XTMoviePlayerController alloc] initWithContentURL:videoUrl_];
    [player startPlaying:[AppDelegate APP].rootViewController withBlock:^{
        NSLog(@"start play movie");
    }];
    [player didPlayFinished:^{
        NSLog(@"finished");
    }];
    NSLog(@"%f,%f",player.moviePlayer.endPlaybackTime,player.moviePlayer.duration);
    [player didplayField:^(NSError *error) {
        //
    }];

}

- (void)dealloc
{
    [[((AVPlayerLayer *)[self layer]) player] pause];
    self.player = nil;
}

- (void) play
{
    [[((AVPlayerLayer *)[self layer]) player] play];
}

- (void) pause
{
    [[((AVPlayerLayer *)[self layer]) player] pause];
}

#pragma mark -
#pragma mark interface

- (void) setURL:(NSURL*)url
{
    self.player = [[AVPlayer alloc] initWithURL:url];
    videoUrl_   = url;
    //    [[NSNotificationCenter defaultCenter] addObserver:self
    //											 selector:@selector(movieHasFinishedPlaying:)
    //												 name:AVPlayerItemDidPlayToEndTimeNotification
    //											   object:player];
}

//- (void)movieHasFinishedPlaying:(NSNotification*)paramNotification
//{
//    [[self player] seekToTime:kCMTimeZero];
//	buttonPlay_.hidden = NO;
//}
@end
