//
//  ConfigurationSelectorCell.m
//  DSPA2015
//
//  Created by runlin on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ConfigurationSelectorCell.h"

@implementation ConfigurationSelectorCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    self.icon.layer.cornerRadius = self.icon.frame.size.width/2.0;
//    self.icon.layer.masksToBounds = YES;
}

@end
