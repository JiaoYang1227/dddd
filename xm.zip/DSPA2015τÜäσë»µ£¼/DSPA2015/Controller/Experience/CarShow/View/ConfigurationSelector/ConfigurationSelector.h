//
//  ConfigurationSelector.h
//  DSPA2015
//
//  Created by runlin on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ConfigurationSelectorCell;

typedef NSString*(^TitleForConfigurationSelectorItem)(ConfigurationSelectorCell *cell,NSInteger index,id item);
typedef NSString*(^ImageForConfigurationSelectorItem)(ConfigurationSelectorCell *cell,NSInteger index,id item);
typedef void (^DidSelectConfigurationSelectorItem)( ConfigurationSelectorCell *cell,NSInteger index,id item);


@interface ConfigurationSelector : UIView
{
    TitleForConfigurationSelectorItem _titleForConfigurationSelectorItem;
    ImageForConfigurationSelectorItem _imageForConfigurationSelectorItem;
    DidSelectConfigurationSelectorItem _didSelectConfigurationSelectorItem;
}
+(ConfigurationSelector*)selector;

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (strong, nonatomic) NSArray *items;
@property (assign, nonatomic) CGFloat resizeWidth;

-(void)titleForConfigurationSelectorItem:(TitleForConfigurationSelectorItem)titleForConfigurationSelectorItem;
-(void)imageForConfigurationSelectorItem:(ImageForConfigurationSelectorItem)imageForConfigurationSelectorItem;
-(void)didSelectConfigurationSelectorItem:(DidSelectConfigurationSelectorItem)didSelectConfigurationSelectorItem;

-(void)show:(BOOL)isShow animate:(BOOL)animate completion:(void (^)(void))completion;

@end
