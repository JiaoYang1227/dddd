//
//  ConfigurationSelector.m
//  DSPA2015
//
//  Created by runlin on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ConfigurationSelector.h"
#import "ConfigurationSelectorCell.h"

@interface ConfigurationSelector()<UICollectionViewDelegate,UICollectionViewDataSource>

@end
@implementation ConfigurationSelector
+(ConfigurationSelector*)selector{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"ConfigurationSelector" owner:nil options:nil];
    return [nibView lastObject];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setItems:(NSArray *)items{
    _items = items;
    [self.collectionView reloadData];
}
-(CGFloat)resizeWidth{
    return ([_items count]*92+4+25)>458?458:([_items count]*92+4+25);
}
-(void)awakeFromNib{
    [super awakeFromNib];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.clipsToBounds = YES;
}
-(void)titleForConfigurationSelectorItem:(TitleForConfigurationSelectorItem)titleForConfigurationSelectorItem{
    _titleForConfigurationSelectorItem = [titleForConfigurationSelectorItem copy];
    [self.collectionView reloadData];
}

-(void)imageForConfigurationSelectorItem:(ImageForConfigurationSelectorItem)imageForConfigurationSelectorItem{
    _imageForConfigurationSelectorItem = [imageForConfigurationSelectorItem copy];
    [self.collectionView reloadData];

}
-(void)didSelectConfigurationSelectorItem:(DidSelectConfigurationSelectorItem)didSelectConfigurationSelectorItem{
    _didSelectConfigurationSelectorItem = [didSelectConfigurationSelectorItem copy];
    [self.collectionView reloadData];

}

#pragma mark -
#pragma mark Collection view data source  Model Group Select
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.items count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = @"ConfigurationSelectorCell";
    [collectionView registerNib:[UINib nibWithNibName:CellIdentifier bundle:nil] forCellWithReuseIdentifier:CellIdentifier];
    ConfigurationSelectorCell *cell = (ConfigurationSelectorCell *)[collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    id item = [self.items objectAtIndex:indexPath.row];

    if (_imageForConfigurationSelectorItem) {
        NSString *path = _imageForConfigurationSelectorItem(cell,indexPath.row,item);
        cell.icon.image = [UIImage imageWithContentsOfFile:path];

    }
    if (_titleForConfigurationSelectorItem) {
        NSString *title = _titleForConfigurationSelectorItem(cell,indexPath.row,item);
        cell.label.text = title;
    }
    
    return cell;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(92, 92);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    id item = [self.items objectAtIndex:indexPath.row];
    ConfigurationSelectorCell *cell = (ConfigurationSelectorCell*)[collectionView cellForItemAtIndexPath:indexPath];
    if (_didSelectConfigurationSelectorItem) {
        _didSelectConfigurationSelectorItem(cell,indexPath.row,item);
    }
}

-(void)show:(BOOL)isShow animate:(BOOL)animate completion:(void (^)(void))completion {
    //    CATransition *transition = [CATransition animation];
    //    transition.duration = .3f;
    //    transition.type = kCATransitionMoveIn;
    //    transition.subtype = kCATransitionFromRight;
    //    [self.configurationSelectView.layer addAnimation:transition forKey:nil];
    //    [self.view addSubview:self.configurationSelectView];
    //
//    self.rightArrowView.hidden = !isShow;
    if (isShow) {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = self.frame;
            frame.size.width = self.resizeWidth;
            frame.origin.x -= self.resizeWidth;
            self.frame = frame;
        } completion:^(BOOL finished) {
            if (completion) {
                completion();
            }
        }];
    }else{
        if (animate) {
            [UIView animateWithDuration:0.3 animations:^{
                CGRect frame =self.frame;
                frame.size.width = 0;
                frame.origin.x += self.resizeWidth;
                self.frame = frame;
            } completion:^(BOOL finished) {
                if (completion) {
                    completion();
                }
                [self removeFromSuperview];
            }];
        }else{
            if (completion) {
                completion();
            }
            [self removeFromSuperview];
        }
        
    }
    [self.collectionView reloadData];
}

@end
