//
//  ShowScene360.m
//  CarShow
//
//  Created by Jakey on 15/6/10.
//  Copyright (c) 2015年 www.skyfox.org. All rights reserved.
//

#import "ShowScene360.h"
#import "ImageMemoryCache.h"
@implementation ShowScene360

-(NSInteger)count{
    return [_imagePaths count];
}

-(void)setImagePaths:(NSArray *)imagePaths{
    if (!imagePaths || imagePaths.count==0) {
        _imageView.image = nil;
    }
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:self.bounds];
        [self addSubview:_imageView];
    }
    _imagePaths = [imagePaths copy];
//#warning 
    if (!self.currentIndex) {
        self.currentIndex = MIN(22, [imagePaths count]);
    }
    [self setCurrentIndex:self.currentIndex];
}

- (void)setCurrentIndex:(NSInteger)currentIndex
{
    if (!_imagePaths || [_imagePaths count]<=0) {
        return;
    }
    
    _currentIndex = MIN(MAX(0, currentIndex), self.count - 1) ;
    
    NSString *path = [_imagePaths objectAtIndex:_currentIndex];
//    NSAssert(image, @"image is nil");
    UIImage *image =  [[ImageMemoryCache sharedMemoryCache] imageFromKey:path];
    if (image) {
        
    }else{
        image = [UIImage imageWithContentsOfFile:path];
//        [[ImageMemoryCache sharedMemoryCache] storeImage:image forKey:path];
    }
    //
    [_imageView setImage:image];
}

-(void)didChangeBlock:(DidChangeBlock)didChangeBlock{
    _didChangeBlock = [didChangeBlock copy];
}
-(void)beginTouchedBlock:(BeginTouchedBlock)beginTouchedBlock{
    _beginTouchedBlock = [beginTouchedBlock copy];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if ([event.allTouches count] == 1)
    {
        _previousTouchTimestamp = event.timestamp;
    }
    if (_beginTouchedBlock) {
        _beginTouchedBlock(self.currentIndex,(360.0/self.count)*self.currentIndex);
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    if ([event.allTouches count] == 1)
    {
        UITouch *touch = [touches anyObject];
        CGPoint lastPoint = [touch previousLocationInView:self];
        CGPoint nowPoint = [touch locationInView:self];
        
        CGFloat xOffset = nowPoint.x - lastPoint.x;
        CGFloat yOffset = nowPoint.y - lastPoint.y;
        CGPoint offset = CGPointMake(xOffset, yOffset);
        
        NSTimeInterval newitme = event.timestamp - _previousTouchTimestamp;
        
        //0.02  36
        //x        N
        
        if (newitme > 0.03)
        {
            if (offset.x < 0)
            {
                if (self.currentIndex < [_imagePaths count]-1?:0)
                {
                    self.currentIndex++;
                }
                else
                {
                    self.currentIndex = 0;
                }
            }
            else
            {
                if (self.currentIndex != 0)
                {
                    self.currentIndex--;
                }
                else
                {
                    self.currentIndex = [_imagePaths count]-1?:0;
                }
                
            }
            if (_didChangeBlock) {
                _didChangeBlock(self.currentIndex,(360.0/self.count)*self.currentIndex);
               
            }
            for (ShowItem360 *view in _360items) {
                view.currentIndex = self.currentIndex;
            }
            _spotView.hidden = YES;
//            if (self.currentIndex == [_imagePaths count] || self.currentIndex == [_imagePaths count]/2 || self.currentIndex ==1) {
//                _spotView.hidden = NO;
//
//            } else{
//                _spotView.hidden = YES;
//                
//            }

            
            
            _previousTouchTimestamp = event.timestamp;
           
        }
    }
}

//- (void)touchesCancelled:(nullable NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
//    if ([event.allTouches count] == 1)
//    {
//        _previousTouchTimestamp = 0;
//    }
//}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if ([event.allTouches count] == 1)
    {
        _previousTouchTimestamp = 0;
    }
    
}
///在本360视图最底部插入ShowItem360
-(void)addSub360AtBottom:(ShowItem360 *)item{
    if (!_360items) {
        _360items = [NSMutableArray array];
    }
    NSMutableArray *tmp = [NSMutableArray arrayWithArray:_360items];
    for (ShowItem360 *obj in _360items) {
        if ([obj.key isEqualToString:item.key]) {
            [tmp removeObject:obj];
            [obj removeFromSuperview];
        }
    }
    _360items = tmp;
    
    item.frame = self.bounds;
    item.currentIndex = self.currentIndex;
    
    [_360items addObject:item];
    [self insertSubview:item belowSubview:_imageView];
}
-(void)addSub360:(ShowItem360 *)item{
    if (!_360items) {
        _360items = [NSMutableArray array];
    }
    NSMutableArray *tmp = [NSMutableArray arrayWithArray:_360items];
    for (ShowItem360 *obj in _360items) {
        if ([obj.key isEqualToString:item.key]) {
            [tmp removeObject:obj];
            [obj removeFromSuperview];
        }
    }
    _360items = tmp;
    
    item.frame = self.bounds;
    item.currentIndex = self.currentIndex;
    
    [_360items addObject:item];
    [self addSubview:item];
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//        
//        dispatch_async(dispatch_get_main_queue(), ^{
//            
//        });
//        
//    });
}

-(void)insertSub360:(ShowItem360 *)item belowOther360:(NSString*)name{
    if (!_360items) {
        _360items = [NSMutableArray array];
    }
    NSMutableArray *tmp = [NSMutableArray arrayWithArray:_360items];
    for (ShowItem360 *obj in _360items) {
        if ([obj.key isEqualToString:item.key]) {
            [tmp removeObject:obj];
            [obj removeFromSuperview];
        }
    }
    _360items = tmp;
    
    item.frame = self.bounds;
    item.currentIndex = self.currentIndex;
    
    [_360items addObject:item];
    
    ShowItem360 *below;
    
    for (ShowItem360 *obj in _360items) {
        if ([obj.key isEqualToString:name]) {
            below = obj;
        }
    }
    if (below) {
        [self insertSubview:item belowSubview:below];
        
    }else{
        [self addSubview:item];
    }
    
}


-(void)clearForType:(NSString *)key{
    NSMutableArray *tmp = [NSMutableArray arrayWithArray:_360items];
    for (ShowItem360 *obj in _360items) {
        if ([obj.key isEqualToString:key]) {
            [tmp removeObject:obj];
            [obj removeFromSuperview];
        }
    }
    _360items = tmp;
}
-(ShowItem360 *)itemViewWithType:(NSString*)typeName{
    for (ShowItem360 *obj in _360items) {
        if ([obj.key isEqualToString:typeName]) {
            return obj;
        }
    }
    return nil;
}
-(void)clear{
    NSMutableArray *tmp = [NSMutableArray arrayWithArray:_360items];

    for (ShowItem360 *obj in _360items) {
        [obj removeFromSuperview];
        [tmp removeObject:obj];
    }
    _360items = tmp;

}
-(void)addLightspot:(OuterHotspotButton *)spot{
    if(!_spotView)
    {
        _spotView = [[UIView alloc]initWithFrame:self.bounds];
        _spotView.layer.zPosition = 1;
        [self addSubview:_spotView];
    }
//    NSArray *subViews = [self.scrollView subviews];
//    if([subViews count] != 0)
//    {
//        [subViews makeObjectsPerformSelector:@selector(removeFromSuperview)];
//    }
//    
   
    if (!_spots) {
        _spots = [NSMutableArray array];
    }
    //[_spots makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [_spots addObject:spot];
    [_spotView addSubview:spot];
}
-(void)setDirection:(ShowDirection)direction{
    if (_spots) {
        [_spots makeObjectsPerformSelector:@selector(removeFromSuperview)];
        [_spots removeAllObjects];
    }
    _spotView.hidden = NO;

    _direction = direction;
    if (_direction == Direction0) {
        self.currentIndex = [_imagePaths count];
    }
    else if (_direction == Direction180) {
        self.currentIndex = [_imagePaths count]/2-1;

    }
    else if (_direction == Direction45) {
        self.currentIndex = 0;

    }
   
    if (_didChangeBlock) {
        _didChangeBlock(self.currentIndex,(360.0/self.count)*self.currentIndex);
        for (ShowItem360 *view in _360items) {
            view.currentIndex = self.currentIndex;
        }
    }
}
//当前角度图片合成
-(UIImage*)currentScreenshot{
    UIImage *sceneImage = _imageView.image;
    
    UIGraphicsBeginImageContext(sceneImage.size);
    //获取当前上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //将该区域设置为透明
    CGContextClearRect(ctx, CGRectMake(0, 0, sceneImage.size.width, sceneImage.size.height));
    
//    [aImage drawInRect:view.frame blendMode:kCGBlendModeNormal alpha:1.0];
    
//    CGContextSetFillColorWithColor(ref, [UIColor clearColor].CGColor);
     
    [sceneImage drawInRect:CGRectMake(0, 0, sceneImage.size.width, sceneImage.size.height)];
    for (ShowItem360 *view in _360items) {
        UIImage *image = view.imageView.image;
        [image drawInRect:CGRectMake(0,0, sceneImage.size.width, sceneImage.size.height)];
    }
    CGImageRef mergeImageRef = CGImageCreateWithImageInRect(UIGraphicsGetImageFromCurrentImageContext().CGImage,
                                                            CGRectMake(0, 0, sceneImage.size.width, sceneImage.size.height));
    
    UIGraphicsEndImageContext();
    UIImage *result = [UIImage imageWithCGImage:mergeImageRef];
    CGImageRelease(mergeImageRef);
    return result;
}
@end
