//
//  LightspotButton.m
//  CarShow
//
//  Created by Jakey on 15/6/23.
//  Copyright © 2015年 www.skyfox.org. All rights reserved.
//

#import "OuterHotspotButton.h"

@implementation OuterHotspotButton

-(void)willMoveToSuperview:(UIView *)newSuperview{
    if(newSuperview){
        [self addTarget:self action:@selector(touchAction:) forControlEvents:UIControlEventTouchUpInside];

//        [self animation];
        
    }
}

- (void)touchAction:(id)sender{
    if(_hotspotButtonBlock){
        _hotspotButtonBlock(self);
    }

}
-(void)addActionHandler:(HotspotButtonBlock)touchHandler{
    _hotspotButtonBlock = [touchHandler copy];
}

#pragma mark - Private
- (void)animation
{
    self.clipsToBounds = NO;
//    self.backgroundColor = [UIColor blackColor];
    self.layer.cornerRadius = self.frame.size.width/2;

    CGFloat width = self.bounds.size.width,
    height = self.bounds.size.height;
    CGFloat  scale = 2.f;
    _circleShape = [self createCircleShapeWithPosition:CGPointMake(width/2, height/2)
                                              pathRect:CGRectMake(-CGRectGetMidX(self.bounds), -CGRectGetMidY(self.bounds), width, height)
                                                radius:self.layer.cornerRadius];
    [self.layer addSublayer:_circleShape];
    
    CAAnimationGroup *groupAnimation = [self createFlashAnimationWithScale:scale duration:1.f];
    
    /* Use KVC to remove layer to avoid memory leak */
    [groupAnimation setValue:_circleShape forKey:@"circleShaperLayer"];
    
    [_circleShape addAnimation:groupAnimation forKey:nil];
    [groupAnimation setDelegate:self];
    
    
}

- (CAShapeLayer *)createCircleShapeWithPosition:(CGPoint)position pathRect:(CGRect)rect radius:(CGFloat)radius
{
    CAShapeLayer *circleShape = [CAShapeLayer layer];
    circleShape.path = [self createCirclePathWithRadius:rect radius:radius];
    circleShape.position = position;
    
    circleShape.fillColor = [UIColor clearColor].CGColor;
    circleShape.strokeColor = self.flashColor ? self.flashColor.CGColor : [UIColor redColor].CGColor;
    
    circleShape.opacity = 0;
    circleShape.lineWidth = 2;
    
    return circleShape;
}

- (CAAnimationGroup *)createFlashAnimationWithScale:(CGFloat)scale duration:(CGFloat)duration
{
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    scaleAnimation.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(scale, scale, 1)];
    
    CABasicAnimation *alphaAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    alphaAnimation.fromValue = @1;
    alphaAnimation.toValue = @0;
    
    CAAnimationGroup *animation = [CAAnimationGroup animation];
    animation.animations = @[scaleAnimation, alphaAnimation];
    animation.delegate = self;
    animation.duration = duration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    
    return animation;
}

- (CGPathRef)createCirclePathWithRadius:(CGRect)frame radius:(CGFloat)radius
{
    return [UIBezierPath bezierPathWithRoundedRect:frame cornerRadius:radius].CGPath;
}

#pragma mark - CAAnimationDelegate
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    [self performSelector:@selector(animation) withObject:nil afterDelay:0.1];
    
}
@end
