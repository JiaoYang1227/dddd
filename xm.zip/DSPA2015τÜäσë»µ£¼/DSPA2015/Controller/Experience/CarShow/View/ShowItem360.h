//
//  Show360.h
//  CarShow
//
//  Created by Jakey on 15/6/8.
//  Copyright (c) 2015年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ShowItem360 : UIView
 
@property(nonatomic) NSInteger count;
@property(nonatomic) NSInteger currentIndex;

@property(nonatomic,strong)  UIImage *defaultImage;
@property (nonatomic,strong) NSMutableArray  *imagePaths;
@property(nonatomic,strong)  UIImageView *imageView;

@property(nonatomic) NSString *key;

@end
