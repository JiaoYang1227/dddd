//
//  LightspotButton.h
//  CarShow
//
//  Created by Jakey on 15/6/23.
//  Copyright © 2015年 www.skyfox.org. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HotspotButton;
typedef void (^HotspotButtonBlock)(HotspotButton *spot);


@interface HotspotButton : UIButton
{
    HotspotButtonBlock _hotspotButtonBlock;
    CAShapeLayer *_circleShape;

}
-(void)addActionHandler:(HotspotButtonBlock)touchHandler;
@property (nonatomic, strong) UIColor *flashColor;

@end
