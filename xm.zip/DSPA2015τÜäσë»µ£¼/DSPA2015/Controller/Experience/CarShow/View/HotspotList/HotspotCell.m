//
//  HotspotCell.m
//  DSPA2015
//
//  Created by runlin on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "HotspotCell.h"

@implementation HotspotCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
