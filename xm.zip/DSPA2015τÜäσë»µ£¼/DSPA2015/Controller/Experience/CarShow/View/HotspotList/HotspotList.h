//
//  HotspotList.h
//  DSPA2015
//
//  Created by runlin on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NSString*(^TitleForHotspotListItem)(UITableViewCell *cell,NSInteger index,id item);
typedef void (^DidSelectHotspotListItem)( UITableViewCell *cell,NSInteger index,id item);


@interface HotspotList : UIView
{
    TitleForHotspotListItem _titleForHotspotListItem;
    DidSelectHotspotListItem _didSelectHotspotListItem;
}
+(HotspotList*)hotspotList;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSArray *items;


-(void)show:(BOOL)isShow animate:(BOOL)animate;
-(void)titleForHotspotListItem:(TitleForHotspotListItem)titleForHotspotListItem;
-(void)didSelectHotspotListItem:(DidSelectHotspotListItem)didSelectHotspotListItem;


@end
