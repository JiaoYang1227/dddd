//
//  HotspotList.m
//  DSPA2015
//
//  Created by runlin on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "HotspotList.h"
#import "HotspotCell.h"
@interface HotspotList()<UITableViewDelegate,UITableViewDataSource>

@end
@implementation HotspotList
+(HotspotList*)hotspotList{
    NSArray* nibView = [[NSBundle mainBundle] loadNibNamed:@"HotspotList" owner:nil options:nil];
    return [nibView lastObject];
}
-(void)awakeFromNib{
    [super awakeFromNib];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.clipsToBounds = YES;
     self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

}
-(void)setItems:(NSArray *)items{
    _items = items;
    [self.tableView reloadData];
}
-(void)titleForHotspotListItem:(TitleForHotspotListItem)titleForHotspotListItem{
    _titleForHotspotListItem = [titleForHotspotListItem copy];
    [self.tableView reloadData];

}
-(void)didSelectHotspotListItem:(DidSelectHotspotListItem)didSelectHotspotListItem{
    _didSelectHotspotListItem = [didSelectHotspotListItem copy];
    [self.tableView reloadData];


}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_items count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"HotspotCell";
    
    [tableView registerNib:[UINib nibWithNibName:@"HotspotCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
    
    //[tableView registerClass:[NewsCell class] forCellReuseIdentifier:CellIdentifier];
    
    HotspotCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  
    id  item =[_items objectWithIndex:indexPath.row];
    
//    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.selectedBackgroundView = [[UIView alloc]init];

    cell.contentView.backgroundColor = [UIColor clearColor];
    cell.backgroundColor = [UIColor clearColor];
    cell.label.text = @"";

    if (_titleForHotspotListItem) {
        NSString *title = _titleForHotspotListItem(cell,indexPath.row,item);
        cell.label.text = title;
    }
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    id  item =[_items objectWithIndex:indexPath.row];

    if (_didSelectHotspotListItem) {
        _didSelectHotspotListItem(nil,indexPath.row,item);
    }
    
    
    
}

-(void)show:(BOOL)isShow animate:(BOOL)animate{
    //    CATransition *transition = [CATransition animation];
    //    transition.duration = .3f;
    //    transition.type = kCATransitionMoveIn;
    //    transition.subtype = kCATransitionFromRight;
    //    [self.configurationSelectView.layer addAnimation:transition forKey:nil];
    //    [self.view addSubview:self.configurationSelectView];
    //
    //    self.rightArrowView.hidden = !isShow;
    if (isShow) {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = self.frame;
            frame.size.width = 165;
            self.frame = frame;
        } completion:^(BOOL finished) {
            
        }];
    }else{
        if (animate) {
            [UIView animateWithDuration:0.3 animations:^{
                CGRect frame =self.frame;
                frame.origin.x = CGRectGetMinX(frame);
                frame.size.width = 0;
                self.frame = frame;
            } completion:^(BOOL finished) {
                [self removeFromSuperview];
            }];
        }else{
            [self removeFromSuperview];
        }
        
    }
    [self.tableView reloadData];
}
@end
