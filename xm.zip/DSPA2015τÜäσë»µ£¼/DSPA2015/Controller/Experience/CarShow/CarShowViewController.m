//
//  CarShowViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarShowViewController.h"
#import "CarShowResource.h"

#import "Car.h"
#import "CarBrandInfo.h"
#import "FlashButton.h"


#import "CarOuterShowViewController.h"
#import "CarInnerShowViewController.h"
#import "CarShowTabController.h"
#import "CarCompareViewController.h"

#import "CarShowPlayer.h"
@interface CarShowViewController ()

@end

@implementation CarShowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.modelDisplayView.backgroundColor = [UIColor clearColor];
//     self.modelDisplayView.layer.cornerRadius = 150;
    self.modelDisplayView.clipsToBounds = YES;
    __weak typeof(self) wealkSelf = self;
    UIBezierPath *maskPath = [UIBezierPath bezierPath];
    CGPoint center = CGPointMake(self.modelDisplayView.bounds.size.width/2, self.modelDisplayView.bounds.size.height/2);
    [maskPath addArcWithCenter:center radius:self.modelDisplayView.width/2 startAngle:0.0 endAngle:180.0 clockwise:YES];
    [maskPath stroke];
  
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.modelDisplayView.bounds;
    maskLayer.path = maskPath.CGPath;
    maskLayer.lineCap = kCALineCapRound;
    self.modelDisplayView.layer.mask = maskLayer;
    self.modelDisplayView.edge = UIEdgeInsetsMake(125, 50, 50, 50);
    
    [self.modelDisplayView modelDisplayViewItemTouched:^(Car *item) {
        
        CarOuterShowViewController *show = [[CarOuterShowViewController alloc]init];
        show.car = [item copy];
        //
        CarInnerShowViewController *inner = [[CarInnerShowViewController alloc]init];
        inner.car = [item copy];

        CarCompareViewController *compare = [[CarCompareViewController alloc]init];
        compare.modelInfo = [item copy];

        
        CarShowTabController *tab = [[CarShowTabController alloc]init];
        tab.viewControllers = @[show,inner,compare];
        [wealkSelf.navigationController pushViewController:tab animated:YES];

    }];
    [[CarShowResource sharedResource] getBrandList:^(NSArray *brandList) {
        _brandList = brandList;
        [wealkSelf initCarBrandButtons];

    }];
    self.title = @"车辆展厅";
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) initCarBrandButtons
{
    FlashButton   *button = nil;
    _allFlashButtons = [NSMutableArray array];
    [_allFlashButtons removeAllObjects];
    
    for (int i = 0; i < _brandList.count; i++)
    {
        CarBrandInfo *branch = [_brandList objectWithIndex:i];
        NSString   *title  = [branch.name stringByReplacingOccurrencesOfString:@"奥迪" withString:@""];
        CGPoint    postion = CGPointZero;
       
        switch (i)
        {
            case 0:
                postion = CGPointMake(229 - 101, 151 - 68 + 20);
                break;
            case 1:
                postion = CGPointMake(194 - 107, 222 - 74 + 20);
                break;
            case 2:
                postion = CGPointMake(167 - 112, 302 - 70 + 20);
                break;
            case 3:
                postion = CGPointMake(159 - 114, 399 - 70 + 20);
                break;
            case 4:
                postion = CGPointMake(173 - 112, 478 - 62 + 20);
                break;
            case 5:
                postion = CGPointMake(93, 556 - 68 + 20);
                break;
            case 6: //
                postion = CGPointMake(141, 572);
                break;
            case 7:
                postion = CGPointMake(784 - 50, 151 - 68 + 20);
                break;
            case 8:
                postion = CGPointMake(830 - 50, 222 - 74 + 20);
                break;
            case 9:
                postion = CGPointMake(857 - 46, 302 - 70 + 20);
                break;
            case 10:
                postion = CGPointMake(865 - 44, 399 - 70 + 20);
                break;
            case 11:
                postion = CGPointMake(852 - 46, 478 - 65 + 20);
                break;
            case 12:
                postion = CGPointMake(819 - 46, 556 - 65 + 20);
                break;
            case 13:
                postion = CGPointMake(819 - 42-55, 556 - 68 + 20+70);
                break;
            default:
            
                break;
        }
        if (i<=13){
            CarBrandButtonStyle style;
            if (i<=6) {
                style = CarBrandButtonStyleLeft;
            }else{
                style = CarBrandButtonStyleRight;
                
            }
            button = [[FlashButton alloc]initWithStyle:style];
            button.center = postion;
            button.index = i;
            [button setTitle:title];
            [button setPosition:postion];
            [button addTarget:self action:@selector(carBrandButtonTouched:) forControlEvents:UIControlEventTouchUpInside];
            button.brandID = branch.brandId;
            [_allFlashButtons addObject:button];
            [self.view addSubview:button];
        }
        
    }
    [_allFlashButtons makeObjectsPerformSelector:@selector(setButtonSelected:) withObject:0];
    [self carBrandButtonTouched:[_allFlashButtons objectWithIndex:3]];

}
- (IBAction)carBrandButtonTouched:(FlashButton*)sender
{
    [_allFlashButtons makeObjectsPerformSelector:@selector(setButtonSelected:) withObject:0];
    [sender setButtonSelected:YES animated:YES];
    
    //动画
    CarBrandInfo *branch = [_brandList objectAtIndex:sender.index];
    [self loadModelInfoWithBrand:branch.brandId];

}
- (BOOL)loadModelInfoWithBrand:(NSString*)branchId
{
    if (branchId == nil)
    {
        return NO;
    }
    
    NSArray *array  = [[CarShowResource sharedResource] getExistModelsWithBrandId:branchId];
    self.modelDisplayView.items = array;
   
    return YES;
}


@end
