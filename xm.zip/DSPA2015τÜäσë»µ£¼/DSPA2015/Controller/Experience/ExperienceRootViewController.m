//
//  ExperienceRootViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ExperienceRootViewController.h"
#import "CarShowViewController.h"
#import "ResourceSearchViewController.h"
#import "CalculationViewController.h"
#import "AccessoriesProductViewController.h"
#import "CarVideoListViewController.h"
#import "CarDeliveryViewController.h"
#import "CarComapreMainViewController.h"
#import "DrivingExperienceNewViewController.h"
#import "CalculatorMenuViewController.h"

#import "TaskBoardViewController.h"
#import "CarVideo.h"
#import "XTMoviePlayerController.h"
#import "ShareCenterViewController.h"
#import "SelectModelsViewController.h"
#import "ConnectViewController.h"
#import "MembersLoginViewController.h"
@interface ExperienceRootViewController ()

@end

@implementation ExperienceRootViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"主页";
    
    
    self.scrollFocus.autoScroll = YES;
    
//    [self.scrollFocus didSelectScrollFocusItem:^(NSInteger index) {
//        NSDictionary *dic = [[CarVideo findBrandIsSelected] objectAtIndex:index];
//        NSString *fileName = [self stringWithstr:[dic stringForKey:@"name"]];
//        //播放本地视频
//        NSString *path = [FileManager documentsPath:[NSString stringWithFormat:@"/video/%@/%@.mp4",fileName,fileName]];
//        if (path == nil) {
//            NSLog(@"path is nil");
//            return;
//        }
//       XTMoviePlayerController * player = [[XTMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:path]];
//        
//        [player startPlaying:self withBlock:^{
//            NSLog(@"start play movie");
//        }];
//        
//        [player didPlayFinished:^{
//            NSLog(@"finished");
//        }];
//        
//        [player didplayField:^(NSError *error) {
//            //
//        }];
//    }];
    [self.scrollFocus downloadFocusItem:^(id downloadItem, UIImageView *currentImageView) {
        currentImageView.image = [UIImage imageWithContentsOfFile:[downloadItem description]];
    }];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.scrollFocus.imageArray = [self GetImageArray];
//    self.scrollFocus.titleArray = [self GetTitleArray];
    self.scrollFocus.hidden = ([self.scrollFocus.imageArray count]<=0)? YES:NO;
    
    
}

-(NSArray *)GetImageArray{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"modelList" ofType:@"plist"];
    NSMutableDictionary *dicModel = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    NSMutableArray *array = [[NSMutableArray alloc] init];
    array = (NSMutableArray *)[CarVideo findBrandIsSelected];
    //过滤掉垃圾数据
    for (int i = 0; i < array.count; i++) {
        NSString *modelName = [dicModel objectForKey:[[array objectAtIndex:i] objectForKey:@"brandId"]];
        if (!modelName) {
            [array removeObjectAtIndex:i];
            i--;
        }
    }
    NSMutableArray *imageArray = [[NSMutableArray alloc]init];
    for (NSDictionary *dic in array) {
        NSString *fileName = [self stringWithstr:[dic stringForKey:@"name"]];
        NSString *path = [FileManager documentsPath:[NSString stringWithFormat:@"/video/%@/bigImage.jpg",fileName]];
        if (path) {
            [imageArray addObject:path];
        }
    }
    return imageArray;
}
-(NSString *)stringWithstr:(NSString *)str{
    NSString *returnStr = [str stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    return returnStr;
}
-(NSArray *)GetTitleArray{
    NSMutableArray *TitleArray = [[NSMutableArray alloc]init];
    for (NSDictionary *dic in [CarVideo findBrandIsSelected]) {
        NSString *fileName = [self stringWithstr:[dic stringForKey:@"name"]];
        if (fileName) {
            [TitleArray addObject:fileName];
        }
    }
    return TitleArray;
}

- (IBAction)videoCenterTouched:(id)sender {
    //统计模块
    [CBTracking trackEvent:@"视频中心"];
    [CBTracking recordModulePath:@"视频中心"];
    SelectModelsViewController *select = [[SelectModelsViewController alloc] init];
    [self.navigationController pushViewController:select animated:YES];
    [Stat sendHomeStatWithName:@"videoCenter"];
}

- (IBAction)carShowTouched:(id)sender {
    //统计模块
    [CBTracking trackEvent:@"车辆展厅"];
    [CBTracking recordModulePath:@"车辆展厅"];
    CarShowViewController *carShow = [[CarShowViewController alloc]init];
    [self.navigationController pushViewController:carShow animated:YES];
    [Stat sendHomeStatWithName:@"carShow"];

}

- (IBAction)calculateTouched:(id)sender {
    //统计模块
    [CBTracking trackEvent:@"购车计算"];
    [CBTracking recordModulePath:@"购车计算"];
    CalculatorMenuViewController *caleMenu = [[CalculatorMenuViewController alloc]init];
    [self.navigationController pushViewController:caleMenu animated:YES];
//    CalculationViewController *calculation = [[CalculationViewController alloc]init];
//    [self.navigationController pushViewController:calculation animated:YES];
    [Stat sendHomeStatWithName:@"calculation"];

}

- (IBAction)compareTouched:(id)sender {
    //统计模块
    [CBTracking trackEvent:@"竞品对比"];
    [CBTracking recordModulePath:@"竞品对比"];
    CarComapreMainViewController *carcompare = [[CarComapreMainViewController alloc]init];
    [self.navigationController pushViewController:carcompare animated:YES];
    [Stat sendHomeStatWithName:@"carCompare"];

}

- (IBAction)resourceQueryTouched:(id)sender {
    
    //统计模块
    [CBTracking trackEvent:@"首页库存查询"];
    [CBTracking recordModulePath:@"库存查询"];
    if ([AppDelegate APP].user) {
        [self.navigationController pushViewController:[[ResourceSearchViewController alloc] init] animated:YES];
        [Stat sendHomeStatWithName:@"resourceSearch"];
    }else{
        [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
        [JKAlert showMessage:@"请登录"];
    }
}

- (IBAction)testDriverTouched:(id)sender {
    
    //统计模块
    [CBTracking trackEvent:@"首页试乘试驾"];
    [CBTracking recordModulePath:@"试乘试驾"];
    if ([AppDelegate APP].user) {
        [self.navigationController pushViewController:[[DrivingExperienceNewViewController alloc]init] animated:YES];
        [Stat sendHomeStatWithName:@"drivingExperience"];
    }else{
        [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
        [JKAlert showMessage:@"请登录"];
    }
}

- (IBAction)showTouched:(id)sender {
//    if ([AppDelegate APP].user) {
//        [self.navigationController pushViewController:[[AccessoriesProductViewController alloc] init] animated:YES];
//        [Stat sendHomeStatWithName:@"accessoriesProduct"];
//    }else{
//        [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
//        [JKAlert showMessage:@"请登录"];
//    }
    
    
    
    // 临时关闭
    //统计模块
    [CBTracking trackEvent:@"Audi connect"];
    [CBTracking recordModulePath:@"Audi connect"];
    [self.navigationController pushViewController:[[ConnectViewController alloc]init] animated:YES];
//    [Stat sendHomeStatWithName:@"authentication"];
}

- (IBAction)deliveCarTouched:(id)sender {
    
    //统计模块
    [CBTracking trackEvent:@"品牌会员"];
    [CBTracking recordModulePath:@"品牌会员"];
    [self.navigationController pushViewController:[[MembersLoginViewController alloc] init] animated:YES];
    
//#ifdef DEMO
//    
//#else
//    if ([AppDelegate APP].user) {
//        [self.navigationController pushViewController:[[ShareCenterViewController alloc] init] animated:YES];
//        [Stat sendHomeStatWithName:@"shareCenter"];
//    }else{
//        [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
//        [JKAlert showMessage:@"请登录"];
//    }
//#endif
}
- (IBAction)taskConsultantTouched:(id)sender {

    //统计模块
    [CBTracking trackEvent:@"首页客户接待"];
    [CBTracking recordModulePath:@"客户接待"];
    if ([AppDelegate APP].user) {
        [Stat sendHomeStatWithName:@"taskBoard"];

        if([AppDelegate APP].user.role == UserRoleReceptionist){
            TaskBoardViewController *borad = [[TaskBoardViewController alloc] initWithRole:TaskBoardRoleReceptionist];
            [self.navigationController pushViewController:borad animated:YES];
        }
       else if([AppDelegate APP].user.role == UserRoleConsultant){
           if(![AppDelegate APP].rootViewController.clientRootViewController.isRecepting){
               TaskBoardViewController *borad = [[TaskBoardViewController alloc] initWithRole:TaskBoardRoleConsultant];
               [self.navigationController pushViewController:borad animated:YES];
           }else{
               JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"您有正在进行的客户接待!"];
               [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
                   
               }];
               [alert show];
           }
        }
       else if([AppDelegate APP].user.role == UserRoleOnlyView){
           TaskBoardViewController *borad = [[TaskBoardViewController alloc] initWithRole:TaskBoardRoleConsultant];
           [self.navigationController pushViewController:borad animated:YES];
       }else{
           [JKAlert showMessage:@"权限不符"];
       }
    }else{
        [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
        [JKAlert showMessage:@"请登录"];
    }
}
- (void)setDetailViewController:(UIViewController *)detailViewController{
    NSLog(@"%s: Line-%d: %@", __func__, __LINE__, [NSThread callStackSymbols]);
    NSLog(@"能执行到这 说明出错啦!!!");
}
@end
