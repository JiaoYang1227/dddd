//
//  RightResourceSearchTableViewCell.h
//  DSPA2015
//
//  Created by gavin on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ResourceSearchTableViewCell.h"

@interface RightResourceSearchTableViewCell : ResourceSearchTableViewCell
@property (nonatomic , strong) NSArray *dataSource;
@property (nonatomic , strong) NSDictionary *dicSource;
@property (weak, nonatomic) IBOutlet UILabel *cellTitle;
@property (weak, nonatomic) IBOutlet UIImageView *cellViewBG;
@end
