//
//  ResourceSearchTableViewCell.m
//  DSPA2015
//
//  Created by gavin on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourceSearchTableViewCell.h"

@implementation ResourceSearchTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


+(UINib*)nib{
    return  [UINib nibWithNibName:NSStringFromClass([self class]) bundle:nil];
}


@end
