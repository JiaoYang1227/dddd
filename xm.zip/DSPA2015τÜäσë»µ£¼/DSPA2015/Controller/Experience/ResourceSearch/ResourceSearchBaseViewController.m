//
//  ResourceSearchBaseViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/29.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourceSearchBaseViewController.h"
#import "ResourceSearchViewController.h"

@interface ResourceSearchBaseViewController ()

@end

@implementation ResourceSearchBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}



- (IBAction)dismissTouched:(id)sender {
    ResourceSearchViewController *borad = (ResourceSearchViewController*)self.parentViewController;
    
    [UIView animateWithDuration:0.3 animations:^{
        borad.coverView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
        //        [self.referenceViewController viewWillAppear:YES];
    } completion:^(BOOL finished) {
        [borad.coverView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
