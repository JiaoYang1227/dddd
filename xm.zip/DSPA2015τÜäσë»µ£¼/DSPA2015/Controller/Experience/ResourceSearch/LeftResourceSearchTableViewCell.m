//
//  LeftResourceSearchTableViewCell.m
//  DSPA2015
//
//  Created by gavin on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "LeftResourceSearchTableViewCell.h"

@implementation LeftResourceSearchTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)setDataSource:(NSArray *)dataSource{
    _dataSource = dataSource;
    
    //    [self.contentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    for (UIView *view in self.subviews) {
        if (view != self.contentView) {
            [view removeFromSuperview];
        }
    }
    
    for (int i = 0; i < _dataSource.count; i++) {
        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(self.cellTitle.origin.x + self.cellTitle.size.width*i + 15,
                                                                   self.cellTitle.origin.y,
                                                                   self.cellTitle.size.width,
                                                                   self.cellTitle.size.height)];
        
        
        lable.textAlignment = NSTextAlignmentCenter;
        [lable setFont:[UIFont fontWithName:@"HelveticaNeue" size:12]];
        lable.numberOfLines = 3;
        lable.text = [self.dicSource stringForKey:_dataSource[i]]?:@"";
        
        
        [self addSubview:lable];
    }
}
@end
