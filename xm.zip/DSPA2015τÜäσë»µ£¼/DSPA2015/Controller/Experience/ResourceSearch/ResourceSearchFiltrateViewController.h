//
//  ResourceSearchFiltrateViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/29.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourceSearchBaseViewController.h"


typedef void(^onResourceSearchFiltrateCallBack)(NSString *carTypeString,NSString *carStateString , NSString *carColorString, NSString *carInColorString);


@interface ResourceSearchFiltrateViewController : ResourceSearchBaseViewController


@property (nonatomic , strong) NSString *resourceType;

@property (nonatomic , copy) onResourceSearchFiltrateCallBack callBackResourceSearchFiltrate;

@end
