//
//  ResourceSearchViewController.m
//  DSPA2015
//
//  Created by gavin on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourceSearchViewController.h"
#import "LeftResourceSearchTableViewCell.h"
#import "RightResourceSearchTableViewCell.h"
#import "SelectView.h"
#import "ResourceSearchModel.h"
#import "ResourceColor.h"
#import "ResourceSearchFiltrateViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "ResourceSearchFiltrateTempViewController.h"

@interface ResourceSearchViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    
    NSString *_carTypeString;
    NSString *_carModelString;
    NSString *_carStateString;
    NSString *_carColorString;  //外饰颜色
    NSString *_carInColorString; //内饰颜色
    
    
    __weak IBOutlet UITableView     *_leftTableView;
           IBOutlet UITableView     *_rightTableView;
    __weak IBOutlet UIScrollView    *_scrollview;
    
    
    NSMutableArray *_dataSources;
    NSMutableArray *_dataSourcesCopy;
    
    NSMutableArray *_leftHeadDataSources;
    NSMutableArray *_rightHeadDataSources;

    NSDictionary *_colorDic;
    
    NSInteger _currentPage;
    
    NSString *_resourceType;
}

- (IBAction)filtrateAction:(id)sender;
- (IBAction)refreshAction:(id)sender;

@end

@implementation ResourceSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"库存查询";
    
    [_leftTableView registerNib:[LeftResourceSearchTableViewCell nib] forCellReuseIdentifier:NSStringFromClass([LeftResourceSearchTableViewCell class])];
    [_rightTableView registerNib:[RightResourceSearchTableViewCell nib] forCellReuseIdentifier:NSStringFromClass([RightResourceSearchTableViewCell class])];
        
    _currentPage = 1;
    _carTypeString = nil;
    _carStateString = nil;
    _carInColorString = nil;
    _carColorString = nil;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self fetchCarResourceType];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


/**
 *  查询获取数据类型 : 厂商 & 经销商
 */
- (void)fetchCarResourceType{
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    if([AppDelegate APP].user && [AppDelegate APP].user.variables){
        if ([[[[AppDelegate APP].user findVariableByKey:KEY_VEHICLE_RESOURCES] stringForKey:@"value"] isEqualToString:@"1"])
        {
            // 经销商获取
            _resourceType = @"1";
//            [self fetchCarResourceListFormDealers:0];
            
            NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
            NSString *urlParam = @"offline/addStoragetype.html?jsonString={\"typeid\":\"60c22c88-fe2a-4b5d-81d4-7438ac2ec411\"}";
            NSString *url = [NSString stringWithFormat:@"%@%@",baseInterface,urlParam];
            
            UIWebView *webview = [[UIWebView alloc] initWithFrame:CGRectMake(0, 70, 1024, 646)];
            NSString *encodedUrl=[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            
            NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:encodedUrl] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
            [webview loadRequest:request];
            
            [self.view addSubview:webview];
 
            
        }else if ([[[[AppDelegate APP].user findVariableByKey:KEY_VEHICLE_RESOURCES] stringForKey:@"value"] isEqualToString:@"2"])
        {
            // 经销商获取
            _resourceType = @"2";
            [ResourceSearchModel getBindFileShare:@{} Success:^(NSString *path, id responseObject) {
                [self fetchCarResourceListFromShareCenter:path];
            } Failure:^(NSError *error) {
                
            }];
        }
        else{
            // 厂商
            _resourceType = @"0";
            [self fetchCarResourceListFromManufacturer:0];
        }
    }else{
        _resourceType = @"0";
        [self fetchCarResourceListFromManufacturer:0];
    }
   
    
//    [ResourceSearchModel fetchCarResourceType:nil Success:^(NSString * resourceType, id responseObject) {
//        
//        _resourceType = resourceType;
//        
//        // 厂商
//        if ([resourceType isEqualToString:@"0"]) {
//            [self fetchCarResourceListFromManufacturer:0];
//            
//        }else if ([resourceType isEqualToString:@"1"]){
//        // 经销商获取
//            [self fetchCarResourceListFormDealers:0];
//        }
//        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
//    } Failure:^(NSError *error) {
//        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
//    }];
}

/**
 *  筛选按钮点击
 */
- (IBAction)filtrateAction:(id)sender {

    /** 演示版功能 */
    //弹出临时筛选页面方式
    ResourceSearchFiltrateTempViewController *rsfvcTemp = [[ResourceSearchFiltrateTempViewController alloc] init];
    rsfvcTemp.resourceType = _resourceType;
    [self presentModelDetail:rsfvcTemp];
    
    __weak __typeof(self)weakSelf = self;
    rsfvcTemp.callBackResourceSearchFiltrate = ^(NSString *carTypeString,NSString *carModelString,NSString *carStateString , NSString *carColorString , NSString *carInColorString){
        
        _carTypeString = carTypeString;
        _carModelString = carModelString;
        _carStateString = carStateString;
        _carColorString = carColorString;
        _carInColorString = carInColorString;
        
        _currentPage = 1;
        // 经销商获取 1
        if ([_resourceType isEqualToString:@"1"]) {
            [weakSelf fetchCarResourceListFormDealers:0];
        }else{
            // 厂商获取
            [weakSelf fetchCarResourceListFromManufacturer:0];
        }
        
        //        [weakSelf filtrateData];
    };

    /** 正式功能 */
//    //弹出页面方式
//    ResourceSearchFiltrateViewController *rsfvc = [[ResourceSearchFiltrateViewController alloc] init];
//    rsfvc.resourceType = _resourceType;
//    [self presentModelDetail:rsfvc];
//    
//    __weak __typeof(self)weakSelf = self;
//    rsfvc.callBackResourceSearchFiltrate = ^(NSString *carTypeString,NSString *carStateString , NSString *carColorString , NSString *carInColorString){
//        
//        _carTypeString = carTypeString;
//        _carStateString = carStateString;
//        _carColorString = carColorString;
//        _carInColorString = carInColorString;
//        
//        _currentPage = 1;
//        // 经销商获取 1
//        if ([_resourceType isEqualToString:@"1"]) {
//            [weakSelf fetchCarResourceListFormDealers:0];
//        }else{
//            // 厂商获取
//            [weakSelf fetchCarResourceListFromManufacturer:0];
//        }
//        
//        //        [weakSelf filtrateData];
//    };
 

}

/**
 *  刷新页面按钮
 */
- (IBAction)refreshAction:(id)sender {
    _currentPage = 1;
    _carTypeString  = nil;
    _carStateString = nil;
    _carInColorString = nil;
    _carColorString   = nil;
    [self fetchCarResourceType];
}


/**
 *  添加滚动视图
 */
- (void)addScrollview{
    CGRect frame = _scrollview.frame;
    _scrollview.showsVerticalScrollIndicator = NO;
    _rightTableView.frame = CGRectMake(0,0, 90*_rightHeadDataSources.count + 30*_rightHeadDataSources.count, frame.size.height);
    _scrollview.contentSize = CGSizeMake(90*_rightHeadDataSources.count+ 30*_rightHeadDataSources.count, _rightTableView.frame.size.height);
    [_scrollview addSubview:_rightTableView];
}
#pragma mark tableview
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (tableView == _leftTableView) {
        static NSString * identifier = @"LeftResourceSearchTableViewCell";
        LeftResourceSearchTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.dicSource = _dataSources[indexPath.row];
        cell.dataSource = _leftHeadDataSources;
        if (indexPath.row % 2) {
            cell.cellViewBG.backgroundColor = [UIColor colorWithRed:230./255 green:230./255 blue:230./255 alpha:1.];
        }else{
            cell.cellViewBG.backgroundColor = [UIColor colorWithRed:241./255 green:241./255 blue:241./255 alpha:1.];
        }
        
        cell.cellTitleImageBG.backgroundColor = [ResourceColor getResColor:[_dataSources[indexPath.row] stringForKey:@"颜色"]]?:[UIColor darkGrayColor];
        cell.cellTitleImageBG.layer.borderColor = [[UIColor whiteColor] CGColor];
        cell.cellTitleImageBG.layer.borderWidth = 2;
        
        return cell;
    }else{
        static NSString * identifier = @"RightResourceSearchTableViewCell";
        RightResourceSearchTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        cell.dicSource = _dataSources[indexPath.row];
        cell.dataSource = _rightHeadDataSources;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (indexPath.row % 2) {
            cell.cellViewBG.backgroundColor = [UIColor colorWithRed:230./255 green:230./255 blue:230./255 alpha:1.];
        }else{
            cell.cellViewBG.backgroundColor = [UIColor colorWithRed:241./255 green:241./255 blue:241./255 alpha:1.];
        }
        return cell;
    }
    return nil;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    if(tableView == _leftTableView){
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _leftTableView.size.width, 50)];
        view.backgroundColor = [UIColor colorWithRed:139./255 green:139./255 blue:139./255 alpha:1.];
        
        for (int i = 0; i<_leftHeadDataSources.count; i++) {
            // 对应cell的坐标计算
            UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(28 + 100*i + 15,
                                                                       5,
                                                                       100,
                                                                       38)];
            
            
            [lable setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14]];
            lable.textAlignment = NSTextAlignmentCenter;
            lable.text = _leftHeadDataSources[i];
            lable.textColor = [UIColor whiteColor];
            [view addSubview:lable];
        }
        return view;
        
    }else{
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _rightTableView.size.width, 50)];
        view.backgroundColor = [UIColor colorWithRed:139./255 green:139./255 blue:139./255 alpha:1.];
        for (int i = 0; i<_rightHeadDataSources.count; i++) {
            
            
            UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(120*i + 15,
                                                                       5,
                                                                       120,
                                                                       38)];
            
            [lable setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14]];
            lable.textAlignment = NSTextAlignmentCenter;
            lable.text = _rightHeadDataSources[i];
            lable.textColor = [UIColor whiteColor];
            [view addSubview:lable];
        }
        return view;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView == _rightTableView) {
        return 50;
    }else{
        return 50;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView == _rightTableView) {
        return 1;
    }else{
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == _leftTableView) {
        return _dataSources.count;
    }else{
        return _dataSources.count;
    }
}

//上拉加载
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {

    if (indexPath.row+1 == _currentPage*20)
    {
        _currentPage++;
        NSLog(@"page = %zd",_currentPage);
        
        if ([_resourceType isEqualToString:@"0"]) {
            [self fetchCarResourceListFromManufacturer:[_dataSources count]];
        }else if ([_resourceType isEqualToString:@"1"]){
            [self fetchCarResourceListFormDealers:[_dataSources count]];
        }
    }
}


#pragma mark
#pragma mark scrollFollow ================================
/**
 *  数据联动
 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == _leftTableView) {
        [self tableView:_rightTableView scrollFollowTheOther:_leftTableView];
    }else{
        [self tableView:_leftTableView scrollFollowTheOther:_rightTableView];
    }
}

- (void)tableView:(UITableView *)tableView scrollFollowTheOther:(UITableView *)other{
    CGFloat offsetY= other.contentOffset.y;
    CGPoint offset=tableView.contentOffset;
    offset.y=offsetY;
    tableView.contentOffset=offset;
}
#pragma mark 
#pragma mark ===========================================
/**
 *  @author Jakey, 16-01-26 16:01:23
 *
 *  获取共享文档
 *
 *  @param path <#path description#>
 */
- (void)fetchCarResourceListFromShareCenter:(NSString*)path{
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    NSString *filePath;
    self.webview.hidden = NO;
    if([path hasPrefix:@"upload/share/"]){
        filePath =  [baseInterface stringByAppendingString:path];
    }else{
        filePath =  path;
    }
    NSURL *url = [NSURL URLWithString:filePath];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webview loadRequest:request];
}
/**
 *  获取车型列表数据   厂商
 */

- (void)fetchCarResourceListFromManufacturer:(NSInteger)startNum{
    __weak __typeof(self)weakSelf = self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    [dic setObject:[NSNumber numberWithInteger:startNum] forKey:@"startNum"];
    
    [dic setObject:_carTypeString?:@"ALL" forKey:@"brandName"];
    [dic setObject:_carModelString?:@"ALL" forKey:@"modelName"];
    [dic setObject:_carStateString?:@"ALL" forKey:@"carstatus"];
    [dic setObject:_carInColorString?:@"ALL" forKey:@"colorIn"];
    [dic setObject:_carColorString?:@"ALL" forKey:@"colorOut"];
    
/*    String brandName=paramString("brandName");//车系名称
      String carstatus=paramString("carstatus"); 车辆状态
      String colorIn=paramString("colorIn");  内饰颜色
      String colorOut=paramString("colorOut"); 外饰颜色
 */
    [ResourceSearchModel fetchCarResourceListFromManufacturer:dic Success:^(NSArray *headList,NSArray *carClassResultlst ,id responseObject) {
        if (headList.count > 0) {
            
            if (!_dataSources) {
                _dataSources = [[NSMutableArray alloc] init];
            }
            if (!_dataSourcesCopy) {
                _dataSourcesCopy = [[NSMutableArray alloc] init];
            }
            
            _leftHeadDataSources = [[NSMutableArray alloc] init];
            _rightHeadDataSources = [[NSMutableArray alloc] init];
            
            for (int i = 0; i < headList.count; i++) {
                if (i < 2) {
                    [_leftHeadDataSources addObj:headList[i]];
                }else{
                    [_rightHeadDataSources addObj:headList[i]];
                }
            }
            
            [weakSelf addScrollview];
            
            
            if (startNum == 0) {
                _dataSources = [[NSMutableArray alloc] initWithArray:carClassResultlst];
                _dataSourcesCopy = [[NSMutableArray alloc] initWithArray:carClassResultlst];
            }else{
                [_dataSources addObjectsFromArray:carClassResultlst];
                [_dataSourcesCopy addObjectsFromArray:carClassResultlst];
            }
            
            
            
            [_leftTableView reloadData];
            [_rightTableView reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

/**
 *  经销商数据
 */
- (void)fetchCarResourceListFormDealers:(NSInteger )startNum{
    __weak __typeof(self)weakSelf = self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    [dic setObject:[NSNumber numberWithInteger:startNum] forKey:@"startNum"];
    
    // ALL 不用传递参数  服务器要求
    if ([_carStateString isEqualToString:@"ALL"]) {
        _carStateString = @"";
    }
    if ([_carInColorString isEqualToString:@"ALL"]) {
        _carInColorString = @"";
    }
    if ([_carColorString isEqualToString:@"ALL"]) {
        _carColorString = @"";
    }
    if ([_carTypeString isEqualToString:@"ALL"]) {
        _carTypeString = @"";
    }
    
    [dic setObject:_carTypeString?:@"" forKey:@"车系"];
    [dic setObject:_carInColorString?:@"" forKey:@"内饰颜色"];
    [dic setObject:_carColorString?:@"" forKey:@"外饰颜色"];
    
//    rowName：在库状态
//    rowType
    [dic setObject:@"在库状态" forKey:@"rowName"];
    [dic setObject:_carStateString?:@"" forKey:@"rowType"];
    
    [dic setObject:[NSNumber numberWithInt:20] forKey:@"rowCount"];
    
    [ResourceSearchModel fetchCarResourceList:dic Success:^(NSArray *headList,NSArray *carClassResultlst ,id responseObject) {
        if (headList.count > 0) {
            
            if (!_dataSources) {
                _dataSources = [[NSMutableArray alloc] init];
            }
            if (!_dataSourcesCopy) {
                _dataSourcesCopy = [[NSMutableArray alloc] init];
            }
            
            _leftHeadDataSources = [[NSMutableArray alloc] init];
            _rightHeadDataSources = [[NSMutableArray alloc] init];
            
            for (int i = 0; i < headList.count; i++) {
                if (i < 4) {
                    [_leftHeadDataSources addObj:headList[i]];
                }else{
                    [_rightHeadDataSources addObj:headList[i]];
                }
            }
            
            [weakSelf addScrollview];
            
            
            if (startNum == 0) {
                _dataSources = [[NSMutableArray alloc] initWithArray:carClassResultlst];
                _dataSourcesCopy = [[NSMutableArray alloc] initWithArray:carClassResultlst];
            }else{
                [_dataSources addObjectsFromArray:carClassResultlst];
                [_dataSourcesCopy addObjectsFromArray:carClassResultlst];
            }
            
            
            
            
            [_leftTableView reloadData];
            [_rightTableView reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}



/**
 *  filtrateViewData
 */

- (void)filtrateData{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //车型
    NSMutableArray *filtrateCarTypeData = [@[]mutableCopy];
    if (_carTypeString && ![_carTypeString isEqualToString:@"ALL"]) {
        for (NSDictionary *dic in _dataSourcesCopy) {
            NSString *carType = [dic stringForKey:@"车系"];
            if ([carType isEqualToString:_carTypeString]) {
                [filtrateCarTypeData addObj:dic];
            }
        }
    }

    if ([_carTypeString isEqualToString:@"ALL"]) {
        filtrateCarTypeData = [[NSMutableArray alloc] initWithArray:_dataSourcesCopy];
    }
    
    _dataSources = [[NSMutableArray alloc] initWithArray:filtrateCarTypeData];
    
    //状态
    
    NSMutableArray *filtrateCarStateData = [@[]mutableCopy];
    if (_carStateString && ![_carStateString isEqualToString:@"ALL"]) {
        for (NSDictionary *dic in filtrateCarTypeData) {
            NSString *carState = [dic stringForKey:@"车辆状态"];
            if ([carState isEqualToString:_carStateString]) {
                [filtrateCarStateData addObj:dic];
            }
        }
    }
    if ([_carStateString isEqualToString:@"ALL"] || !_carStateString) {
        filtrateCarStateData = [[NSMutableArray alloc] initWithArray:filtrateCarTypeData];
    }
    
    _dataSources = [[NSMutableArray alloc] initWithArray:filtrateCarStateData];
    
    //外饰颜色

    NSMutableArray *filtrateCarColorData = [@[]mutableCopy];
    if (_carColorString && ![_carColorString isEqualToString:@"ALL"]) {
        for (NSDictionary *dic in filtrateCarStateData) {
            NSString *carColor = [dic stringForKey:@"外饰颜色"];
            if ([carColor isEqualToString:_carColorString]) {
                [filtrateCarColorData addObj:dic];
            }
        }
    }
    if ([_carColorString isEqualToString:@"ALL"] || !_carColorString) {
        filtrateCarColorData = [[NSMutableArray alloc] initWithArray:filtrateCarStateData];
    }
    _dataSources = [[NSMutableArray alloc] initWithArray:filtrateCarColorData];
    
    
    //内饰颜色
    NSMutableArray *filtrateInCarColorData = [@[]mutableCopy];
    if (_carInColorString && ![_carInColorString isEqualToString:@"ALL"]) {
        for (NSDictionary *dic in filtrateCarStateData) {
            NSString *carColor = [dic stringForKey:@"内饰颜色"];
            if ([carColor isEqualToString:_carInColorString]) {
                [filtrateInCarColorData addObj:dic];
            }
        }
    }
    if ([_carInColorString isEqualToString:@"ALL"] || !_carInColorString) {
        filtrateInCarColorData = [[NSMutableArray alloc] initWithArray:filtrateCarColorData];
    }
    
    _dataSources = [[NSMutableArray alloc] initWithArray:filtrateInCarColorData];
    
    
    [_leftTableView reloadData];
    [_rightTableView reloadData];
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}



/**
 *  present detail
 */
-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
//    [self presentDSPAPopup:modelDetailViewController parentViewController:self touchCallBack:nil haveMask:YES includeNavgation:NO alignTop:YES];
    
    [self.coverView removeFromSuperview];
    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 70, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
    self.coverView.backgroundColor = [UIColor blackColor];
    self.coverView.alpha = 0;
    [self.view addSubview:self.coverView];
    
    modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, self.view.height, modelDetailViewController.view.width, modelDetailViewController.view.height);
    [self.view addSubview:modelDetailViewController.view];
    [self addChildViewController:modelDetailViewController];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.coverView.alpha = 0.55;
        modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, (self.view.height-modelDetailViewController.view.height)/2, modelDetailViewController.view.width, modelDetailViewController.view.height);
    }];
}


@end
