//
//  ResourceSearchFiltrateTempViewController.h
//  DSPA2015
//
//  Created by runlin on 16/7/19.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ResourceSearchFiltrateViewController.h"
typedef void(^onResourceSearchFiltrateCallBackTemp)(NSString *carTypeString ,NSString *carModelString , NSString *carStateString , NSString *carColorString, NSString *carInColorString);

@interface ResourceSearchFiltrateTempViewController : ResourceSearchBaseViewController

@property (nonatomic , strong) NSString *resourceType;
@property (nonatomic , copy) onResourceSearchFiltrateCallBackTemp callBackResourceSearchFiltrate;

@end
