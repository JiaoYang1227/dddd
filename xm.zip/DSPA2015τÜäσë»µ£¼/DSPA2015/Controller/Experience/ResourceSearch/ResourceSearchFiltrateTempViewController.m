//
//  ResourceSearchFiltrateTempViewController.m
//  DSPA2015
//
//  Created by runlin on 16/7/19.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ResourceSearchFiltrateTempViewController.h"
#import "ResourceSearchFiltrateModel.h"

@interface ResourceSearchFiltrateTempViewController ()
{
    NSMutableArray *_brandlist;
    NSMutableArray *_carStatuslist;
    NSMutableArray *_outColorlist;
    NSMutableArray *_inColorlist;
    NSMutableArray *_modelList;
    
    
    NSString *_carTypeString;
    NSString *_carModelString;
    NSString *_carStateString;
    NSString *_carColorString;
    NSString *_carInColorString;
}
@property (weak, nonatomic) IBOutlet SelectButton *carTypeButtonOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *carStateButtonOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *outCarColorButtonOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *inCarColorButtonOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *carModelButtonOutlet;

@end

@implementation ResourceSearchFiltrateTempViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // 厂商
    if ([self.resourceType isEqualToString:@"0"]) {
        [self requestFiltrateFactoryData];
        
    }else if ([self.resourceType isEqualToString:@"1"]){
        // 经销商获取
        [self requestFiltrateData];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)requestFiltrateData{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ResourceSearchFiltrateModel fetchResourceFiltrateBrandList:nil Success:^(NSMutableArray *brandlist,NSMutableArray *carStatuslist,NSMutableArray *outColorlist,NSMutableArray *inColorlist ,id responseObject) {
        
        _brandlist = [[NSMutableArray alloc] initWithArray:brandlist];
        _carStatuslist = [[NSMutableArray alloc] initWithArray:carStatuslist];
        _outColorlist = [[NSMutableArray alloc] initWithArray:outColorlist];
        _inColorlist = [[NSMutableArray alloc] initWithArray:inColorlist];
        
//        [self filtrateViewData];
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}

//厂商
- (void)requestFiltrateFactoryData{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ResourceSearchFiltrateModel fetchResourceFiltrateFactoryModelList:nil Success:^(NSMutableArray *brandlist,NSMutableArray *carStatuslist,NSMutableArray *outColorlist,NSMutableArray *inColorlist ,NSMutableArray *modelList,id responseObject) {
        
        _brandlist = [[NSMutableArray alloc] initWithArray:brandlist];
        _carStatuslist = [[NSMutableArray alloc] initWithArray:carStatuslist];
        _outColorlist = [[NSMutableArray alloc] initWithArray:outColorlist];
        _inColorlist = [[NSMutableArray alloc] initWithArray:inColorlist];
        
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}




- (IBAction)carTypeButtonAction:(SelectButton *)sender {
    PopoverSearchController *search = [self showSearchSelectController:sender withData:_brandlist selectItem:^(ResourceSearchFiltrateModel *item, NSString *key, NSString *value) {
        
        sender.value = item.brandname?:@"ALL";
        _carTypeString = item.brandname?:@"ALL";
        
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [ResourceSearchFiltrateModel fetchResourceFiltrateFactoryModelList:@{@"brandName":item.brandname?:@""} Success:^(NSMutableArray *brandlist,NSMutableArray *carStatuslist,NSMutableArray *outColorlist,NSMutableArray *inColorlist ,NSMutableArray *modelList ,id responseObject) {
            
//            _brandlist = [[NSMutableArray alloc] initWithArray:brandlist];
            _carStatuslist = [[NSMutableArray alloc] initWithArray:carStatuslist];
            _outColorlist = [[NSMutableArray alloc] initWithArray:outColorlist];
            _inColorlist = [[NSMutableArray alloc] initWithArray:inColorlist];
            _modelList = [[NSMutableArray alloc] initWithArray:modelList];
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        } Failure:^(NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }];
        
    }];
    
    
    [search titleForSelectSearchItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel *item) {
        return item.brandname?:@"ALL";
    }];
    
    [search hiddenSearchBar:YES];
}


- (IBAction)carModelButtonAction:(SelectButton *)sender {
    PopoverSearchController *search = [self showSearchSelectController:sender withData:_modelList selectItem:^(ResourceSearchFiltrateModel *item, NSString *key, NSString *value) {
        
        sender.value = item.model?:@"ALL";
        _carModelString = item.model?:@"ALL";
        
    }];
    
    
    [search titleForSelectSearchItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel *item) {
        return item.model?:@"ALL";
    }];
    
    [search hiddenSearchBar:YES];
}





- (IBAction)carStateButtonAction:(SelectButton *)sender {
    PopoverSearchController *search = [self showSearchSelectController:sender withData:_carStatuslist selectItem:^(ResourceSearchFiltrateModel *item, NSString *key, NSString *value) {
        
        sender.value = item.carstatus?:@"ALL";
        _carStateString = item.carstatus?:@"ALL";
        
    }];
    
    
    [search titleForSelectSearchItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel *item) {
        return item.carstatus?:@"ALL";
    }];
    
    [search hiddenSearchBar:YES];
}
- (IBAction)outCarColorButtonAction:(SelectButton *)sender {
    PopoverSearchController *search = [self showSearchSelectController:sender withData:_outColorlist selectItem:^(ResourceSearchFiltrateModel *item, NSString *key, NSString *value) {
        
        sender.value = item.outcolor?:@"ALL";
        _carColorString = item.outcolor?:@"ALL";
    }];
    
    [search titleForSelectSearchItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel *item) {
        return item.outcolor?:@"ALL";
    }];
    
    [search hiddenSearchBar:YES];
}
- (IBAction)inCarColorButtonAction:(SelectButton *)sender {
    PopoverSearchController *search = [self showSearchSelectController:sender withData:_inColorlist selectItem:^(ResourceSearchFiltrateModel *item, NSString *key, NSString *value) {
        
        sender.value = item.incolor?:@"ALL";
        _carInColorString = item.incolor?:@"ALL";
    }];
    
    
    [search titleForSelectSearchItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel *item) {
        return item.incolor?:@"ALL";
    }];
    
    [search hiddenSearchBar:YES];
}


- (IBAction)okButtonAction:(id)sender {
    if (self.callBackResourceSearchFiltrate) {
        self.callBackResourceSearchFiltrate(_carTypeString?:@"ALL",_carModelString?:@"ALL",_carStateString?:@"ALL",_carColorString?:@"ALL",_carInColorString?:@"ALL");
    }
    
    
    [self dismissTouched:sender];
}

@end
