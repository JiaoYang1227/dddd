//
//  ResourceSearchFiltrateViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/29.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourceSearchFiltrateViewController.h"
#import "ResourceSearchFiltrateModel.h"

@interface ResourceSearchFiltrateViewController ()
{
//    __weak IBOutlet SelectView *_carType;       // 车型
    IBOutlet SelectView *_carState;      // 车辆状态
    IBOutlet SelectView *_carColour;     // 外饰颜色
    IBOutlet SelectView *_carInColor;    // 内饰颜色
    IBOutlet SelectView *_carType;
    
    __weak IBOutlet UIScrollView *_scrollview;
    __weak IBOutlet UIView *_staticView;
    
    
    
    
    
    NSMutableArray *_brandlist;
    NSMutableArray *_carStatuslist;
    NSMutableArray *_outColorlist;
    NSMutableArray *_inColorlist;
    
    
    NSString *_carTypeString;
    NSString *_carStateString;
    NSString *_carColorString;
    NSString *_carInColorString;
}
- (IBAction)okButtonAction:(id)sender;
@end

@implementation ResourceSearchFiltrateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    

        // 厂商
    if ([self.resourceType isEqualToString:@"0"]) {
        [self requestFiltrateFactoryData];
        
    }else if ([self.resourceType isEqualToString:@"1"]){
        // 经销商获取
        [self requestFiltrateData];
    }
    
    self.title = @"库存查询高级搜索";
}

- (void)requestFiltrateData{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ResourceSearchFiltrateModel fetchResourceFiltrateBrandList:nil Success:^(NSMutableArray *brandlist,NSMutableArray *carStatuslist,NSMutableArray *outColorlist,NSMutableArray *inColorlist ,id responseObject) {
        
        _brandlist = [[NSMutableArray alloc] initWithArray:brandlist];
        _carStatuslist = [[NSMutableArray alloc] initWithArray:carStatuslist];
        _outColorlist = [[NSMutableArray alloc] initWithArray:outColorlist];
        _inColorlist = [[NSMutableArray alloc] initWithArray:inColorlist];
        
        [self filtrateViewData];
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}

//厂商
- (void)requestFiltrateFactoryData{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ResourceSearchFiltrateModel fetchResourceFiltrateFactoryBrandList:nil Success:^(NSMutableArray *brandlist,NSMutableArray *carStatuslist,NSMutableArray *outColorlist,NSMutableArray *inColorlist ,id responseObject) {
        
        _brandlist = [[NSMutableArray alloc] initWithArray:brandlist];
        _carStatuslist = [[NSMutableArray alloc] initWithArray:carStatuslist];
        _outColorlist = [[NSMutableArray alloc] initWithArray:outColorlist];
        _inColorlist = [[NSMutableArray alloc] initWithArray:inColorlist];
        
        [self filtrateViewData];
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}




/**
 *  筛选页面数据
 */
- (void)filtrateViewData{
    
    UILabel *brandLable = [[UILabel alloc] initWithFrame:CGRectMake(_staticView.frame.origin.x, _staticView.frame.origin.y, 200, 50)];
    brandLable.text = @"车型";
    brandLable.font = [UIFont systemFontOfSize:22];
    [_scrollview addSubview:brandLable];
    NSUInteger brand = 0;
    if (_brandlist.count < 15) {
        brand = _brandlist.count/7;
    }else{
        brand = _brandlist.count/7 + 1;
    }
    
    _carType.frame = CGRectMake(_staticView.frame.origin.x,_staticView.frame.origin.y + 50, _staticView.frame.size.width, 50 * brand);

    
    UILabel *carStateLable = [[UILabel alloc] initWithFrame:CGRectMake(_carType.frame.origin.x, _carType.frame.origin.y + _carType.frame.size.height, 200, 50)];
    carStateLable.text = @"车辆状态";
    carStateLable.font = [UIFont systemFontOfSize:22];
    [_scrollview addSubview:carStateLable];
    NSUInteger state = _carStatuslist.count / 7 + 1;
    _carState.frame = CGRectMake(_carType.frame.origin.x, _carType.frame.origin.y + _carType.frame.size.height + 50, _staticView.frame.size.width, 50 * state);
    

    UILabel *carColourLable = [[UILabel alloc] initWithFrame:CGRectMake(_staticView.frame.origin.x, _carState.frame.origin.y + _carState.frame.size.height, 200, 50)];
    carColourLable.text = @"外饰颜色";
    carColourLable.font = [UIFont systemFontOfSize:22];
    [_scrollview addSubview:carColourLable];
    NSUInteger carColour = _outColorlist.count/7 + 1;
    _carColour.frame = CGRectMake(_carState.frame.origin.x, _carState.frame.origin.y+ _carState.frame.size.height + 50, _staticView.frame.size.width, 50*carColour);
    
    UILabel *carInColorLable = [[UILabel alloc] initWithFrame:CGRectMake(_staticView.frame.origin.x, _carColour.frame.origin.y + _carColour.frame.size.height, 200, 50)];
    carInColorLable.text = @"内饰颜色";
    carInColorLable.font = [UIFont systemFontOfSize:22];
    [_scrollview addSubview:carInColorLable];
    NSInteger carInColor = _inColorlist.count/7 + 1;
    _carInColor.frame = CGRectMake(_carColour.frame.origin.x, _carColour.frame.origin.y+ _carColour.frame.size.height + 50, _staticView.frame.size.width, 50*carInColor);
    
    _scrollview.contentSize = CGSizeMake(947, 50*(brand + state+ carColour + carInColor + 5));
    
    [_scrollview addSubview:_carType];
    [_scrollview addSubview:_carState];
    [_scrollview addSubview:_carColour];
    [_scrollview addSubview:_carInColor];
    
    
    
    //车系
    _carType.items = _brandlist;
    [_carType didSelectItem:^(NSInteger index, ResourceSearchFiltrateModel* item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        if (!value) {
            return;
        }
        _carTypeString = item.brandname?:@"ALL";
    }];
    
    
    [_carType titleForSelectItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel *item) {
        if (!item.brandname) {
            return @"ALL";
        }
        return item.brandname;
    }];
    
    //车俩状态
    _carState.items = _carStatuslist;
    [_carState didSelectItem:^(NSInteger index, ResourceSearchFiltrateModel *item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        if (!value) {
            return ;
        }
        _carStateString = item.carstatus?:@"ALL";
    }];
    [_carState titleForSelectItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel * item) {
        if (!item.carstatus) {
            return @"ALL";
        }
        return item.carstatus;
    }];
    //外饰颜色
    _carColour.items = _outColorlist;
    [_carColour didSelectItem:^(NSInteger index, ResourceSearchFiltrateModel *item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        if (!value) {
            return ;
        }
        _carColorString = item.outcolor?:@"ALL";
    }];
    
    [_carColour titleForSelectItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel* item) {
        if (!item.outcolor) {
            return @"ALL";
        }
        return item.outcolor;
    }];
    
    //内饰颜色
    _carInColor.items = _inColorlist;
    [_carInColor didSelectItem:^(NSInteger index, ResourceSearchFiltrateModel *item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        if (!value) {
            return ;
        }
        _carInColorString = item.incolor?:@"ALL";
    }];
    
    [_carInColor titleForSelectItem:^NSString *(NSInteger index, ResourceSearchFiltrateModel* item) {
        if (!item.incolor) {
            return @"ALL";
        }
        return item.incolor;
    }];
    
}


- (IBAction)okButtonAction:(id)sender {
    
    if (self.callBackResourceSearchFiltrate) {
        self.callBackResourceSearchFiltrate(_carTypeString?:@"ALL",_carStateString?:@"ALL",_carColorString?:@"ALL",_carInColorString?:@"ALL");
    }
    
    
    [self dismissTouched:sender];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
