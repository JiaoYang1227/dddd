//
//  ResourceSearchViewController.h
//  DSPA2015
//
//  Created by gavin on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface ResourceSearchViewController : BaseViewController
@property(strong,nonatomic)  UIView *coverView;
@property (weak, nonatomic) IBOutlet UIWebView *webview;
@end
