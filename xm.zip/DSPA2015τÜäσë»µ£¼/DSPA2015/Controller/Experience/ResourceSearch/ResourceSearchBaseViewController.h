//
//  ResourceSearchBaseViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/29.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface ResourceSearchBaseViewController : BaseViewController
- (IBAction)dismissTouched:(id)sender;
@end
