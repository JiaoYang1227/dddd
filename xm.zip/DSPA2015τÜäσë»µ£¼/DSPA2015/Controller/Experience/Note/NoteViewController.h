//
//  NoteViewController.h
//  DSPA2015
//
//  Created by Jakey on 16/1/9.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//


@interface NoteViewController : UIViewController<UITextViewDelegate>
@property(nonatomic,assign)BOOL show;
@property (weak, nonatomic) IBOutlet UITextView *noteView;
@end



typedef void(^NoteBackgroundViewCallback)(CGPoint point);
@interface NoteBackgroundView : UIView
{
    NoteBackgroundViewCallback _callback;
}
-(void)touchesBegan:(NoteBackgroundViewCallback)callback;
@end