//
//  NoteViewController.m
//  DSPA2015
//
//  Created by Jakey on 16/1/9.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "NoteViewController.h"
#import "FileManager.h"
@interface NoteViewController ()

@end

@implementation NoteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   NSData *note =  [[FileManager sharedManager] dataWithFilePath:[FileManager documentsPath:@"note.db"]];
    self.noteView.text =  [[NSString alloc] initWithData:note  encoding:NSUTF8StringEncoding]?:@"";
}

- (void)textViewDidChange:(UITextView *)textView{
    NSString *note = textView.text;
    [[FileManager sharedManager] saveData:[note dataUsingEncoding:NSUTF8StringEncoding]toFilePath:[FileManager documentsPath:@"note.db"]];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{


}

@end


@implementation NoteBackgroundView

-(void)touchesBegan:(void (^)(CGPoint))callback{
    _callback = [callback copy];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    if (_callback) {
        _callback(point);
    }
}

@end