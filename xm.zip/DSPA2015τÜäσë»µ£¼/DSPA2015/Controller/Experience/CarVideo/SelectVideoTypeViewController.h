//
//  SelectVideoTypeViewController.h
//  DSPA2015
//
//  Created by sun on 16/6/30.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface SelectVideoTypeViewController : BaseViewController
@property (nonatomic,strong)NSString *brandId;
@end
