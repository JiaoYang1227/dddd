//
//  SelectModelsCell.h
//  DSPA2015
//
//  Created by sun on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectModelsCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIImageView *MainImage;
@end
