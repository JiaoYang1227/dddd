//
//  CarVideoListCell.m
//  D-CARS
//
//  Created by owen on 15/7/16.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "CarVideoListCell.h"

@implementation CarVideoListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    self.MainView.layer.cornerRadius = 5;
//    self.MainView.layer.masksToBounds = YES;
    
    
}

@end
