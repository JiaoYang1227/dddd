//
//  SelectVideoTypeViewController.m
//  DSPA2015
//
//  Created by sun on 16/6/30.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "SelectVideoTypeViewController.h"
#import "CarVideo.h"
#import "CarVideoListViewController.h"
#import "JKToast.h"
@interface SelectVideoTypeViewController (){
    NSMutableArray *_items;
    NSMutableArray *_array;
}

@end

@implementation SelectVideoTypeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getTypeView];
}
-(void)viewWillDisappear:(BOOL)animated{
    
}
-(void)getTypeView{
    _items = [[NSMutableArray array]init];
    [CarVideo videoTypeWithSuccess:^(NSArray *array, id responseObject) {
        [_items addObjectsFromArray:array];
    } Failure:^(NSError *error) {
        
    }];
}
- (IBAction)ChooseTheType:(UIButton *)sender {
    NSString *strType;
    if (sender.tag == 100) {
        [CBTracking trackEvent:@"视频中心_全部视频"];
    } else if (sender.tag == 1) {
        [CBTracking trackEvent:@"视频中心_宣传类"];
    } else {
        [CBTracking trackEvent:@"视频中心_技术类"];
    }
    if (sender.tag == 100) {
        strType = @"all";
    }else{
        if (_items.count>0) {
            strType = [[_items objectAtIndex:sender.tag] objectForKey:@"key"];
        }else{
            [JKToast toastWithText:@"数据加载中,稍后再试..."];
            return;
        }
        
    }
    CarVideoListViewController *carVideo = [[CarVideoListViewController alloc]init];
    carVideo.brandId = self.brandId;
    carVideo.vtid = strType;
    carVideo.vtid_jsl = [[_items objectAtIndex:0] objectForKey:@"key"];
    carVideo.vtid_xcl = [[_items objectAtIndex:1] objectForKey:@"key"];
    [self.navigationController pushViewController:carVideo animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
