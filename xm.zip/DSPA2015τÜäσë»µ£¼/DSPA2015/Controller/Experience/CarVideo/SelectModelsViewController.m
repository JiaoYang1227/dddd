//
//  SelectModelsViewController.m
//  DSPA2015
//
//  Created by sun on 16/6/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "SelectModelsViewController.h"
#import "SelectModelsCell.h"
#import "CarVideo.h"
#define COLLECTIONVIEW_CELL_IDENTIFIER @"SelectModelsCell"
#import "SelectVideoTypeViewController.h"
@interface SelectModelsViewController (){
    
    __weak IBOutlet UICollectionView *_SelectModelCollectionView;
    NSMutableArray *_items;
//    NSMutableDictionary *_dicModel;
}
@property(nonatomic,strong)NSMutableArray *items;
@end

@implementation SelectModelsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"carVideoModelList" ofType:@"plist"];
    _items = [[NSMutableArray alloc] initWithContentsOfFile:plistPath];
    [_SelectModelCollectionView registerNib:[UINib nibWithNibName:@"SelectModelsCell" bundle:nil] forCellWithReuseIdentifier:COLLECTIONVIEW_CELL_IDENTIFIER];
}
//-(void)getCarsView{
//    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
//    for (NSDictionary *dic in [CarVideo findAllDownListWithbrandId:@"all" vtid:@"all"]) {
//        [dict setObject:dic forKey:[dic objectForKey:@"brandId"]];
//    }
//    _items = [NSMutableArray arrayWithArray:[dict allValues]];
//    for (int i = 0; i < _items.count; i++) {
//        NSString *modelName = [_dicModel objectForKey:[[_items objectAtIndex:i] objectForKey:@"brandId"]];
//        if (!modelName) {
//            [_items removeObjectAtIndex:i];
//            i--;
//        }
//    }
//    [_SelectModelCollectionView registerNib:[UINib nibWithNibName:@"SelectModelsCell" bundle:nil] forCellWithReuseIdentifier:COLLECTIONVIEW_CELL_IDENTIFIER];
//    [_SelectModelCollectionView reloadData];
//}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"viewWillAppear");
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    NSLog(@"viewWillDisappear");
}
#pragma mark -collectionView delegate && dataSoutce
- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _items.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = COLLECTIONVIEW_CELL_IDENTIFIER;
    SelectModelsCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
//    NSDictionary *dic = [_items objectWithIndex:indexPath.row];
//    NSString *modelName = [_dicModel objectForKey:[dic objectForKey:@"brandId"]];
//    cell.title.text = modelName;
//    [cell.MainImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"CarVideo_SelectModels_%@",modelName]]];
    NSDictionary *dic = [_items objectWithIndex:indexPath.row];
    NSString *modelName = [dic objectForKey:@"value"];
    cell.title.text = modelName;
    [cell.MainImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"CarVideo_SelectModels_奥迪%@",modelName]]];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(230, 200);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 2, 0);
}

- (void) collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
        SelectVideoTypeViewController *selectvideo = [[SelectVideoTypeViewController alloc]init];
//        selectvideo.brandId = [[_items objectAtIndex:indexPath.row] objectForKey:@"brandId"];
        NSDictionary *dic = [_items objectWithIndex:indexPath.row];
        NSString *modelID = [dic objectForKey:@"key"];
        selectvideo.brandId = modelID;
        [self.navigationController pushViewController:selectvideo animated:YES];
    
}
/**
 *  全部视频
 *
 */
- (IBAction)allResourcesTouched:(id)sender {
    SelectVideoTypeViewController *selectvideo = [[SelectVideoTypeViewController alloc]init];
    selectvideo.brandId = @"all";
    [self.navigationController pushViewController:selectvideo animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
