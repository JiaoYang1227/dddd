//
//  CarVideoListViewController.h
//  DSPA2015
//
//  Created by sun on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "SelectView.h"
@interface CarVideoListViewController : BaseViewController
@property (weak, nonatomic) IBOutlet SelectView *carsView;
@property (weak, nonatomic) IBOutlet SelectView *typeView;
@property (weak, nonatomic) IBOutlet UIImageView *promptImageView;
@property (weak, nonatomic) IBOutlet UIButton *screeningButton;
@property (nonatomic,strong)NSString *brandId;
@property (nonatomic,strong)NSString *vtid;
@property (nonatomic,strong)NSString *vtid_xcl; //宣传类视频id
@property (nonatomic,strong)NSString *vtid_jsl; //技术类视频id
@end
