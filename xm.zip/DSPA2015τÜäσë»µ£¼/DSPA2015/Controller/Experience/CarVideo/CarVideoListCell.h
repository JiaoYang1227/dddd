//
//  CarVideoListCell.h
//  D-CARS
//
//  Created by owen on 15/7/16.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarVideoListCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UIImageView *MainImage;
@property (weak, nonatomic) IBOutlet UIView *MainView;

@end
