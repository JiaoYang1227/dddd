//
//  CarVideoListViewController.m
//  DSPA2015
//
//  Created by sun on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarVideoListViewController.h"
#import "XTMoviePlayerController.h"
#import "FileManager.h"
#import "CarVideoListCell.h"
#import "CarVideo.h"
#import "JKToast.h"
#import <AVFoundation/AVFoundation.h>
#define COLLECTIONVIEW_CELL_IDENTIFIER @"CarVideoListCell"
@interface CarVideoListViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>{
    
    IBOutlet UIView *_SearchViewFiltrateView;//筛选视图
    __weak IBOutlet UIView *_SearchFiltrateCenterView;//筛选视图内容

    __weak IBOutlet UICollectionView *_videoListCollectionView;
    
    XTMoviePlayerController *player;
}
@property (nonatomic, strong) NSMutableArray *videosDataList;
@end

@implementation CarVideoListViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [_videoListCollectionView registerNib:[UINib nibWithNibName:@"CarVideoListCell" bundle:nil] forCellWithReuseIdentifier:COLLECTIONVIEW_CELL_IDENTIFIER];
    UICollectionViewFlowLayout * FlowLayout = [[UICollectionViewFlowLayout alloc]init];
    [FlowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    FlowLayout.itemSize = CGSizeMake(310. , 200.);
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"modelList" ofType:@"plist"];
    NSMutableDictionary *dicModel = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    self.videosDataList = (NSMutableArray *)[CarVideo findAllDownListWithbrandId:self.brandId vtid:self.vtid];
    //过滤掉垃圾数据
    for (int i = 0; i < self.videosDataList.count; i++) {
        NSString *modelName = [dicModel objectForKey:[[self.videosDataList objectAtIndex:i] objectForKey:@"brandId"]];
        if (!modelName) {
            [self.videosDataList removeObjectAtIndex:i];
            i--;
        }
    }
    if (self.videosDataList.count == 0) {//没有资源提示
        [_promptImageView setHidden:NO];
        [_promptImageView setImage:[UIImage imageNamed:@"carVideo_PromptDownload.png"]];
        [_screeningButton setHidden:YES];
    }else{
        [_promptImageView setHidden:YES];
        [_screeningButton setHidden:NO];
        [_videoListCollectionView reloadData];
    }
//    [self getTypeView];
//    [self getCarsView];
    
    self.title = @"视频中心";
}

-(void)getCarsView{
    __weak typeof(self)weakSelf = self;
    NSMutableArray *items = [[NSMutableArray array]init];
    [items addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"ALL",@"value",@"all",@"key",  nil]];
    NSLog(@"%f",_carsView.itemSize.height);
    [CarVideo videoBrandWithSuccess:^(NSArray *array, id responseObject) {
        [items addObjectsFromArray:array];
        weakSelf.carsView.items = items;
        
        NSLog(@"%f",_carsView.itemSize.height);
        [weakSelf.carsView didSelectItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *multiSelectItems) {
            NSLog(@"%@",multiSelectItems);
            _brandId = key;
        }];
        [weakSelf.carsView setSelectedIndex:0];
    } Failure:^(NSError *error) {
        
    }];
}
-(void)getTypeView{
    __weak typeof(self)weakSelf = self;
    NSMutableArray *items = [[NSMutableArray array]init];
    [items addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"ALL",@"value",@"all",@"key",  nil]];
    [CarVideo videoTypeWithSuccess:^(NSArray *array, id responseObject) {
        [items addObjectsFromArray:array];
        weakSelf.typeView.items = items;
        
        NSLog(@"%f",_carsView.itemSize.height);
        [weakSelf.typeView didSelectItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *multiSelectItems) {
            NSLog(@"%@",multiSelectItems);
            _vtid = key;
        }];
        [weakSelf.typeView setSelectedIndex:0];
    } Failure:^(NSError *error) {
        
    }];
    
    NSLog(@"%f",_typeView.itemSize.height);
    [weakSelf.typeView didSelectItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        NSLog(@"%@",multiSelectItems);
        _vtid = key;
    }];
    [self.typeView setSelectedIndex:0];
}
#pragma mark -collectionView delegate && dataSoutce
- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.videosDataList.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = COLLECTIONVIEW_CELL_IDENTIFIER;
    CarVideoListCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    NSDictionary *dic = [self.videosDataList objectWithIndex:indexPath.row];
    cell.title.text = [dic stringForKey:@"name"];
    NSString *path = [FileManager documentsPath:[NSString stringWithFormat:@"/video/%@/smallImage.jpg",[dic stringForKey:@"name"]]];
   
    [cell.MainImage setImage:[UIImage imageWithContentsOfFile:path]];
//    cell.time.text = [dic stringForKey:@"videoDuration"];
     NSString *filepath = [FileManager documentsPath:[NSString stringWithFormat:@"/video/%@/%@.mp4",[dic stringForKey:@"name"],[dic stringForKey:@"name"]]];
    cell.time.text = [self getVideoTotalTime:filepath];
    
    return cell;
}
-(NSString *)getVideoTotalTime:(NSString *)path{
    NSURL *movieURL = [NSURL fileURLWithPath:path];
    NSDictionary *opts = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO]
                                                     forKey:AVURLAssetPreferPreciseDurationAndTimingKey];
    AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:movieURL options:opts];  // 初始化视频媒体文件
    long long  second = 0 ,minute=0;
    second = urlAsset.duration.value / urlAsset.duration.timescale; // 获取视频总时长,单位秒
    if (second >= 60) {
        long long index = second / 60;
        minute = index;
        second = second - index*60;
    }
    return [NSString stringWithFormat:@"%lld分钟%lld秒",minute,second];
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(310, 200);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 2, 0);
}

- (void) collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.videosDataList.count>=indexPath.row+1) {
        NSDictionary *dic = [self.videosDataList objectWithIndex:indexPath.row];
        NSString *fileName = [FileManager documentsPath:[NSString stringWithFormat:@"/video/%@/%@.mp4",[dic stringForKey:@"name"],[dic stringForKey:@"name"]]];
        if (fileName == nil) {
            [JKToast toastWithText:@"没有找到该资源文件"];
            return;
        }
        
        player = [[XTMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:fileName]];
        __weak typeof(self) _weakSelf = self;
        [player startPlaying:self withBlock:^{
            NSLog(@"start play movie");
            
            NSString *resource = [NSString stringWithFormat:@"厂商/%@.%@@%@",[dic objectForKey:@"name"],[[dic objectForKey:@"videoPath"] pathExtension],[dic objectForKey:@"brandId"]];
            if ([_weakSelf.vtid_xcl isEqualToString:[dic objectForKey:@"vtId"]]) {
                [CBTracking startTracResource:resource?:@"" withModuleName:@"视频中心_宣传类"];
            } else if ([_weakSelf.vtid_jsl isEqualToString:[dic objectForKey:@"vtId"]]) {
                [CBTracking startTracResource:resource?:@"" withModuleName:@"视频中心_技术类"];
            } else {
                
            }
        }];
        [player didPlayFinished:^{
            NSLog(@"finished");
            NSString *resource = [NSString stringWithFormat:@"厂商/%@.%@@%@",[dic objectForKey:@"name"],[[dic objectForKey:@"videoPath"] pathExtension],[dic objectForKey:@"brandId"]];
            if ([_weakSelf.vtid_xcl isEqualToString:[dic objectForKey:@"vtId"]]) {
                [CBTracking endTracResource:resource?:@"" withModuleName:@"视频中心_宣传类"];
            } else if ([_weakSelf.vtid_jsl isEqualToString:[dic objectForKey:@"vtId"]]) {
                [CBTracking endTracResource:resource?:@"" withModuleName:@"视频中心_技术类"];
            } else {
                
            }
        }];
        NSLog(@"%f,%f",player.moviePlayer.endPlaybackTime,player.moviePlayer.duration);
        [player didplayField:^(NSError *error) {
            //
        }];
    }
    
}
/**
 *  筛选按钮点击
 */
- (IBAction)ONCLICKScreening:(id)sender {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [_screeningButton setImage:[UIImage imageNamed:@"screeningSelected.png"] forState:UIControlStateNormal];
    [self.view addSubview:_SearchViewFiltrateView];
    
    _SearchFiltrateCenterView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    _SearchFiltrateCenterView.layer.cornerRadius = 8;
    _SearchFiltrateCenterView.layer.borderWidth = 1;
    _SearchFiltrateCenterView.layer.masksToBounds = YES;
    
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}
/**
 *  筛选页面确认按钮
 */
- (IBAction)resourceSearchViewFiltrateAction:(id)sender {
    [_screeningButton setImage:[UIImage imageNamed:@"screeningNormal.png"] forState:UIControlStateNormal];
    self.videosDataList = [NSMutableArray arrayWithArray:[CarVideo findAllDownListWithbrandId:self.brandId vtid:_vtid]];//根据筛选条件从数据库取出数据
    if (self.videosDataList.count == 0) {//没有视频提示
        [_promptImageView setHidden:NO];
        [_promptImageView setImage:[UIImage imageNamed:@"carVideo_PromptNOVideo.png"]];
    }else{
        [_promptImageView setHidden:YES];
    }
     [_videoListCollectionView reloadData];
    [_SearchViewFiltrateView removeFromSuperview];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
