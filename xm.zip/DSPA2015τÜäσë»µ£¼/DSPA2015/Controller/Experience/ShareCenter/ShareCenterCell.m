//
//  ShareCenterCell.m
//  DSPA2015
//
//  Created by Jakey on 16/1/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ShareCenterCell.h"
#import "AppDelegate.h"
@implementation ShareCenterCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)bindData:(NSDictionary*)item{
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];

    self.fileName.text = [NSString stringWithFormat:@"%@",[item stringForKey:@"filename"]];
    self.filePath =  [baseInterface stringByAppendingString:[item stringForKey:@"path"]];
    self.shareUser.text =   [NSString stringWithFormat:@"%@",[item stringForKey:@"username"]];
    self.shareDate.text =   [DateManager date_YMDHMS_WithTimeIntervalSince1970:[[item stringForKey:@"createtime"] longLongValue]];
    
    if ([item integerForKey:@"filetype"] == 1) {
        self.myImageView.image = [UIImage imageNamed:@"fileshare_pdf.png"];
        
    }
    if ([item integerForKey:@"filetype"]  == 3){
        self.myImageView.image = [UIImage imageNamed:@"fileshare_excel.png"];
    }
}

@end
