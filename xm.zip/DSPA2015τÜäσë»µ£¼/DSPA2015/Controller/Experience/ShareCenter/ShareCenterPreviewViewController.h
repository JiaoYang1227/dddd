//
//  ShareCenterPreviewViewController.h
//  DSPA2015
//
//  Created by Jakey on 16/1/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface ShareCenterPreviewViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIWebView *myWebView;
@property (strong, nonatomic)  NSString *filePath;
@property (strong, nonatomic)  NSString *fileName;

- (IBAction)dismissTouched:(id)sender;

@end
