//
//  ShareCenterViewController.h
//  DSPA2015
//
//  Created by Jakey on 16/1/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface ShareCenterViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_dataArray;
}
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@end
