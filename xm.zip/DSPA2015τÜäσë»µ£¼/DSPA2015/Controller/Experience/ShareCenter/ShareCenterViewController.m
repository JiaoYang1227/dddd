//
//  ShareCenterViewController.m
//  DSPA2015
//
//  Created by Jakey on 16/1/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ShareCenterViewController.h"
#import "ShareCenter.h"
#import "ShareCenterCell.h"
#import "ShareCenterPreviewViewController.h"
#import "UIViewController+DSPAPopup.h"
@interface ShareCenterViewController ()

@end
static NSString *ShareCenterCellIdentifier = @"ShareCenterCell";

@implementation ShareCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self.myTableView registerNib:[UINib nibWithNibName:ShareCenterCellIdentifier bundle:nil] forCellReuseIdentifier:ShareCenterCellIdentifier];
    [self loadData];
    self.title = @"共享资源";
}

- (IBAction)backButtonTouched:(id)sender {
    [super backButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)loadData{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    [ShareCenter getFileShares:nil Success:^(NSDictionary *dic, id responseObject) {
        [_dataArray addObjectsFromArray:[dic arrayForKey:@"FileShares"]];
        [self.myTableView reloadData];
    } Failure:^(NSError *error) {
        
    }];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_dataArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    ShareCenterCell *cell = [tableView dequeueReusableCellWithIdentifier:ShareCenterCellIdentifier];
  
    if (indexPath.row %2 == 0) {
        cell.contentView.backgroundColor = [UIColor whiteColor];
    }else{
        cell.contentView.backgroundColor = [UIColor colorWithWhite:0.945 alpha:1.000];
    }
    
    [cell bindData:[_dataArray objectWithIndex:indexPath.row]];
    
    return cell;
}


#pragma mark --UICollectionViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    ShareCenterPreviewViewController *preview = [[ShareCenterPreviewViewController alloc]init];
    NSDictionary *item = [_dataArray objectWithIndex:indexPath.row];
    preview.fileName = [item objectForKey:@"filename"]?:@"";
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    if([[item stringForKey:@"path"] hasPrefix:@"upload/share/"]){
        preview.filePath =  [baseInterface stringByAppendingString:[item stringForKey:@"path"]];
    }else{
        preview.filePath =  [item stringForKey:@"path"];
    }
    [self presentDSPAPopup:preview parentViewController:self touchCallBack:^{
        
    } haveMask:NO includeNavgation:YES alignTop:YES];
    
}


@end
