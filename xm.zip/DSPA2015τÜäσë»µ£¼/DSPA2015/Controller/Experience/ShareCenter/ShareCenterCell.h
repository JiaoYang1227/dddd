//
//  ShareCenterCell.h
//  DSPA2015
//
//  Created by Jakey on 16/1/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareCenterCell : UITableViewCell
@property (strong, nonatomic)  NSString *filePath;
@property (weak, nonatomic) IBOutlet UILabel *fileName;
@property (weak, nonatomic) IBOutlet UILabel *shareUser;
@property (weak, nonatomic) IBOutlet UILabel *shareDate;
@property (weak, nonatomic) IBOutlet UIImageView *myImageView;
-(void)bindData:(NSDictionary*)item;
@end
