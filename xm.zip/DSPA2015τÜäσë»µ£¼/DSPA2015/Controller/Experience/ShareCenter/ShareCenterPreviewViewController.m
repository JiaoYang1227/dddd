//
//  ShareCenterPreviewViewController.m
//  DSPA2015
//
//  Created by Jakey on 16/1/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ShareCenterPreviewViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "Util.h"
@interface ShareCenterPreviewViewController ()

@end

@implementation ShareCenterPreviewViewController
-(void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"共享资源详情";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracResource:self.fileName?:@"" withModuleName:@"资源共享"];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [CBTracking startTracResource:self.fileName?:@"" withModuleName:@"资源共享"];
    [self loadWebView:self.filePath];
}
-(void)loadWebView:(NSString*)path{
    if(self.filePath)
    {
        NSURL *url = [NSURL URLWithString:[self.filePath?:@"" stringByAppendingString:[NSString stringWithFormat:@"?random=%@",[Util randomCode]]]];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [self.myWebView loadRequest:request];
    }
   
}
//- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
//    return YES;
//}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    //[MBProgressHUD hideHUDForView:webView animated:YES];
    
}
-(void)webViewDidStartLoad:(UIWebView *)webView{
    //[MBProgressHUD showHUDAddedTo:webView animated:YES];
}
- (IBAction)dismissTouched:(id)sender {
    [self dismissDSPAPopup:^{
        
    }];
}
@end
