//
//  SetingMasterViewController.m
//  D-CARS
//
//  Created by gavin on 15/7/28.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "SetingMasterViewController.h"
#import "SettingViewController.h"
#import "ResourcesManagerViewController.h"
#import "SoftManagerViewController.h"
#import "BackgroundManagerViewController.h"

@interface SetingMasterViewController ()
@property (weak, nonatomic) IBOutlet UIButton *feedbackOutlet;
@property (weak, nonatomic) IBOutlet UIButton *resourcesManagerOutlet;
@property (weak, nonatomic) IBOutlet UIButton *softManagerOutlet;
@property (weak, nonatomic) IBOutlet UIButton *backgroundButton;

- (IBAction)feedbackAction:(id)sender;
- (IBAction)resourcesManagerAction:(id)sender;
- (IBAction)softManagerAction:(id)sender;
@end

@implementation SetingMasterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.feedbackOutlet.selected = YES;
    self.resourcesManagerOutlet.selected = YES;
    self.softManagerOutlet.selected = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark detail nad edit
//获取master的父视图
-(UIViewController *)detailViewController{
    SettingViewController *setting = (SettingViewController*)self.parentViewController;
    return setting.detailViewController;
}
-(void)setDetailViewController:(UIViewController *)detailViewController{
    SettingViewController *setting = (SettingViewController*)self.parentViewController;
    setting.detailViewController = detailViewController;
}

- (IBAction)resourcesManagerAction:(id)sender {
    self.feedbackOutlet.selected = NO;
    self.resourcesManagerOutlet.selected = YES;
    self.softManagerOutlet.selected = NO;
    self.backgroundButton.selected =NO;

    ResourcesManagerViewController *rmvc = [[ResourcesManagerViewController alloc] init];
     self.detailViewController = rmvc;
    [Stat sendSettingStatWithName:@"resourcesManager"];

}

- (IBAction)softManagerAction:(id)sender {
    self.feedbackOutlet.selected = NO;
    self.resourcesManagerOutlet.selected = NO;
    self.softManagerOutlet.selected = YES;
    self.backgroundButton.selected =NO;

    SoftManagerViewController *smvc = [[SoftManagerViewController alloc] init];
    self.detailViewController = smvc;

}
- (IBAction)backgroundTouched:(id)sender {
    self.feedbackOutlet.selected = NO;
    self.resourcesManagerOutlet.selected = NO;
    self.softManagerOutlet.selected = NO;
    self.backgroundButton.selected =YES;
    
    BackgroundManagerViewController *background = [[BackgroundManagerViewController alloc] init];
    self.detailViewController = background;
}

@end
