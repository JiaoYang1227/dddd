//
//  RankTableViewCell.h
//  DSPA2015
//
//  Created by 李朋远 on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ComplaintsSuggestionsModel.h"

@interface RankTableViewCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *rankNo;
@property (nonatomic, weak) IBOutlet UILabel *rankDealer;
@property (nonatomic, weak) IBOutlet UILabel *rankName;
@property (nonatomic, weak) IBOutlet UILabel *rankIntegral;

- (void)cell_configuration:(ComplaintsSuggestionsModel *)model withType:(BOOL)isCurrentMonth;

@end
