//
//  ProductCenterTableViewCell.h
//  DSPA2015
//
//  Created by 李朋远 on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ComplaintsSuggestionsModel.h"

@interface ProductCenterTableViewCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *submitTime;
@property (nonatomic, weak) IBOutlet UILabel *submitContent;
@property (nonatomic, weak) IBOutlet UILabel *submitUser;
@property (nonatomic, weak) IBOutlet UILabel *submitStatus;

- (void)cell_configuration:(ComplaintsSuggestionsModel *)model;
@end
