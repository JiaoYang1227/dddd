//
//  ProductCenterTableViewCell.m
//  DSPA2015
//
//  Created by 李朋远 on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ProductCenterTableViewCell.h"
#import "DateManager.h"

@implementation ProductCenterTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)cell_configuration:(ComplaintsSuggestionsModel *)model
{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.submitTime.text = [DateManager date_YMD_WithTimeIntervalStringSince1970:model.addtime];
    self.submitContent.text =  model.describe;
    self.submitUser.text = model.username;
    self.submitStatus.text = model.state;
}

@end
