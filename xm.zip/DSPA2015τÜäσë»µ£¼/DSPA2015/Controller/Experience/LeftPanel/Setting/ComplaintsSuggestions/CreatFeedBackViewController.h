//
//  CreatFeedBackViewController.h
//  DSPA2015
//
//  Created by 李朋远 on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "BorderTextView.h"
#import "ComplaintsSuggestionsModel.h"

@protocol CreatFeedBackViewControllerDelegate <NSObject>

- (void)updateSuggestList;

@end

@interface CreatFeedBackViewController : BaseViewController

@property (nonatomic, weak) IBOutlet UIButton *firstImage;
@property (nonatomic, weak) IBOutlet UIButton *secondImage;
@property (nonatomic, weak) IBOutlet UIButton *thirdImage;
@property (nonatomic, weak) IBOutlet UIButton *fourthImage;
@property (nonatomic, weak) IBOutlet UIButton *addImageBtn;
@property (nonatomic, weak) IBOutlet UIButton *submitBtn;
@property (nonatomic, weak) IBOutlet BorderTextView *feedbackContent;
@property (nonatomic, weak) IBOutlet UITextField *dealerName;
@property (nonatomic, weak) IBOutlet UITextField *feedbackUserPhone;
@property (nonatomic, weak) IBOutlet UILabel *addTime;
@property (nonatomic, weak) IBOutlet UIView *addTimeView;
@property (nonatomic, strong) NSString *serviceCode;
@property (nonatomic, weak) id<CreatFeedBackViewControllerDelegate> delegate;

- (IBAction)addFeedBackImage:(id)sender;
- (IBAction)modifyFeedBackImage:(id)sender;

- (IBAction)submitFeedBack:(id)sender;

- (instancetype) initWithSuggestInfo:(ComplaintsSuggestionsModel *)suggestInfo;
@end
