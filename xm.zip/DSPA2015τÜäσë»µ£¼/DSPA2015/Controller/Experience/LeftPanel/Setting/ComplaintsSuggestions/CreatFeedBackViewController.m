//
//  CreatFeedBackViewController.m
//  DSPA2015
//
//  Created by 李朋远 on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "CreatFeedBackViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "CTAssetsPickerController.h"
#import "AppDelegate.h"
#import "JKAlert.h"
#import "UIButton+AFNetworking.h"
#import "DateManager.h"

@interface CreatFeedBackViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,CTAssetsPickerControllerDelegate,UINavigationControllerDelegate,UIPopoverPresentationControllerDelegate>
{
    UIImagePickerController *imagePicker;//图片选择器
    NSMutableArray *_imageArray;
    BOOL ISModify;
    NSInteger modifyIndex;
    ComplaintsSuggestionsModel *_suggestInfo;
}
@end

@implementation CreatFeedBackViewController

- (instancetype) initWithSuggestInfo:(ComplaintsSuggestionsModel *)suggestInfo
{
    self = [super init];
    if (self) {
        _suggestInfo = suggestInfo;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _imageArray = [NSMutableArray array];
    self.view.backgroundColor = [UIColor whiteColor];
    self.dealerName.layer.borderWidth = 0.5f;
    self.dealerName.layer.borderColor = [[UIColor colorWithWhite:0.783 alpha:1.000] CGColor];
    
    self.feedbackUserPhone.layer.borderWidth = 0.5f;
    self.feedbackUserPhone.layer.borderColor = [[UIColor colorWithWhite:0.783 alpha:1.000] CGColor];
    self.dealerName.text = [AppDelegate APP].user.dealerOrgName;
    if (_suggestInfo) {
        [self buildView];
    }
}

- (void)buildView
{
    self.feedbackContent.text = _suggestInfo.describe;
    self.dealerName.text = _suggestInfo.dealername;
    self.feedbackUserPhone.text = _suggestInfo.phone;
    self.submitBtn.hidden = YES;
    
    _firstImage.hidden = YES;
    _secondImage.hidden = YES;
    _thirdImage.hidden = YES;
    _fourthImage.hidden = YES;
    for (int i = 0; i< _suggestInfo.tbSuggestImageList.count ;i++) {
        
//        NSString *imageUrl = [[[AppDelegate APP].platformServerIP stringByAppendingString:URI_PLATFORM_INTERFACE_ROOT] stringByAppendingString:[[_suggestInfo.tbSuggestImageList objectWithIndex:i] objectForKey:@"imagepath"]];

        NSString *imageUrl = [[_suggestInfo.tbSuggestImageList objectWithIndex:i] objectForKey:@"imagepath"];
        if (i == 0) {
            [_firstImage setImageForState:UIControlStateNormal withURL:[NSURL URLWithString:imageUrl?:@""]];
            _firstImage.hidden = NO;
        } else if (i == 1) {
            [_secondImage setImageForState:UIControlStateNormal withURL:[NSURL URLWithString:imageUrl?:@""]];
            _secondImage.hidden = NO;
        } else if (i ==2) {
            [_thirdImage setImageForState:UIControlStateNormal withURL:[NSURL URLWithString:imageUrl?:@""]];
            _thirdImage.hidden = NO;
        } else {
            [_fourthImage setImageForState:UIControlStateNormal withURL:[NSURL URLWithString:imageUrl?:@""]];
            _fourthImage.hidden = NO;
        }
    }
    
    self.addImageBtn.hidden = YES;
    self.addTimeView.hidden = NO;
    self.addTime.text = [DateManager date_YMD_WithTimeIntervalStringSince1970:_suggestInfo.addtime];
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 54, self.view.size.width, self.view.size.height - 54)];
    [self.view addSubview:view];
}

- (IBAction)addFeedBackImage:(id)sender
{
    ISModify = NO;
    UIActionSheet* mySheet = [[UIActionSheet alloc]
                              initWithTitle:@"请选择图片源"
                              delegate:self
                              cancelButtonTitle:@"取消"
                              destructiveButtonTitle:nil
                              otherButtonTitles:@"使用摄像头",@"从相册选取", nil];
    [mySheet showInView:self.view];
}

- (IBAction)modifyFeedBackImage:(UIButton *)sender
{
    ISModify = YES;
    modifyIndex = sender.tag - 10000;
    UIActionSheet* mySheet = [[UIActionSheet alloc]
                              initWithTitle:@"请选择图片源"
                              delegate:self
                              cancelButtonTitle:@"取消"
                              destructiveButtonTitle:nil
                              otherButtonTitles:@"使用摄像头",@"从相册选取", nil];
    [mySheet showInView:self.view];
}

- (IBAction)submitFeedBack:(id)sender
{
    NSString *errStr = [self checkData];
    if (![errStr isEqualToString:@""]) {
        [JKAlert showMessage:errStr];
        return;
    }
    NSDictionary *param = @{@"userid":[AppDelegate APP].user.userID?:@"",
                            @"username":[AppDelegate APP].user.salesConsultantName?:@"",
                            @"servicecode":self.serviceCode?:@"",
                            @"phone":self.feedbackUserPhone.text?:@"",
                            @"describe":self.feedbackContent.text?:@""};
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ComplaintsSuggestionsModel submitFeedBack:param FeedBackImage:_imageArray Success:^(BOOL isSuccess, id responseObject) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (isSuccess) {
            [self dismissDSPAPopup:nil];
            [JKAlert showMessage:@"谢谢您的宝贵建议，我们会尽快处理！"];
            
            if (self.delegate && [self.delegate respondsToSelector:@selector(updateSuggestList)]) {
                [self.delegate updateSuggestList];
            }
            
        } else {
            [JKAlert showMessage:@"反馈失败，请重试"];
        }
        
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        [JKAlert showMessage:@"网络连接失败"];
    }];
}

- (NSString *)checkData
{
    NSString *errStr = @"";
    if (_feedbackContent.text == nil || [_feedbackContent.text isEqualToString:@""]) {
        errStr = @"请输入详情描述";
    } else if (_feedbackUserPhone.text == nil || [_feedbackUserPhone.text isEqualToString:@""]) {
        errStr = @"请输入您的联系方式";
    } else if (_dealerName.text == nil || [_dealerName.text isEqualToString:@""]) {
        errStr = @"请输入您所属的经销商";
    } else {
        errStr = @"";
    }
    return errStr;
}

- (IBAction)closeBtnClick:(id)sender
{
    [self dismissDSPAPopup:nil];
}


#pragma mark -- UIActionSheet delegate
- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){//使用摄像头
        [self pickImageFromCamera];
    }
    if(buttonIndex == 1){//本地相册选取
        CTAssetsPickerController *picker = [[CTAssetsPickerController alloc] init];
        //设置最多选择多少张图片
        if (ISModify == YES) {
            picker.maximumNumberOfSelection = 1;
        }else{
            picker.maximumNumberOfSelection = 4 - _imageArray.count;
        }
        picker.assetsFilter = [ALAssetsFilter allAssets];//只选择图片
        picker.delegate = self;
        if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
        {
            [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                [self presentViewController:picker animated:YES completion:NULL];
            }];
        }
        else{
            [self presentViewController:picker animated:YES completion:NULL];
        }
    }
}
//相机选取
- (void)pickImageFromCamera{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        //没有摄像头 或者模拟器下使用 跳过
        return;
    }
    //创建图像选取控制器
    imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    //设置图像选取控制器的来源模式为相机模式
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    //不允许用户进行编辑
    imagePicker.allowsEditing = NO;
    if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
    {
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            [self presentViewController:imagePicker animated:YES completion:nil];
        }];
    }
    else{
        [self presentViewController:imagePicker animated:YES completion:nil];
    }
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    if (ISModify == YES) {
        [imagePicker dismissViewControllerAnimated:YES completion:^() {
            UIImage *portraitImg = [info objectForKey:UIImagePickerControllerOriginalImage];
            [self modifyImage:portraitImg];
            [self ImageButtonReloadData];
        }];
    }else{
        [imagePicker dismissViewControllerAnimated:YES completion:^() {
            UIImage *portraitImg = [info objectForKey:UIImagePickerControllerOriginalImage];
            [_imageArray addObject:portraitImg];
            [self ImageButtonReloadData];
        }];
    }
}
#pragma mark - Assets Picker Delegate
//实现 CTAssetsPickerControllerDelegate 的函数 完成选择之后 didFinishPickingAssets
- (void)assetsPickerController:(CTAssetsPickerController *)picker didFinishPickingAssets:(NSArray *)assets
{
    if (assets.count>0) {
        if (ISModify == YES) {
            ALAsset *asset=assets[0];
            UIImage *tempImg=[UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
            [self modifyImage:tempImg];
        }else{
            for (int i=0; i<assets.count; i++) {
                ALAsset *asset=assets[i];
                UIImage *tempImg=[UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
                [_imageArray addObject:tempImg];
            }
        }
        [self ImageButtonReloadData];
    }
}

-(void)ImageButtonReloadData{//ReloadData图片按钮
    _firstImage.hidden = YES;
    _secondImage.hidden = YES;
    _thirdImage.hidden = YES;
    _fourthImage.hidden = YES;
    for (int i = 0; i< _imageArray.count ;i++) {
        UIImage *img = [_imageArray objectAtIndex:i];
        if (i == 0) {
            [_firstImage setImage:img forState:UIControlStateNormal];
            _firstImage.hidden = NO;
        } else if (i == 1) {
            [_secondImage setImage:img forState:UIControlStateNormal];
            _secondImage.hidden = NO;
        } else if (i ==2) {
            [_thirdImage setImage:img forState:UIControlStateNormal];
            _thirdImage.hidden = NO;
        } else {
            [_fourthImage setImage:img forState:UIControlStateNormal];
            _fourthImage.hidden = NO;
        }
    }
    
    _addImageBtn.hidden = NO;
    switch (_imageArray.count) {
        case 0:
            _addImageBtn.frame = _firstImage.frame;
            break;
        case 1:
            _addImageBtn.frame = _secondImage.frame;
            break;
        case 2:
            _addImageBtn.frame = _thirdImage.frame;
            break;
        case 3:
            _addImageBtn.frame = _fourthImage.frame;
            break;
        default:
            _addImageBtn.hidden = YES;
            break;
    }
}

-(void)modifyImage:(UIImage *)image{//修改某个图片
    NSMutableArray *arrimage = [NSMutableArray arrayWithArray:_imageArray];
    [_imageArray removeAllObjects];
    for (int i = 0; i < arrimage.count; i++) {
        if (i != modifyIndex) {
            [_imageArray addObject:[arrimage objectAtIndex:i]];
        }else{
            [_imageArray addObject:image];
        }
    }
}

#pragma mark popover Delegate
- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController{
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    // 删除回退的时候返回yes
    if (text.length == 0 && range.length == 1) {
        return YES;
    }

    if(textView ==_feedbackContent){
        _feedbackContent.limit = 500;
    }
    
    return YES;
}
@end
