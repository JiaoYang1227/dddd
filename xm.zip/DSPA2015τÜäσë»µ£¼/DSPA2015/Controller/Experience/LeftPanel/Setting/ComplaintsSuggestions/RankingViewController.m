//
//  RankingViewController.m
//  DSPA2015
//
//  Created by 李朋远 on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "RankingViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "RankTableViewCell.h"
#import "ComplaintsSuggestionsModel.h"

#define CELL_IDENTIFIER @"cell_identifier"

@interface RankingViewController ()
{
    NSString *_selectType ;
}
@end

@implementation RankingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:@"RankTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER];
    _selectType = @"当月";
    [self loadData];
}

- (IBAction)showHistory:(id)sender
{
    if ([_selectType isEqualToString:@"当月"]) {
        _selectType = @"上个月";
        self.viewTitle.text = @"上个季度排行榜";
    } else {
        _selectType = @"当月";
        self.viewTitle.text = @"本季度排行榜";
    }
    
    [self loadData];
}

- (IBAction)closeBtnClick:(id)sender
{
    [self dismissDSPAPopup:nil];
}

- (void)loadData
{
    NSDictionary *param = @{@"flag":[_selectType isEqualToString:@"当月"]?@"1":@"2"};
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ComplaintsSuggestionsModel getRankList:param Success:^(NSArray *array, id responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        self.dataList = [NSArray arrayWithArray:array];
        [self.tableView reloadData];
        
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataList.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RankTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER forIndexPath:indexPath];
    ComplaintsSuggestionsModel *model = [self.dataList objectAtIndex:indexPath.row];
    [cell cell_configuration:model withType:[_selectType isEqualToString:@"当月"]?YES:NO];
    return cell;
}
@end
