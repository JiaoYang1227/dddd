//
//  ComplaintsSuggestionsViewController.m
//  D-CARS
//
//  Created by owen on 15/7/23.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "ComplaintsSuggestionsViewController.h"
#import "CTAssetsPickerController.h"
#import "UploadManager.h"
#import "ComplaintsSuggestionsModel.h"
#import "PopoverSearchController.h"
#import "AppDelegate.h"
#define TABLEVIEW_CELL_IDENTIFIER @"Cell"
@interface ComplaintsSuggestionsViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,CTAssetsPickerControllerDelegate,UINavigationControllerDelegate,UIPopoverPresentationControllerDelegate>{
    UIImagePickerController *imagePicker;//图片选择器
    NSMutableArray *_imageArray;
    NSArray *_dataList;
    NSMutableArray *_headerDataList;
    ComplaintsSuggestionsModel *selectComplaintsSuggestionsModel;
//    PopoverController *popView;
    NSInteger ModifyIndex;//修改图片的坐标
    BOOL ISModify;//是否是修改图片
    PopoverSearchController *search;
}
@property (nonatomic, strong) NSMutableArray *assets;
@end

@implementation ComplaintsSuggestionsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_suggestedTypeTable registerClass:[UITableViewCell class] forCellReuseIdentifier:TABLEVIEW_CELL_IDENTIFIER];
    _ComplaintsSuggestionsCount.placeholder = @"如需得到项目组反馈，可在内容最后加上自己的名字";
    _headerDataList = [NSMutableArray array];
    _ComplaintsSuggestionsCount.layer.borderWidth = 1;
    _ComplaintsSuggestionsCount.layer.borderColor = [[UIColor colorWithRed:180.0/255.0 green:180.0/255.0 blue:180.0/255.0 alpha:0.5] CGColor];
    
    _imageArray = [NSMutableArray array];
//    NSDictionary *param = [[NSDictionary alloc]initWithObjectsAndKeys:@"dicFeedBackargue",@"dicName", nil];
//    popView = [[PopoverController alloc]initWithContentView:_suggestedTypeTable];
//    popView.popoverPresentationController.delegate = self;
//    [ComplaintsSuggestionsModel getDictionary:param Success:^(NSArray *array, id responseObject) {
//        [_headerDataList setArray:array];
//        [_suggestedTypeTable reloadData];
//    } Failure:^(NSError *error) {
//    }];
    self.title = @"问题反馈";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [TalkingData trackPageEnd:self.title];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [TalkingData trackPageBegin:self.title];
}
- (IBAction)backHomeButtonTouched:(id)sender{
    [super backHomeButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
}
#pragma mark -- UIActionSheet delegate
- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){//使用摄像头
        [self pickImageFromCamera];
    }
    if(buttonIndex == 1){//本地相册选取
        if (!self.assets)
            self.assets = [[NSMutableArray alloc] init];
        CTAssetsPickerController *picker = [[CTAssetsPickerController alloc] init];
        //设置最多选择多少张图片
        if (ISModify == YES) {
            picker.maximumNumberOfSelection = 1;
        }else{
        picker.maximumNumberOfSelection = 4 - _imageArray.count;
        }
        picker.assetsFilter = [ALAssetsFilter allAssets];//只选择图片
        picker.delegate = self;
        if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
        {
            [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                [self presentViewController:picker animated:YES completion:NULL];
            }];
        }
        else{
            [self presentViewController:picker animated:YES completion:NULL];
        }
    }
}
//相机选取
- (void)pickImageFromCamera{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        //没有摄像头 或者模拟器下使用 跳过
        return;
    }
    //创建图像选取控制器
    imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    //设置图像选取控制器的来源模式为相机模式
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    //不允许用户进行编辑
    imagePicker.allowsEditing = NO;
    if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
    {
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            [self presentViewController:imagePicker animated:YES completion:nil];
        }];
    }
    else{
        [self presentViewController:imagePicker animated:YES completion:nil];
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    if (ISModify == YES) {
        [imagePicker dismissViewControllerAnimated:YES completion:^() {
            UIImage *portraitImg = [info objectForKey:UIImagePickerControllerOriginalImage];
            [self ModifyImage:portraitImg];
            [self ImageButtonReloadData];
        }];
    }else{
    [imagePicker dismissViewControllerAnimated:YES completion:^() {
        UIImage *portraitImg = [info objectForKey:UIImagePickerControllerOriginalImage];
        [_imageArray addObject:portraitImg];
        [self ImageButtonReloadData];
    }];
    }
}
#pragma mark - Assets Picker Delegate
//实现 CTAssetsPickerControllerDelegate 的函数 完成选择之后 didFinishPickingAssets
- (void)assetsPickerController:(CTAssetsPickerController *)picker didFinishPickingAssets:(NSArray *)assets
{
    if (assets.count>0) {
        [self.assets addObjectsFromArray:assets];
        if (ISModify == YES) {
            ALAsset *asset=assets[0];
            UIImage *tempImg=[UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
            [self ModifyImage:tempImg];
        }else{
            for (int i=0; i<assets.count; i++) {
                ALAsset *asset=assets[i];
                UIImage *tempImg=[UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
                [_imageArray addObject:tempImg];
            }
        }
        [self ImageButtonReloadData];
    }
}
- (IBAction)AddImageButtonTouched:(id)sender {//添加图片
    UIButton *btn = (UIButton *)sender;
    if (btn.tag == 100) {
        ISModify = NO;
    }else{
        ISModify = YES;
        ModifyIndex = btn.tag;
    }
        UIActionSheet* mySheet = [[UIActionSheet alloc]
                                  initWithTitle:@"请选择图片源"
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"使用摄像头",@"从相册选取", nil];
        [mySheet showInView:self.view];
}
-(void)ImageButtonReloadData{//ReloadData图片按钮
    switch (0) {
        case 0:{
            if (_imageArray.count == 0) {
                [self AddImageSetMobile:CGRectMake(264, 450, 85, 85)];
                break;
            }
        }
        case 1:{
            [_AddImageFirst setBackgroundImage:[_imageArray objectWithIndex:0] forState:UIControlStateNormal];
            [_AddImageFirst setHidden:NO];
            if (_imageArray.count == 1) {
                [self AddImageSetMobile:CGRectMake(264+98*1, 450, 85, 85)];
                break;
            }
        }
        case 2:{
            [_AddImageSecond setBackgroundImage:[_imageArray objectWithIndex:1] forState:UIControlStateNormal];
            [_AddImageSecond setHidden:NO];
            if (_imageArray.count == 2) {
                [self AddImageSetMobile:CGRectMake(264+98*2, 450, 85, 85)];
                break;
            }
        }
        case 3:{
            [_AddImageThird setBackgroundImage:[_imageArray objectWithIndex:2] forState:UIControlStateNormal];
            [_AddImageThird setHidden:NO];
            if (_imageArray.count == 3) {
                [self AddImageSetMobile:CGRectMake(264+98*3, 450, 85, 85)];
                break;
            }
        }
        case 4:{
            [_AddImageFourth setBackgroundImage:[_imageArray objectWithIndex:3] forState:UIControlStateNormal];
            [_AddImageFourth setHidden:NO];
            if (_imageArray.count == 4) {
                [_addImage setHidden:YES];
                break;
            }
        }
        default:
            break;
    }
}
-(void)ModifyImage:(UIImage *)image{//修改某个图片
    NSMutableArray *arrimage = [NSMutableArray arrayWithArray:_imageArray];
    [_imageArray removeAllObjects];
    for (int i = 0; i < arrimage.count; i++) {
        if (i != ModifyIndex) {
            [_imageArray addObject:[arrimage objectAtIndex:i]];
        }else{
            [_imageArray addObject:image];
        }
    }
}
-(void)AddImageSetMobile:(CGRect)rect{//添加按钮移动方法
    [_addImage setHidden:NO];
    [UIView animateWithDuration:0.3f animations:^{
        [_addImage setFrame:rect];
    }];
}
- (IBAction)sendButtonTouched:(id)sender {
    if (!selectComplaintsSuggestionsModel) {
        [JKAlert showMessage:@"请选择问题类型！"];
        return;
    }
    if (_ComplaintsSuggestionsCount.text.length == 0) {
        [JKAlert showMessage:@"请输入问题反馈内容！"];
        return;
    }
    if (_ComplaintsSuggestionsCount.text.length > 200) {
        [JKAlert showMessage:@"输入内容不能超过200字！"];
        return;
    }
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
//    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",URI_SERVER_ADDRESS,URI_INTERFACE_ROOT];

    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:selectComplaintsSuggestionsModel.key?:@"" forKey:@"argueFeedbackType"];
    [dic setObject:_ComplaintsSuggestionsCount.text?:@"" forKey:@"argueFeedback"];
    [UploadManager imageUploadMultiple:[NSString stringWithFormat:@"%@%@",baseInterface,INTERFACE_UPLOADTESTDRIVEFEEDBACKIMG]
                        withParameters:dic
                          withImageArr:_imageArray
                         uploadSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                             [JKAlert showMessage:@"上传成功！"];
                             [self CleanTheData];
    } uploadError:^(AFHTTPRequestOperation *operation, NSError *error) {
                        NSLog(@"%@",error);
    }];
}
- (IBAction)suggestedTypeButtonTouched:(id)sender {
    UIButton *btn = (UIButton *)sender;
     NSDictionary *param = [[NSDictionary alloc]initWithObjectsAndKeys:@"dicFeedBackargue",@"dicName", nil];
    if (_headerDataList.count>0) {
//        popView.popoverPresentationController.sourceView = btn;
//        popView.popoverPresentationController.sourceRect = btn.bounds;
//        [self presentViewController:popView animated:YES completion:nil];
        search = [[PopoverSearchController alloc]initWithSender:btn andItems:_headerDataList];
        [search didSelectSearchItem:^(id item, NSString *key, NSString *value) {
            [_suggestedTypeButton setTitle:value forState:UIControlStateNormal];
            selectComplaintsSuggestionsModel = [[ComplaintsSuggestionsModel alloc]init];
            selectComplaintsSuggestionsModel.key = key;
            selectComplaintsSuggestionsModel.value = value;
        }];
        [self presentViewController:search animated:YES completion:nil];
    }else{
    [ComplaintsSuggestionsModel getDictionary:param Success:^(NSArray *array, id responseObject) {
        [_headerDataList setArray:array];
//        [_suggestedTypeTable reloadData];
//        popView.popoverPresentationController.sourceView = btn;
//        popView.popoverPresentationController.sourceRect = btn.bounds;
//        [self presentViewController:popView animated:YES completion:nil];
        search = [[PopoverSearchController alloc]initWithSender:btn andItems:array];
        [search didSelectSearchItem:^(id item, NSString *key, NSString *value) {
            [_suggestedTypeButton setTitle:value forState:UIControlStateNormal];
            selectComplaintsSuggestionsModel = [[ComplaintsSuggestionsModel alloc]init];
            selectComplaintsSuggestionsModel.key = key;
            selectComplaintsSuggestionsModel.value = value;
            [_suggestedTypeButton setTitle:value forState:UIControlStateNormal];
        }];
        [self presentViewController:search animated:YES completion:nil];
    } Failure:^(NSError *error) {
    }];
    }
    
   
}
//#pragma mark -tableView delegate && dataSoutce
//- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
//{
//    return 1;
//}
//- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
//{
//    return _headerDataList.count;
//}
//- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TABLEVIEW_CELL_IDENTIFIER forIndexPath:indexPath];
//    cell.selectedBackgroundView = [[UIView alloc] initWithFrame:cell.frame];
//    cell.selectedBackgroundView.backgroundColor = [UIColor whiteColor];
//    ComplaintsSuggestionsModel *model = [_headerDataList objectAtIndex:indexPath.row];
//    cell.textLabel.text = model.value;
//    return cell;
//}
//- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    ComplaintsSuggestionsModel *model = [_headerDataList objectAtIndex:indexPath.row];
//    selectComplaintsSuggestionsModel = [[ComplaintsSuggestionsModel alloc]init];
//    selectComplaintsSuggestionsModel = model;
//    [popView dismissViewControllerAnimated:NO completion:^{
//        [_suggestedTypeButton setTitle:model.value forState:UIControlStateNormal];
//    }];
//}
- (IBAction)cancelButtonTouched:(id)sender {
    [self CleanTheData];
}
#pragma mark popover Delegate
- (BOOL)popoverPresentationControllerShouldDismissPopover:(UIPopoverPresentationController *)popoverPresentationController{
    return YES;
}
-(void)CleanTheData{//清空界面
    selectComplaintsSuggestionsModel = nil;
    [_imageArray removeAllObjects];
    [_AddImageFirst setHidden:YES];
    [_AddImageSecond setHidden:YES];
    [_AddImageThird setHidden:YES];
    [_AddImageFourth setHidden:YES];
    [self ImageButtonReloadData];
    _ComplaintsSuggestionsCount.text = @"";
//    [_ComplaintsSuggestionsCount setPlaceholderAccording];
    [_ComplaintsSuggestionsCount resignFirstResponder];
    [_suggestedTypeButton setTitle:@"请选择问题类型" forState:UIControlStateNormal];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
