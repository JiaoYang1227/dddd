//
//  RankTableViewCell.m
//  DSPA2015
//
//  Created by 李朋远 on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "RankTableViewCell.h"

@implementation RankTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)cell_configuration:(ComplaintsSuggestionsModel *)model withType:(BOOL)isCurrentMonth
{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.rankNo.text = model.flag;
    self.rankDealer.text = model.dealername;
    self.rankName.text = model.username;
//    if (isCurrentMonth) {
//        self.rankIntegral.text = model.quarterscore?:@"0";
//    } else {
//        self.rankIntegral.text = model.lastquarterscore?:@"0";
//    }
    self.rankIntegral.text = model.score?:@"0";

}
@end
