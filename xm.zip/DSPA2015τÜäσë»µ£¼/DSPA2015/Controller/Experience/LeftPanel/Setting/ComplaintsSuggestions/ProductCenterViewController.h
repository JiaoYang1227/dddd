//
//  ProductCenterViewController.h
//  DSPA2015
//
//  Created by 李朋远 on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

typedef NS_ENUM(NSInteger, FeedBackType) {
    FeedBackTypeAll = 0,
    FeedBackTypeMine,
};

@interface ProductCenterViewController : BaseViewController

@property (nonatomic, weak) IBOutlet UILabel *integralLabel;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, weak) IBOutlet UIButton *allFeedBack;
@property (nonatomic, weak) IBOutlet UIButton *myFeedBack;
@property (nonatomic, strong) NSMutableArray *dataList;
@property (nonatomic) FeedBackType feedBackType;

@end
