//
//  RankingViewController.h
//  DSPA2015
//
//  Created by 李朋远 on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

typedef NS_ENUM(NSInteger, RankType) {
    RankTypeCurrentTime = 0,
    RankTypeHistory,
};

@interface RankingViewController : BaseViewController

@property (nonatomic, weak) IBOutlet UILabel *viewTitle;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSArray *dataList;
@property (nonatomic) RankType rankType;


@end
