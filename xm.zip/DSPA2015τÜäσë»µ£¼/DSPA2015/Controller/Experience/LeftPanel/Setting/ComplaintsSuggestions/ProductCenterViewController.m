//
//  ProductCenterViewController.m
//  DSPA2015
//
//  Created by 李朋远 on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ProductCenterViewController.h"
#import "ComplaintsSuggestionsModel.h"
#import "AppDelegate.h"
#import "UIColor+HEX.h"
#import "ProductCenterTableViewCell.h"
#import "CreatFeedBackViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "MBProgressHUD.h"
#import "Stat.h"
#import "RankingViewController.h"


#define CELL_IDENTIFIER @"cell_identifier"

@interface ProductCenterViewController ()<UITableViewDelegate,UITableViewDataSource,CreatFeedBackViewControllerDelegate>
{
    NSString *_serviveCode;
}
@end

@implementation ProductCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:@"ProductCenterTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER];
    [self loadServiceCode];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (IBAction)backHomeButtonTouched:(id)sender{
    [super backHomeButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
}

- (void)loadServiceCode {

    [ComplaintsSuggestionsModel getServiceCode:[AppDelegate APP].user.userID Success:^(NSDictionary *result, id responseObject) {
        
        _serviveCode = [result objectForKey:@"servicecode"];
        [self loadData];
        [self loadSorce];
        
    } Failure:^(NSError *error) {
        
    }];
    
}

- (void)loadSorce
{
    if (_serviveCode == nil || [_serviveCode isEqualToString:@""]) {
        return;
    }
    NSDictionary *param = @{@"servicecode":_serviveCode,
                            @"userid":[AppDelegate APP].user.userID?:@""};
    
    [ComplaintsSuggestionsModel getUserSorce:param Success:^(NSString *sorce, id responseObject) {
        self.integralLabel.text = sorce;
    } Failure:^(NSError *error) {
        self.integralLabel.text = 0;
    }];
}
     
- (void)loadData
{
    if (_serviveCode == nil || [_serviveCode isEqualToString:@""]) {
        return;
    }
    NSDictionary *param = nil;
    if (self.feedBackType == FeedBackTypeAll) {
        param = @{@"servicecode":_serviveCode};
    } else {
        param = @{@"servicecode":_serviveCode,
                  @"userid":[AppDelegate APP].user.userID?:@""};
    }

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ComplaintsSuggestionsModel getFeedBackList:param Success:^(NSArray *array, id responseObject) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        self.dataList = [NSMutableArray arrayWithArray:array];
        [self.tableView reloadData];
        
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}

- (IBAction)changeTypeAction:(id)sender
{
    if ([sender isEqual:self.allFeedBack]) {
        self.feedBackType = FeedBackTypeAll;
        [self.allFeedBack setTitleColor:[UIColor colorWithHexString:@"ab152b"] forState:UIControlStateNormal];
        [self.myFeedBack setTitleColor:[UIColor colorWithHexString:@"c0c0c0"] forState:UIControlStateNormal];
        self.allFeedBack.enabled = NO;
        self.myFeedBack.enabled = YES;
    } else {
        self.feedBackType = FeedBackTypeMine;
        [self.allFeedBack setTitleColor:[UIColor colorWithHexString:@"c0c0c0"] forState:UIControlStateNormal];
        [self.myFeedBack setTitleColor:[UIColor colorWithHexString:@"ab152b"] forState:UIControlStateNormal];
        self.myFeedBack.enabled = NO;
        self.allFeedBack.enabled = YES;
    }
}

- (void)setFeedBackType:(FeedBackType)feedBackType
{
    _feedBackType = feedBackType;
    [self loadData];
}

- (IBAction)askAction:(id)sender
{
    CreatFeedBackViewController *creatVc = [[CreatFeedBackViewController alloc] init];
    creatVc.serviceCode = _serviveCode;
    creatVc.delegate = self;
    [self presentDSPAPopup:creatVc
      parentViewController:self
             touchCallBack:nil
                  haveMask:YES
          includeNavgation:NO
                  alignTop:NO];
}

- (IBAction)showRanking:(id)sender
{
    RankingViewController *rank = [[RankingViewController alloc] init];
    [self presentDSPAPopup:rank
      parentViewController:self
             touchCallBack:nil
                  haveMask:YES
          includeNavgation:NO
                  alignTop:NO];
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataList.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ProductCenterTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER forIndexPath:indexPath];
    ComplaintsSuggestionsModel *model = [self.dataList objectAtIndex:indexPath.row];
    [cell cell_configuration:model];
    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ComplaintsSuggestionsModel *model = [self.dataList objectAtIndex:indexPath.row];
    CreatFeedBackViewController * infoVC = [[CreatFeedBackViewController alloc] initWithSuggestInfo:model];
    [self presentDSPAPopup:infoVC
      parentViewController:self
             touchCallBack:nil
                  haveMask:YES
          includeNavgation:NO
                  alignTop:NO];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //begin by owen 20161205
    //BUG #42299::【客户视图】【概览】输入【备注】信息，点击其他页签，备注信息被清空，无保存提示
    ComplaintsSuggestionsModel *model = [self.dataList objectAtIndex:indexPath.row];
    if (_feedBackType == FeedBackTypeAll) {
        return NO;
    } else if (_feedBackType == FeedBackTypeMine && [model.state isEqualToString:@"已提交"]) {
        return YES;
    } else {
        return NO;
    }
    //end by owen
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle != UITableViewCellEditingStyleDelete) {
        return;
    }
    
    ComplaintsSuggestionsModel *model = [self.dataList objectAtIndex:indexPath.row];
    if (![model.state isEqualToString:@"已提交"]) {
        return;
    }
    NSDictionary *param = @{@"id":model.ID};
    [ComplaintsSuggestionsModel removeMyFeedBack:param Success:^(BOOL isSuccess, id responseObject) {

    } Failure:^(NSError *error) {
        //
    }];
    
    [_dataList removeObjectAtIndex:indexPath.row];
    // Delete the row from the data source.
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark -----------CreatFeedBackViewControllerDelegate------------
- (void)updateSuggestList
{
    [self loadData];
}
@end
