//
//  ComplaintsSuggestionsViewController.h
//  D-CARS
//
//  Created by owen on 15/7/23.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "PopoverController.h"
#import "IQTextView.h"
@interface ComplaintsSuggestionsViewController : BaseViewController
- (IBAction)AddImageButtonTouched:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *AddImageFirst;
@property (weak, nonatomic) IBOutlet UIButton *AddImageSecond;
@property (weak, nonatomic) IBOutlet UIButton *AddImageThird;
@property (weak, nonatomic) IBOutlet UIButton *AddImageFourth;
@property (strong, nonatomic) IBOutlet UIButton *addImage;



@property (weak, nonatomic) IBOutlet UITableView *suggestedTypeTable;
@property (weak, nonatomic) IBOutlet IQTextView *ComplaintsSuggestionsCount;
- (IBAction)sendButtonTouched:(id)sender;
- (IBAction)suggestedTypeButtonTouched:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *suggestedTypeButton;
- (IBAction)cancelButtonTouched:(id)sender;

@end
