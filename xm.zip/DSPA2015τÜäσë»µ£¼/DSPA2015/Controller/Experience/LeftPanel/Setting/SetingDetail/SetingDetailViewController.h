//
//  SetingDetailViewController.h
//  D-CARS
//
//  Created by gavin on 15/7/28.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseSplitDetailViewController.h"

@interface SetingDetailViewController : BaseSplitDetailViewController

@end
