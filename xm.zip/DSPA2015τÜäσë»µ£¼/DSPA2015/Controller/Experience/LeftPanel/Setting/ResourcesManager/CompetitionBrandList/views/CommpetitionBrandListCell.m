//
//  CommpetitionBrandListCell.m
//  DSPA2015
//
//  Created by runlin on 16/7/1.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "CommpetitionBrandListCell.h"
#import "CarCompare.h"


@implementation CommpetitionBrandListCell

//- (void)awakeFromNib {
//    // Initialization code
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (void)configData:(CompetitionBrandListModel *)model withIndexPath:(NSIndexPath *)indexPath{
    self.cellName.text = model.name;
    self.cellDownloadButtonOutlet.indexPath = indexPath;
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        // 处理耗时操作的代码块...
        BOOL success = [CarCompare isDownLoadSuccessFromBrandID:model.brandId];
        
        //通知主线程刷新
        dispatch_async(dispatch_get_main_queue(), ^{
            //回调或者说是通知主线程刷新，
            if (success) {
                self.cellDownloadStateLable.text = @"已下载";
                self.cellDownloadStateImg.image = [UIImage imageNamed:@"videoDownload_select_yes"];
            }else{
                self.cellDownloadStateLable.text = @"未下载";
                self.cellDownloadStateImg.image = [UIImage imageNamed:@"videoDownload_state_no"];
            }
        });
    });
    
//    self.cellDownloadStateLable.text = @"";
//    self.cellDownloadStateImg.image
}



- (void)configDataFromAudiBrandCompetition:(AudiBrandCompetition *)model withIndexPath:(NSIndexPath *)indexPath{
    self.cellName.text = model.name;
    self.cellDownloadButtonOutlet.indexPath = indexPath;
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        // 处理耗时操作的代码块...
        //判断下数据库中是否存在，存在的话，说明已经下载完成
        BOOL success = [CarCompare isDownLoadFromBrandID:model.brandId];
        
        //通知主线程刷新
        dispatch_async(dispatch_get_main_queue(), ^{
            //回调或者说是通知主线程刷新，
            if (success) {
                self.cellDownloadStateLable.text = @"已下载";
                self.cellDownloadStateImg.image = [UIImage imageNamed:@"videoDownload_select_yes"];
            }else{
                self.cellDownloadStateLable.text = @"未下载";
                self.cellDownloadStateImg.image = [UIImage imageNamed:@"videoDownload_state_no"];
            }
        });
    });
}


@end
