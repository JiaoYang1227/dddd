//
//  AudiBrandCompetitionViewController.h
//  DSPA2015
//
//  Created by runlin on 16/7/14.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ResourcesBaseTableViewController.h"

@interface AudiBrandCompetitionViewController : ResourcesBaseTableViewController

@end
