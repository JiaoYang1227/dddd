//
//  VideoCenterViewController.h
//  D-CARS
//
//  Created by gavin on 15/7/21.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourcesBaseTableViewController.h"

@interface VideoCenterViewController : ResourcesBaseTableViewController

@end
