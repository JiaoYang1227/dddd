//
//  CommpetitionBrandListViewController.m
//  DSPA2015
//
//  Created by runlin on 16/7/1.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "CommpetitionBrandListViewController.h"
#import "CompetitionBrandListModel.h"
#import "CommpetitionBrandListCell.h"
#import "CarCompare.h"

@interface CommpetitionBrandListViewController ()
{
    NSMutableArray *_commpetitionBrandList;
    NSInteger downloadIndex;
    
    __weak IBOutlet UITableView *_commpetitionBrandTableview;
}
@end

@implementation CommpetitionBrandListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    downloadIndex = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CompetitionBrandListModel getCompetitionBrandList:nil Success:^(NSMutableArray *arrList) {
        
        if (arrList.count > 0) {
            _commpetitionBrandList = [[NSMutableArray alloc] initWithArray:arrList];
            [_commpetitionBrandTableview reloadData];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}

#pragma mark ======
#pragma mark tableview delegate ======
#pragma mark tableview data source ======
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _commpetitionBrandList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView registerNib:[UINib nibWithNibName:@"CommpetitionBrandListCell" bundle:nil] forCellReuseIdentifier:@"CommpetitionBrandListCell"];
    CommpetitionBrandListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommpetitionBrandListCell"];
    
    CompetitionBrandListModel *model = [_commpetitionBrandList objectWithIndex:indexPath.row];
    [cell configData:model withIndexPath:indexPath];
    [cell.cellDownloadButtonOutlet addTarget:self action:@selector(downloadAction:) forControlEvents:UIControlEventTouchDown];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 102.;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CompetitionBrandListModel *model = [_commpetitionBrandList objectWithIndex:indexPath.row];
    // 判断数据是否存在
    if([CarCompare isDownLoadSuccessFromBrandID:model.brandId]){
        return YES;
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {

    dispatch_queue_t concurrentQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(concurrentQueue, ^{
        dispatch_sync(concurrentQueue, ^{
            CompetitionBrandListModel *model = [_commpetitionBrandList objectWithIndex:indexPath.row];
            [CarCompare isDeleteSuccessFromBrandID:model.brandId];
        });
        dispatch_sync(dispatch_get_main_queue(), ^{
            [_commpetitionBrandTableview reloadData];
        });
    });
}




- (void)downloadAction:(CellButton *)sender{
    CompetitionBrandListModel *model = [_commpetitionBrandList objectWithIndex:sender.indexPath.row];
    // 判断数据是否存在
    if([CarCompare isDownLoadSuccessFromBrandID:model.brandId]){
        NSString *overInfo = [NSString stringWithFormat:@"%@%@",model.name , @"已经下载完成"];
        [JKAlert showMessage:overInfo];
        return;
    }
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CompetitionBrandListModel downCompetitionDetailedBrand:@{@"brandid":model.brandId} Success:^(NSMutableArray *arrList) {
        
        if ([CarCompare createCacsCompareTable:arrList]) {
            [_commpetitionBrandTableview reloadData];
        }else{
            NSString *error = [NSString stringWithFormat:@"%@%@",model.name , @"创建失败"];
            [JKAlert showMessage:error];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];

    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


- (IBAction)downloadAllButtonAction:(id)sender {
    if (downloadIndex == 0) {
        [self downloadAll:downloadIndex];
    }
}

- (void)downloadAll:(NSInteger )index{
    __weak __typeof(self)weakSelf = self;
    //index 是否大于 _commpetitionBrandList 的count
    if (index > _commpetitionBrandList.count - 1) {
        return;
    }
    
    CompetitionBrandListModel *model = [_commpetitionBrandList objectWithIndex:index];
    // 判断数据是否存在
    if([CarCompare isDownLoadSuccessFromBrandID:model.brandId]){
        downloadIndex = index + 1;
        [self downloadAll:(index + 1)];
        return;
    }
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.detailsLabelText = [NSString stringWithFormat:@"%@%@",model.name,@"正在下载中..."];
    [CompetitionBrandListModel downCompetitionDetailedBrand:@{@"brandid":model.brandId?:@""} Success:^(NSMutableArray *arrList) {
        
        if ([CarCompare createCacsCompareTable:arrList]) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            [_commpetitionBrandTableview reloadData];
            downloadIndex = index + 1;
            [weakSelf downloadAll:(index + 1)];
        }else{
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }
        
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


@end
