//
//  ResourcesBaseTableViewCell.m
//  D-CARS
//
//  Created by gavin on 15/7/29.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourcesBaseTableViewCell.h"

@implementation ResourcesBaseTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
