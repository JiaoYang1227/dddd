//
//  ResourcesBaseTableViewController.h
//  D-CARS
//
//  Created by gavin on 15/7/22.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface ResourcesBaseTableViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic , assign) NSInteger count;

@end
