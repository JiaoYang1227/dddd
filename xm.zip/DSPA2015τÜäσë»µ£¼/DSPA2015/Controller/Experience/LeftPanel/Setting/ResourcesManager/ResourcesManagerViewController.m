//
//  ResourcesManagerViewController.m
//  D-CARS
//
//  Created by gavin on 15/7/21.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourcesManagerViewController.h"
#import "VideoCenterViewController.h"
#import "CarShowDownloadViewController.h"
#import "ResourcesBaseTableViewCell.h"
#import "FileManager.h"
#import "AFDownloadManager.h"
#import "KeychainManager.h"
#import "CarCompare.h"
#import "OfflineClient.h"
#import "CarCompareDownLoadViewController.h"
#import "CompetitionBrandViewController.h"
#import "CommpetitionBrandListViewController.h"
#import "AudiConnectShowViewController.h"
#import "AudiBrandCompetitionViewController.h"
#import "LogWriter.h"
#import "JKToast.h"

@interface ResourcesManagerViewController ()
{
    NSArray *_arrList;
    BOOL nibsRegistered_;
}
@property (weak, nonatomic) IBOutlet UITableView *resourceTableview;

@end

@implementation ResourcesManagerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"资源管理";
    _arrList = @[@"视频中心",@"车辆展厅",@"竞品对比参数更新",@"竞品对比图片下载",@"离线集客字典",@"奥迪connect展示宣传文件资源列表"];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


#pragma mark tableview delegate
#pragma mark tableview dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _arrList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * identifier = @"ResourcesBaseTableViewCell";
    if (!nibsRegistered_) {
        UINib * nib = [UINib nibWithNibName:@"ResourcesBaseTableViewCell" bundle:nil];
        [tableView registerNib:nib forCellReuseIdentifier:identifier];
        nibsRegistered_ = YES;
    }
    
    ResourcesBaseTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.alertTitle.hidden = YES;
    if (indexPath.row == 2) {
        cell.alertTitle.hidden = NO;
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        switch ([[userDefaults objectForKey:KEY_DOWNLOAD_STUTS]integerValue]) {
            case DownLoadTypeSucced:{
                 cell.alertTitle.text =@"下载成功";
                 [cell.alertTitle setTextColor:[UIColor colorWithRed:17/255.0 green:240 /255.0 blue:39/255.0 alpha:1.0]];
            }
                break;
            case DownLoadTypeFaild:{
                cell.alertTitle.text =@"下载失败，请重新下载";
                [cell.alertTitle setTextColor:[UIColor redColor]];
            }
                break;
            case DownLoadTypeIng:{
                cell.alertTitle.text =@"下载中......";
                [cell.alertTitle setTextColor:[UIColor colorWithRed:17/255.0 green:240 /255.0 blue:39/255.0 alpha:1.0]];
            }
                break;
                
            default:{
                cell.alertTitle.text =@"";
                [cell.alertTitle setTextColor:[UIColor whiteColor]];
            }
                break;
        }
    }
    if (indexPath.row == 2 || indexPath.row == 4) {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }else{
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    cell.backgroundColor = [UIColor colorWithWholeRed:249 green:249 blue:249 alpha:1];
    cell.cellTitleName.text = [_arrList objectWithIndex:indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
        {
            VideoCenterViewController *video = [[VideoCenterViewController alloc] init];
            [self.navigationController pushViewController:video animated:YES];
        }
            break;
        case 1:
        {
            CarShowDownloadViewController *carShowDownload = [[CarShowDownloadViewController alloc] init];
            [self.navigationController pushViewController:carShowDownload animated:YES];
        }
            break;
        case 2:
        {
            //@"竞品对比参数更新"
            if (_downLoadType == DownLoadTypeIng) {
                [JKAlert showMessage:@"竞品对比数据正在下载......"];
            }else{
                _downLoadType = DownLoadTypeIng;
                [self saveDefault];
                [self carIntroduceAction:self];
            }
        }
            break;
            //        case 3:
            //        {
            //            //,@"综合对比数据下载"
            //            [self.navigationController pushViewController:[[CommpetitionBrandListViewController alloc] init] animated:YES];
            //
            //        }
            //            break;
            //        case 4:
            //        {
            //            //本品对比数据下载
            //            [self.navigationController pushViewController:[AudiBrandCompetitionViewController new] animated:YES];
            //        }
            //            break;
        case 3:
        {
            //,@"竞品对比图片下载"
            [self carShowPictureAction:self];
            
        }
            break;
            //        case 6:
            //        {
            //            //,@"综合对比参数更新"
            //            [self LoadPDFList:self];
            //        }
            //            break;
            //        case 7:
            //        {
            //            //,@"综合对比PDF下载"
            //            [self.navigationController pushViewController:[[CompetitionBrandViewController alloc] init] animated:YES];
            //        }
            //            break;
        case 4:
        {
            //,@"离线集客字典"
            [self offlineTouched:self];
        }
            break;
        case 5:
        {
            //奥迪展示宣传资料
            [self.navigationController pushViewController:[[AudiConnectShowViewController alloc] init] animated:YES];
        }
            break;
            
        default:
            break;
    }
}


#pragma mark =======================================================================================
// 视频中心
- (IBAction)videoCenterAction:(id)sender {
    VideoCenterViewController *video = [[VideoCenterViewController alloc] init];
    [self.navigationController pushViewController:video animated:YES];
}
// 车辆展厅
- (IBAction)carShowAction:(id)sender {
    CarShowDownloadViewController *carShowDownload = [[CarShowDownloadViewController alloc] init];
    [self.navigationController pushViewController:carShowDownload animated:YES];
}
//车型介绍图片资源
- (IBAction)carShowPictureAction:(id)sender{
    CarCompareDownLoadViewController *carCompareDownLoadVC = [[CarCompareDownLoadViewController alloc] init];
    [self.navigationController pushViewController:carCompareDownLoadVC animated:YES];
}
- (IBAction)offlineTouched:(id)sender {
    MBProgressHUD *hud  = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [OfflineClient getOfflineDic:[NSDictionary dictionary] Success:^(NSDictionary *collection) {
        [[FileManager sharedManager] createDirectoryAtPath:[FileManager documentsPath:@"Offline"]];
        NSMutableDictionary *dicWrite = [NSMutableDictionary dictionaryWithDictionary:collection];
        
        if([FileManager writeToJSON:dicWrite path:[FileManager documentsPath:@"Offline/OfflineClient.json"]]){
            [hud showSuccess:@"同步离线集客字典表成功"];
            [hud hide:YES afterDelay:3];
        }
    } Failure:^(NSError *error) {
        [hud showFailure:@"同步离线集客字典表失败"];
        [hud hide:YES afterDelay:3];
    }];
}
//综合对比参数更新
-(IBAction)LoadPDFList:(id)sender{
    MBProgressHUD *hud  = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [APIManager SafePOST:INTERFACE_OFFLINE_COMPARE_PDF parameters:nil  appendUserInfo:NO success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *collection = [responseObject arrayForKey:@"data"];
        if ([CarCompare createPdfTable:collection] == YES) {
            [hud showSuccess:@"综合对比参数更新成功"];
            [hud hide:YES afterDelay:3];
        }else{
            [hud showSuccess:@"综合对比参数更新失败"];
            [hud hide:YES afterDelay:3];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [hud showSuccess:@"综合对比参数更新失败"];
        [hud hide:YES afterDelay:3];
    }];
}

// 车型介绍
- (void)saveDefault{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:[NSString stringWithFormat:@"%lu",(unsigned long)_downLoadType] forKey:KEY_DOWNLOAD_STUTS];
    [userDefaults synchronize];
    [_resourceTableview reloadData];
    
}

- (IBAction)carIntroduceAction:(id)sender {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
        //         [CarCompare createParamInfoFromJson:@"competitionDetailedList.sql"];
        [CarCompare dropTable];
        //    获取所有车型
        [CarCompare loadAllCarList:^(BOOL responseObject) {
            if (!responseObject) {
                _downLoadType = DownLoadTypeFaild;
                [self saveDefault];
                [JKToast toastWithText:@"竞品资源下载失败!"];
                return;
            }
            //获取车系车型对比关系表
            [CarCompare loadCompareCarList:^(BOOL responseObject) {
                if (!responseObject) {
                    _downLoadType = DownLoadTypeFaild;
                    [self saveDefault];
                    [JKToast toastWithText:@"竞品资源下载失败!"];
                    return;
                }
                //获取参数项接口
                [CarCompare loadParamItemList:^(BOOL responseObject) {
                    if (!responseObject) {
                        _downLoadType = DownLoadTypeFaild;
                        [self saveDefault];
                        [JKToast toastWithText:@"竞品资源下载失败!"];
                        return;
                    }
                    [CarCompare LoadPictureItemsSucces:^(BOOL responseObject) {
                        if (!responseObject) {
                            _downLoadType = DownLoadTypeFaild;
                            [self saveDefault];
                            [JKToast toastWithText:@"竞品资源下载失败!"];
                            return;
                        }
                        [self downloadPictureItemValues:^(BOOL responseObject) {
                            if (!responseObject) {
                                _downLoadType = DownLoadTypeFaild;
                                [self saveDefault];
                                [JKToast toastWithText:@"竞品资源下载失败!"];
                                return;
                            }
                            [self downloadCompetitionDetailedList:^(BOOL responseObject) {
                                if (!responseObject) {
                                    _downLoadType = DownLoadTypeFaild;
                                    [self saveDefault];
                                    [JKToast toastWithText:@"竞品资源下载失败!"];
                                }
                                else{
                                    _downLoadType = DownLoadTypeSucced;
                                    [self saveDefault];
                                    [JKToast toastWithText:@"竞品资源下载成功!"];
                                }
                            }];
                        }];
                    }];
                }];
            }];
        }];
    });
    
    
}
#pragma mark 竞品对比
#pragma mark down car resource
- (void)downloadPictureItemValues:(void(^)(BOOL responseObject))result{
    [APIManager SafePOST:INTERFACE_OFFLINE_COMPARE_PICTUREITEM_VALUES parameters:nil  appendUserInfo:NO success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSString *tempUrl = [responseObject objectForKey:@"pictureConstrastList"];
        if (![tempUrl isEqualToString:@""]) {
            NSString *url3 = [NSString stringWithFormat:@"%@%@%@",[KeychainManager getBaseURL]?:URI_SERVER_ADDRESS?:@"",@"/dspa_crmserver/",tempUrl];
            NSString *filePath = [NSString stringWithFormat:@"%@/%@",[FileManager documentsPath],@"pictureConstrastList.sql"];
            if([[FileManager sharedManager]fileExistsAtPath:filePath]){
                [[FileManager sharedManager]removeFileAtPath:filePath];
            }
            [[AFDownloadManager sharedDownloadManager] downloadQueueTask:@"pictureConstrastList.sql" withDownloadURL:url3 withDownloadSavePath:[FileManager documentsPath] withUIProgressView:nil withAFHTTPRequestOperation:self.singleDownload downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject, DownloadState state) {
                //                BOOL  insertDone = [CarCompare createPictureInfoTable:@"pictureConstrastList.sql"];
                BOOL  insertDone = [CarCompare createParamInfoFromJson:@"pictureConstrastList.sql"];
                result(insertDone);
                
            } downloadError:^(AFHTTPRequestOperation *operation, NSError *error, NSString *filePath) {
                [LogWriter writeLog:@"offline/getPictureConstrastList.do" param:nil log:[NSString stringWithFormat:@"竞品对比资源下载失败！error:%@  filePath:%@",error,filePath]];
                result(NO);
                
            } downloadInfo:^(NSString *speedInfo, float ratio) {
                NSLog(@"%@",speedInfo);
                
            }];
        }else{
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSString *responseString =  [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
        [LogWriter writeLog:@"offline/getPictureConstrastList.do" param:nil log:[NSString stringWithFormat:@"竞品对比资源下载失败！网络error:%@",responseString]];
        result(NO);
    }];
    
}
- (void)downloadCompetitionDetailedList:(void(^)(BOOL responseObject))result{
    [APIManager SafePOST:@"offline/competeParamItemInfoList.do" parameters:nil  appendUserInfo:NO success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSString *tempUrl = [responseObject objectForKey:@"competitionDetailedList"];
        if (![tempUrl isEqualToString:@""]) {
            NSString *url3 = [NSString stringWithFormat:@"%@%@%@",[KeychainManager getBaseURL]?:URI_SERVER_ADDRESS?:@"",@"/dspa_crmserver/",tempUrl];
            NSString *filePath = [NSString stringWithFormat:@"%@/%@",[FileManager documentsPath],@"competitionDetailedList.sql"];
            if([[FileManager sharedManager]fileExistsAtPath:filePath]){
                [[FileManager sharedManager]removeFileAtPath:filePath];
            }
            [[AFDownloadManager sharedDownloadManager] downloadQueueTask:@"competitionDetailedList.sql" withDownloadURL:url3 withDownloadSavePath:[FileManager documentsPath] withUIProgressView:nil withAFHTTPRequestOperation:self.singleDownload downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject, DownloadState state) {
                BOOL  insertDone = [CarCompare createParamInfoFromJson:@"competitionDetailedList.sql"];
                result(insertDone);
                
            } downloadError:^(AFHTTPRequestOperation *operation, NSError *error, NSString *filePath) {
                [LogWriter writeLog:@"offline/competeParamItemInfoList.do" param:nil log:[NSString stringWithFormat:@"竞品对比资源下载失败！error:%@  filePath:%@",error,filePath]];
                result(NO);
                
            } downloadInfo:^(NSString *speedInfo, float ratio) {
                NSLog(@"%@",speedInfo);
                
            }];
        }else{
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        result(NO);
    }];
    
}
#pragma mark 竞品对比参数 and PDF 下载 （废弃）
//- (void)downloadJingPinParam:(NSString *)url withFilePath:(NSString *)path{
////     [CarCompare createPdfFromJson:@"pdfCompare.json"];
//    NSString *downloadUrl = [NSString stringWithFormat:@"%@%@",[KeychainManager getBaseURL]?:URI_SERVER_ADDRESS?:@"",@"/dspa_crmserver/offline/getPdfConstrastList.do"];
//
//    MBProgressHUD *hud  = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    hud.labelText = @"下载中...";
//
//    [[AFDownloadManager sharedDownloadManager] downloadSingleTask:self.singleDownload
//                                                          withUrl:downloadUrl
//                                                     withFilePath:[FileManager documentsPath:@"pdfCompare.json"]
//                                                   withUIProgress:nil
//                                                  downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
//                                                      [CarCompare createPdfFromJson:@"pdfCompare.json"];
//                                                      [hud showSuccess:@"同步竞品参数成功"];
//                                                      [hud hide:YES afterDelay:3];
//
//
//                                                  } downloadError:^(AFHTTPRequestOperation *operation, NSError *error) {
//                                                      [hud showFailure:@"同步竞品参数失败"];
//                                                      [hud hide:YES afterDelay:3];
//                                                      
//                                                  } currSpeed:^(NSString *speed) {
//                                                      
//                                                  }];
//}

@end
