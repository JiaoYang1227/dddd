//
//  ResourcesManagerSandbox.h
//  DSPA2015
//
//  Created by runlin on 17/2/22.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM( NSInteger, CLASS_NAME)
{
    //0:视频中心 1:奥迪中心
    CLASS_NAME_VIDEO = 0,
    CLASS_NAME_AUDICONNECT = 1
};

@interface ResourcesManagerSandbox : NSObject
+ (NSArray *)getAllFileFromPath:(NSString *)path;
+ (NSMutableArray *)getAllFileFromPath:(NSString *)path withServerData:(NSArray *)dataList;
+ (NSMutableArray *)getAllFilePathFromAudiConnect:(NSString *)path withServerData:(NSArray *)dataList;
@end
