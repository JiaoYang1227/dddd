//
//  AudiConnectShowViewController.m
//  DSPA2015
//
//  Created by runlin on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "AudiConnectShowViewController.h"
#import "VideoCell.h"
#import "AudiConnectShow.h"
#import "TMCache.h"
#import "AFDownloadItem.h"
#import "AFDownloadManager.h"
#import "UILabel+AFDownloadRequestOperation.h"
#import "ResourcesManagerSandbox.h"


#define AUDICONNECTSHOW_DOWNLOAD_OVER @"audiconnectshow_download_over"
#define AUDICONNECTSHOW_FINDER_NAME @"/audiconnectshow"
#define AUDICONNECTSHOW_FILE_PATH [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],AUDICONNECTSHOW_FINDER_NAME]


@interface AudiConnectShowViewController ()
{
    BOOL nibsRegistered_;
    NSMutableArray *_audiConnectShowList;
    NSMutableArray *_rubbishAudiConnectShowList;
    AFHTTPRequestOperation *_audiConnectShowOperation;      //创建请求管理（用于上传和下载）
    BOOL isNewPage;
}

@property (weak, nonatomic) IBOutlet UITableView *audiConnectShowTableView;

@end

@implementation AudiConnectShowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"奥迪connect展示宣传文件资源列表";
    isNewPage = YES;
    [[NSNotificationCenter  defaultCenter] addObserver:self  selector:@selector(notificationUIRefresh) name:AUDICONNECTSHOW_DOWNLOAD_OVER object:nil];
    [[FileManager sharedManager] createDirectoryAtPath:AUDICONNECTSHOW_FILE_PATH];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    __weak typeof(self)weak = self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [AudiConnectShow getAudiConnectShowList:nil Success:^(NSMutableArray *arrList,NSMutableArray *all) {
        if (arrList.count > 0) {
            
            _audiConnectShowList = [[NSMutableArray alloc] initWithArray:arrList];
            
            _rubbishAudiConnectShowList = [ResourcesManagerSandbox getAllFilePathFromAudiConnect:AUDICONNECTSHOW_FILE_PATH withServerData:all];
            
            
            weak.count = _audiConnectShowList.count;
            [weak.audiConnectShowTableView reloadData];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}

#pragma mark ======
#pragma mark tableview delegate ======
#pragma mark tableview data source ======
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (_rubbishAudiConnectShowList.count > 0) {
        return 2;
    }
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case 0:
            if (_rubbishAudiConnectShowList.count > 0) {
                return _rubbishAudiConnectShowList.count;
            }
            return _audiConnectShowList.count;
        case 1:
            return _audiConnectShowList.count;
        default:
            return 0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case 0:
            if (_rubbishAudiConnectShowList.count > 0) {
                return @"冗余数据";
            }
            return @"最新数据";
        case 1:
            return @"最新数据";
        default:
            return @"";
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 102;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    AudiConnectShow *videoModel = [[AudiConnectShow alloc] init];
    
    if (indexPath.section == 0 && _rubbishAudiConnectShowList.count >0) {
        videoModel = [_rubbishAudiConnectShowList objectWithIndex:indexPath.row];
    }else{
        videoModel = [_audiConnectShowList objectWithIndex:indexPath.row];
    }
    
    NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld%@",(long)indexPath.section,(long)indexPath.row,videoModel.filename];
    
    UINib * nib = [UINib nibWithNibName:@"VideoCell" bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:CellIdentifier];
    VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[VideoCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    cell.cellName.text = videoModel.filename;
    
    if ([[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
        cell.cellProgress.progress = [item.progrees floatValue];
        cell.downloadState = [item.state integerValue];
    }
    
    if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl]  && isNewPage) {
        [self updateBackMainUI:videoModel withUIProgrees:cell];
    }
    
    
    //////////////////////////////////////
    if(videoModel.locaRubbish){
        cell.downloadState = DOWNLOADOVER;
    }
    
    
    switch (cell.downloadState) {
        case NOTDOWNLOAD:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_no"];
            cell.cellRatio.hidden = NO;
            cell.cellRatio.text = @"0";
            cell.cellSpeed.text = @"未下载";
            cell.cellProgress.hidden = NO;
            cell.cellProgress.progress = 0;
            cell.cellVideoSelectFlag.image = [UIImage imageNamed:@"videoDownload_select_no"];
            break;
        case DOWNLOADING:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_ing"];
            break;
        case DOWNLOADPAUSE:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_pause"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f"@"%@",cell.cellProgress.progress*100,@"%"];
            cell.cellSpeed.text = @"0";
            break;
        case DOWNLOADOVER:
        {
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_over"];
            cell.cellRatio.hidden = YES;
            cell.cellSpeed.text = @"下载完成";
            cell.cellProgress.hidden = YES;
            //======= 完成处理 给车辆视频中心
//            if ([CarVideo findvideoId:videoModel.videoId]) {
//                cell.cellVideoSelectFlag.image = [UIImage imageNamed:@"videoDownload_select_yes"];
//            }else{
//                cell.cellVideoSelectFlag.image = [UIImage imageNamed:@"videoDownload_select_no"];
//            }
        }
            break;
        default:
            break;
    }
    
    [cell.cellDownloadOutlet addTarget:self action:@selector(cellDownloadAction:) forControlEvents:UIControlEventTouchDown];
    cell.cellDownloadOutlet.indexPath = indexPath;
    
    return cell;
}
#pragma mark cell button action
- (void)cellDownloadAction:(CellButton *) sender{
    VideoCell *cell = (VideoCell *)[self.audiConnectShowTableView cellForRowAtIndexPath:sender.indexPath];
    __weak __typeof(self)weakSelf = self;
    
    NSIndexPath *index = [_audiConnectShowTableView indexPathForCell:cell];
    AudiConnectShow *videoModel = [_audiConnectShowList objectWithIndex:index.row];
    
    // 判断文件夹是否存在
    [[FileManager sharedManager] createDirectoryAtPath:[AUDICONNECTSHOW_FILE_PATH stringByAppendingPathComponent:videoModel.filename]];
    
    isNewPage = NO;
    switch (cell.downloadState) {
        case NOTDOWNLOAD: // prepareing
        {
            AFDownloadRequestOperation *videoOperation;
            
            [[AFDownloadManager sharedDownloadManager] downloadQueueTask:[NSString stringWithFormat:@"%@%@%@",videoModel.filename,@".",videoModel.customFileType?:@""]
                                                         withDownloadURL:videoModel.downUrl
                                                    withDownloadSavePath:[AUDICONNECTSHOW_FILE_PATH stringByAppendingPathComponent:videoModel.filename]
                                                      withUIProgressView:cell.cellProgress
                                              withAFHTTPRequestOperation:videoOperation
                                                         downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                             
                                                             [weakSelf saveDownloadItem:state withUrl:videoModel.downUrl withProgrees:@"1"];
                                                             [self saveDatabase:videoModel];
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:AUDICONNECTSHOW_DOWNLOAD_OVER object:weakSelf];
                                                             
                                                         } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                             [[FileManager sharedManager] removeFileAtPath:filePath];
                                                             cell.downloadState = NOTDOWNLOAD;
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:AUDICONNECTSHOW_DOWNLOAD_OVER object:weakSelf];
                                                             [weakSelf showErrorMessage:error];
                                                             
                                                         } downloadInfo:^(NSString *speedInfo ,  float ratio) {
                                                             cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                             cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                         }];
            cell.downloadState = DOWNLOADING;
            [_audiConnectShowTableView reloadData];
        }
            break;
            
        case DOWNLOADING:// downloading
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
                [[AFDownloadManager sharedDownloadManager] pauseDownload:operation];
                cell.downloadState = DOWNLOADPAUSE;
                [weakSelf saveDownloadItem:DOWNLOADPAUSE withUrl:videoModel.downUrl withProgrees:[NSString stringWithFormat:@"%f",cell.cellProgress.progress]];
            }
            [_audiConnectShowTableView reloadData];
        }
            break;
            
        case DOWNLOADPAUSE: // pauseing
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
                [[AFDownloadManager sharedDownloadManager] resumeDownload:operation];
                
                [weakSelf updateBackMainUI:videoModel withUIProgrees:cell];
                
            }else{
                
                AFDownloadRequestOperation *operation;
                
                [[AFDownloadManager sharedDownloadManager] downloadQueueTask:[NSString stringWithFormat:@"%@%@%@",videoModel.filename,@".",videoModel.customFileType?:@""]
                                                             withDownloadURL:videoModel.downUrl
                                                        withDownloadSavePath:[AUDICONNECTSHOW_FILE_PATH stringByAppendingPathComponent:videoModel.filename]
                                                          withUIProgressView:cell.cellProgress
                                                  withAFHTTPRequestOperation:operation
                                                             downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                                 [weakSelf saveDownloadItem:state withUrl:videoModel.downUrl withProgrees:@"1"];
                                                                 [self saveDatabase:videoModel];
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:AUDICONNECTSHOW_DOWNLOAD_OVER object:weakSelf];
                                                                 
                                                             } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                                 [[FileManager sharedManager] removeFileAtPath:filePath];
                                                                 cell.downloadState = NOTDOWNLOAD;
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:AUDICONNECTSHOW_DOWNLOAD_OVER object:weakSelf];
                                                                 [weakSelf showErrorMessage:error];
                                                                 
                                                             } downloadInfo:^(NSString *speedInfo , float ratio) {
                                                                 cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                                 cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                             }];
            }
            [[TMDiskCache sharedCache] removeObjectForKey:videoModel.downUrl];
            cell.downloadState = DOWNLOADING;
            [_audiConnectShowTableView reloadData];
        }
            break;
        case DOWNLOADOVER:
        {
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:@"资源已经下载完成" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [al show];
        }
            break;
        default:
            break;
    }
}

// edit video tableview
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    AudiConnectShow *videoModel = [[AudiConnectShow alloc] init];
    
    if (indexPath.section == 0 && _rubbishAudiConnectShowList.count >0) {
        videoModel = [_rubbishAudiConnectShowList objectWithIndex:indexPath.row];
    }else{
        videoModel = [_audiConnectShowList objectWithIndex:indexPath.row];
    }
    
    
//    AudiConnectShow *videoModel = [_audiConnectShowList objectWithIndex:indexPath.row];
    
    if ([[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
        if ([item.state integerValue] == DOWNLOADOVER) {
            return YES;
        }
    }
    
    if (videoModel.isdelete || videoModel.locaRubbish) {
        return YES;
    }
    
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    dispatch_queue_t concurrentQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(concurrentQueue, ^{
        dispatch_sync(concurrentQueue, ^{
//            AudiConnectShow *videoModel = [_audiConnectShowList objectWithIndex:indexPath.row];
            
            AudiConnectShow *videoModel;
            
            if (indexPath.section == 0 && _rubbishAudiConnectShowList.count >0) {
                videoModel = [_rubbishAudiConnectShowList objectWithIndex:indexPath.row];
            }else{
                videoModel = [_audiConnectShowList objectWithIndex:indexPath.row];
            }
            
            
            
            if (editingStyle == UITableViewCellEditingStyleDelete && [[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
                AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
                if ([item.state integerValue] == DOWNLOADOVER) {
                    [[TMDiskCache sharedCache] removeObjectForKey:videoModel.downUrl];
                    NSString *fileName = [[AUDICONNECTSHOW_FILE_PATH stringByAppendingPathComponent:videoModel.filename] stringByReplacingOccurrencesOfString:@".zip" withString:@""];
                    [[FileManager sharedManager] removeFileAtPath:fileName];
                    VideoCell *cell = (VideoCell *)[tableView cellForRowAtIndexPath:indexPath];
                    cell.downloadState = NOTDOWNLOAD;
                    [AudiConnectShow deleteWithId:videoModel.id];
                }
            }else if (editingStyle == UITableViewCellEditingStyleDelete || videoModel.isdelete || videoModel.locaRubbish){
                NSString *fileName = [[AUDICONNECTSHOW_FILE_PATH stringByAppendingPathComponent:videoModel.filename] stringByReplacingOccurrencesOfString:@".zip" withString:@""];
                [[FileManager sharedManager] removeFileAtPath:fileName];
                [_rubbishAudiConnectShowList removeObject:videoModel];
            }
        });
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self.audiConnectShowTableView reloadData];
        });
    });
    
}



#pragma mark back view refresh main view
- (void)updateBackMainUI:(AudiConnectShow *)videoModel withUIProgrees:(UITableViewCell *)tbCell{
    VideoCell *cell = (VideoCell *)tbCell;
    AFHTTPRequestOperation *op = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
    if (![op isPaused]) {
        
        [cell.cellSpeed setUILabelWithDownloadUILabelOfOperation:(AFDownloadRequestOperation*)op downloadInfo:^(NSString *speedInfo, float ratio) {
            cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
            
        } currDownloadSpeed:^(float currRatio) {
            cell.cellProgress.progress = currRatio;
        }];
        cell.downloadState = DOWNLOADING;
    }
}


#pragma mark notification tableview reload
- (void)notificationUIRefresh{
    [self.audiConnectShowTableView reloadData];
}

#pragma mark download over save item
- (void)saveDownloadItem:(NSInteger )state withUrl:(NSString *)url withProgrees:(NSString *)progrees{
    AFDownloadItem *item = [[AFDownloadItem alloc] init];
    item.url = url;
    item.progrees = progrees;
    item.state = [NSString stringWithFormat:@"%zd",state];
    [[TMDiskCache sharedCache] setObject:item forKey:url];
}

#pragma mark show error message
- (void)showErrorMessage:(NSError *)error{
    NSString *errorStr = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:errorStr delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [al show];
}

- (void)saveDatabase:(AudiConnectShow *)model{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setValue:(NSString *)model.fileimagepath?:@"" forKey:@"fileimagepath"];
    [dic setValue:(NSString *)model.filename?:@"" forKey:@"filename"];
    [dic setValue:(NSString *)model.filepath?:@"" forKey:@"filepath"];
    [dic setValue:(NSString *)model.filetype?:@"" forKey:@"filetype"];
    [dic setValue:(NSString *)model.id?:@"" forKey:@"id"];
    [dic setBool:(BOOL)model.isdelete forKey:@"isdelete"];
    [dic setValue:model.imgUrl?:@"" forKey:@"imgUrl"];
    [AudiConnectShow insertWithDic:dic];
}
@end
