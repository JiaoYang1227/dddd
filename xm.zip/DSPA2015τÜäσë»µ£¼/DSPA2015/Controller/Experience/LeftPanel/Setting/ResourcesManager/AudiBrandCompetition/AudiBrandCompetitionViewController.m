//
//  AudiBrandCompetitionViewController.m
//  DSPA2015
//
//  Created by runlin on 16/7/14.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "AudiBrandCompetitionViewController.h"
#import "CommpetitionBrandListCell.h"
#import "AudiBrandCompetition.h"
#import "CarCompare.h"

@interface AudiBrandCompetitionViewController ()
{
    NSMutableArray *_audiBrandCompetitionList;
    NSInteger downloadIndex;
    
    __weak IBOutlet UITableView *_audiBrandCompetitionTableview;
}


@end

@implementation AudiBrandCompetitionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"本品对比数据下载";
    downloadIndex = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [AudiBrandCompetition getAudiBrandCompetitionList:nil Success:^(NSMutableArray *arrList) {
        
        if (arrList.count > 0) {
            _audiBrandCompetitionList = [[NSMutableArray alloc] initWithArray:arrList];
            [_audiBrandCompetitionTableview reloadData];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


#pragma mark ======
#pragma mark tableview delegate ======
#pragma mark tableview data source ======
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _audiBrandCompetitionList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView registerNib:[UINib nibWithNibName:@"CommpetitionBrandListCell" bundle:nil] forCellReuseIdentifier:@"CommpetitionBrandListCell"];
    CommpetitionBrandListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommpetitionBrandListCell"];
    
    AudiBrandCompetition *model = [_audiBrandCompetitionList objectWithIndex:indexPath.row];
    [cell configDataFromAudiBrandCompetition:model withIndexPath:indexPath];
    [cell.cellDownloadButtonOutlet addTarget:self action:@selector(audiBrandCompetitionDownloadAction:) forControlEvents:UIControlEventTouchDown];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 102.;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    AudiBrandCompetition *model = [_audiBrandCompetitionList objectWithIndex:indexPath.row];
    // 判断数据是否存在
    if([CarCompare isDownLoadFromBrandID:model.brandId]){
        return YES;
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    dispatch_queue_t concurrentQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(concurrentQueue, ^{
        dispatch_sync(concurrentQueue, ^{
            AudiBrandCompetition *model = [_audiBrandCompetitionList objectWithIndex:indexPath.row];
            [CarCompare isDeleteFromBrandID:model.brandId];
        });
        dispatch_sync(dispatch_get_main_queue(), ^{
            [_audiBrandCompetitionTableview reloadData];
        });
    });
}

- (void)audiBrandCompetitionDownloadAction:(CellButton *)sender{
    AudiBrandCompetition *model = [_audiBrandCompetitionList objectWithIndex:sender.indexPath.row];
    // 判断数据是否存在
    if([CarCompare isDownLoadFromBrandID:model.brandId]){
        NSString *overInfo = [NSString stringWithFormat:@"%@%@",model.name , @"已经下载完成"];
        [JKAlert showMessage:overInfo];
        return;
    }
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [AudiBrandCompetition downAudiBrandCompetitionDetailed:@{@"brandid":model.brandId} Success:^(NSMutableArray *arrList) {
        
        //成功创建数据库，刷新列表数据
        if ([CarCompare createCarCompareTable:arrList]) {
              [_audiBrandCompetitionTableview reloadData];
        }else{
            NSString *error = [NSString stringWithFormat:@"%@%@",model.name , @"创建失败"];
            [JKAlert showMessage:error];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}



- (IBAction)audiBrandCompetitionDownloadAllButtonAction:(id)sender {
    if (downloadIndex == 0) {
        [self downloadAll:downloadIndex];
    }
}

- (void)downloadAll:(NSInteger )index{
    __weak __typeof(self)weakSelf = self;
    //index 是否大于 _audiBrandCompetitionList 的count
    if (index > _audiBrandCompetitionList.count - 1) {
        return;
    }
    
    AudiBrandCompetition *model = [_audiBrandCompetitionList objectWithIndex:index];
    // 判断数据是否存在
    if([CarCompare isDownLoadFromBrandID:model.brandId]){
        downloadIndex = index + 1;
        [self downloadAll:(index + 1)];
        return;
    }
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.detailsLabelText = [NSString stringWithFormat:@"%@%@",model.name,@"正在下载中..."];
    [AudiBrandCompetition downAudiBrandCompetitionDetailed:@{@"brandid":model.brandId?:@""} Success:^(NSMutableArray *arrList) {
        
        //成功创建数据库，刷新列表数据
        if ([CarCompare createCarCompareTable:arrList]) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            [_audiBrandCompetitionTableview reloadData];
            downloadIndex = index + 1;
            [weakSelf downloadAll:(index + 1)];
            
        }else{
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }
        
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


@end
