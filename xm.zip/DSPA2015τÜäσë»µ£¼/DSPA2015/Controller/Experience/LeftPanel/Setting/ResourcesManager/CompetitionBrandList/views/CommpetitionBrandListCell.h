//
//  CommpetitionBrandListCell.h
//  DSPA2015
//
//  Created by runlin on 16/7/1.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CompetitionBrandListModel.h"
#import "CellButton.h"
#import "AudiBrandCompetition.h"

@interface CommpetitionBrandListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cellName;
@property (weak, nonatomic) IBOutlet UILabel *cellDownloadStateLable;
@property (weak, nonatomic) IBOutlet UIImageView *cellDownloadStateImg;


@property (weak, nonatomic) IBOutlet CellButton *cellDownloadButtonOutlet;

- (void)configData:(CompetitionBrandListModel *)model withIndexPath:(NSIndexPath *)indexPath;


- (void)configDataFromAudiBrandCompetition:(AudiBrandCompetition *)model withIndexPath:(NSIndexPath *)indexPath;

@end
