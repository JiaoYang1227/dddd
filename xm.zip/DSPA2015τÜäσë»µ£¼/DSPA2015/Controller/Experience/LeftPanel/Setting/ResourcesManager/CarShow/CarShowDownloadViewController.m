//
//  CarShowDownloadViewController.m
//  D-CARS
//
//  Created by gavin on 15/7/22.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "CarShowDownloadViewController.h"
#import "VideoCell.h"
#import "AFDownloadManager.h"
#import "AFDownloadItem.h"
#import "TMCache.h"
#import "JKAlert.h"
#import "UIProgressView+AFNetworking.h"
#import "UILabel+AFDownloadRequestOperation.h"
#import "CarShowDownloadModel.h"
#import "FileManager.h"
#import "ZipManager.h"

#define CARSHOW_DOWNLOAD_OVER @"carshow_download_over"

#define CARSHOW_DOWNLOAD_FINDER_NAME_TEMP @"/downloadModelTemp"

#define CARSHOW_DOWNLOAD_FINDER_NAME @"/model"

#define CARSHOW_DOWNLOAD_FILE_PATH [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],CARSHOW_DOWNLOAD_FINDER_NAME]

#define CARSHOW_DOWNLOAD_FILE_PATH_TEMP [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],CARSHOW_DOWNLOAD_FINDER_NAME_TEMP]

@interface CarShowDownloadViewController ()
{
    BOOL nibsRegistered_;
    NSMutableArray *_carList;
    BOOL isNewPage;
}
@property (weak, nonatomic) IBOutlet UITableView *carShowTableview;
@end

@implementation CarShowDownloadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    isNewPage = YES;
    
    [[NSNotificationCenter  defaultCenter] addObserver:self  selector:@selector(notificationCarShowDownloadUIRefresh) name:CARSHOW_DOWNLOAD_OVER object:nil];
    [[FileManager sharedManager] createDirectoryAtPath:CARSHOW_DOWNLOAD_FILE_PATH_TEMP];
    [[FileManager sharedManager] createDirectoryAtPath:CARSHOW_DOWNLOAD_FILE_PATH];
    
    [FileManager documentsPath:nil];
    self.title = @"车辆展厅资源管理";
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    __weak typeof(self)weak = self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CarShowDownloadModel getCarShowDownloadList:nil Success:^(NSMutableArray *arrList) {
        if (arrList.count > 0) {
            _carList = [[NSMutableArray alloc] initWithArray:arrList];
            weak.count = _carList.count;
            [weak.carShowTableview reloadData];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (void)backButtonTouched:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
    [[NSNotificationCenter  defaultCenter] removeObserver:self name:CARSHOW_DOWNLOAD_OVER object:nil];
}


#pragma mark ======
#pragma mark tableview delegate ======
#pragma mark tableview data source ======
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 102;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld",(long)indexPath.section,(long)indexPath.row];
    
    UINib * nib = [UINib nibWithNibName:@"VideoCell" bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:CellIdentifier];
    CarShowDownloadModel *carModel = [_carList objectWithIndex:indexPath.row];
    VideoCell * cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.cellName.text = [carModel.filename stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    cell.cellVideoSelectFlag.hidden = YES;
    
    if ([[TMDiskCache sharedCache] objectForKey:carModel.downUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:carModel.downUrl];
        cell.cellProgress.progress = [item.progrees floatValue];
        cell.downloadState = [item.state integerValue];
    }
    
    if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downUrl]  && isNewPage) {
        AFHTTPRequestOperation *op = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downUrl];
        if (![op isPaused]) {
            [self updateBackMainUI:carModel withUIProgrees:cell];
            cell.downloadState = DOWNLOADING;
        }
    }
    
    switch (cell.downloadState) {
        case NOTDOWNLOAD:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_no"];
            cell.cellRatio.hidden = NO;
            cell.cellRatio.text = @"0";
            cell.cellSpeed.text = @"未下载";
            cell.cellProgress.hidden = NO;
            cell.cellProgress.progress = 0;
            break;
        case DOWNLOADING:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_ing"];
            break;
        case DOWNLOADPAUSE:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_pause"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f"@"%@",cell.cellProgress.progress*100,@"%"];
            cell.cellSpeed.text = @"0";
            break;
        case DOWNLOADOVER:
        {
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_over"];
            cell.cellRatio.hidden = YES;
            cell.cellSpeed.text = @"下载完成";
            cell.cellProgress.hidden = YES;
        }
            break;
        default:
            break;
    }
    
    [cell.cellDownloadOutlet addTarget:self action:@selector(cellDownloadAction:) forControlEvents:UIControlEventTouchDown];
    cell.cellDownloadOutlet.indexPath = indexPath;
    
    return cell;
}
#pragma mark cell button action
- (void)cellDownloadAction:(CellButton *) sender{
    VideoCell *cell = (VideoCell *)[self.carShowTableview cellForRowAtIndexPath:sender.indexPath];
    __weak __typeof(self)weakSelf = self;
    
    NSIndexPath *index = [_carShowTableview indexPathForCell:cell];
    CarShowDownloadModel *carModel = [_carList objectWithIndex:index.row];
    isNewPage = NO;
    switch (cell.downloadState) {
        case NOTDOWNLOAD: // prepareing
        {
            AFDownloadRequestOperation *carShowOperation;
            
            [[AFDownloadManager sharedDownloadManager] downloadQueueTask:carModel.filename
                                                         withDownloadURL:carModel.downUrl
                                                    withDownloadSavePath:CARSHOW_DOWNLOAD_FILE_PATH_TEMP
                                                      withUIProgressView:cell.cellProgress
                                              withAFHTTPRequestOperation:carShowOperation
                                                         downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                             
                                                             [weakSelf saveDownloadItem:state withUrl:carModel.downUrl withProgrees:@"1" withMD5:carModel.identification];
                                                             
//                                                             [weakSelf zipFileRelease:operation.responseObject];
                                                             
                                                             NSString *fileName = [operation.responseObject stringByReplacingOccurrencesOfString:@".zip" withString:@""];
                                                             [ZipManager unZip:operation.responseObject withZipToFilePath:fileName unZipSuccess:^(NSString *filePath, NSString *toFilePath) {
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:CARSHOW_DOWNLOAD_OVER object:self];
                                                                 [[FileManager sharedManager] moveItems:toFilePath toDir:CARSHOW_DOWNLOAD_FILE_PATH];
                                                             }];
                                                             
//                                                             [[NSNotificationCenter defaultCenter] postNotificationName:CARSHOW_DOWNLOAD_OVER object:weakSelf];
                                                             
                                                         } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                             [[FileManager sharedManager] removeFileAtPath:filePath];
                                                             cell.downloadState = NOTDOWNLOAD;
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:CARSHOW_DOWNLOAD_OVER object:weakSelf];
                                                             [weakSelf showErrorMessage:error];
                                                             
                                                         } downloadInfo:^(NSString *speedInfo ,  float ratio) {
                                                             cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                             cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                         }];
            cell.downloadState = DOWNLOADING;
            [_carShowTableview reloadData];
        }
            break;
            
        case DOWNLOADING:// downloading
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downUrl]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downUrl];
                [[AFDownloadManager sharedDownloadManager] pauseDownload:operation];
                cell.downloadState = DOWNLOADPAUSE;
                
                [weakSelf saveDownloadItem:DOWNLOADPAUSE withUrl:carModel.downUrl withProgrees:[NSString stringWithFormat:@"%f",cell.cellProgress.progress] withMD5:carModel.identification];
            }
            [_carShowTableview reloadData];
        }
            break;
            
        case DOWNLOADPAUSE: // pauseing
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downUrl]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downUrl];
                [[AFDownloadManager sharedDownloadManager] resumeDownload:operation];
                [weakSelf updateBackMainUI:carModel withUIProgrees:cell];
            }else{
                AFDownloadRequestOperation *operation;
                
                [[AFDownloadManager sharedDownloadManager] downloadQueueTask:carModel.filename
                                                             withDownloadURL:carModel.downUrl
                                                        withDownloadSavePath:CARSHOW_DOWNLOAD_FILE_PATH_TEMP
                                                          withUIProgressView:cell.cellProgress
                                                  withAFHTTPRequestOperation:operation
                                                             downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                                 [weakSelf saveDownloadItem:state withUrl:carModel.downUrl withProgrees:@"1" withMD5:carModel.identification];
                                                                 
//                                                                 [weakSelf zipFileRelease:operation.responseObject];
//                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:CARSHOW_DOWNLOAD_OVER object:weakSelf];
                                                                 
                                                                 NSString *fileName = [operation.responseObject stringByReplacingOccurrencesOfString:@".zip" withString:@""];
                                                                 [ZipManager unZip:operation.responseObject withZipToFilePath:fileName unZipSuccess:^(NSString *filePath, NSString *toFilePath) {
                                                                     [[NSNotificationCenter defaultCenter] postNotificationName:CARSHOW_DOWNLOAD_OVER object:self];
                                                                     [[FileManager sharedManager] moveItems:toFilePath toDir:CARSHOW_DOWNLOAD_FILE_PATH];
                                                                 }];
                                                                 
                                                                 
                                                             } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                                 [[FileManager sharedManager] removeFileAtPath:filePath];
                                                                 cell.downloadState = NOTDOWNLOAD;
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:CARSHOW_DOWNLOAD_OVER object:weakSelf];
                                                                 [weakSelf showErrorMessage:error];
                                                                 
                                                             } downloadInfo:^(NSString *speedInfo , float ratio) {
                                                                 cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                                 cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                             }];
            }
            [[TMDiskCache sharedCache] removeObjectForKey:carModel.downUrl];
            cell.downloadState = DOWNLOADING;
            [_carShowTableview reloadData];
        }
            break;
        case DOWNLOADOVER:
        {
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:@"资源已经下载完成" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [al show];
        }
            break;
        default:
            break;
    }
}


// edit video tableview
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    CarShowDownloadModel *videoModel = [_carList objectWithIndex:indexPath.row];
    if ([[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
        if ([item.state integerValue] == DOWNLOADOVER) {
            return YES;
        }
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    dispatch_queue_t concurrentQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(concurrentQueue, ^{
        dispatch_sync(concurrentQueue, ^{
            CarShowDownloadModel *carModel = [_carList objectWithIndex:indexPath.row];
            if (editingStyle == UITableViewCellEditingStyleDelete && [[TMDiskCache sharedCache] objectForKey:carModel.downUrl]) {
                AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:carModel.downUrl];
                if ([item.state integerValue] == DOWNLOADOVER) {
                    [[TMDiskCache sharedCache] removeObjectForKey:carModel.downUrl];
                    NSString *fileNameReplacing = [carModel.filename stringByReplacingOccurrencesOfString:@".zip" withString:@""];
                    NSString *fileName = [CARSHOW_DOWNLOAD_FILE_PATH stringByAppendingPathComponent:fileNameReplacing];
                    [[FileManager sharedManager] removeFileAtPath:fileName];
                    VideoCell *cell = (VideoCell *)[tableView cellForRowAtIndexPath:indexPath];
                    cell.downloadState = NOTDOWNLOAD;
                }
            }
        });
        dispatch_sync(dispatch_get_main_queue(), ^{
            [_carShowTableview reloadData];
        });
    });
    
}

#pragma mark back view refresh main view
- (void)updateBackMainUI:(CarShowDownloadModel *)carModel withUIProgrees:(UITableViewCell *)tbCell{
    VideoCell *cell = (VideoCell *)tbCell;
    AFHTTPRequestOperation *op = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downUrl];
    if (![op isPaused]) {
        
        [cell.cellSpeed setUILabelWithDownloadUILabelOfOperation:(AFDownloadRequestOperation*)op downloadInfo:^(NSString *speedInfo, float ratio) {
            cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
            
        } currDownloadSpeed:^(float currRatio) {
            cell.cellProgress.progress = currRatio;
        }];
        cell.downloadState = DOWNLOADING;
    }
}
#pragma mark notification tableview reload
- (void)notificationCarShowDownloadUIRefresh{
    [self.carShowTableview reloadData];
}

#pragma mark download over save item
- (void)saveDownloadItem:(NSInteger )state withUrl:(NSString *)url withProgrees:(NSString *)progrees withMD5:(NSString *)md5{
    AFDownloadItem *item = [[AFDownloadItem alloc] init];
    item.url = url;
    item.progrees = progrees;
    item.state = [NSString stringWithFormat:@"%zd",state];
    [[TMDiskCache sharedCache] setObject:item forKey:url];
}

#pragma mark show error message
- (void)showErrorMessage:(NSError *)error{
    NSString *errorStr = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:errorStr delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [al show];
}

#pragma mark zip file
- (void)zipFileRelease:(NSString *)filePath{
    NSString *fileName = [filePath stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    [ZipManager unZip:filePath withZipToFilePath:fileName unZipSuccess:^(NSString *filePath, NSString *toFilePath) {
        [[NSNotificationCenter defaultCenter] postNotificationName:CARSHOW_DOWNLOAD_OVER object:self];
        [[FileManager sharedManager] moveItems:toFilePath toDir:CARSHOW_DOWNLOAD_FILE_PATH];
    }];
}

@end
