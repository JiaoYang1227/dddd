//
//  CommpetitionBrandListViewController.h
//  DSPA2015
//
//  Created by runlin on 16/7/1.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ResourcesBaseTableViewController.h"

@interface CommpetitionBrandListViewController : ResourcesBaseTableViewController

@end
