//
//  ResourcesBaseTableViewController.m
//  D-CARS
//
//  Created by gavin on 15/7/22.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "ResourcesBaseTableViewController.h"

@interface ResourcesBaseTableViewController ()

@end

@implementation ResourcesBaseTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _count = 0;
    self.automaticallyAdjustsScrollViewInsets = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //    return 0;
    return _count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    /*    static NSString * identifier = @"CellName";
     if (!nibsRegistered_) {
     UINib * nib = [UINib nibWithNibName:@"CellName" bundle:nil];
     [tableView registerNib:nib forCellReuseIdentifier:identifier];
     nibsRegistered_ = YES;
     }
     
     UITableviewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
     cell.selectionStyle = UITableViewCellSelectionStyleNone;
     
     cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
     */
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{}
@end
