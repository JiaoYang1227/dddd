//
//  VideoCenterViewController.m
//  D-CARS
//
//  Created by gavin on 15/7/21.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "VideoCenterViewController.h"
#import "VideoCell.h"
#import "AFDownloadManager.h"
#import "AFDownloadItem.h"
#import "TMCache.h"
#import "UIProgressView+AFNetworking.h"
#import "UILabel+AFDownloadRequestOperation.h"
#import "VideoModel.h"
#import "UIProgressView+AFDownloadRequestOperation.h"
#import "FileManager.h"
#import "ZipManager.h"
#import "CarVideo.h"
#import "ResourcesManagerSandbox.h"

#define VIDEO_DOWNLOAD_OVER @"video_download_over"

#define VIDEO_FINDER_NAME @"/video"

#define VIDEO_FILE_PATH [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],VIDEO_FINDER_NAME]

@interface VideoCenterViewController ()
{
    BOOL nibsRegistered_;
    NSMutableArray *_videoList;
    NSMutableArray *_rubbishList;
    
    AFHTTPRequestOperation *_videoOperation;      //创建请求管理（用于上传和下载）
    
    BOOL isNewPage;
}
@property (weak, nonatomic) IBOutlet UITableView *videoTableview;

- (IBAction)downloadAllButtonAction:(id)sender;


@end

@implementation VideoCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isNewPage = YES;
    [[NSNotificationCenter  defaultCenter] addObserver:self  selector:@selector(notificationUIRefresh) name:VIDEO_DOWNLOAD_OVER object:nil];
    [[FileManager sharedManager] createDirectoryAtPath:VIDEO_FILE_PATH];
    self.title = @"视频中心资源管理";
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    __weak typeof(self)weak = self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [VideoModel getVideoList:nil Success:^(NSMutableArray *arrList, NSMutableArray *rubbishList, NSMutableArray *all) {
        if (arrList.count > 0) {
            _videoList = [[NSMutableArray alloc] initWithArray:arrList];
//            _rubbishList = [[NSMutableArray alloc] initWithArray:rubbishList];
            
            _rubbishList = [ResourcesManagerSandbox getAllFileFromPath:VIDEO_FILE_PATH withServerData:all];
            
            weak.count = _videoList.count;
            [weak.videoTableview reloadData];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)backButtonTouched:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
    [[NSNotificationCenter  defaultCenter] removeObserver:self name:VIDEO_DOWNLOAD_OVER object:nil];
}


#pragma mark ======
#pragma mark tableview delegate ======
#pragma mark tableview data source ======

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (_rubbishList.count > 0) {
        return 2;
    }
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case 0:
            if (_rubbishList.count > 0) {
                return _rubbishList.count;
            }
            return _videoList.count;
        case 1:
            return _videoList.count;
        default:
            return 0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case 0:
            if (_rubbishList.count > 0) {
                return @"冗余数据";
            }
            return @"最新数据";
        case 1:
            return @"最新数据";
        default:
            return @"";
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 102;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    VideoModel *videoModel;
    
    if (indexPath.section == 0 && _rubbishList.count >0) {
        videoModel = [_rubbishList objectWithIndex:indexPath.row];
    }else{
        videoModel = [_videoList objectWithIndex:indexPath.row];
    }
    
    
    NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld%ld%@",(long)indexPath.section,(long)indexPath.row,videoModel.name];
    UINib * nib = [UINib nibWithNibName:@"VideoCell" bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:CellIdentifier];
    VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;


    cell.cellName.text = [videoModel.name stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    
    if ([[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
        cell.cellProgress.progress = [item.progrees floatValue];
        cell.downloadState = [item.state integerValue];
    }
    
    if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl]  && isNewPage) {
        [self updateBackMainUI:videoModel withUIProgrees:cell];
    }
    
    //////////////////////////////////////
    if(videoModel.locaRubbish){
        cell.downloadState = DOWNLOADOVER;
    }
    
    
    switch (cell.downloadState) {
        case NOTDOWNLOAD:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_no"];
            cell.cellRatio.hidden = NO;
            cell.cellRatio.text = @"0";
            cell.cellSpeed.text = @"未下载";
            cell.cellProgress.hidden = NO;
            cell.cellProgress.progress = 0;
            cell.cellVideoSelectFlag.image = [UIImage imageNamed:@"videoDownload_select_no"];
            break;
        case DOWNLOADING:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_ing"];
            break;
        case DOWNLOADPAUSE:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_pause"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f"@"%@",cell.cellProgress.progress*100,@"%"];
            cell.cellSpeed.text = @"0";
            break;
        case DOWNLOADOVER:
        {
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_over"];
            cell.cellRatio.hidden = YES;
            cell.cellSpeed.text = @"下载完成";
            cell.cellProgress.hidden = YES;
            //======= 完成处理 给车辆视频中心
            if ([CarVideo findvideoId:videoModel.videoId]) {
                cell.cellVideoSelectFlag.image = [UIImage imageNamed:@"videoDownload_select_yes"];
            }else{
                cell.cellVideoSelectFlag.image = [UIImage imageNamed:@"videoDownload_select_no"];
            }
        }
            break;
        default:
            break;
    }
    
    [cell.cellDownloadOutlet addTarget:self action:@selector(cellDownloadAction:) forControlEvents:UIControlEventTouchDown];
    cell.cellDownloadOutlet.indexPath = indexPath;
    __block typeof(self)weakself = self;
    cell.videoDownloadOverSelectCallBack = ^(VideoCell *cell){
        VideoModel *videoModel = [_videoList objectWithIndex:[_videoTableview indexPathForCell:cell].row];
        //======= 完成处理 给车辆视频中心
        if (cell.downloadState == DOWNLOADOVER && ![CarVideo findvideoId:videoModel.videoId]) {
            [weakself saveDatabase:videoModel withSelected:@"YES"];
        }else{
            [weakself saveDatabase:videoModel withSelected:@"NO"];
        }
        
        [_videoTableview reloadData];
    };
    
    return cell;
}
#pragma mark cell button action
- (void)cellDownloadAction:(CellButton *) sender{
    VideoCell *cell = (VideoCell *)[self.videoTableview cellForRowAtIndexPath:sender.indexPath];
    __weak __typeof(self)weakSelf = self;

    NSIndexPath *index = [_videoTableview indexPathForCell:cell];
    VideoModel *videoModel = [_videoList objectWithIndex:index.row];
    
    // 判断文件夹是否存在
    [[FileManager sharedManager] createDirectoryAtPath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name]];
    
    isNewPage = NO;
    switch (cell.downloadState) {
        case NOTDOWNLOAD: // prepareing
        {
            AFDownloadRequestOperation *videoOperation;

            [[AFDownloadManager sharedDownloadManager] downloadQueueTask:[NSString stringWithFormat:@"%@%@",videoModel.name,@".mp4"]
                                                         withDownloadURL:videoModel.downUrl
                                                    withDownloadSavePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name]
                                                      withUIProgressView:cell.cellProgress
                                              withAFHTTPRequestOperation:videoOperation
                                                         downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                             
                                                             [weakSelf saveDownloadItem:state withUrl:videoModel.downUrl withProgrees:@"1"];
                                                             NSLog(@"videoModel.recommend=%@",videoModel.recommend);
                                                             NSString *isSelected;
                                                             if ([videoModel.recommend intValue] == 0) {
                                                                 isSelected = [NSString stringWithFormat:@"NO"];
                                                             }else{
                                                                 isSelected = [NSString stringWithFormat:@"YES"];
                                                             }
                                                             [weakSelf saveDatabase:videoModel withSelected:isSelected];
                                                             
                                                             [weakSelf downImage:videoModel.bigUrl withFilePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] withFileName:@"bigImage.jpg"];
                                                             
                                                             [weakSelf downImage:videoModel.smallUrl withFilePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] withFileName:@"smallImage.jpg"];
                                                             
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:VIDEO_DOWNLOAD_OVER object:weakSelf];
                                                             
                                                         } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                             [[FileManager sharedManager] removeFileAtPath:filePath];
                                                             cell.downloadState = NOTDOWNLOAD;
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:VIDEO_DOWNLOAD_OVER object:weakSelf];
                                                             [weakSelf showErrorMessage:error];
                                                             
                                                         } downloadInfo:^(NSString *speedInfo ,  float ratio) {
                                                             cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                             cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                         }];
            cell.downloadState = DOWNLOADING;
            [_videoTableview reloadData];
        }
            break;
            
        case DOWNLOADING:// downloading
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
                [[AFDownloadManager sharedDownloadManager] pauseDownload:operation];
                cell.downloadState = DOWNLOADPAUSE;
                [weakSelf saveDownloadItem:DOWNLOADPAUSE withUrl:videoModel.downUrl withProgrees:[NSString stringWithFormat:@"%f",cell.cellProgress.progress]];
            }
            [_videoTableview reloadData];
        }
            break;
            
        case DOWNLOADPAUSE: // pauseing
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl]) {
            
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
                [[AFDownloadManager sharedDownloadManager] resumeDownload:operation];
                
                [weakSelf updateBackMainUI:videoModel withUIProgrees:cell];
                
            }else{
            
                AFDownloadRequestOperation *operation;
            
                [[AFDownloadManager sharedDownloadManager] downloadQueueTask:[NSString stringWithFormat:@"%@%@",videoModel.name,@".mp4"]
                                                             withDownloadURL:videoModel.downUrl
                                                        withDownloadSavePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name]
                                                          withUIProgressView:cell.cellProgress
                                                  withAFHTTPRequestOperation:operation
                                                             downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                                 [weakSelf saveDownloadItem:state withUrl:videoModel.downUrl withProgrees:@"1"];
                                                                 NSLog(@"videoModel.recommend=%@",videoModel.recommend);
                                                                 NSString *isSelected;
                                                                 if ([videoModel.recommend intValue] == 0) {
                                                                     isSelected = [NSString stringWithFormat:@"NO"];
                                                                 }else{
                                                                     isSelected = [NSString stringWithFormat:@"YES"];
                                                                 }
                                                                 [weakSelf saveDatabase:videoModel withSelected:isSelected];
                                                                 [weakSelf downImage:videoModel.bigUrl withFilePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] withFileName:@"bigImage.jpg"];
                                                                 
                                                                 [weakSelf downImage:videoModel.smallUrl withFilePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] withFileName:@"smallImage.jpg"];
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:VIDEO_DOWNLOAD_OVER object:weakSelf];
                                                                 
                                                             } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                                 [[FileManager sharedManager] removeFileAtPath:filePath];
                                                                 cell.downloadState = NOTDOWNLOAD;
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:VIDEO_DOWNLOAD_OVER object:weakSelf];
                                                                 [weakSelf showErrorMessage:error];
                                                                 
                                                             } downloadInfo:^(NSString *speedInfo , float ratio) {
                                                                 cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                                 cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                             }];
            }
            [[TMDiskCache sharedCache] removeObjectForKey:videoModel.downUrl];
            cell.downloadState = DOWNLOADING;
            [_videoTableview reloadData];
        }
            break;
        case DOWNLOADOVER:
        {
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:@"资源已经下载完成" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [al show];
        }
            break;
        default:
            break;
    }
}
// edit video tableview
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    VideoModel *videoModel;
    
    if (indexPath.section == 0 && _rubbishList.count >0) {
        videoModel = [_rubbishList objectWithIndex:indexPath.row];
    }else{
        videoModel = [_videoList objectWithIndex:indexPath.row];
    }
    
//    videoModel = [_videoList objectWithIndex:indexPath.row];
    
    if ([[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
        if ([item.state integerValue] == DOWNLOADOVER) {
            return YES;
        }
    }
    
    if (videoModel.deleteFlag || videoModel.locaRubbish) {
        return YES;
    }
    
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {

    dispatch_queue_t concurrentQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(concurrentQueue, ^{
        dispatch_sync(concurrentQueue, ^{
//            VideoModel *videoModel = [_videoList objectWithIndex:indexPath.row];
            
            VideoModel *videoModel;
            
            if (indexPath.section == 0 && _rubbishList.count >0) {
                videoModel = [_rubbishList objectWithIndex:indexPath.row];
            }else{
                videoModel = [_videoList objectWithIndex:indexPath.row];
            }
            
            
            if (editingStyle == UITableViewCellEditingStyleDelete && [[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
                AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
                if ([item.state integerValue] == DOWNLOADOVER) {
                    [[TMDiskCache sharedCache] removeObjectForKey:videoModel.downUrl];
                    NSString *fileName = [[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] stringByReplacingOccurrencesOfString:@".zip" withString:@""];
                    [[FileManager sharedManager] removeFileAtPath:fileName];
                    VideoCell *cell = (VideoCell *)[tableView cellForRowAtIndexPath:indexPath];
                    cell.downloadState = NOTDOWNLOAD;
                    [CarVideo deleteWithId:[NSString stringWithFormat:@"%@",videoModel.videoId]];
                }
            }else if (editingStyle == UITableViewCellEditingStyleDelete || videoModel.deleteFlag || videoModel.locaRubbish){
                NSString *fileName = [[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] stringByReplacingOccurrencesOfString:@".zip" withString:@""];
                [[FileManager sharedManager] removeFileAtPath:fileName];
                [CarVideo deleteWithId:[NSString stringWithFormat:@"%@",videoModel.videoId]];
                [_rubbishList removeObject:videoModel];
            }
            
        });
        dispatch_sync(dispatch_get_main_queue(), ^{
            @synchronized (_videoTableview) {
                [_videoTableview reloadData];
            }
        });   
    });
    
}


#pragma mark back view refresh main view
- (void)updateBackMainUI:(VideoModel *)videoModel withUIProgrees:(UITableViewCell *)tbCell{
    VideoCell *cell = (VideoCell *)tbCell;
    AFHTTPRequestOperation *op = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
    if (![op isPaused]) {
        
        [cell.cellSpeed setUILabelWithDownloadUILabelOfOperation:(AFDownloadRequestOperation*)op downloadInfo:^(NSString *speedInfo, float ratio) {
            cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
            
        } currDownloadSpeed:^(float currRatio) {
            cell.cellProgress.progress = currRatio;
        }];
        cell.downloadState = DOWNLOADING;
    }
}


#pragma mark notification tableview reload
- (void)notificationUIRefresh{
    [self.videoTableview reloadData];
}

#pragma mark download over save item
- (void)saveDownloadItem:(NSInteger )state withUrl:(NSString *)url withProgrees:(NSString *)progrees{
    AFDownloadItem *item = [[AFDownloadItem alloc] init];
    item.url = url;
    item.progrees = progrees;
    item.state = [NSString stringWithFormat:@"%zd",state];
    [[TMDiskCache sharedCache] setObject:item forKey:url];
}


#pragma mark zip file 
- (void)zipFileRelease:(NSString *)filePath{
    NSString *fileName = [filePath stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    [ZipManager unZip:filePath withZipToFilePath:fileName unZipSuccess:^(NSString *filePath, NSString *toFilePath) {
        
    }];
}


#pragma mark show error message
- (void)showErrorMessage:(NSError *)error{
    NSString *errorStr = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:errorStr?:@"下载失败" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [al show];
}

#pragma mark save database 
- (void)saveDatabase:(VideoModel *)model withSelected:(NSString *)selected{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObj:model.videoId?:@"" forKey:@"videoId"];
    [dic setObj:model.name?:@"" forKey:@"name"];
    [dic setObj:model.videoPath?:@"" forKey:@"videoPath"];
    [dic setObj:model.smallPath?:@"" forKey:@"smallPath"];
    [dic setObject:model.videoDuration?:@"" forKeyedSubscript:@"videoDuration"];
    [dic setObj:model.uploadTime?:@"" forKey:@"uploadTime"];
    [dic setObj:model.bigPath?:@"" forKey:@"bigPath"];
    [dic setObj:model.brandId?:@"" forKey:@"brandId"];
    [dic setObj:model.vtid?:@"" forKey:@"vtId"];
    [dic setObj:selected forKey:@"selected"];
    
    [CarVideo insertWithDic:dic];
}



#pragma mark download image 
- (void)downImage:(NSString *)url withFilePath:(NSString *)filePath withFileName:(NSString *)name{
    NSString *savePath = [filePath stringByAppendingPathComponent:name];
    
    AFDownloadRequestOperation *singleDownload;
    [[AFDownloadManager sharedDownloadManager] downloadSingleTask:singleDownload
                                                          withUrl:url
                                                     withFilePath:savePath
                                                   withUIProgress:nil
                                                  downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
                                                      
           
                                                      
                                                  } downloadError:^(AFHTTPRequestOperation *operation, NSError *error) {
                                                      
                                                  } currSpeed:^(NSString *speed) {
                                                      
                                                  }];
}
/**
 *  下载全部
 */
- (IBAction)downloadAllButtonAction:(id)sender {
    __weak __typeof(self)weakSelf = self;    
    for (int i = 0; i < _videoList.count; i++) {
        VideoModel *videoModel = [_videoList objectWithIndex:i];
        // 判断文件夹是否存在
        [[FileManager sharedManager] createDirectoryAtPath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name]];
        
        if ([[TMDiskCache sharedCache] objectForKey:videoModel.downUrl]) {
//            AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downUrl];
//            cell.cellProgress.progress = [item.progrees floatValue];
//            cell.downloadState = [item.state integerValue];
            continue;
        }
        
        
        if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl]) {
            
            
            AFHTTPRequestOperation *operationTemp = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
            
            if ([operationTemp isPaused]) {
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:videoModel.downUrl];
                [[AFDownloadManager sharedDownloadManager] resumeDownload:operation];
//                [weakSelf updateBackMainUI:videoModel withUIProgrees:cell];

            }
            continue;
        }
        
        
        AFDownloadRequestOperation *videoOperation;
        
        [[AFDownloadManager sharedDownloadManager] downloadQueueTask:[NSString stringWithFormat:@"%@%@",videoModel.name,@".mp4"]
                                                     withDownloadURL:videoModel.downUrl
                                                withDownloadSavePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name]
                                                  withUIProgressView:nil
                                          withAFHTTPRequestOperation:videoOperation
                                                     downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
        
                                                             [weakSelf saveDownloadItem:state withUrl:videoModel.downUrl withProgrees:@"1"];
                                                         NSString *isSelected;
                                                         if ([videoModel.recommend intValue] == 0) {
                                                             isSelected = [NSString stringWithFormat:@"NO"];
                                                         }else{
                                                             isSelected = [NSString stringWithFormat:@"YES"];
                                                         }
                                                         [weakSelf saveDatabase:videoModel withSelected:isSelected];
                                                         
        
                                                             [weakSelf downImage:videoModel.bigUrl withFilePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] withFileName:@"bigImage.jpg"];
        
                                                             [weakSelf downImage:videoModel.smallUrl withFilePath:[VIDEO_FILE_PATH stringByAppendingPathComponent:videoModel.name] withFileName:@"smallImage.jpg"];
        
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:VIDEO_DOWNLOAD_OVER object:weakSelf];
        
                                                      } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                             [[FileManager sharedManager] removeFileAtPath:filePath];
//                                                             cell.downloadState = NOTDOWNLOAD;
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:VIDEO_DOWNLOAD_OVER object:weakSelf];
                                                             [weakSelf showErrorMessage:error];
        
                                                      } downloadInfo:^(NSString *speedInfo ,  float ratio) {
//                                                             cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
//                                                             cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                         }];

    }
    
    [_videoTableview reloadData];
    

}
@end
