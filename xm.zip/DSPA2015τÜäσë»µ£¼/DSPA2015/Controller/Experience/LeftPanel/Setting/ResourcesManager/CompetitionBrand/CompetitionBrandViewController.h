//
//  CompetitionBrandViewController.h
//  DSPA2015
//
//  Created by runlin on 16/6/20.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ResourcesBaseTableViewController.h"

@interface CompetitionBrandViewController : ResourcesBaseTableViewController

@end
