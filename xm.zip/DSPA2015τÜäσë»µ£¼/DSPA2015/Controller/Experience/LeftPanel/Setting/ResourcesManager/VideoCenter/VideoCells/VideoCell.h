//
//  VideoCell.h
//  D-CARS
//
//  Created by gavin on 15/7/22.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellButton.h"

typedef void(^onVideoCellDownloadButtonCallBack)(id);

typedef void(^onVideoCellSelectButtonCallBack)(id);

@interface VideoCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *cellName;
@property (weak, nonatomic) IBOutlet UIProgressView *cellProgress;
@property (weak, nonatomic) IBOutlet UILabel *cellSpeed;
@property (weak, nonatomic) IBOutlet UILabel *cellRatio;
@property (weak, nonatomic) IBOutlet UIImageView *cellDownloadState;
@property (weak, nonatomic) IBOutlet UIImageView *cellVideoSelectFlag;


@property (nonatomic ) NSInteger downloadState;

- (IBAction)videoDownloadAction:(id)sender;

- (IBAction)videoDownloadOverSelectAction:(id)sender;

@property (nonatomic , copy) onVideoCellDownloadButtonCallBack videoCallDownloadCallBackButton;


@property (nonatomic , copy) onVideoCellSelectButtonCallBack videoDownloadOverSelectCallBack;

@property (weak, nonatomic) IBOutlet CellButton *cellDownloadOutlet;

@end
