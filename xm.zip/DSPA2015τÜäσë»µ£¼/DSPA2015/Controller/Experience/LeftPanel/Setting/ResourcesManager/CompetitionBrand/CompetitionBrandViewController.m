//
//  CompetitionBrandViewController.m
//  DSPA2015
//
//  Created by runlin on 16/6/20.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "CompetitionBrandViewController.h"
#import "CompetitionBrandModel.h"
#import "VideoCell.h"
#import "AFDownloadManager.h"
#import "AFDownloadItem.h"
#import "TMCache.h"
#import "UIProgressView+AFNetworking.h"
#import "UILabel+AFDownloadRequestOperation.h"
#import "ZipManager.h"

#define COMPETITIONBRAND_DOWNLOAD_OVER @"competitionBrand_download_over"

#define COMPETITIONBRAND_FINDER_NAME @"/upload/pdf/"
#define COMPETITIONBRAND_FINDER_NAME_TEMP @"/competitionBrandTEMP"

#define COMPETITIONBRAND_DOWNLOAD_FILE_PATH [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],COMPETITIONBRAND_FINDER_NAME]

#define COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP [NSString stringWithFormat:@"%@%@",[FileManager documentsPath],COMPETITIONBRAND_FINDER_NAME_TEMP]


/*
    竞品对比 pdf 下载
 */

@interface CompetitionBrandViewController ()
{
    BOOL nibsRegistered_;
    NSMutableArray *_competitionBrandList;
    
    AFHTTPRequestOperation *_videoOperation;      //创建请求管理（用于上传和下载）
    
    BOOL isNewPage;
}
@property (weak, nonatomic) IBOutlet UITableView *competitionBrandTableview;

@end

@implementation CompetitionBrandViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    isNewPage = YES;
    [[NSNotificationCenter  defaultCenter] addObserver:self  selector:@selector(notificationUIRefresh) name:COMPETITIONBRAND_DOWNLOAD_OVER object:nil];
    [[FileManager sharedManager] createDirectoryAtPath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH];
    [[FileManager sharedManager] createDirectoryAtPath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP];
    self.title = @"竞品对比PDF下载";
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    __weak typeof(self)weak = self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CompetitionBrandModel getCompetitionBrandList:nil Success:^(NSMutableArray *arrList) {
        if (arrList.count > 0) {
            _competitionBrandList = [[NSMutableArray alloc] initWithArray:arrList];
            weak.count = _competitionBrandList.count;
            [weak.competitionBrandTableview reloadData];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)backButtonTouched:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
    [[NSNotificationCenter  defaultCenter] removeObserver:self name:COMPETITIONBRAND_DOWNLOAD_OVER object:nil];
}


#pragma mark ======
#pragma mark tableview delegate ======
#pragma mark tableview data source ======
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 102;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * identifier = @"VideoCell";
    if (!nibsRegistered_) {
        UINib * nib = [UINib nibWithNibName:@"VideoCell" bundle:nil];
        [tableView registerNib:nib forCellReuseIdentifier:identifier];
        nibsRegistered_ = YES;
    }
    CompetitionBrandModel *carModel = [_competitionBrandList objectWithIndex:indexPath.row];
    VideoCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.cellName.text = [carModel.name stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    cell.cellVideoSelectFlag.hidden = YES;
    
    if ([[TMDiskCache sharedCache] objectForKey:carModel.downloadUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:carModel.downloadUrl];
        cell.cellProgress.progress = [item.progrees floatValue];
        cell.downloadState = [item.state integerValue];
    }
    
    if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downloadUrl]  && isNewPage) {
        AFHTTPRequestOperation *op = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downloadUrl];
        if (![op isPaused]) {
            [self updateBackMainUI:carModel withUIProgrees:cell];
            cell.downloadState = DOWNLOADING;
        }
    }
    
    switch (cell.downloadState) {
        case NOTDOWNLOAD:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_no"];
            cell.cellRatio.hidden = NO;
            cell.cellRatio.text = @"0";
            cell.cellSpeed.text = @"未下载";
            cell.cellProgress.hidden = NO;
            cell.cellProgress.progress = 0;
            break;
        case DOWNLOADING:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_ing"];
            break;
        case DOWNLOADPAUSE:
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_pause"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f"@"%@",cell.cellProgress.progress*100,@"%"];
            cell.cellSpeed.text = @"0";
            break;
        case DOWNLOADOVER:
        {
            cell.cellDownloadState.image = [UIImage imageNamed:@"videoDownload_state_over"];
            cell.cellRatio.hidden = YES;
            cell.cellSpeed.text = @"下载完成";
            cell.cellProgress.hidden = YES;
        }
            break;
        default:
            break;
    }
    
    [cell.cellDownloadOutlet addTarget:self action:@selector(cellDownloadAction:) forControlEvents:UIControlEventTouchDown];
    cell.cellDownloadOutlet.indexPath = indexPath;
    
    return cell;
}
#pragma mark cell button action
- (void)cellDownloadAction:(CellButton *) sender{
    VideoCell *cell = (VideoCell *)[self.competitionBrandTableview cellForRowAtIndexPath:sender.indexPath];
    __weak __typeof(self)weakSelf = self;
    
    NSIndexPath *index = [_competitionBrandTableview indexPathForCell:cell];
    CompetitionBrandModel *carModel = [_competitionBrandList objectWithIndex:index.row];
    isNewPage = NO;
    switch (cell.downloadState) {
        case NOTDOWNLOAD: // prepareing
        {
            AFDownloadRequestOperation *carShowOperation;
            
            [[AFDownloadManager sharedDownloadManager] downloadQueueTask:carModel.name
                                                         withDownloadURL:carModel.downloadUrl
                                                    withDownloadSavePath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP
                                                      withUIProgressView:cell.cellProgress
                                              withAFHTTPRequestOperation:carShowOperation
                                                         downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                             
                                                             [weakSelf saveDownloadItem:state withUrl:carModel.downloadUrl withProgrees:@"1" withMD5:carModel.brandId];
                                                             
                                                             [weakSelf zipFileRelease:operation.responseObject];
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:COMPETITIONBRAND_DOWNLOAD_OVER object:weakSelf];
                                                             
                                                         } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                             [[FileManager sharedManager] removeFileAtPath:filePath];
                                                             cell.downloadState = NOTDOWNLOAD;
                                                             [[NSNotificationCenter defaultCenter] postNotificationName:COMPETITIONBRAND_DOWNLOAD_OVER object:weakSelf];
                                                             [weakSelf showErrorMessage:error];
                                                             
                                                         } downloadInfo:^(NSString *speedInfo ,  float ratio) {
                                                             cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                             cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                         }];
            cell.downloadState = DOWNLOADING;
            [_competitionBrandTableview reloadData];
        }
            break;
            
        case DOWNLOADING:// downloading
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downloadUrl]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downloadUrl];
                [[AFDownloadManager sharedDownloadManager] pauseDownload:operation];
                cell.downloadState = DOWNLOADPAUSE;
                
                [weakSelf saveDownloadItem:DOWNLOADPAUSE withUrl:carModel.downloadUrl withProgrees:[NSString stringWithFormat:@"%f",cell.cellProgress.progress] withMD5:carModel.brandId];
            }
            [_competitionBrandTableview reloadData];
        }
            break;
            
        case DOWNLOADPAUSE: // pauseing
        {
            if ([[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downloadUrl]) {
                
                AFHTTPRequestOperation *operation = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downloadUrl];
                [[AFDownloadManager sharedDownloadManager] resumeDownload:operation];
                [weakSelf updateBackMainUI:carModel withUIProgrees:cell];
            }else{
                AFDownloadRequestOperation *operation;
                
                [[AFDownloadManager sharedDownloadManager] downloadQueueTask:carModel.name
                                                             withDownloadURL:carModel.downloadUrl
                                                        withDownloadSavePath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP
                                                          withUIProgressView:cell.cellProgress
                                                  withAFHTTPRequestOperation:operation
                                                             downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject , DownloadState state) {
                                                                 [weakSelf saveDownloadItem:state withUrl:carModel.downloadUrl withProgrees:@"1" withMD5:carModel.brandId];
                                                                 [weakSelf zipFileRelease:operation.responseObject];
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:COMPETITIONBRAND_DOWNLOAD_OVER object:weakSelf];
                                                                 
                                                             } downloadError:^(AFHTTPRequestOperation *operation, NSError *error , NSString *filePath) {
                                                                 [[FileManager sharedManager] removeFileAtPath:filePath];
                                                                 cell.downloadState = NOTDOWNLOAD;
                                                                 [[NSNotificationCenter defaultCenter] postNotificationName:COMPETITIONBRAND_DOWNLOAD_OVER object:weakSelf];
                                                                 [weakSelf showErrorMessage:error];
                                                                 
                                                             } downloadInfo:^(NSString *speedInfo , float ratio) {
                                                                 cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
                                                                 cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
                                                             }];
            }
            [[TMDiskCache sharedCache] removeObjectForKey:carModel.downloadUrl];
            cell.downloadState = DOWNLOADING;
            [_competitionBrandTableview reloadData];
        }
            break;
        case DOWNLOADOVER:
        {
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:@"资源已经下载完成" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [al show];
        }
            break;
        default:
            break;
    }
}


// edit video tableview
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    CompetitionBrandModel *videoModel = [_competitionBrandList objectWithIndex:indexPath.row];
    if ([[TMDiskCache sharedCache] objectForKey:videoModel.downloadUrl]) {
        AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:videoModel.downloadUrl];
        if ([item.state integerValue] == DOWNLOADOVER) {
            return YES;
        }
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    dispatch_queue_t concurrentQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(concurrentQueue, ^{
        dispatch_sync(concurrentQueue, ^{
            CompetitionBrandModel *carModel = [_competitionBrandList objectWithIndex:indexPath.row];
            if (editingStyle == UITableViewCellEditingStyleDelete && [[TMDiskCache sharedCache] objectForKey:carModel.downloadUrl]) {
                AFDownloadItem *item = (AFDownloadItem *)[[TMDiskCache sharedCache] objectForKey:carModel.downloadUrl];
                if ([item.state integerValue] == DOWNLOADOVER) {
                    [[TMDiskCache sharedCache] removeObjectForKey:carModel.downloadUrl];
                    NSString *fileName = [COMPETITIONBRAND_DOWNLOAD_FILE_PATH stringByAppendingPathComponent:carModel.brandId];
                    [[FileManager sharedManager] removeFileAtPath:fileName];
                    VideoCell *cell = (VideoCell *)[tableView cellForRowAtIndexPath:indexPath];
                    cell.downloadState = NOTDOWNLOAD;
                }
            }
        });
        dispatch_sync(dispatch_get_main_queue(), ^{
            [_competitionBrandTableview reloadData];
        });
    });
    
}

#pragma mark back view refresh main view
- (void)updateBackMainUI:(CompetitionBrandModel *)carModel withUIProgrees:(UITableViewCell *)tbCell{
    VideoCell *cell = (VideoCell *)tbCell;
    AFHTTPRequestOperation *op = [[AFDownloadManager sharedDownloadManager].downloadDic objectForKey:carModel.downloadUrl];
    if (![op isPaused]) {
        
        [cell.cellSpeed setUILabelWithDownloadUILabelOfOperation:(AFDownloadRequestOperation*)op downloadInfo:^(NSString *speedInfo, float ratio) {
            cell.cellSpeed.text = [NSString stringWithFormat:@"%@%@",speedInfo,@"/S"];
            cell.cellRatio.text = [NSString stringWithFormat:@"%.2f%@",ratio*100,@"%"];
            
        } currDownloadSpeed:^(float currRatio) {
            cell.cellProgress.progress = currRatio;
        }];
        cell.downloadState = DOWNLOADING;
    }
}
#pragma mark notification tableview reload
- (void)notificationUIRefresh{
    [self.competitionBrandTableview reloadData];
}

#pragma mark download over save item
- (void)saveDownloadItem:(NSInteger )state withUrl:(NSString *)url withProgrees:(NSString *)progrees withMD5:(NSString *)md5{
    AFDownloadItem *item = [[AFDownloadItem alloc] init];
    item.url = url;
    item.progrees = progrees;
    item.state = [NSString stringWithFormat:@"%zd",state];
    [[TMDiskCache sharedCache] setObject:item forKey:url];
}

#pragma mark show error message
- (void)showErrorMessage:(NSError *)error{
    NSString *errorStr = [error.userInfo objectForKey:@"NSLocalizedDescription"];
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"提示" message:errorStr delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [al show];
}

#pragma mark zip file
- (void)zipFileRelease:(NSString *)filePath{
//    NSString *fileName = [filePath stringByReplacingOccurrencesOfString:@".zip" withString:@""];
    [ZipManager unZip:filePath withZipToFilePath:COMPETITIONBRAND_DOWNLOAD_FILE_PATH_TEMP unZipSuccess:^(NSString *filePath, NSString *toFilePath) {
        [[FileManager sharedManager] moveItems:toFilePath toDir:COMPETITIONBRAND_DOWNLOAD_FILE_PATH];
    }];
}

@end
