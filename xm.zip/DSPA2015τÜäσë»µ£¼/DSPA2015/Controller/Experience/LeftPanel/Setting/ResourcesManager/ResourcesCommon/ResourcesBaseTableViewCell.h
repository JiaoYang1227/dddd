//
//  ResourcesBaseTableViewCell.h
//  D-CARS
//
//  Created by gavin on 15/7/29.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResourcesBaseTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *alertTitle;
@property (weak, nonatomic) IBOutlet UILabel *cellTitleName;
@end
