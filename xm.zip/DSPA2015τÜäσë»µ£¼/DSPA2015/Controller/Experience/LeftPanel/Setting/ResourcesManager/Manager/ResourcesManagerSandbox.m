//
//  ResourcesManagerSandbox.m
//  DSPA2015
//
//  Created by runlin on 17/2/22.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "ResourcesManagerSandbox.h"
#import "VideoModel.h"
#import "AudiConnectShow.h"
#import "CarVideo.h"


@implementation ResourcesManagerSandbox

//遍历文件夹
+ (NSArray *)getAllFileFromPath:(NSString *)path{
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *tempFileList = [[NSArray alloc] initWithArray:[fileManager contentsOfDirectoryAtPath:path error:nil]];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF != %@", @".DS_Store"];
    NSArray *results = [tempFileList filteredArrayUsingPredicate:predicate];
    
    return results;
}

+ (NSMutableArray *)getAllFileFromPath:(NSString *)path withServerData:(NSArray *)dataList{
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *tempFileList = [[NSArray alloc] initWithArray:[fileManager contentsOfDirectoryAtPath:path error:nil]];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF != %@", @".DS_Store"];
    NSArray *results = [tempFileList filteredArrayUsingPredicate:predicate];
    
    
    NSMutableArray *optionResults = [[NSMutableArray alloc] initWithArray:results];
    NSMutableArray *locaRubbishListFromServer = [[NSMutableArray alloc] init];
    
    //先找出来服务器要删除的
    //服务器要删除，本地也存在的数据  显示删除
    for (VideoModel *model in dataList) {
        if (model.deleteFlag) {
            for (NSString *locaName in results) {
                if ([locaName isEqualToString:model.name]) {
                    [locaRubbishListFromServer addObject:model];
                    [optionResults removeObject:locaName];
                }
            }
        }
    }
    
    
    //在找出来服务器没有返回，但是在本地已经存在的垃圾数据
    NSMutableArray *optionResults_loca = [[NSMutableArray alloc] initWithArray:optionResults];
    
    for (NSString *name in optionResults_loca) {
        for (VideoModel *model in dataList) {
            if ([model.name isEqualToString:name]) {
                // 不是垃圾数据，从垃圾数据源将数据删除掉
                [optionResults removeObject:name];
            }
        }
    }
    
    
    
    NSMutableArray *returnList = [[NSMutableArray alloc] init];
    
    for (NSString *name in optionResults) {
        
        VideoModel *mode = [[VideoModel alloc] init];
        mode.name = name;
        mode.downUrl = @"";
        mode.locaRubbish = YES;
        mode.videoId = [CarVideo findvideoIdWithName:name]?:@"";
        
        [returnList addObject:mode];
    }
    
    
    for (VideoModel *model in locaRubbishListFromServer) {
        [returnList addObject:model];
    }
    
    return returnList;
}

+ (NSMutableArray *)getAllFilePathFromAudiConnect:(NSString *)path withServerData:(NSArray *)dataList{
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *tempFileList = [[NSArray alloc] initWithArray:[fileManager contentsOfDirectoryAtPath:path error:nil]];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF != %@", @".DS_Store"];
    NSArray *results = [tempFileList filteredArrayUsingPredicate:predicate];
    
    
    NSMutableArray *optionResults = [[NSMutableArray alloc] initWithArray:results];
    NSMutableArray *locaRubbishListFromServer = [[NSMutableArray alloc] init];
    
    //先找出来服务器要删除的
    //服务器要删除，本地也存在的数据  显示删除
    for (AudiConnectShow *model in dataList) {
        if (model.isdelete) {
            for (NSString *locaName in results) {
                if ([locaName isEqualToString:model.filename]) {
                    [locaRubbishListFromServer addObject:model];
                    [optionResults removeObject:locaName];
                }
            }
        }
    }
    
    
    //在找出来服务器没有返回，但是在本地已经存在的垃圾数据
    NSMutableArray *optionResults_loca = [[NSMutableArray alloc] initWithArray:optionResults];
    
    for (NSString *name in optionResults_loca) {
        for (AudiConnectShow *model in dataList) {
            if ([model.filename isEqualToString:name]) {
                // 不是垃圾数据，从垃圾数据源将数据删除掉
                [optionResults removeObject:name];
            }
        }
    }
    
    
    
    NSMutableArray *returnList = [[NSMutableArray alloc] init];
    
    for (NSString *name in optionResults) {
        
        AudiConnectShow *mode = [[AudiConnectShow alloc] init];
        mode.filename = name;
        mode.downUrl = @"";
        mode.locaRubbish = YES;
        
        [returnList addObject:mode];
    }
    
    
    for (AudiConnectShow *model in locaRubbishListFromServer) {
        [returnList addObject:model];
    }
    
    return returnList;
}


@end
