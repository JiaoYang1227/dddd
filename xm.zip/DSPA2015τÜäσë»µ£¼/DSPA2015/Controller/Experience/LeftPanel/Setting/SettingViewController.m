//
//  SettingViewController.m
//  D-CARS
//
//  Created by gavin on 15/7/4.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "SettingViewController.h"
#import "ResourcesManagerViewController.h"
#import "SoftManagerViewController.h"

#define NAVHEIGHT (76-7)
#define MASTER_WIDTH 259

@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.contentNavigationController.navigationBarHidden = YES;
    
    SetingMasterViewController *master =   [[SetingMasterViewController alloc]init];
    ResourcesManagerViewController *detail =   [[ResourcesManagerViewController alloc]init];
    
    [self setMasterViewController:master];
    [self setDetailViewController:detail];

    self.topBar.layer.zPosition = 1000;
    self.title = @"设置";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
- (IBAction)backButtonTouched:(id)sender {
    [super backButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
    
}
#pragma mark -
- (void)setMasterViewController:(UIViewController *)masterViewController
{
    if (_masterViewController != masterViewController)
    {
        if (_masterViewController) {
            [_masterViewController.view removeFromSuperview];
            [_masterViewController removeFromParentViewController];
        }
        _masterViewController = masterViewController;
        _masterViewController.view.clipsToBounds = YES;
        [self.view addSubview:_masterViewController.view];
        [self addChildViewController:_masterViewController];
    }
    [self layoutView];
}


- (void)setDetailViewController:(UIViewController *)detailViewController
{
    if (_detailViewController != detailViewController)
    {
        _detailViewController = detailViewController;
        // push
        [self.contentNavigationController popToRootViewControllerAnimated:NO];
        [self.contentNavigationController pushViewController:_detailViewController animated:YES];
    }
}

-(UINavigationController *)contentNavigationController{
    if (!_contentNavigationController) {
        
        _contentNavigationController = [[UINavigationController alloc] initWithRootViewController:[[UIViewController alloc] init]];
        _contentNavigationController.navigationBarHidden = YES;
        _contentNavigationController.view.frame = CGRectMake([self screenWidth], NAVHEIGHT, [self screenWidth] - MASTER_WIDTH, [self screenHeight]-NAVHEIGHT);
//        _contentNavigationController.view.frame = self.view.bounds;
        _contentNavigationController.view.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:_contentNavigationController.view];
        [self addChildViewController:_contentNavigationController];
    }
    return _contentNavigationController;
}


-(void)layoutView{
    self.masterViewController.view.frame =  CGRectMake(0, NAVHEIGHT - 5, MASTER_WIDTH, [self screenHeight]-NAVHEIGHT);
    
    [UIView animateWithDuration:0.3 animations:^{
        self.contentNavigationController.view.frame =  CGRectMake(MASTER_WIDTH+2, NAVHEIGHT,[self screenWidth] - MASTER_WIDTH - 2, [self screenHeight]-NAVHEIGHT);
    }];
}
-(CGFloat)screenWidth{
    return 1024;
}
-(CGFloat)screenHeight{
    return 768; // 剪掉底部的距离
}

@end
