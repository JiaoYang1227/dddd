//
//  BackgroundManagerViewController.h
//  DSPA2015
//
//  Created by Jakey on 16/1/26.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface BackgroundManagerViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UILabel *notiLabel;
@property (weak, nonatomic) IBOutlet UILabel *notiTimeLabel;

@property (weak, nonatomic) IBOutlet UIButton *indicateButton;

- (IBAction)buttonTouched:(id)sender;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttons;
@end
