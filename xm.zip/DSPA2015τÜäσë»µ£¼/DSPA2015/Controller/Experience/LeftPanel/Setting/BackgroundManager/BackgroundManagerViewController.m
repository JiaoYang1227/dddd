//
//  BackgroundManagerViewController.m
//  DSPA2015
//
//  Created by Jakey on 16/1/26.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BackgroundManagerViewController.h"
#import "BackgroundRunner.h"
@interface BackgroundManagerViewController ()

@end

@implementation BackgroundManagerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSInteger tag = [[BackgroundRunner getBackgroundTime] integerValue];
    
    for (UIButton *button in self.buttons) {
        if (button.tag-2000 == tag) {
            [self selelcted:button animate:NO];
        }else{
            button.selected = NO;
        }
    }
    self.title = @"后台管理";
}

- (IBAction)buttonTouched:(UIButton*)sender {
    [self selelcted:sender animate:YES];
}
-(void)selelcted:(UIButton*)sender animate:(BOOL)animate{
    for (UIButton *button in self.buttons) {
        if (sender == button) {
            button.selected = YES;
        }else{
            button.selected = NO;
        }
    }
    if (animate) {
        [UIView animateWithDuration:0.2 animations:^{
            self.indicateButton.centerX = sender.centerX;
        } completion:^(BOOL finished) {
        }];
        
    }else{
        self.indicateButton.centerX = sender.centerX;
    }
    
    NSInteger tag = sender.tag-2000;
    [BackgroundRunner saveBackgroundTime:[NSString stringWithFormat:@"%zd",tag]];
    
    self.notiTimeLabel.text = [NSString stringWithFormat:@"DSPA后台运行或者锁屏[%zd]小时自动关闭",tag];
    if (tag==0) {
        self.notiTimeLabel.text = [NSString stringWithFormat:@"iOS系统预置,系统会根据PAD资源使用情况,一定时间后强制退出DSPA程序"];
    }
    if (tag==50) {
        self.notiTimeLabel.text = [NSString stringWithFormat:@"DSPA后台运行或者锁屏很长时间内不会主动关闭"];
    }
}
@end
