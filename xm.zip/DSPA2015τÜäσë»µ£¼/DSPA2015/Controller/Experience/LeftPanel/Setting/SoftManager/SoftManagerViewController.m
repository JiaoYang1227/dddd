//
//  SoftManagerViewController.m
//  D-CARS
//
//  Created by gavin on 15/7/21.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "SoftManagerViewController.h"
#import "AFDownloadManager.h"
#import "NSTimer+Blocks.h"
#import "JKAlert.h"
#import "MBProgressHUD.h"
#import "Validator.h"
#import "KeychainManager.h"
#import "IQUIView+IQKeyboardToolbar.h"
@interface SoftManagerViewController ()<UITextFieldDelegate>

- (IBAction)TestDownloadSpeedAction:(id)sender;

@property (nonatomic , strong) NSTimer *timer;
@property (nonatomic) NSInteger recordTimer;
@property (nonatomic , strong) AFDownloadRequestOperation *operationSingleDownload;

@property (strong, nonatomic) IBOutlet UIView *testSpeedView;
@property (weak, nonatomic) IBOutlet UIView *testSpeedFrame;
- (IBAction)closeAction:(id)sender;
@property (nonatomic ) BOOL isClose;

#pragma mark outlet 
@property (weak, nonatomic) IBOutlet UILabel *fileSize;
@property (weak, nonatomic) IBOutlet UILabel *downloadTime;
@property (weak, nonatomic) IBOutlet UILabel *avgSpeed;
@property (weak, nonatomic) IBOutlet UILabel *currSpeed;

@property (weak, nonatomic) IBOutlet UITextField *inputHttp;
@end

@implementation SoftManagerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"软件管理";
    NSString *version =  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    NSString *build =  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];

    self.versionLable.text = [NSString stringWithFormat:@"%@(%@)",version,build];
    //Adding done button for textField1
    [self.inputHttp addDoneOnKeyboardWithTarget:self action:@selector(doneAction:)];
    self.view.backgroundColor = [UIColor whiteColor];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showPlatfromTF)];
    tap.numberOfTapsRequired = 5;
    [self.view addGestureRecognizer:tap];
    NSString *url = [SSKeychain passwordForService:@"DSPA_PLATFORM" account:@"DSPA2015-PLATFORM_IP"];
    self.platformTF.text = url;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.inputHttp.text = [AppDelegate APP].ServerIP;
    self.isClose = NO;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.timer invalidate];
}
-(BOOL)checkInput:(UITextField*)textField{
    NSString *strUrl;
    
    
    if ([textField.text hasPrefix:@"http"] || [textField.text hasPrefix:@"https://"]) {
        strUrl = textField.text;
    }else{
        strUrl = [NSString stringWithFormat:@"%@%@",@"http://",textField.text];
        
    }
    
    if ([textField.text isEqualToString:@""] || [textField.text isEqualToString:@"http://"]) {
        // 设置新的ip地址http://
        [self resetNewURL:@"http://"];
        return YES;
    }
    
    if ([Validator isUrl:strUrl]) {
        // 设置新的ip地址
        [self resetNewURL:strUrl];
        return YES;
    }else{
        [self resetNewURL:@"http://"];
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"输入正确的网址"];
        [alert addButtonWithTitle:@"ok"];
        [alert show];
    }
    
    return NO;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if (textField == _inputHttp) {
        BOOL result = [self checkInput:textField];
        if (result) {
            [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
        }
        return result;
    } else {
        [SSKeychain setPassword:textField.text forService:@"DSPA_PLATFORM" account:@"DSPA2015-PLATFORM_IP"];
        [AppDelegate APP].platformServerIP = textField.text;
        return YES;
    }
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == _platformTF) {
        [SSKeychain setPassword:textField.text forService:@"DSPA_PLATFORM" account:@"DSPA2015-PLATFORM_IP"];
        [AppDelegate APP].platformServerIP = textField.text;
    }
}

- (void)showPlatfromTF
{
    self.platformTF.hidden = !self.platformTF.hidden;
}
#pragma mark textfiled
//- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
//    return [self checkInput:textField];
//}
- (BOOL)textFieldShouldClear:(UITextField *)textField{
    [KeychainManager deleteBaseURL];
    textField.text = @"http://";
    return NO;
}
/*!iqkeyborad doneAction. */
-(void)doneAction:(UIBarButtonItem*)barButton
{
    BOOL result = [self checkInput:self.inputHttp];
    if (result) {
        [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
    }
}
//存储url
-(void)resetNewURL:(NSString*)url{
    //如果登陆状态注销登陆
//    __weak typeof(self) weakSelf = self;
//    if([AppDelegate APP].user){
//        [User OutLogin:nil Success:^(NSDictionary *dic, id responseObject) {
//            [AppDelegate APP].user = nil;
//            [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
//            [weakSelf saveNewURL:url];
//        } Failure:^(NSError *error) {
//            [weakSelf saveNewURL:url];
//        }];
//    }else{
//        [self saveNewURL:url];
//    }
    
    [self saveNewURL:url];

}
-(void)saveNewURL:(NSString*)url
{
    [KeychainManager saveSetBaseURL:url];
    [AppDelegate APP].ServerIP = nil;
    [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    self.inputHttp.text = [AppDelegate APP].ServerIP;
    [APIManager cancelAllOperations:nil];
    [APIManager reset];
    
}
#pragma mark test speed action
- (IBAction)TestDownloadSpeedAction:(id)sender {
    
    
    if ([self.inputHttp.text isEqualToString:@""]) {
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"输入正确的网址" ];
        [alert addButtonWithTitle:@"ok"];
        [alert show];
        return;
    }

    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 block:^{
        self.recordTimer = self.recordTimer + 1;
    } repeats:YES];
    
//    NSString *url = @"http://dl_dir2.qq.com/invc/xfspeed/qdesk/versetup/QDeskSetup_25_1277.exe";
    NSString *url = [NSString stringWithFormat:@"%@%@",[KeychainManager getBaseURL],@"/dspa_crmserver/testNetworkSpeedFile.zip"];
    NSString *filePath = [self dirDoc:@"testSpeed.zip"];
    
    __weak __typeof(self)weakSelf = self;
    
    self.testSpeedView.frame = self.testSpeedFrame.frame;
    self.currSpeed.text = @"0";
    self.isClose = NO;

    [self.view addSubview:self.testSpeedView];
    
    //多次点击取消之前的
    if (_operationSingleDownload) {
        [_operationSingleDownload cancel];
    }
    [[AFDownloadManager sharedDownloadManager] downloadSingleTask:_operationSingleDownload
                                                          withUrl:url
                                                     withFilePath:filePath
                                                   withUIProgress:nil
                                                  downloadSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
                                                      __strong __typeof(weakSelf)strongSelf = weakSelf;
                                                      
                                                      [strongSelf.timer invalidate];
                                                      
                                                      strongSelf.downloadTime.text = [NSString stringWithFormat:@"%zd%@",strongSelf.recordTimer,@" S"];
                                                      
                                                      strongSelf.fileSize.text =[NSString stringWithFormat:@"%lld%@", [strongSelf fileSizeAtPath:filePath],@" B"];

                                                      double avg = [strongSelf fileSizeAtPath:filePath] / 1000.0 / 1000.0 / strongSelf.recordTimer;
                                                      
                                                      strongSelf.avgSpeed.text = [NSString stringWithFormat:@"%f%@",avg,@" M/S"];

                                                      [strongSelf deleteFile:@"testSpeed.zip"];
                                                      
                                                  } downloadError:^(AFHTTPRequestOperation *operation, NSError *error) {
                                                      if (weakSelf.isClose) {
                                                          weakSelf.isClose = NO;
                                                          return;
                                                      }
                                                      JKAlert *alert = [JKAlert alertWithTitle:@"下载失败" andMessage:[weakSelf getErrorDescription:operation error:error]];
                                                      
                                                      [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
                                                          
                                                      }];
                                                      [alert show];
                                                      [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
                                                      
                                                  } currSpeed:^(NSString *speed) {
                                                      weakSelf.currSpeed.text = [NSString stringWithFormat:@"%@%@",speed,@"/S"];
                                                  }];

}
/**
 *  @author Jakey, 15-12-07 12:12:50
 *
 *  @brief  下载失败后 弹出错误信息用于调试
 *
 *  @param operation <#operation description#>
 *  @param error     <#error description#>
 *
 *  @return <#return value description#>
 */
-(NSString*)getErrorDescription:(AFHTTPRequestOperation *)operation  error:(NSError *)error{
    NSLog(@"error debugDescription:%@",[error debugDescription]);
    NSString *errorMessage = [NSString stringWithFormat:@"%zd",error.code];
    NSDictionary *errorDic = operation.responseObject;
    NSString * webCode = [errorDic stringForKey:@"status"];
    if (webCode) {
        errorMessage = [@"A" stringByAppendingString:webCode];
        NSLog(@"web api error:%@",[errorDic description]);
    }else if(operation.response){
        //如果后台出错没有返回数据 拼接上S代表服务器异常
        errorMessage = [@"S" stringByAppendingString:[NSString stringWithFormat:@"%zd",operation.response.statusCode]];
    }
    //如果以上都没有错误 提示网络异常信息
    return  [NSString stringWithFormat:@"%@(%@)",error.localizedDescription?:@"",errorMessage];
}
#pragma mark file
- (NSString *)dirDoc:(NSString *)name{
    NSString *str = [NSString stringWithFormat:@"%@%@",@"%@/Documents/",name];
    NSString *filePath = [NSString stringWithFormat:str, NSHomeDirectory()];
    return filePath;
}

- (long long) fileSizeAtPath:(NSString*) filePath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]){
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
    }
    return 0;
}

-(void)deleteFile:(NSString *)fileName{
    NSFileManager* fileManager=[NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    //文件名
    NSString *uniquePath=[[paths objectWithIndex:0] stringByAppendingPathComponent:fileName];
    BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:uniquePath];
    if (!blHave) {
        NSLog(@"no  have");
        return ;
    }else {
        NSLog(@" have");
        BOOL blDele= [fileManager removeItemAtPath:uniquePath error:nil];
        if (blDele) {
            NSLog(@"dele success");
        }else {
            NSLog(@"dele fail");
        }
    }
}

// 关闭视图
- (IBAction)closeAction:(id)sender {
    self.isClose = YES;
    [self.testSpeedView removeFromSuperview];
    [[AFDownloadManager sharedDownloadManager] cancelSingTask];
}
@end
