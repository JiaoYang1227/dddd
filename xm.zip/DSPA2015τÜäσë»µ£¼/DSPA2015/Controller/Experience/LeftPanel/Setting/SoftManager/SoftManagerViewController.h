//
//  SoftManagerViewController.h
//  D-CARS
//
//  Created by gavin on 15/7/21.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface SoftManagerViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UILabel *versionLable;
@property (weak, nonatomic) IBOutlet UITextField *platformTF;
@end
