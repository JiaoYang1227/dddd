//
//  SettingViewController.h
//  D-CARS
//
//  Created by gavin on 15/7/4.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "SetingDetailViewController.h"
#import "SetingMasterViewController.h"

@interface SettingViewController : BaseViewController

- (IBAction)backButtonTouched:(id)sender;

@property(nonatomic , strong) UINavigationController *contentNavigationController;

/**
 *  获取master
 */
@property (strong, nonatomic) UIViewController *masterViewController;
/**
 *  获取Detail
 */
@property (strong, nonatomic) UIViewController *detailViewController;

@property (weak, nonatomic) IBOutlet UIView *topBar;
@end
