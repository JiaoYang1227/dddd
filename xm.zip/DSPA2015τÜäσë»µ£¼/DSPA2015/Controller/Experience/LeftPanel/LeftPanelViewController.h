//
//  LeftPanelViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftPanelRootViewController.h"

@interface LeftPanelViewController : UIViewController
@property (nonatomic, strong) UINavigationController *contentNavigationController;
@property (nonatomic, strong) LeftPanelRootViewController *leftPanelRootViewController;


- (void)pushViewController:(UIViewController *)viewController
                  animated:(BOOL)animated;

- (UIViewController *)popViewControllerAnimated:(BOOL)animated;
- (void)replaceViewController:(UIViewController *)viewController animated:(BOOL)animated;
@end
