//
//  OfflineClientDetailViewController.m
//  DSPA2015
//
//  Created by sun on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "OfflineClientDetailViewController.h"
#import "NSString+UUID.h"
#import "SalesLeadEditViewController.h"
#import "UIViewController+DSPAPopup.h"
@interface OfflineClientDetailViewController ()

@end

@implementation OfflineClientDetailViewController
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [_dbQueue close];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.editClient) {
        self.titleLable.text = @"编辑集客信息";
    }else{
        self.titleLable.text = @"添加集客信息";
    }
    [self.scrollView setContentSize:CGSizeMake(840, 640)];
    _item = [NSMutableDictionary dictionary];
    _dbQueue  = [DBManagerQueue managerForDSPA_Offline];
    NSString *path = [FileManager documentsPath:@"Offline/OfflineClient.json"];
    _offlineDic = [FileManager loadJSON:path];
    if(!_offlineDic){
        [JKAlert showMessage:@"字典数据为空，请到【设置】-【资源管理】中同步店外集客字典"];
    }
    [self.view setBackgroundColor:[UIColor whiteColor]];
    if (self.editClient) {
        [self bringTheData];
    }
    [_bInfoStatus didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
        if (on == YES) {
            [self.unInfoReasonButton reset];
            [self.unInfoReasionIcon setHidden:YES];
            [self.CustNameICON setHidden:NO];
        }else{
            [self.unInfoReasionIcon setHidden:NO];
            [self.CustNameICON setHidden:YES];
        }
        
    }];
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
-(void)bringTheData{
    self.createdByButton.value = self.editClient.createdBy?:@"";
    self.createdByButton.key = self.editClient.createdByCode?:@"";
    self.mobileTextField.text = self.editClient.mobile?:@"";
    self.collectCustNameTextField.text = self.editClient.collectCustName?:@"";
    self.mobileTextField.text = self.editClient.mobile?:@"";
    self.otherPhoneTextField.text =self.editClient.otherPhone ?:@"";
    self.brandButton.value =self.editClient.brand ?:@"";
    self.brandButton.key =self.editClient.brandCode ?:@"";
    self.collectFromButton.value = self.editClient.collectFrom?:@"";
    self.collectFromButton.key =self.editClient.collectFromCode ?:@"";
    self.modelButton.value = self.editClient.model?:@"";
    self.modelButton.key = self.editClient.modelCode?:@"";
    self.unInfoReasonButton.value =self.editClient.unInfoReason ?:@"";
    self.unInfoReasonButton.key =self.editClient.unInfoReasonCode ?:@"";
    self.infoFromButton.value = self.editClient.infoFrom?:@"";
    self.infoFromButton.key = self.editClient.infoFromCode?:@"";
    self.licensePropButton.value =self.editClient.licenseProp ?:@"";
    self.licensePropButton.key = self.editClient.licensePropCode?:@"";
    self.accomCountTextField.text = self.editClient.accomCount?:@"";
    self.accomRelationButton.value = self.editClient.accomRelation?:@"";
    self.accomRelationButton.key = self.editClient.accomRelaCode?:@"";
    self.purchaseExpeButton.value = self.editClient.purchaseExpe?:@"";
    self.purchaseExpeButton.key = self.editClient.purchaseExpeCode?:@"";
     self.comment.text =self.editClient.comment?:@"";
//    self.isFirst.on = [self.editClient.isFirst boolValue];
    self.bInfoStatus.on = [self.editClient.bInfoStatus boolValue];
    self.brandassoButton.key = self.editClient.sbrandassoCode?:@"";
    self.brandassoButton.value = self.editClient.sbrandasso?:@"";
    
    
    self.vInfoFromButtonOutlet.key = self.editClient.vInfoFromCode;
    self.vInfoFromButtonOutlet.value = self.editClient.vInfoFrom;
    
    self.vCusFromVWButtonOutlet.key = self.editClient.vCusFromVWCode;
    self.vCusFromVWButtonOutlet.value = self.editClient.vCusFromVW;
    
    self.vCusFromButtonOutlet.key = self.editClient.vCusFromCode;
    self.vCusFromButtonOutlet.value = self.editClient.vCusFrom;
    
    
    
    if ([self.editClient.sbrandassoCode isEqual:@""]) {
        [_brandassoIcon setHidden:YES];
    }else{
        [_brandassoIcon setHidden:NO];
    }
    if ([self.editClient.bInfoStatus boolValue] == YES) {
        [_brandassoIcon setHidden:YES];
        [self.unInfoReasionIcon setHidden:YES];
        [self.CustNameICON setHidden:NO];
    }else{
        [self.unInfoReasionIcon setHidden:NO];
        [_brandassoIcon setHidden:NO];
        [self.CustNameICON setHidden:YES];
    }
}
- (IBAction)onclickSubmit:(id)sender {
    if ([self checkFormData]) {
        [JKAlert showMessage:[self checkFormData]];
        return;
    }
    if(self.editClient){
        self.oneClient = self.editClient;
    }else{
        self.oneClient = [[OfflineClient alloc]init];
    }
    self.oneClient.createdBy = self.createdByButton.value?:@"";
    self.oneClient.createdByCode = self.createdByButton.key?:@"";
    self.oneClient.mobile = self.mobileTextField.text?:@"";
    self.oneClient.collectCustName = self.collectCustNameTextField.text?:@"";
    self.oneClient.mobile = self.mobileTextField.text?:@"";

    
    
    self.oneClient.otherPhone = self.otherPhoneTextField.text?:@"";
    self.oneClient.brand = self.brandButton.value?:@"";
    self.oneClient.brandCode = self.brandButton.key?:@"";
    self.oneClient.collectFrom = self.collectFromButton.value?:@"";
    self.oneClient.collectFromCode = self.collectFromButton.key?:@"";
    self.oneClient.model = self.modelButton.value?:@"";
    self.oneClient.modelCode = self.modelButton.key?:@"";
    self.oneClient.unInfoReason = self.unInfoReasonButton.value?:@"";
    self.oneClient.unInfoReasonCode = self.unInfoReasonButton.key?:@"";
    self.oneClient.infoFrom = self.infoFromButton.value?:@"";
    self.oneClient.infoFromCode = self.infoFromButton.key?:@"";
    self.oneClient.licenseProp = self.licensePropButton.value?:@"";
    self.oneClient.licensePropCode = self.licensePropButton.key?:@"";
    self.oneClient.accomCount = self.accomCountTextField.text?:@"";
    self.oneClient.accomRelation = self.accomRelationButton.value?:@"";
    self.oneClient.accomRelaCode = self.accomRelationButton.key?:@"";
    self.oneClient.purchaseExpe = self.purchaseExpeButton.value?:@"";
    self.oneClient.purchaseExpeCode = self.purchaseExpeButton.key?:@"";
    self.oneClient.comment = self.comment.text?:@"";
//    self.oneClient.isFirst = [NSNumber numberWithBool:self.isFirst.on];
    self.oneClient.bInfoStatus = [NSNumber numberWithBool:self.bInfoStatus.on];
    self.oneClient.sbrandassoCode = self.brandassoButton.key?:@"";
    self.oneClient.sbrandasso = self.brandassoButton.value?:@"";
//    [self.editCustomerReception.isFirst boolValue];
    
    
    self.oneClient.vInfoFromCode = self.vInfoFromButtonOutlet.key;
    self.oneClient.vInfoFrom = self.vInfoFromButtonOutlet.value;
    
    self.oneClient.vCusFromVWCode = self.vCusFromVWButtonOutlet.key;
    self.oneClient.vCusFromVW = self.vCusFromVWButtonOutlet.value;
    
    self.oneClient.vCusFromCode = self.vCusFromButtonOutlet.key;
    self.oneClient.vCusFrom = self.vCusFromButtonOutlet.value;
    self.oneClient.vComeType = @"01";
    

    //新建的默认值
    if(!self.editClient){
        _oneClient.isSync = @"0";
        _oneClient.ID = [NSString UUID];
        _oneClient.collectDate = [DateManager timeStampStringWithDate:[NSDate date]];
    }
    
    NSLog(@"self.item:%@",[self.oneClient description]);
    if (_oneClient) {
        BOOL resut = [OfflineClient insert:_dbQueue WithArray:@[_oneClient]];
        if (resut) {
//            if (self.oneClient.uCarShowID && self.oneClient.carShowText) {
//                [self saveNewCarShow:@{@"key":self.oneClient.uCarShowID,@"value":self.oneClient.carShowText}];
//            }
            [self dismiss];
            [_delegate  loadDataOfflineClient];
        }else{
            [JKAlert showMessage:@"保存失败"];
        }
    }
}
//手动更新字典表
-(BOOL)saveNewCarShow:(NSDictionary*)itemNew{
    NSString *path = [FileManager documentsPath:@"Offline/OfflineClient.json"];
    NSMutableDictionary *oldDic = [[FileManager loadJSON:path] mutableCopy];
    NSMutableArray *oldArray =   [[oldDic arrayForKey:@"dicCarShowDict"] mutableCopy]?:[NSMutableArray array];
    
    BOOL have = NO;
    for (NSDictionary *dic in oldArray) {
        if ([[itemNew stringForKey:@"key"] isEqualToString:[dic stringForKey:@"key"]]) {
            have = YES;
        }
    }
    if (!have) {
        [oldArray addObject:itemNew];
        [oldDic setObject:oldArray forKey:@"dicCarShowDict"];
        if([FileManager writeToJSON:oldDic path:[FileManager documentsPath:@"Offline/OfflineClient.json"]]){
            NSLog(@"同步离线集客字典表成功");
        }
        return YES;
    }
    return NO;
}
- (IBAction)onclickCreatedBy:(SelectButton *)sender {//所属销售顾问
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicEmployee"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}
- (IBAction)oclickCollectFrom:(SelectButton *)sender {// 集客方式
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicCollectWay"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}
- (IBAction)onclickBrand:(SelectButton *)sender {// 关注车系
    //BUG #36967::【销售视图】【离线集客】，新建界面无法选择相关车系。  后台返回的是 dicBrand
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicBrand"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
        [self.brandassoButton reset];
        [self.modelButton reset];
        NSDictionary *dicCity = [_offlineDic objectForKey:@"brandasso"];
        NSArray *brandasso = [dicCity arrayForKey:self.brandButton.key];
        if (brandasso.count > 0) {
            [_brandassoIcon setHidden:NO];
        }else{
            [_brandassoIcon setHidden:YES];
        }
        
    }];
}
- (IBAction)onclickModel:(SelectButton *)sender {// 关注车型
    if (!self.brandButton.key) {
        [JKAlert showMessage:@"请先选择车系"];
        return;
    }
    NSArray *dicCity = [_offlineDic arrayForKey:self.brandButton.key];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}
- (IBAction)onclickBrandasso:(SelectButton *)sender {//车系子码
    if (!self.brandButton.key) {
        [JKAlert showMessage:@"请先选择车系"];
        return;
    }
    NSDictionary *dicCity = [_offlineDic objectForKey:@"brandasso"];
    NSArray *brandasso = [dicCity arrayForKey:self.brandButton.key];
    [self showCommonSearchSelect:sender withData:brandasso callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}
- (IBAction)onclickUnInfoReason:(SelectButton *)sender {// 未留档原因
    if (self.bInfoStatus.on == YES) {
        [JKAlert showMessage:@"留档没有未留档原因！"];
        return;
    }
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicUnprofileReason"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}
- (IBAction)onclickInfoFrom:(SelectButton *)sender {// 信息来源
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicInfoFrom"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        [_vInfoFromButtonOutlet reset];
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}


- (IBAction)onclickVInfoFrom:(SelectButton *)sender {// 信息来源二级
    
    if (!self.infoFromButton.key) {
        [JKAlert showMessage:@"请先选择信息来源"];
        return;
    }
    
    NSDictionary *dicInfoFrom2 = [_offlineDic dictionaryForKey:@"dicInfoFrom2"];
    NSArray *dicCity = [dicInfoFrom2 arrayForKey:self.infoFromButton.key];
    
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}

- (IBAction)onclickVCusFromVW:(SelectButton *)sender {// 首次接触途径
    NSArray *dicCity = [_offlineDic arrayForKey:@"vCusFromVW"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}

- (IBAction)onclickVCusFrom:(SelectButton *)sender {// 首次接触途径二级
    if (!self.vCusFromVWButtonOutlet.key) {
        [JKAlert showMessage:@"请先选择客户来源"];
        return;
    }
    NSDictionary *vCusFromVW2 = [_offlineDic dictionaryForKey:@"vCusFromVW2"];

    NSArray *dicCity = [vCusFromVW2 arrayForKey:self.vCusFromVWButtonOutlet.key];
    
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}







- (IBAction)onclickLicenseProp:(SelectButton *)sender {// 牌照属性
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicPZH"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}

- (IBAction)onclickAccomRelation:(SelectButton *)sender {// 同行人关系
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicAccomRela"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}
- (IBAction)onclickPurchaseExpe:(SelectButton *)sender {// 购车经验
    NSArray *dicCity = [_offlineDic arrayForKey:@"dicPurchaseExpe"];
    [self showCommonSearchSelect:sender withData:dicCity callBack:^(id item, NSString *key, NSString *value) {
        sender.obj = item;
        sender.key = key;
        sender.value = value;
    }];
}
-(void)showCommonSearchSelect:(SelectButton*)sender withData:(NSArray*)array callBack:(void (^)(id item, NSString *key, NSString *value))callBack{
    _searchControl = [[PopoverSearchController alloc]initWithSender:sender andItems:array];
    [_searchControl reverseIndexWithKey:sender.key];
    [_searchControl didSelectSearchItem:^(id item, NSString *key, NSString *value) {
        if (callBack) {
            callBack(item,key,value);
        }
    }];
    [self presentViewController:_searchControl animated:YES completion:nil];
}
-(NSString*)checkFormData{
    if (![self.createdByButton hasText]) {
        return @"销售代表不能为空，请输入";
    }
    
    if (self.bInfoStatus.on == YES) {//留档客户姓名是必填字段，手机号必须填一个
        if (![self.collectCustNameTextField hasText]) {
            return @"请输入客户姓名";
        }
        if (self.mobileTextField.text.length==0&&self.otherPhoneTextField.text.length==0) {
            return @"请输入客户手机号或客户其他手机号！";
        }
    }
    
    
//    if (self.collectCustNameTextField.text.length>25) {
//        return @"客户姓名不能超过25个字符";
//    }
//    if (self.collectCustNameTextField.text.length > 25) {
//        return @"客户姓名过长";
//    }
    if (self.mobileTextField.text.length>0) {
        if (![Validator isMobile:self.mobileTextField.text]) {
            return @"客户手机号输入有误！";
        }
    }
    if (self.otherPhoneTextField.text.length>0) {
        if (![Validator isMobile:self.otherPhoneTextField.text]) {
            return @"客户其他手机号输入有误！";
        }
    }
    
    if (![self.collectFromButton hasText]) {
        return @"集客方式不能为空，请输入";
    }
    
    if (![self.brandButton hasText]) {
        return @"关注车系不能为空，请输入";
    }
    if (![self.modelButton hasText]) {
        return @"关注车型不能为空，请输入";
    }
    if (![self.vCusFromVWButtonOutlet hasText]) {
        return @"客户来源不能为空，请输入";
    }
    if (![self.vCusFromButtonOutlet hasText]) {
        return @"客户来源2级不能为空，请输入";
    }
    if (![self.infoFromButton hasText]) {
        return @"信息来源不能为空，请输入";
    }
    if (![self.vInfoFromButtonOutlet hasText]) {
        return @"信息来源2级不能为空，请输入";
    }
    NSDictionary *dicCity = [_offlineDic objectForKey:@"brandasso"];
    NSArray *brandasso = [dicCity arrayForKey:self.brandButton.key];
    if (brandasso.count>0&&![self.brandassoButton hasText]) {
        return @"车系子码不能为空，请输入";
    }
    if (self.bInfoStatus.on == NO&&![_unInfoReasonButton hasText]) {
        return @"未留档客户请选择未留档原因";
    }
//    if (self.comment.text.length>100) {
//        return @"备注不能超过100个字符";
//    }
//    accomCountTextField
    return nil;
}

- (IBAction)onclickBack:(id)sender {
    [self dismiss];
}

-(void)dismiss{
   [self dismissDSPAPopup:^{
       
   }];
}
-(void)handleTap:(UITapGestureRecognizer*)tapRecognizer{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark textField &textView
- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    //同行人数
    if(textField ==_accomCountTextField){
        _accomCountTextField.limit = 3;
        int a = [textField.text intValue];
        if (![Validator isNumber:textField.text decimalLimit:0]) {
            [JKAlert showMessage:@"同行人数为纯数字"];
            return;
        }
        if (a > 100){
            [JKAlert showMessage:@"同行人数不可以大于100"];
        }
    }
//    if(textField ==_collectCustNameTextField){
//        if (_collectCustNameTextField.text.length>=25) {
//            [JKAlert showMessage:@"客户姓名不能超过25个字符"];
//            return;
//        }
//    }
//    if (textField == _comment) {
//        if (self.comment.text.length >= 100) {
//            [JKAlert showMessage:@"备注不能超过100个字符"];
//            return;
//        }
//    }
    
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
//    NSMutableString *muString = [[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"%@",textField.text?:@""]];
//    [muString replaceCharactersInRange:range withString:string];
    // 删除回退的时候返回yes
    if (string.length == 0 && range.length == 1) {
        return YES;
    }
    
    //手机号
    if(textField ==_mobileTextField){
        _mobileTextField.limit = 11;
    }
    //其他号
    if(textField == _otherPhoneTextField){
        _otherPhoneTextField.limit = 20;
        
    }
    //同行人数
    if(textField == _accomCountTextField){
        _accomCountTextField.limit = 99;
        
    }
    //客户名称
    if(textField == _collectCustNameTextField){
        _collectCustNameTextField.limit = 25;
        
    }
     return YES;
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    //    NSMutableString *muString = [[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"%@",textView.text?:@""]];
    //    [muString replaceCharactersInRange:range withString:text];
    // 删除回退的时候返回yes
    if (text.length == 0 && range.length == 1) {
        return YES;
    }
    //备注
    if(textView ==_comment){
        _comment.limit = 100;
    }
    return YES;
}
@end
