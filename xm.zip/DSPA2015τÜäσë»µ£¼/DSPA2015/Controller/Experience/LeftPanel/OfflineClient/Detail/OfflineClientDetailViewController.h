//
//  OfflineClientDetailViewController.h
//  DSPA2015
//
//  Created by sun on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseDetailViewController.h"
#import "OfflineClient.h"
@protocol  OfflineClientDetailDelegate<NSObject>
@optional
-(void)loadDataOfflineClient;
@end
@interface OfflineClientDetailViewController : BaseDetailViewController{
    PopoverSearchController *_searchControl;
    NSMutableDictionary *_item;
    NSDictionary *_offlineDic;
}
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property(nonatomic,weak)id<OfflineClientDetailDelegate>delegate;
@property (weak, nonatomic) IBOutlet UILabel *CustNameICON;
@property (strong, nonatomic)OfflineClient *oneClient;
@property (strong, nonatomic)OfflineClient *editClient;
@property (strong, nonatomic)  DBManagerQueue *dbQueue;
@property (weak, nonatomic) IBOutlet SelectButton *createdByButton;//所属销售顾问
@property (weak, nonatomic) IBOutlet BorderTextField *collectCustNameTextField;// 接待集客客户名称
@property (weak, nonatomic) IBOutlet BorderTextField *mobileTextField;// 手机号码
@property (weak, nonatomic) IBOutlet BorderTextField *otherPhoneTextField;//其他人手机号
@property (weak, nonatomic) IBOutlet SelectButton *collectFromButton;// 集客方式
@property (weak, nonatomic) IBOutlet SelectButton *brandButton;// 关注车系
@property (weak, nonatomic) IBOutlet SelectButton *modelButton;// 关注车型
@property (weak, nonatomic) IBOutlet SelectButton *unInfoReasonButton;// 未留档原因
@property (weak, nonatomic) IBOutlet UILabel *unInfoReasionIcon;
@property (weak, nonatomic) IBOutlet SelectButton *infoFromButton;// 信息来源
@property (weak, nonatomic) IBOutlet SelectButton *licensePropButton;// 牌照属性
@property (weak, nonatomic) IBOutlet BorderTextField *accomCountTextField;// 同行人数
@property (weak, nonatomic) IBOutlet SelectButton *accomRelationButton;// 同行人关系
@property (weak, nonatomic) IBOutlet SelectButton *purchaseExpeButton;// 购车经验

@property (weak, nonatomic) IBOutlet BorderTextView *comment;///客户接待备注
@property (weak, nonatomic) IBOutlet SwitchView *isFirst;// 是否首次
@property (weak, nonatomic) IBOutlet SwitchView *bInfoStatus;// 留档状态
@property (weak, nonatomic) IBOutlet SelectButton *brandassoButton;//车系子码
@property (weak, nonatomic) IBOutlet UILabel *brandassoIcon;



@property (weak, nonatomic) IBOutlet SelectButton *vInfoFromButtonOutlet;// 信息来源二级
@property (weak, nonatomic) IBOutlet SelectButton *vCusFromVWButtonOutlet;// ：首次接触途径
@property (weak, nonatomic) IBOutlet SelectButton *vCusFromButtonOutlet;//：首次接触途径二级




@end
