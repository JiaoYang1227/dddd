//
//  OfflineClientViewController.h
//  DSPA2015
//
//  Created by sun on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//


#import "FooterMenu.h"
#import "BaseViewController.h"
@interface OfflineClientViewController : BaseViewController<JKSearchBarDelegate>
{
    NSMutableArray *_dataList; 
    DBManagerQueue *_dbQueue;
    NSInteger _currentPage;
    BOOL _reachability;
}
@property(strong,nonatomic)  UIView *coverView;
@property (weak, nonatomic) IBOutlet JKSearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@end
