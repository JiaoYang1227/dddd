//
//  OfflineClientViewController.m
//  DSPA2015
//
//  Created by sun on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "OfflineClientViewController.h"
#import "OfflineLoginViewController.h"
#import "UIViewController+MJPopupViewController.h"
#import "OfflineClientDetailViewController.h"
#import "ServiceReceptionCell.h"
#import "UIViewController+DSPAPopup.h"
@interface OfflineClientViewController ()<OfflineClientDetailDelegate>

@end

@implementation OfflineClientViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"离线集客";

    _dbQueue  = [DBManagerQueue managerForDSPA_Offline];
    [OfflineClient createOfflineClientTable];
    _reachability = YES;
    _currentPage = 1;
    _dataList = [[NSMutableArray alloc]init];
    _dbQueue  = [DBManagerQueue managerForDSPA_Offline];
    NSString *path = [FileManager documentsPath:@"Offline/OfflineClient.json"];
    NSDictionary *offlineDic = [FileManager loadJSON:path];
    self.searchBar.iconAlign = JKSearchBarIconAlignCenter;
    if(!offlineDic){
        [JKAlert showMessage:@"字典数据为空，请到【设置】-【资源管理】中同步店外集客字典"];
    }
//    [self loadOfflineData:nil startNum:0];
    //    [self buildFooterMenu];
//    self.avasterButton.layer.cornerRadius = self.avasterButton.width/2;
//    self.avasterButton.clipsToBounds = YES;
    
    self.searchBar.placeholder = @"客户姓名、手机";
    [self.searchBar setDelegate:self];
    [self.searchBar setBackgroundColor:[UIColor clearColor]];

}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [_dataList removeAllObjects];
    [self loadOfflineData:nil startNum:0];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];    
    [_dbQueue close];
}
-(void)loadOfflineData:(NSString*)keyword startNum:(NSUInteger)startNum{
    [_dataList removeAllObjects];
    NSArray *data = [OfflineClient getLocalClients:_dbQueue keyword:keyword startNum:startNum RecordType:0];
    [_dataList addObjectsFromArray:data];
    [self.collectionView reloadData];
}
- (IBAction)onclickSyncOfflineData:(id)sender {
    [self switchUser];
}
- (IBAction)backHomeButtonTouched:(id)sender{
    [super backHomeButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
}
//数据同步
-(void)SyncOfflineDataWithCreatedByCode:(NSString *)CreatedByCode{
    NSDictionary *list =  [OfflineClient getLocalOfflineClients:_dbQueue CreatedByCode:CreatedByCode];
    if (!list || ([[list allKeys] count]<=0)) {
        [JKAlert showMessage:@"该销售顾问下没有需要同步的数据!"];
        return;
    }
    [OfflineClient gatherSync:list Success:^(NSDictionary *collection) {
        if([collection boolForKey:@"success"]){
            NSArray *uuids = [list objectForKey:@"ID"];
            [OfflineClient updateUUIDS:_dbQueue WithArray:uuids];
            [_dataList removeAllObjects];
            [self loadOfflineData:nil startNum:0];
        }
        
    } Failure:^(NSError *error) {
        
    }];
    NSLog(@"list:%@",[list JSONStringValue]);
}
//切换账户
- (void)switchUser{
    OfflineLoginViewController *login = [[OfflineLoginViewController alloc]init];
    [self presentPopupViewController:login animationType:MJPopupViewAnimationSlideBottomTop backgroundTouch:YES dismissed:^{
        if ([AppDelegate APP].createdByCode) {
            if([OfflineClient countOfLocalClients:_dbQueue RecordType:OfflineRecordTypeOffile]>0){
                JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"确定同步未转化数据吗？"];
                [alert addCancleButtonWithTitle:@"取消" handler:^(JKAlertItem *item) {
                    
                }];
                [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
                    [self SyncOfflineDataWithCreatedByCode:[AppDelegate APP].createdByCode];
                }];
                [alert show];
            }
        }
        
//        NSLog(@"%@",login.MYUser);
//        [AppDelegate APP].user.createdByCode
//        //            [self.masterViewController viewWillAppear:YES];
//        if ([AppDelegate APP].user) {
//            //姓名
////            self.userName.text = [AppDelegate APP].user.salesConsultantName;
//            NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
//            NSLog(@"%@",[NSString stringWithFormat:@"%@%@",baseInterface,[AppDelegate APP].user.userImgpath]);
//            //头像
////            [self.avasterButton setBackgroundImageForState:UIControlStateNormal withURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",baseInterface,[AppDelegate APP].user.userImgpath]]];
//        }
    }];
}
- (IBAction)onclickOfflineClient:(id)sender {
    OfflineClientDetailViewController *add = [[OfflineClientDetailViewController alloc]init];
    add.delegate = self;
    [self presentDetail:add];
}
-(void)searchBarCancelButtonClicked:(JKSearchBar *)searchBar{
    [self loadOfflineData:nil  startNum:0];
}
#pragma mark Collection view data source

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [_dataList count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    [collectionView registerNib:[UINib nibWithNibName:@"ServiceReceptionCell" bundle:nil] forCellWithReuseIdentifier:@"ServiceReceptionCell"];
    
    ServiceReceptionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ServiceReceptionCell" forIndexPath:indexPath];
    //    cell.backgroundColor =  indexPath.row == 2 ?[UIColor darkGrayColor]:[UIColor colorWithRed:0.682 green:0.000 blue:0.117 alpha:1.000];
    [cell configCell1:[_dataList objectWithIndex:indexPath.row]];
    return cell;
    
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    OfflineClient *offline = [_dataList objectAtIndex:indexPath.row];
    OfflineClientDetailViewController *offlineClient = [[OfflineClientDetailViewController alloc]init];
    offlineClient.editClient = offline;
    offlineClient.delegate = self;
    [self presentDetail:offlineClient];
    
}
//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    return CGSizeMake(440, 40);
//}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 10, 0, 10);
}

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"indexPath.row%zd",indexPath.row);
    if (indexPath.row+1 == _currentPage*20)
    {
        _currentPage++;
        NSLog(@"page = %zd",_currentPage);
        [self loadOfflineData:nil startNum:[_dataList count]];
    }
}
-(void)searchBarSearchButtonClicked:(JKSearchBar *)searchBar{
    [self loadOfflineData:self.searchBar.text?:@""  startNum:0];
}

-(void)presentDetail:(UIViewController*)modelDetailViewController{
    [self presentDSPAPopup:modelDetailViewController
      parentViewController:self
             touchCallBack:nil
                  haveMask:YES
          includeNavgation:NO
                  alignTop:NO];
}
-(void)loadDataOfflineClient{
    [_dataList removeAllObjects];
    [self loadOfflineData:nil startNum:0];
}
@end
