//
//  OfflineLoginViewController.m
//  DSPA2015
//
//  Created by sun on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "OfflineLoginViewController.h"
#import "UIViewController+MJPopupViewController.h"
#import "AppDelegate.h"
@interface OfflineLoginViewController ()

@end

@implementation OfflineLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (IBAction)onclickLogin:(id)sender{
        if (_name.text.length == 0) {
            [JKAlert showMessage:@"用户名不能为空！"];
            return;
        }
        //    if (_passwordTextField.text.length == 0) {
        //        [JKAlert showMessage:@"密码不能为空！"];
        //        return;
        //    }
        NSDictionary *parameter = [[NSDictionary alloc]initWithObjectsAndKeys:_name.text,@"username",_password.text,@"password",@"00",@"dealerOrgID", nil];
        
        [User login:parameter Success:^(User *user,NSDictionary *responseObject) {
            NSLog(@"成功");
            if(user){
                [AppDelegate APP].createdByCode = user.userID;
                [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationSlideTopBottom];
            }else{
                [JKAlert showMessage:[responseObject errorMessages]];
                
            }
            
        } Failure:^(NSError *error) {
            //取消请求
            if(error.code != NSURLErrorCancelled)
            {
                //            [JKAlert showMessage:@"网络连接失败！"];
                NSLog(@"失败");
            }
            
        }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
