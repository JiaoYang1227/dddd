//
//  OfflineLoginViewController.h
//  DSPA2015
//
//  Created by sun on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//
#import "BorderTextField.h"
#import "User.h"
@interface OfflineLoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet BorderTextField *name;
@property (weak, nonatomic) IBOutlet BorderTextField *password;
//@property (weak, nonatomic)User *MYUser;
- (IBAction)onclickLogin:(id)sender;

@end
