//
//  LonginHistoryViewController.h
//  D-CARS
//
//  Created by owen on 15/7/14.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "User.h"
@protocol LonginHistoryDelegate<NSObject>
@optional
-(void)GetUserInformation:(NSDictionary *) dicUser;
@end
@interface LonginHistoryViewController : BaseViewController{
    NSMutableArray *_userDataArray;
}
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property(nonatomic,weak)__weak id<LonginHistoryDelegate>delegate;
@end
