//
//  LoginHistoryCell.m
//  D-CARS
//
//  Created by owen on 15/7/14.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "LoginHistoryCell.h"

@implementation LoginHistoryCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.HeadPortrait.layer.cornerRadius = 35;
    self.HeadPortrait.layer.masksToBounds = YES;
}
@end
