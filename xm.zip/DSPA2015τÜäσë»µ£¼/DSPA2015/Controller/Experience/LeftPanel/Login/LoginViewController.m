//
//  LoginViewController.m
//  D-CARS
//
//  Created by Jakey on 15/7/7.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "LoginViewController.h"
#import "LonginHistoryViewController.h"
#import "DateManager.h"
#import "UIViewController+MJPopupViewController.h"
#import "IQUIView+IQKeyboardToolbar.h"
@interface LoginViewController ()<LonginHistoryDelegate>

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSDictionary *dicUserData = [[NSMutableArray arrayWithArray:[User findAll]] objectWithIndex:0];
//    [_UserNameTextField addDoneOnKeyboardWithTarget:self action:@selector(doneAction:)];
    [_passwordTextField addDoneOnKeyboardWithTarget:self action:@selector(doneAction:)];

    _UserNameTextField.text = [dicUserData objectForKey:@"userName"];
    self.title = @"登录";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)doneAction:(UIBarButtonItem*)barButton
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
    [self loginButtonTouched:nil];
}
- (IBAction)loginButtonTouched:(id)sender {

    if (_UserNameTextField.text.length == 0) {
        [JKAlert showMessage:@"用户名不能为空！"];
        return;
    }
//    if (_passwordTextField.text.length == 0) {
//        [JKAlert showMessage:@"密码不能为空！"];
//        return;
//    }
    NSDictionary *parameter = [[NSDictionary alloc]initWithObjectsAndKeys:_UserNameTextField.text,@"username",_passwordTextField.text,@"password",@"00",@"dealerOrgID", nil];
    
    AFHTTPRequestOperation *currentOperation = [User login:parameter Success:^(User *user,NSDictionary *responseObject) {
        NSLog(@"成功");
        //插入数据库

        if(user){
            [AppDelegate APP].user = user;
            //自动登录问题
            [User saveAccount:_UserNameTextField.text andPassword:_passwordTextField.text];
            
            [User insertWithDic:@{@"userName":_UserNameTextField.text?:@"",@"userImgpath":user.userImgpath?:@"",@"loginDate":[DateManager nowTimeStampString]}];
            self.icon = user.userImgpath?:@"";
                [self.navigationController popViewControllerAnimated:YES];
            
            [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];

        }else{
            [JKAlert showMessage:[responseObject errorMessages]];

        }
        
    } Failure:^(NSError *error) {
        //取消请求
        if(error.code != NSURLErrorCancelled)
        {
//            [JKAlert showMessage:@"网络连接失败！"];
            NSLog(@"失败");
        }
       
    }];
    [_currentOperations addObject:currentOperation];
}

-(void)GetUserInformation:(NSDictionary *) dicUser{
    self.UserNameTextField.text = [dicUser objectForKey:@"userName"];
}
- (IBAction)LoginHistoryButtonTouched:(id)sender {
    LonginHistoryViewController *login = [[LonginHistoryViewController alloc]init];
    login.delegate = self;
    [self.navigationController pushViewController:login animated:YES];
}
@end
