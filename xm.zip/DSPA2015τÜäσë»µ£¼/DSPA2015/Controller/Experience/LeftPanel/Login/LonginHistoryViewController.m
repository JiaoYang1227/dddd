//
//  LonginHistoryViewController.m
//  D-CARS
//
//  Created by owen on 15/7/14.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "LonginHistoryViewController.h"
#import "LoginHistoryCell.h"
#import "UIImageView+AFNetworking.h"
#define TABLEVIEW_CELL_IDENTIFIER @"LoginHistoryCell"
@interface LonginHistoryViewController ()

@end

@implementation LonginHistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.collectionView registerNib:[UINib nibWithNibName:@"LoginHistoryCell" bundle:nil] forCellWithReuseIdentifier:TABLEVIEW_CELL_IDENTIFIER];
    _userDataArray = [NSMutableArray arrayWithArray:[User findAll]];
    [self.collectionView reloadData];
    // Do any additional setup after loading the view from its nib.
    self.title = @"登录历史";
}

//返回section的个数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}
//返回section中的cell个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return _userDataArray.count;
}

//返回cell
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    LoginHistoryCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:TABLEVIEW_CELL_IDENTIFIER forIndexPath:indexPath];
    NSDictionary *dicUserData = [_userDataArray dictionaryWithIndex:indexPath.row];
    //[dicUserData objectForKey:@"userImgpath"]//图片
//    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    NSLog(@"%@",[NSString stringWithFormat:@"http://192.168.215.192:8080/dspa_crmserver%@",[dicUserData objectForKey:@"userImgpath"]]);
    [cell.HeadPortrait setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.215.192:8080/dspa_crmserver%@",[dicUserData objectForKey:@"userImgpath"]]] placeholderImage:[UIImage imageWithFileName:@"HeadPortrait.png"]];
    cell.name.text = [dicUserData stringForKey:@"userName"];
        return cell;
}
//返回cell的宽和高
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewFlowLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{

    return CGSizeMake(73, 114);
    
}
//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    //    return UIEdgeInsetsMake(10, 0, 10, 90);
    return UIEdgeInsetsMake(0, 0, 0, 0);
}
#pragma mark --UICollectionViewDelegate
//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dicUserData = [_userDataArray dictionaryWithIndex:indexPath.row];
    [_delegate GetUserInformation:dicUserData];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
