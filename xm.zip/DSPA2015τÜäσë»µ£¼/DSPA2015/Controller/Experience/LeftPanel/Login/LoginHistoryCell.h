//
//  LoginHistoryCell.h
//  D-CARS
//
//  Created by owen on 15/7/14.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginHistoryCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UIImageView *HeadPortrait;

@end
