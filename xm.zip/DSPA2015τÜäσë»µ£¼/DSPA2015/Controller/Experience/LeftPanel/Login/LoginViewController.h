//
//  LoginViewController.h
//  D-CARS
//
//  Created by Jakey on 15/7/7.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "User.h"
@interface LoginViewController : BaseViewController
@property(nonatomic,strong) NSString *icon;
@property (weak, nonatomic) IBOutlet UIImageView *HeadPortrait;
@property (weak, nonatomic) IBOutlet UITextField *UserNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
- (IBAction)loginButtonTouched:(id)sender;
- (IBAction)LoginHistoryButtonTouched:(id)sender;

@end
