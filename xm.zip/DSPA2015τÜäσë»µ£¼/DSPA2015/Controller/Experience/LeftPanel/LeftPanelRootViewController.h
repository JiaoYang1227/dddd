//
//  LeftPanelRootViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceRootViewController.h"
//#import "OfflineClientViewController.h"
@class OfflineClientViewController;
@interface LeftPanelRootViewController : UIViewController


@property (weak, nonatomic) IBOutlet UIButton *logoutButton;
@property (weak, nonatomic) IBOutlet UIView *PersonalInformationView;
@property (weak, nonatomic) IBOutlet UIImageView *HeadPortrait;
@property (weak, nonatomic) IBOutlet UIButton *LoginButton;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *professional;
@property (strong, nonatomic) OfflineClientViewController *offline;

- (IBAction)ComplaintsSuggestionsTouched:(id)sender;

- (IBAction)logoutTouched:(id)sender;
- (IBAction)loginButtonTouched:(id)sender;
- (IBAction)indexButtonTouched:(id)sender;
- (IBAction)serviceButtonTouched:(id)sender;
- (IBAction)settingButtonTouched:(id)sender;
-(void)reloadDataLogin:(NSNotification*)notifacation;
@property (weak, nonatomic) IBOutlet UIButton *tuijianhanButton;
- (IBAction)tuijianhanTouched:(id)sender;

//@property (strong, nonatomic) ServiceRootViewController *serviceRootViewController;
@end
