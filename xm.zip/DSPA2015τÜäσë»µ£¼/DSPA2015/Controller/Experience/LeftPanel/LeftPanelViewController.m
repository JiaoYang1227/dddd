//
//  LeftPanelViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "LeftPanelViewController.h"

@interface LeftPanelViewController ()

@end

@implementation LeftPanelViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.contentNavigationController.navigationBarHidden = YES;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}
-(UINavigationController *)contentNavigationController{
    if (!_contentNavigationController) {
        _leftPanelRootViewController = [[LeftPanelRootViewController alloc] init];
        _contentNavigationController = [[UINavigationController alloc] initWithRootViewController:_leftPanelRootViewController];
        _contentNavigationController.navigationBarHidden = YES;
        //    self.contentNavigationController.view.frame = CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds)-64);
        _contentNavigationController.view.frame = self.view.bounds;
        
        [self.view addSubview:_contentNavigationController.view];
    }
    return _contentNavigationController;
}
#pragma --mark push and pop
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if ([[self.contentNavigationController.viewControllers lastObject] class] != [viewController class]) {
        [self.contentNavigationController pushViewController:viewController animated:animated];
    }
}

- (UIViewController *)popViewControllerAnimated:(BOOL)animated{
    return [self.contentNavigationController popViewControllerAnimated:animated];
}

- (void)replaceViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [self.contentNavigationController popToRootViewControllerAnimated:NO];
    [self.contentNavigationController pushViewController:viewController animated:animated];
    //    [self.contentNavigationController setViewControllers:@[viewController] animated:animated];
}
@end
