//
//  LeftPanelRootViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "LeftPanelRootViewController.h"
#import "AppDelegate.h"
#import "ServiceRootViewController.h"
#import "LoginViewController.h"
#import "CTAssetsPickerController.h"
#import "UploadManager.h"
#import "UIImageView+AFNetworking.h"
#import "SettingViewController.h"
#import "OfflineClientViewController.h"
#import "UIImage+SuperCompress.h"
//#import "ComplaintsSuggestionsViewController.h"
#import "ProductCenterViewController.h"
#import "MessageCenter.h"
#import "ShareCenterViewController.h"
#import "AccessoriesProductViewController.h"
#import "RecommendationViewController.h"

@interface LeftPanelRootViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,CTAssetsPickerControllerDelegate,UINavigationControllerDelegate,UIPopoverPresentationControllerDelegate>{
    UIImagePickerController *imagePicker;//图片选择器

    __weak IBOutlet UIButton *_ShareCenterProductBTN;
    __weak IBOutlet UIButton *_AccessoriesProductBTN;
    __weak IBOutlet UIView *_moreView;
}

@end

@implementation LeftPanelRootViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self reloadDataLogin:nil];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    _HeadPortrait.layer.cornerRadius = 25;
    _HeadPortrait.clipsToBounds = YES;
    UITapGestureRecognizer* singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeHeadPortrait)];
    [_HeadPortrait setUserInteractionEnabled:YES];
    [_HeadPortrait addGestureRecognizer:singleTap];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadDataLogin:) name:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
    [_name setFont:[UIFont fontWithName:@"Helvetica-Bold" size:20]];
    self.title = @"侧边栏";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (IBAction)loginButtonTouched:(id)sender {
    LoginViewController *login = [[LoginViewController alloc]init];
    [self.navigationController pushViewController:login animated:YES];
}
- (IBAction)indexButtonTouched:(id)sender {
    [[AppDelegate APP].rootViewController showPanel:NO];
    [[AppDelegate APP].rootViewController showClientBar:YES];
    [[AppDelegate APP].rootViewController popToRootViewControllerAnimated:NO];
}
- (IBAction)moreTouched:(UIButton *)sender {
    if (sender.tag==0) {
        sender.tag=1;
        [UIView animateWithDuration:0.3
                         animations:^{
                             _AccessoriesProductBTN.frame = CGRectMake(50, 8, 115, 0);
                             _ShareCenterProductBTN.frame = CGRectMake(50, 54, 115, 0);
                             _moreView.frame = CGRectMake(20, 560, 300, 0);
                             self.tuijianhanButton.frame = CGRectMake(50, 94, 115, 0);
                         }
                         completion:^(BOOL finished){
                         }];
        [UIView animateWithDuration:0.5
                         animations:^{
                             _logoutButton.frame = CGRectMake(32, 573, 265, 34);
                         }];
    }else{
        sender.tag=0;
        [UIView animateWithDuration:0.5
                         animations:^{
                             _moreView.frame = CGRectMake(20, 560, 300, 150);
                             _AccessoriesProductBTN.frame = CGRectMake(50, 8, 115, 35);
                             _ShareCenterProductBTN.frame = CGRectMake(50, 54, 115, 35);
                             self.tuijianhanButton.frame = CGRectMake(50, 94, 115, 35);
                         }
                         completion:^(BOOL finished){
                         }];
        [UIView animateWithDuration:0.3
                         animations:^{
                             _logoutButton.frame = CGRectMake(32, 50+662, 265, 34);
                         }];
    }
}

- (IBAction)serviceButtonTouched:(id)sender {
    if ([[AppDelegate APP] user] == nil) {
        [JKAlert showMessage:@"请登录"];
        return;
    }
    [[AppDelegate APP].rootViewController showPanel:NO];
    [[AppDelegate APP].rootViewController showClientBar:NO];
    
    ServiceRootViewController *serviceRootViewController = [[ServiceRootViewController alloc]init];
    [[AppDelegate APP].rootViewController replaceViewController:serviceRootViewController animated:NO];
}
- (IBAction)offlineClientTouched:(id)sender {//离线集客
    [CBTracking recordModulePath:@"other module"];
    [[AppDelegate APP].rootViewController showPanel:NO];
    [[AppDelegate APP].rootViewController showClientBar:NO];
    _offline = [[OfflineClientViewController alloc]init];
    [[AppDelegate APP].rootViewController replaceViewController:_offline animated:NO];
    
    [Stat sendSettingStatWithName:@"offlineClient"];
}

- (IBAction)settingButtonTouched:(id)sender {
    [CBTracking recordModulePath:@"other module"];
    [[AppDelegate APP].rootViewController showPanel:NO];
    [[AppDelegate APP].rootViewController showClientBar:NO];
    
    SettingViewController *setting = [[SettingViewController alloc]init];
    [[AppDelegate APP].rootViewController replaceViewController:setting animated:NO];
    
}
- (IBAction)ComplaintsSuggestionsTouched:(id)sender {
    
    [CBTracking recordModulePath:@"other module"];
    if ([AppDelegate APP].user) {
        
        [[AppDelegate APP].rootViewController showPanel:NO];
        [[AppDelegate APP].rootViewController showClientBar:NO];
        
        ProductCenterViewController *productCenter = [[ProductCenterViewController alloc]init];
        [[AppDelegate APP].rootViewController replaceViewController:productCenter animated:NO];
    }else{
        [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
        [JKAlert showMessage:@"请登录"];
    }
}
//精品附件
- (IBAction)AccessoriesProductTouched:(id)sender {
    
    [CBTracking recordModulePath:@"other module"];
    [[AppDelegate APP].rootViewController showPanel:NO];
    [[AppDelegate APP].rootViewController showClientBar:NO];
    
    AccessoriesProductViewController *AccessoriesProduct = [[AccessoriesProductViewController alloc]init];
    [[AppDelegate APP].rootViewController replaceViewController:AccessoriesProduct animated:NO];
}
//资源共享
- (IBAction)ShareCenterProductTouched:(id)sender {
    
    //统计
    [CBTracking trackEvent:@"资源共享"];
    [CBTracking recordModulePath:@"资源共享"];
    [[AppDelegate APP].rootViewController showPanel:NO];
    [[AppDelegate APP].rootViewController showClientBar:NO];
    
    ShareCenterViewController *ShareCenter = [[ShareCenterViewController alloc]init];
    [[AppDelegate APP].rootViewController replaceViewController:ShareCenter animated:NO];
}
- (IBAction)logoutTouched:(id)sender {

//    __weak typeof(self) weakSelf = self;
    
    [AppDelegate APP].user = nil;
    [AppDelegate APP].isFromCale = NO;
    [self reloadDataLogin:nil];
    //auto login
    [User logoutAccount];
    [User OutLogin:nil Success:^(NSDictionary *dic, id responseObject) {
        [self reloadDataLogin:nil];
        [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:NO]];

    } Failure:^(NSError *error) {
        
    }];
}
-(void)reloadDataLogin:(NSNotification*)notifacation{
    BOOL fromAPI = [notifacation.object boolValue];
   

    if ([AppDelegate APP].user) {
        [_LoginButton setHidden:YES];
        [_PersonalInformationView setHidden:NO];
        _name.text = [AppDelegate APP].user.salesConsultantName;
        _professional.text = [AppDelegate APP].user.roleName;
        
        NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
        
        
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",baseInterface,[AppDelegate APP].user.userImgpath]);
        if ([AppDelegate APP].user.image) {
            [_HeadPortrait setImage:[AppDelegate APP].user.image];
        }else{
            [_HeadPortrait setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",baseInterface,[AppDelegate APP].user.userImgpath]] placeholderImage:[UIImage imageWithFileName:@"HeadPortrait.png"]];
            
            [AppDelegate APP].user.image = _HeadPortrait.image;
        }
        [_logoutButton setHidden:NO];
        
        
        
    }else{
        if (fromAPI) {
            //注销 登录时 清空客户接待信息 跳到左侧面板
            [[AppDelegate APP].rootViewController showPanel:YES];
        }
        [_LoginButton setHidden:NO];
        [_PersonalInformationView setHidden:YES];
        [_logoutButton setHidden:YES];
    }
    
}
-(void)changeHeadPortrait{
    UIActionSheet* mySheet = [[UIActionSheet alloc]
                              initWithTitle:@"请选择图片源"
                              delegate:self
                              cancelButtonTitle:@"取消"
                              destructiveButtonTitle:nil
                              otherButtonTitles:@"使用摄像头",@"从相册选取", nil];
    [mySheet showInView:self.view];
}
#pragma mark -- UIActionSheet delegate
- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){//使用摄像头
        [self pickImageFromCamera];
    }
    if(buttonIndex == 1){//本地相册选取
        CTAssetsPickerController *picker = [[CTAssetsPickerController alloc] init];
        picker.maximumNumberOfSelection = 1;
        picker.assetsFilter = [ALAssetsFilter allAssets];//只选择图片
        picker.delegate = self;
        if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
        {
            [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                [self presentViewController:picker animated:YES completion:NULL];
            }];
        }
        else{
            [self presentViewController:picker animated:YES completion:NULL];
        }
    }
}

//相机选取
- (void)pickImageFromCamera{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        //没有摄像头 或者模拟器下使用 跳过
        return;
    }
    imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    //不允许用户进行编辑
    imagePicker.allowsEditing = NO;
    if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
    {
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            [self presentViewController:imagePicker animated:YES completion:nil];
        }];
    }
    else{
        [self presentViewController:imagePicker animated:YES completion:nil];
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    [imagePicker dismissViewControllerAnimated:YES completion:^() {
        UIImage *tempImg = [info objectForKey:UIImagePickerControllerOriginalImage];
        [self uploadPictures:tempImg];
    }];
}
#pragma mark - Assets Picker Delegate
//实现 CTAssetsPickerControllerDelegate 的函数 完成选择之后 didFinishPickingAssets
- (void)assetsPickerController:(CTAssetsPickerController *)picker didFinishPickingAssets:(NSArray *)assets
{
    if (assets.count>0) {
        ALAsset *asset=assets[0];
        UIImage *tempImg=[UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
        [self uploadPictures:tempImg];
    }
}
-(void)uploadPictures:(UIImage *)image{
    if (!image) {
        [JKAlert showMessage:@"请先选择图片!"];
        return;
    }
    NSData *documentData = [UIImage compressImage:image toMaxLength:512*1024*8 maxWidth:1024];
    if (!documentData) {
        [JKAlert showMessage:@"图片压缩失败!"];
        return;
    }
    NSDictionary *dic = [[NSDictionary alloc]init];
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    
    [UploadManager imageUploadOne:[NSString stringWithFormat:@"%@%@",baseInterface,INTERFACE_CREATEPERSONALDETAIL]
                   withParameters:dic
                    withImageData:documentData
                     withFileName:@"personalImg"
                    uploadSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        [AppDelegate APP].user.image = image;
        [_HeadPortrait setImage:image];
        NSLog(@"chenggong,,%@",responseObject);
    } uploadError:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"shibai");
    }];
}
- (IBAction)tuijianhanTouched:(id)sender {
    [CBTracking recordModulePath:@"other module"];
    [[AppDelegate APP].rootViewController showPanel:NO];
    [[AppDelegate APP].rootViewController showClientBar:NO];
    
    RecommendationViewController *re = [[RecommendationViewController alloc]init];
    [[AppDelegate APP].rootViewController replaceViewController:re animated:NO];
}
@end
