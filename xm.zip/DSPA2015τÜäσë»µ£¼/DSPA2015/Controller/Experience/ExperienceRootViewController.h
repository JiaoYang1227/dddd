//
//  ExperienceRootViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "JKScrollFocus.h"
@interface ExperienceRootViewController : BaseViewController
@property (weak, nonatomic) IBOutlet JKScrollFocus *scrollFocus;
- (IBAction)videoCenterTouched:(id)sender;
- (IBAction)carShowTouched:(id)sender;
- (IBAction)calculateTouched:(id)sender;
- (IBAction)compareTouched:(id)sender;
- (IBAction)resourceQueryTouched:(id)sender;
- (IBAction)testDriverTouched:(id)sender;
- (IBAction)showTouched:(id)sender;
- (IBAction)deliveCarTouched:(id)sender;

//任务看板

- (IBAction)taskConsultantTouched:(id)sender;

@end
