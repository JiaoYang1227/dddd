//
//  SearchOldCustomeViewController.h
//  DSPA2015
//
//  Created by Jakey on 16/2/24.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseSearchViewController.h"
typedef void(^SearchOldCustomerSelectOne)(BOOL isCustomer,id model);

@interface SearchOldCustomeViewController : BaseSearchViewController
{
    SearchOldCustomerSelectOne _searchCustomerSelectOne;
    //    NSMutableArray *_dataArray;
    NSString *_mobile;
}
@property (strong, nonatomic)  NSMutableArray *customerList;
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@property (weak, nonatomic) IBOutlet UILabel *titileLabel;
-(instancetype)initWithMobile:(NSString*)mobile;
-(void)searchCustomerSelectOne:(SearchOldCustomerSelectOne)searchCustomerSelectOne;


@end
