//
//  SearchOldCustomeViewController.m
//  DSPA2015
//
//  Created by Jakey on 16/2/24.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "SearchOldCustomeViewController.h"
#import "SearchOldCustomerCell.h"
static NSString *SearchOldCustomerCellIdentifier = @"SearchOldCustomerCell";

@interface SearchOldCustomeViewController ()

@end

@implementation SearchOldCustomeViewController
-(instancetype)initWithMobile:(NSString*)mobile{
    if (self = [super init]) {
        _mobile = mobile;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor clearColor];

    self.title = @"客户接待搜索老客户(首页)";
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.titileLabel.text = [NSString stringWithFormat:@"已有相同移动电话<%@>的<%zd>位客户被建立",_mobile,[self.customerList count]];

    //    [_dataArray addObjectsFromArray:[self.customerList arrayForKey:@"customer"]];
    //    [_dataArray addObjectsFromArray:[self.customerList arrayForKey:@"customerReception"]];
    [self.myTableView reloadData];
    
}
#pragma -mark tableView Delegates
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.customerList count];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //    [self.myTableView deselectRowAtIndexPath:indexPath animated:YES];
//    id item = [self.customerList objectWithIndex:indexPath.row];
    
//    if(_searchCustomerSelectOne){
//        if ([item isKindOfClass:[CustomerReception class]]) {
//            _searchCustomerSelectOne(NO,item);
//        }
//        if ([item isKindOfClass:[Customer class]]) {
//            _searchCustomerSelectOne(YES,item);
//        }
//        [self dismissTouched:nil];
//    }
//    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.myTableView registerNib:[UINib nibWithNibName:@"SearchOldCustomerCell" bundle:nil] forCellReuseIdentifier:SearchOldCustomerCellIdentifier];
    
    SearchOldCustomerCell *cell = (SearchOldCustomerCell*)[tableView dequeueReusableCellWithIdentifier:SearchOldCustomerCellIdentifier];
    if(indexPath.row %2==0){
        cell.backgroundColor = [UIColor colorWithRed:0.931 green:0.935 blue:0.956 alpha:1.000];
    }else{
        cell.backgroundColor = [UIColor whiteColor];
        
    }
    [cell configCell:[self.customerList objectWithIndex:indexPath.row]];
    return cell;
}
-(void)searchCustomerSelectOne:(SearchOldCustomerSelectOne)searchCustomerSelectOne{
    _searchCustomerSelectOne = [searchCustomerSelectOne copy];
}
-(void)dismissTouched:(id)sender{
    [super dismissTouched:sender];
}
-(IBAction)closeTouched:(id)sender{
    [self dismissTouched:nil];

}


@end
