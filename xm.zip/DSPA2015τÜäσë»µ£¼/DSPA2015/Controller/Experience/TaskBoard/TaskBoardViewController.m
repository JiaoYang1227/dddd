//
//  TaskBoardViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskBoardViewController.h"
#import "TaskBoard.h"
#import "TaskLineView.h"

#import "TaskAssignViewController.h"
#import "TaskUtil.h"
#import "TaskBoardDuplicateViewController.h"
#import "CustomerReception.h"
#import "UIViewController+DSPAPopup.h"

#import "SearchOldCustomeViewController.h"

#import <AudioToolbox/AudioToolbox.h>
#import "MessageCenter.h"
#import "NSDictionary+JSONString.h"
#define TIME_RESRESH 15
@interface TaskBoardViewController ()

@end

@implementation TaskBoardViewController
-(instancetype)initWithRole:(TaskBoardRole)role{
    if (self = [super initWithNibName:nil bundle:nil]) {
        _role = role;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
  
    self.title = @"客户接待(首页)";
    
    NSLog(@"%@",[[AppDelegate APP].user description]);
    
    [self reloadDataWithLogin:nil];

    //不能总是刷新 因为当前选中展厅无法选中
    
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGesture:)];
    [self.view addGestureRecognizer:longPressGesture];
    
    [self buildMessageCenter:NO];
}
-(void)buildMessageCenter:(BOOL)force{
    if (force) {
        [MessageCenter reconnectForDSPA];
    }else{
        if([MessageCenter sharedCenter].readyState>1){
            NSLog(@"重新连接");
            [MessageCenter reconnectForDSPA];
        }
    }
    
    __weak typeof(self) weakSelf = self;
    [MessageCenter MCDidReceiveMessage:^(id message) {
        NSDictionary *result = [message dictionaryValue];
//         [JKAlert showMessage:[result description]];
        
        if ([[result stringForKey:@"msgModel"] isEqualToString:@"TaskSchedule"]) {
//            [weakSelf loadPanelList:nil];
            [NSObject cancelPreviousPerformRequestsWithTarget:weakSelf selector:@selector(loadPanelList:) object:nil];
            [weakSelf performSelector:@selector(loadPanelList:) withObject:nil];
            if ([AppDelegate APP].user.role == UserRoleConsultant) {
                [weakSelf loadAssignStatus];
            }
        }
    } forModule:@"TaskBorad"];
    
    [MessageCenter MCSocketDidOpen:^(SRWebSocket *webSocket) {
        [weakSelf showBarMessage:[NSString stringWithFormat:@"连接服务器成功"]];
        [MessageCenter sendMessage:[@{@"msgType":@"all",@"msgContent":@"",@"msgModel":@"TaskSchedule",@"sendUsers":@""} JSONStringValue]];

    }];
    [MessageCenter MCSocketDidFailWithError:^(SRWebSocket *webSocket, NSError *error) {
//        [JKAlert showMessage:@"连接服务器错误" message:[error description]];
        [weakSelf showBarMessage:[NSString stringWithFormat:@"连接服务器错误"]];
    }];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadDataWithLogin:) name:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:NO]];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];

}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:NO]];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}
-(void)dealloc{
//     [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)applicationDidBecomeActive:(NSNotification*)notifacation{
//    if([MessageCenter sharedCenter].readyState>1){
//        NSLog(@"重新连接");
//        [MessageCenter reconnectForDSPA];
//    }
    [self reloadDataWithLogin:nil];
}
/**
 *  @author Jakey, 15-12-09 11:12:09
 *
 *  @brief  根据角色布局UI
 *
 *  @param role <#role description#>
 */
-(void)appearanceWith:(TaskBoardRole)role{
    
    if (role == TaskBoardRoleConsultant) {
        //顾问
        self.assignButton.hidden = YES;
        self.InitButton.hidden = YES;
        self.oldCustomerButton.hidden = YES;
        [self loadAssignStatus];
        [self loadPanelList:nil];

        self.titleLabel.text = @"客户接待(顾问)";
    }else if (role == TaskBoardRoleReceptionist){
        [self loadPanelList:nil];
        self.titleLabel.text = @"客户接待(前台)";
        self.receptionButton.hidden =YES;
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadAssignStatus) object:nil];
    }else{
        self.titleLabel.text = @"客户接待(无权限)";
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadAssignStatus) object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadPanelList:) object:nil];

        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    
    //隐藏无用按钮

}
#define CELL_HIGHT 90
#pragma mark-- reload Panel
/**
 *  @author Jakey, 15-12-10 11:12:43
 *
 *  @brief  布局所有存在的展厅
 *
 *  @param hallData 展厅实体数组
 */
- (void)layerHallLine:(NSArray*)hallData
{
//    __weak typeof(self) weakSelf = self;
    [self.scrollPanel.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self.waitPanel.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    NSMutableArray *tempHallLines = [NSMutableArray array];
    for (int index = 0 ;index < [hallData count] ;index++) {
        TaskHall *aHall = [hallData objectWithIndex:index];
        TaskLineView *line;
        //等待队列 固定在顶部
        if (index <1) {
                line = [[TaskLineView alloc] initWithFrame:CGRectMake(0, 0, self.waitPanel.frame.size.width, 2*CELL_HIGHT) andMode:TaskLineViewModeFloating];
            
            if(_role == TaskBoardRoleReceptionist){
                line.disbaleDraggingIn = NO; //都可以拖入
                line.disbaleDraggingOut = NO;

            }else{
                line.disbaleDraggingIn = YES;
                line.disbaleDraggingOut = YES;
            }
            //禁止从其他地方拖回来
            [self.waitPanel addSubview:line];
        }else
        {
            line = [[TaskLineView alloc] initWithFrame:CGRectMake(0, CELL_HIGHT * (index-1), self.scrollPanel.frame.size.width, CELL_HIGHT) andMode:TaskLineViewModeDisable];
            line.hall = aHall;
            if(_role == TaskBoardRoleReceptionist){
                line.disbaleDraggingIn = NO;
                line.disbaleDraggingOut = NO;
                self.titleLabel.text = @"客户接待(前台)";
            }else{
                line.disbaleDraggingIn = YES;
                line.disbaleDraggingOut = YES;
                self.titleLabel.text = @"客户接待(顾问)";
            }
            [self.scrollPanel addSubview:line];
        }
        if ((_role == TaskBoardRoleReceptionist) && (index ==1)) {
            line.disbaleDraggingIn = NO; //都可以拖入
            line.disbaleDraggingOut = NO;

         }
        line.hall = aHall;
        line.index = index;
        line.iconImage = [NSString stringWithFormat:@"task_hall_status_icon_%d.png",index];
        if (index>8) {
            line.iconImage = @"task_hall_status_icon_default.png";
        }
        if (line) {
            [tempHallLines addObject:line];
        }
    }
    self.scrollPanel.contentSize = CGSizeMake(self.scrollPanel.width, CELL_HIGHT*[hallData count] -1+1);
    _hallLines = [tempHallLines mutableCopy];
    
}

#pragma mark--获取展厅分组
-(void)loadMenuData{
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    [TaskBoard initTaskPanelList:@"runlin_dsps_splace" Success:^(NSDictionary *collection) {
//        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
//        //展厅分组
//        _groupNameArray =  [NSMutableArray arrayWithArray:[collection arrayForKey:@"placeList"]];
//       [_groupNameArray insertObject:@{@"hallName":@"全部展厅",@"key":@"runlin_dsps_splace"} atIndex:0];
//        _hallNameSelectButton.key = @"runlin_dsps_splace";
//        _hallNameSelectButton.value = @"全部展厅";
//
//        
//    } Failure:^(NSError *error) {
//        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
//    }];
}
#pragma mark-- 轮询
- (void)loadPanelList:(NSDictionary*)collectionFromSocket{
    if(_isDragging || [UIApplication sharedApplication].applicationState  != UIApplicationStateActive){
        return;
    }

    if (collectionFromSocket)
    {
        NSMutableArray *hallData = [NSMutableArray array];
        for (NSDictionary *item in   [collectionFromSocket arrayForKey:@"panelList"]) {
            TaskHall *hall = [TaskHall objectFromDictionary:item];
            //其实不是hall类型
            hall.hallId = [item stringForKey:@"id"];
            hall.hallName = [item stringForKey:@"name"];
            [hallData addObject:hall];
        }
        [self layerHallLine:hallData];
        
    }else{
        __weak typeof(self) weakSelf = self;
        [TaskBoard initTaskPanelList:_hallNameSelectButton.key?:@"runlin_dsps_splace" Success:^
         (NSDictionary *collection) {
             __strong typeof(self) strongSelf = weakSelf;
            //展厅分组
            _groupNameArray =  [NSMutableArray arrayWithArray:[collection arrayForKey:@"placeList"]];
            [_groupNameArray insertObject:@{@"hallName":@"全部展厅",@"key":@"runlin_dsps_splace"} atIndex:0];
            
             NSMutableArray *hallData = [NSMutableArray array];

            for (NSDictionary *item in   [collection arrayForKey:@"panelList"]) {
                TaskHall *hall = [TaskHall objectFromDictionary:item];
                //其实不是hall类型
                hall.hallId = [item stringForKey:@"id"];
                hall.hallName = [item stringForKey:@"name"];
                [hallData addObject:hall];
            }
            [strongSelf layerHallLine:hallData];
            NSLog(@"_hallData:%zd",[hallData count]);
            [strongSelf startLongPollPanelList];
        } Failure:^(NSError *error) {
            
        }];
    }
}
-(void)reloadDataWithLogin:(NSNotification*)notifacation{
    NSLog(@"%@",[[AppDelegate APP].user description]);
    if (![AppDelegate APP].user) {
        _role  = TaskBoardRoleUnknow;
    }
    if ([AppDelegate APP].user.role == UserRoleConsultant) {
        _role = TaskBoardRoleConsultant;
    }
    if ([AppDelegate APP].user.role == UserRoleReceptionist) {
        _role = TaskBoardRoleReceptionist;
    }
    [self appearanceWith:_role];
}
- (void)startLongPollPanelList{
//    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadPanelList:) object:nil];
//    [self performSelector:@selector(loadPanelList:) withObject:nil afterDelay:TIME_RESRESH];
}
-(void)loadAssignStatus{
    __weak typeof(self) weakSelf = self;
    if (_receptionAlert || [UIApplication sharedApplication].applicationState  != UIApplicationStateActive) {
        return;
    }
    
    [TaskBoard getAssignStatus:^(NSDictionary *collection) {
        if (collection != nil && [collection integerForKey:@"assignStatus"] == 1) {
            //播放声音
//            AudioServicesPlaySystemSound(ringringring);
            
           __weak CustomerReception *r = [CustomerReception objectFromDictionary:[collection dictionaryForKey:@"result"]];

            weakSelf.receptionButton.enabled = NO;
            _receptionAlert = [JKAlert alertWithTitle:@"提示" andMessage:@"您被分配了一个客户,请开始接待!"];
            [_receptionAlert addCommonButtonWithTitle:@"接待" handler:^(JKAlertItem *item) {
                [weakSelf updateAssignStatus:^{
                    weakSelf.receptionButton.enabled = YES;
                    [weakSelf receptionDone:r];
                    NSLog(@"接待成功!");
                }];
                _receptionAlert = nil;
                
            }];
            [_receptionAlert show];
        }else if([collection integerForKey:@"assignStatus"] == 2){
            weakSelf.receptionButton.enabled = YES;
            
        }else{
            weakSelf.receptionButton.enabled = NO;
        }
        [self startLongPollAssignStatus];

    } Failure:^(NSError *error) {
        
    }];
}
- (void)startLongPollAssignStatus{
//    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadAssignStatus) object:nil];
//    [self performSelector:@selector(loadAssignStatus) withObject:nil afterDelay:TIME_RESRESH];
}
//点击接待更新状态
-(void)updateAssignStatus:(void (^)(void))success{
    [TaskBoard updateAssignStatus:@"2" Success:^(NSDictionary *collection) {
        if ([collection boolForKey:@"success"]) {
            success();
            NSLog(@"接待中。。。");
        }
    } Failure:^(NSError *error) {
        
    }];
}
//-(void)dealloc{
//    
//}
-(void)backButtonTouched:(id)sender{
    //停止轮询
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadAssignStatus) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadPanelList:) object:nil];
    [super backButtonTouched:sender];
}
#pragma -mark ----Gesture Handle

/**
 *  @author Jakey, 15-12-10 11:12:01
 *
 *  @brief  长按手势处理
 *
 *  @param sender <#sender description#>
 */
- (void)handleLongPressGesture:(UILongPressGestureRecognizer *)sender {
    _isDragging = YES;
   
    if (sender.state == UIGestureRecognizerStateBegan)
    {
        self.sourceLine = [TaskUtil findLineWithSender:sender hallLines:_hallLines inView:self.view];
        CGPoint locationInCollectionView = CGPointZero;
        if (self.sourceLine==nil)
        {
            NSLog(@"没有按在一个collectionView上。");
            return;
        }else
        {
            locationInCollectionView = [sender locationInView:self.sourceLine.collectionView];
        }
        NSLog(@"%@ is selected", self.sourceLine.hall.hallName);
        
        if(self.sourceLine.disbaleDraggingOut){
            [self showBarMessage:@"已禁止拖出"];
            NSLog(@"禁止拖出");
            return;
        }
        //找到Cell index
        NSIndexPath *selectedIndex = [self.sourceLine.collectionView indexPathForItemAtPoint:locationInCollectionView];
        if (selectedIndex)
        {
            //初始化数据
            _dragManView = [[TaskDragManView alloc]init];
            _dragManView.sourceIndexPath = selectedIndex;
            
            //抽出cell view
            TaskCell *cell = (TaskCell *)[self.sourceLine.collectionView cellForItemAtIndexPath:_dragManView.sourceIndexPath];
            _dragManView.man = [self.sourceLine.hall.salemanlist objectWithIndex:_dragManView.sourceIndexPath.row];
            _dragManView.frame = cell.bounds;
            [_dragManView cloneViewsFromTaskCell:cell];
            [self.view addSubview:_dragManView];
            
            //不移除cell了
            NSLog(@"move a aman:%@ atIndex:%zi",_dragManView.man, _dragManView.sourceIndexPath.row);
            if (self.sourceLine.hall.salemanlist)
            {
                [self.sourceLine.hall.salemanlist removeObjectAtIndex:_dragManView.sourceIndexPath.row];
                [self.sourceLine.collectionView performBatchUpdates:^{
                    [self.sourceLine.collectionView deleteItemsAtIndexPaths:@[_dragManView.sourceIndexPath]];
                } completion:^(BOOL finished) {
                    NSLog(@"删除后计：:%zi", self.sourceLine.hall.salemanlist.count);
                    [self.sourceLine.collectionView reloadData];
                }];
            }
            _dragManView.center = [sender locationInView:self.view];
            [self.view bringSubviewToFront:_dragManView];
        }else
        {
            NSLog(@"没找按下的cell Index.");
            return;
        }
    }
    
    if (sender.state == UIGestureRecognizerStateChanged)
    {
        if (!_dragManView) {
            return;
        }
        self.targetLine = [TaskUtil findLineWithSender:sender hallLines:_hallLines inView:self.view];
        
        CGPoint location = [sender locationInView:self.view];
        //location.x -= selectedLine.collectionView.contentOffset.x;
        _dragManView.center = location;
        
        [self.view bringSubviewToFront:_dragManView];
        
//        //indicate
//        CGPoint locationInCollectionView = [sender locationInView:self.targetLine.collectionView];
//        NSIndexPath *currentIndexPath = [self.targetLine.collectionView indexPathForItemAtPoint:locationInCollectionView];
//        self.targetLine.indicatePath = currentIndexPath;
        
        //挪到哪个line，高亮
        [TaskUtil highlightLine:self.targetLine hallLines:_hallLines];
        //自动滚动视图
        [self autoScrollViews];
    }
    
    if (sender.state == UIGestureRecognizerStateCancelled
        || sender.state == UIGestureRecognizerStateFailed
        || sender.state == UIGestureRecognizerStateEnded)
    {
        _isDragging = NO;
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(autoScrollViews) object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(autoScroll) object:nil];
        
        //清楚高亮
        [TaskUtil highlightLine:nil hallLines:_hallLines];
        
        if (!_dragManView) {
            NSLog(@"丢失dragView");
            return;
        }
        
        //查找目标队列
        self.targetLine = [TaskUtil findLineWithSender:sender hallLines:_hallLines inView:self.view];
        
        CGPoint locationInCollectionView = [sender locationInView:self.targetLine.collectionView];
        NSLog(@"locationInCollectionViewX:%lf",locationInCollectionView.x);
        
        NSIndexPath *selectedIndex = [self.targetLine.collectionView indexPathForItemAtPoint:locationInCollectionView];
        NSLog(@"selectedIndexX:%zd",selectedIndex.row);
        
        //如果目标队列是禁止拖入状态 重置目标队列
        if (self.targetLine.disbaleDraggingIn) {
            [self showBarMessage:[NSString stringWithFormat:@"%@ 已禁止拖入",self.targetLine.hall.hallName]];
            NSLog(@"禁止拖入");
            self.targetLine = nil;
        }
        //        //未分配队列
        //        if (self.targetLine.index == 0)
        //        {
        //            self.targetLine = self.sourceLine;
        //        }
        
        //处理拖到队列中  并且拖拽到左右边界 重置selectedIndex 到首尾
        NSInteger numCount = [self.targetLine.collectionView  numberOfItemsInSection:0];
        CGFloat locationInCollectionX = [self.view.superview convertPoint:_dragManView.center toView:self.targetLine.collectionView].x;
        CGFloat locationInCollectionY = [self.view.superview convertPoint:_dragManView.center toView:self.targetLine.collectionView].y;
        
        NSLog(@"locationInCollectionX:%f",locationInCollectionX);
        CGFloat leftTargetX = [self.targetLine.superview convertPoint:self.targetLine.collectionView.frame.origin toView:self.view].x;
        
        if (locationInCollectionX > numCount/2 * _dragManView.width) {
            selectedIndex = [NSIndexPath indexPathForRow:numCount inSection:0];
            if(numCount > 11 && locationInCollectionY<_dragManView.height){
                selectedIndex = [NSIndexPath indexPathForRow:11 inSection:0];
            }
        }
        
        if (numCount>11 && locationInCollectionY>_dragManView.height && locationInCollectionX > MIN(numCount-11, numCount) * _dragManView.width) {
            selectedIndex = [NSIndexPath indexPathForRow:numCount inSection:0];
        }
        
        if ([sender locationInView:self.view].x < leftTargetX) {
            selectedIndex = [NSIndexPath indexPathForRow:0 inSection:0];
        }
        
        if(!self.sourceLine){
            NSLog(@"丢失 sourceLine");
        }
        
        //没拖到队列上的情况 或者拖到了禁止拖入队列  或者队列名称与id为空 不操作 还原到原始队列
        if(!self.targetLine || !selectedIndex || !self.targetLine.hall.hallName)
        {
            NSLog(@"_dragManView.sourceIndexPath:%zd",_dragManView.sourceIndexPath.row);
            selectedIndex = _dragManView.sourceIndexPath;
            self.targetLine = self.sourceLine;
        }
        
        //如果有目标selected IndexPath 并且有目标队列,并且目标队列有salemanlist
        if (selectedIndex && self.targetLine) {
            NSLog(@"selectedIndex.row:%zd",selectedIndex.row);

            //目标位置的id
            _dragManView.targetIndexPath = selectedIndex;
            //插入队列数据源
           
            if (self.targetLine.hall.salemanlist && _dragManView.man)
            {
                [self.targetLine.collectionView performBatchUpdates:^{
                    [self.targetLine.hall.salemanlist insertObject:_dragManView.man
                                                           atIndex:selectedIndex.item];
                    [self.targetLine.collectionView insertItemsAtIndexPaths:@[selectedIndex]];
                } completion:^(BOOL finished) {
                    NSLog(@"插入后计:%zi", self.targetLine.hall.salemanlist.count);
                    [self.targetLine.collectionView reloadItemsAtIndexPaths:@[selectedIndex]];
                    //[selectedLine.collectionView reloadData];
                }];
                
            }
            //服务器数据操作
            if(!self.targetLine.disbaleDraggingIn){
                if (_dragManView.man.semployeeid && self.targetLine.hall.hallName)
                {
                    if (self.sourceLine.index != self.targetLine.index) {
                        //BUG #36396::【客户体验】【任务看板】，将销售顾问拖拽到后，显示等待时长。
                        _dragManView.man.dtaskbegin = @"0:0";
                        [self changeManAndHall:self.sourceLine
                                     andTarget:self.targetLine
                                           and:_dragManView
                                  addReception:YES];
                    }else{
                        [self changeManAndHall:self.sourceLine
                                     andTarget:self.targetLine
                                           and:_dragManView
                                  addReception:NO];
                    }
                   
                }else{
                    NSLog(@"数据不全 不能同步数据");
                }
            }else{
                NSLog(@"禁止拖入队列不交换服务器数据");
            }
            
        }
        [_dragManView removeFromSuperview];
        _dragManView = nil;
    }
    
    
}
/**
 *  @author Jakey, 15-12-10 11:12:20
 *
 *  @brief  超出边界 自动滚动
 */
-(void)autoScrollViews{
    int oneRowCount = self.targetLine.collectionView.width/_dragManView.frame.size.width;
    
    CGFloat leftTargetX = [self.targetLine.superview convertPoint:self.targetLine.collectionView.frame.origin toView:self.view].x;
    CGFloat rightTargetX = leftTargetX +self.targetLine.collectionView.width;
    CGFloat leftSourceX = [self.sourceLine.superview convertPoint:self.sourceLine.collectionView.frame.origin toView:self.view].x;

    //向左滑动
    if ((_dragManView.frame.origin.x < leftTargetX) && [self.targetLine.collectionView numberOfItemsInSection:0]>oneRowCount) {
        _dragManView.direction = DragDirectionLeft;
        NSLog(@"左");
        [self autoScroll];
    }
    if((CGRectGetMaxX(_dragManView.frame)>rightTargetX) && [self.targetLine.collectionView numberOfItemsInSection:0]>oneRowCount){
        _dragManView.direction = DragDirectionRight;
        NSLog(@"右");
        [self autoScroll];
    }
    
    //上下滚动
    if((_dragManView.frame.origin.y  < self.scrollPanel.frame.origin.y) &&(_dragManView.frame.origin.x>leftSourceX) && (CGRectGetMaxY(_dragManView.frame)  > self.scrollPanel.frame.origin.y)){
        _dragManView.direction = DragDirectionUp;
        NSLog(@"上");
        [self autoScroll];
    }
    if(_dragManView.frame.origin.y + _dragManView.frame.size.height > self.scrollPanel.frame.size.height + self.scrollPanel.frame.origin.y){
        _dragManView.direction = DragDirectionDown;
        NSLog(@"下");
        
        [self autoScroll];
    }
    
    
    
}
-(void)autoScroll{
    
    CGPoint next;
    switch (_dragManView.direction) {
        case DragDirectionUp:
        {
            next = CGPointMake(self.scrollPanel.contentOffset.x, self.scrollPanel.contentOffset.y-10);
            if (next.y<0)
            {
                next.y=0;
                return;
            }
        }
            break;
        case DragDirectionDown:
        {
            next = CGPointMake(self.scrollPanel.contentOffset.x, self.scrollPanel.contentOffset.y+10);
            if (self.scrollPanel.contentOffset.y > self.scrollPanel.contentSize.height  -self.scrollPanel.height)
            {
                next.y  = self.scrollPanel.contentSize.height  -self.scrollPanel.height;
                return;
            }
        }
            break;
        case DragDirectionLeft:
        {
            next = CGPointMake(self.targetLine.collectionView.contentOffset.x-10,self.targetLine.collectionView.contentOffset.y);
            if (next.x<0)
            {
                next.x = 0;
                return;
            }
        }
            break;
        case DragDirectionRight:
        {
            next = CGPointMake(self.targetLine.collectionView.contentOffset.x+10,self.targetLine.collectionView.contentOffset.y);
            if (next.x > [self.targetLine.hall.salemanlist count] * 80)
            {
                next.x = [self.targetLine.hall.salemanlist count] * 80;
                return;
            }
            
        }
            break;
        default:
        {
            NSLog(@"no direction");
        }
            break;
    }
    NSLog(@"next:%@", NSStringFromCGPoint(next));
    //    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(autoScroll) object:nil];
    
    if (_dragManView.direction == DragDirectionUp || _dragManView.direction == DragDirectionDown) {
        self.scrollPanel.contentOffset = next;
        [self performSelector:@selector(autoScrollViews) withObject:nil afterDelay:0.2];
    }else{
        self.targetLine.collectionView.contentOffset = next;
        [self performSelector:@selector(autoScrollViews) withObject:nil afterDelay:0.1];
        
    }
    
}
#pragma mark-- button action
//接待完毕按钮点击
- (IBAction)receptionDoneTouched:(id)sender {
    [self receptionDone:nil];
}
/**
 *  @author Jakey, 16-02-23 09:02:31
 *
 *  接待完毕
 *
 *  @param aReception 传一个客户接待 为空手动获取下
 */
-(void)receptionDone:(CustomerReception*)aReception{
    if(![AppDelegate APP].rootViewController.clientRootViewController.isRecepting){
        if (aReception)
        {
            [[AppDelegate APP].rootViewController.clientRootViewController presentAddReception:aReception type:ClientReceptionTypeTaskBoardConsulantAdd];

        }else{
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            [CustomerReception getReceptionCollectCust:^(CustomerReception *aReception) {
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                if (aReception && ![aReception.completeFlag boolValue]) {
                    [[AppDelegate APP].rootViewController.clientRootViewController presentAddReception:aReception type:ClientReceptionTypeTaskBoardConsulantAdd];
                }
                
            } Failure:^(NSError *error) {
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                
            }];
        }
        
    }else{
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"您有正在进行的客户接待!"];
        [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            
        }];
        [alert show];
    }

}
//展厅分组按钮点击
- (IBAction)groupButtonTouched:(SelectButton*)sender {
    __weak typeof(self) weakSelf = self;
    PopoverSearchController *search =   [self showSearchSelectController:sender withData:_groupNameArray selectItem:^(id item, NSString *key, NSString *value) {
        if (item != [NSNull null] && [item hasKey:@"key"]) {
            sender.key = @"runlin_dsps_splace";
            sender.value =  @"全部展厅";
        }else{
            if (item  == [NSNull null]) {
                sender.key = @"";
                sender.value =@"";
            }else{
                sender.key = [item stringForKey:@"hallName"]?:@"";
                sender.value = [item stringForKey:@"hallName"]?:@"";
            }
        }
        [weakSelf loadPanelList:nil];
    }];
    [search hiddenSearchBar:YES];
    search.contentSize = CGSizeMake(170, 200);
    [search titleForSelectSearchItem:^NSString *(NSInteger index, id item) {
        if (item  == [NSNull null]) {
            return @"";
        }
        return [item stringForKey:@"hallName"]?:@"";
    }];
    
}
//老客户查重
- (IBAction)oldCustomerButtonTouched:(id)sender {
    __weak typeof(self) weakSelf = self;

    [CBTracking trackEvent:@"首页客户接待_查号"];
    TaskBoardDuplicateViewController *duplicate = [[TaskBoardDuplicateViewController alloc]init];
    [duplicate taskBoardDuplicateDone:^(NSString *mobile,id data) {
        //客户接待和客户选择界面
        SearchOldCustomeViewController *show = [[SearchOldCustomeViewController alloc] initWithMobile:mobile];
        show.customerList = data;
        [show searchCustomerSelectOne:^(BOOL isCustomer, id model) {
            
        }];
        [weakSelf presentModelDetail:show];
        
     }];
    [self presentModelDetail:duplicate];
}
//手动刷新任务看板
- (IBAction)manualRefreshTouched:(id)sender {
    [CBTracking trackEvent:@"首页客户接待_其他"];
    
    [self buildMessageCenter:YES];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadPanelList:) object:nil];
    [self performSelector:@selector(loadPanelList:) withObject:nil afterDelay:0];
    
    if ([AppDelegate APP].user.role == UserRoleConsultant) {
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadAssignStatus) object:nil];
        [self performSelector:@selector(loadAssignStatus) withObject:nil afterDelay:0];
        
    }else if ([AppDelegate APP].user.role == UserRoleReceptionist){
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadAssignStatus) object:nil];
    }else{
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadAssignStatus) object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadPanelList:) object:nil];
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
   
}
//分配按钮点击
- (IBAction)assignButtonTouched:(id)sender {
    TaskAssignViewController *assign = [[TaskAssignViewController alloc]init];
    [self.navigationController pushViewController:assign animated:YES];
}
//初始化按钮点击
- (IBAction)InitButtonTouched:(id)sender {
//    __weak typeof(self) weakSelf = self;
    [CBTracking trackEvent:@"首页客户接待_其他"];
    JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"是否初始化顾问到等待队列?"];
    [alert addButtonWithTitle:@"否"];
    [alert addCommonButtonWithTitle:@"是" handler:^(JKAlertItem *item) {
        [TaskBoard reResetSaleMans:^(NSDictionary *collection) {
            if ([collection boolForKey:@"success"]) {
//                [weakSelf loadPanelList:nil];
                [JKAlert showMessage:@"初始化成功"];
            } else
            {
                [JKAlert showMessage:@"初始化失败"];
            }

        } Failure:^(NSError *error) {
            
        }];
    }];
    [alert show];
}

-(void)showBarMessage:(NSString*)message{
    self.notiLabel.text = message;
    self.notiLabel.transform=  CGAffineTransformIdentity;
    [self hiddenBarMessage:[NSNumber numberWithBool:NO]];
    [UIView animateWithDuration:0.5 animations:^{
        self.notiLabel.transform = CGAffineTransformMakeTranslation(0,CGRectGetHeight(self.notiLabel.frame));
    } completion:^(BOOL finished) {
        [self performSelector:@selector(hiddenBarMessage:) withObject:[NSNumber numberWithBool:YES] afterDelay:1.5];
    }];
}
-(void)hiddenBarMessage:(NSNumber*)animated{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hiddenBarMessage:) object:[NSNumber numberWithBool:YES]];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hiddenBarMessage:) object:[NSNumber numberWithBool:NO]];
    
    if ([animated boolValue]) {
        [UIView animateWithDuration:0.5 animations:^{
            self.notiLabel.transform=  CGAffineTransformIdentity;
        }];
    }else{
        self.notiLabel.transform=  CGAffineTransformIdentity;
        
    }
}
#pragma -present

-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
    [self presentDSPAPopup:modelDetailViewController
      parentViewController:self
              touchCallBack:nil
                  haveMask:YES
          includeNavgation:NO
                  alignTop:NO];
}
#pragma -mark ----interface data  接口请求
-(void)changeManAndHall:(TaskLineView*)sourceLine
              andTarget:(TaskLineView*)targetLine
                    and:(TaskDragManView*)dragManView
           addReception:(BOOL)addReception

{
    /*
     startID	顾问移动位置前的展板CODE
     endID	顾问移动位置后的展板CODE
     startSalemenID	移动位置前的展板中全部的顾问ID
     endSalemenID	移动位置后的展板中全部的顾问ID
     draggedID	被移动顾问的ID
     draggedName	被移动顾问的姓名
     */
    __weak typeof(self) weakSelf = self;

    NSString *startSalemenID = [sourceLine.hall allSaleManListString];
    NSString *endSalemenID= [targetLine.hall allSaleManListString];

     [TaskBoard moveBtnWithSplace:_hallNameSelectButton.key?:@"runlin_dsps_splace"
                          startID:sourceLine.hall.dCode
                        withEndID:targetLine.hall.dCode
               withStartSalemenID:startSalemenID
                 withEndSalemenID:endSalemenID
                    withDraggedID:dragManView.man.semployeeid
                  withDraggedName:dragManView.man.semployeename
                          Success:^(NSDictionary *collection) {
                              [CBTracking trackEvent:@"首页客户接待_新建客户接待"];
                              //    //更改成功后socket会发过来消息 也会刷新
                              [NSObject cancelPreviousPerformRequestsWithTarget:weakSelf selector:@selector(loadPanelList:) object:nil];
                              [weakSelf performSelector:@selector(loadPanelList:) withObject:nil];
                              //客户接待中才弹出页面
                              
                              if ((weakSelf.targetLine.index ==1) && addReception) {
                                  //弹出前台新建客户接待编辑页
                                  CustomerReception *reception = [[CustomerReception alloc]init];
                                  reception.createdBy = dragManView.man.semployeeid;
                                  reception.createdByName = dragManView.man.semployeename;
                                  reception.dragManID = dragManView.man.semployeeid;
                                  reception.endID = targetLine.hall.dCode;

                                  [[AppDelegate APP].rootViewController.clientRootViewController presentAddReception:reception type:ClientReceptionTypeTaskBoardReceptionAddAssign];

                              }else{
//在目前‘客户接待（前台）’中，拖拽销售顾问会显示该销售顾问的等待时间，现需增加拖拽销售顾问的累积次数，以数字方式在头像右下角位置进行显示（注：只统计拖拽到‘接待中’看板时才会统计拖拽次数，其他看板则不加入统计）。
                                  
//                                  [TaskBoard saveHistory:@{@"empId":dragManView.man.semployeeid?:@"",@"empName":dragManView.man.semployeename?:@"",@"taskState":dragManView.man.splace?:@""} Success:^(NSDictionary *collection) {
//                                      
//                                  } Failure:^(NSError *error) {
//                                      
//                                  }];
                              }
                              
                          } Failure:^(NSError *error) {
                              [NSObject cancelPreviousPerformRequestsWithTarget:weakSelf selector:@selector(loadPanelList:) object:nil];
                              [weakSelf performSelector:@selector(loadPanelList:) withObject:nil];
                          }];

}

@end
