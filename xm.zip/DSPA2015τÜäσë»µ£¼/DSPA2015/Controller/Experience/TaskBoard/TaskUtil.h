//
//  TaskUtil.h
//  DSPA2015
//
//  Created by Jakey on 15/12/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TaskLineView.h"

@interface TaskUtil : NSObject
/**
 *  @author Jakey, 15-12-10 11:12:35
 *
 *  @brief  寻找拖拽点所在collectionview line
 *
 *
 *  @return return TaskLineView
 */
+(TaskLineView*)findLineWithSender:(UILongPressGestureRecognizer *)sender
                         hallLines:(NSArray*)hallLines
                            inView:(UIView*)view;

+ (void)highlightLine:(TaskLineView *)selectedLine
            hallLines:(NSArray*)hallLines;
@end
