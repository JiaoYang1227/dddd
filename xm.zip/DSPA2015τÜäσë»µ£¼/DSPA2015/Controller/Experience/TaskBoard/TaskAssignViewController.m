//
//  TaskAssignViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskAssignViewController.h"
#import "TaskBoard.h"
#import "TaskHall.h"
#import "TaskSaleman.h"

#import "TaskLineView.h"
#import "TaskCell.h"
#import "TaskSaleman.h"

#import "TaskUtil.h"
@interface TaskAssignViewController ()

@end

@implementation TaskAssignViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self getHallsSalemenList:^(NSArray *hallList) {
        [self layerHallLine:hallList];
    }];
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGesture:)];
    [self.view addGestureRecognizer:longPressGesture];

    self.title = @"客户接待分配(首页)";
}

#define CELL_HIGHT 90
/**
 *  @author Jakey, 15-12-10 11:12:43
 *
 *  @brief  布局所有存在的展厅
 *
 *  @param hallData 展厅实体数组
 */
- (void)layerHallLine:(NSArray*)hallData
{
    __weak typeof(self) weakSelf = self;
    NSMutableArray *tempHallLines = [NSMutableArray array];
    for (int index = 0 ;index < [hallData count] ;index++) {
        TaskHall *aHall = [hallData objectWithIndex:index];
        TaskLineView *line;
        //未分配展厅 固定在顶部
        if (index == 0) {
            line = [[TaskLineView alloc] initWithFrame:CGRectMake(0, 0, self.unAssignPanel.frame.size.width, CELL_HIGHT) andMode:TaskLineViewModeAssignFloating];
            line.disbaleDraggingIn = YES;
            line.iconImage = @"task_hall_status_icon_0.png";
            //禁止从其他地方拖回来
            [self.unAssignPanel addSubview:line];
        }else
        {
            line = [[TaskLineView alloc] initWithFrame:CGRectMake(0, CELL_HIGHT * (index-1), self.scrollPanel.frame.size.width, CELL_HIGHT) andMode:TaskLineViewModeEdit];
            line.hall = aHall;
            line.iconImage = @"task_hall_status_icon_default.png";
            [self.scrollPanel addSubview:line];
        }
        line.hall = aHall;
        line.index = index;
        [tempHallLines addObject:line];

        [line didEditdHallName:^(TaskLineView *line, NSString *name, NSInteger index, id item) {
            [weakSelf modifyNameHandle:line newName:name];
        }];
    }
    self.scrollPanel.contentSize = CGSizeMake(self.scrollPanel.width, CELL_HIGHT*[hallData count] -1+1);
    self.hallLines = [tempHallLines mutableCopy];
    //新增一个空line
    _tempHallLine = [self addHallline:nil];

}
/**
 *  @author Jakey, 15-12-10 11:12:19
 *
 *  @brief  增加一行空的展厅 用于新建
 *
 *  @param hall 展厅实体
 *
 *  @return TaskLineView
 */
-(TaskLineView*)addHallline:(TaskHall*)hall{
    __weak typeof(self) weakSelf = self;
    TaskLineView *hallView = [[TaskLineView alloc] initWithFrame:CGRectMake(0, CELL_HIGHT * ([self.hallLines count] -1), self.view.frame.size.width, CELL_HIGHT) andMode:TaskLineViewModeEdit];
    hallView.hall = hall?:[[TaskHall alloc] init];
    [self.scrollPanel addSubview:hallView];
    self.scrollPanel.contentSize = CGSizeMake(self.scrollPanel.width, CELL_HIGHT*[self.hallLines count] -1+1);
    [hallView didEditdHallName:^(TaskLineView *line, NSString *name, NSInteger index, id item) {
        [weakSelf modifyNameHandle:line newName:name];
    }];
    return hallView;
}
/**
 *  @author Jakey, 15-12-10 11:12:50
 *
 *  @brief  当展厅名称改变时候的处理
 *
 *  @param hallView 展厅view
 *  @param newName  变换的展厅名称
 */
-(void)modifyNameHandle:(TaskLineView *)hallView newName:(NSString*)newName{
    if (!newName || [[newName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""]) {
        [hallView updateButtonIcon];
        [JKAlert showMessage:@"展厅名称不能为空"];
        return;
    }
    if ([newName isEqualToString:@"未分配的销售顾问"] || [newName isEqualToString:@"全部展厅"]) {
        [hallView updateButtonIcon];
        [JKAlert showMessage:@"不可输入重复的展厅名称"];
        return;
    }
    
    if (hallView.hall.hallId) {
        if([newName isEqualToString:hallView.hall.hallName]){
            //未更改直接返回
            return;
        }
        [self updateHall:hallView withName:newName];
    }else{
        [self createHall:newName];
    }

}

#pragma -mark ----Gesture Handle

/**
 *  @author Jakey, 15-12-10 11:12:01
 *
 *  @brief  长按手势处理
 *
 *  @param sender <#sender description#>
 */
- (void)handleLongPressGesture:(UILongPressGestureRecognizer *)sender {

    if (sender.state == UIGestureRecognizerStateBegan)
    {
        self.sourceLine = [TaskUtil findLineWithSender:sender hallLines:_hallLines inView:self.view];
        CGPoint locationInCollectionView = CGPointZero;
        if (self.sourceLine==nil)
        {
            NSLog(@"没有按在一个collectionView上。");
            return;
        }else
        {
            locationInCollectionView = [sender locationInView:self.sourceLine.collectionView];
        }
       NSLog(@"%@ is selected", self.sourceLine.hall.hallName);
        
        //找到Cell index
        NSIndexPath *selectedIndex = [self.sourceLine.collectionView indexPathForItemAtPoint:locationInCollectionView];
        if (selectedIndex)
        {
            _dragManView = [[TaskDragManView alloc]init];
            _dragManView.backgroundColor = [UIColor redColor];
            _dragManView.sourceIndexPath = selectedIndex;

            //抽出cell view
            TaskCell *cell = (TaskCell *)[self.sourceLine.collectionView cellForItemAtIndexPath:_dragManView.sourceIndexPath];
            _dragManView.man = [self.sourceLine.hall.salemanlist objectWithIndex:_dragManView.sourceIndexPath.row];
            _dragManView.frame = cell.bounds;
            [_dragManView cloneViewsFromTaskCell:cell];
            [self.view addSubview:_dragManView];

            //不移除cell了
            NSLog(@"move a aman:%@ atIndex:%zi",_dragManView.man, _dragManView.sourceIndexPath.row);
            if (self.sourceLine.hall.salemanlist)
            {
                [self.sourceLine.hall.salemanlist removeObjectAtIndex:_dragManView.sourceIndexPath.row];
                [self.sourceLine.collectionView performBatchUpdates:^{
                    [self.sourceLine.collectionView deleteItemsAtIndexPaths:@[_dragManView.sourceIndexPath]];
                } completion:^(BOOL finished) {
                    NSLog(@"删除后计：:%zi", self.sourceLine.hall.salemanlist.count);
                    [self.sourceLine.collectionView reloadData];
                }];
            }
            _dragManView.center = [sender locationInView:self.view];
            [self.view bringSubviewToFront:_dragManView];
        }else
        {
            NSLog(@"没找按下的cell Index.");
            return;
        }
    }
    
    if (sender.state == UIGestureRecognizerStateChanged)
    {
        if (!_dragManView) {
            return;
        }
        self.targetLine = [TaskUtil findLineWithSender:sender hallLines:_hallLines inView:self.view];

        CGPoint location = [sender locationInView:self.view];
        //location.x -= selectedLine.collectionView.contentOffset.x;
        _dragManView.center = location;

        [self.view bringSubviewToFront:_dragManView];

        //挪到哪个line，高亮
        [TaskUtil highlightLine:self.targetLine hallLines:_hallLines];
        //自动滚动视图
        [self autoScrollViews];
    }
    
    if (sender.state == UIGestureRecognizerStateCancelled
        || sender.state == UIGestureRecognizerStateFailed
        || sender.state == UIGestureRecognizerStateEnded)
    {
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(autoScrollViews) object:nil];
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(autoScroll) object:nil];

        //清楚高亮
        [TaskUtil highlightLine:nil hallLines:_hallLines];
       
        if (!_dragManView) {
            NSLog(@"丢失dragView");
            return;
        }
        
        //查找目标队列
        self.targetLine = [TaskUtil findLineWithSender:sender hallLines:_hallLines inView:self.view];
        
        CGPoint locationInCollectionView = [sender locationInView:self.targetLine.collectionView];
        NSLog(@"locationInCollectionViewX:%lf",locationInCollectionView.x);
        
        NSIndexPath *selectedIndex = [self.targetLine.collectionView indexPathForItemAtPoint:locationInCollectionView];
        NSLog(@"selectedIndexX:%zd",selectedIndex.row);

        //如果目标队列是禁止拖入状态 重置目标队列
        if (self.targetLine.disbaleDraggingIn) {
            [self showBarMessage:[NSString stringWithFormat:@"%@ 展厅禁止拖入",self.targetLine.hall.hallName]];

            self.targetLine = nil;
        }
        
//        //未分配队列
//        if (self.targetLine.index == 0)
//        {
//            self.targetLine = self.sourceLine;
//        }

        //处理拖到队列中  并且拖拽到左右边界 重置selectedIndex 到首尾
        NSInteger numCount = [self.targetLine.collectionView  numberOfItemsInSection:0];
        CGFloat locationInCollectionX = [self.view.superview convertPoint:_dragManView.center toView:self.targetLine.collectionView].x;
        NSLog(@"locationInCollectionX:%zd",locationInCollectionX);
        CGFloat leftTargetX = [self.targetLine.superview convertPoint:self.targetLine.collectionView.frame.origin toView:self.view].x;
        if (locationInCollectionX > numCount * _dragManView.width) {
            selectedIndex = [NSIndexPath indexPathForRow:numCount inSection:0];
        }
        if ([sender locationInView:self.view].x < leftTargetX) {
            selectedIndex = [NSIndexPath indexPathForRow:0 inSection:0];
        }
        
        if(!self.sourceLine){
            NSLog(@"丢失 sourceLine");
        }

        //没拖到队列上的情况 或者拖到了禁止拖入队列  或者队列名称与id为空 不操作 还原到原始队列
        if(!self.targetLine || !selectedIndex || !self.targetLine.hall.hallName)
        {
            selectedIndex = _dragManView.sourceIndexPath;
            self.targetLine = self.sourceLine;
        }
        
        //如果有目标selected IndexPath 并且有目标队列,并且目标队列有salemanlist
        if (selectedIndex && self.targetLine) {
            //插入队列数据源
            if (self.targetLine.hall.salemanlist && _dragManView.man)
            {
                [self.targetLine.collectionView performBatchUpdates:^{
                    [self.targetLine.hall.salemanlist insertObject:_dragManView.man
                                                           atIndex:selectedIndex.item];
                    [self.targetLine.collectionView insertItemsAtIndexPaths:@[selectedIndex]];
                } completion:^(BOOL finished) {
                    NSLog(@"插入后计:%zi", self.targetLine.hall.salemanlist.count);
                    [self.targetLine.collectionView reloadItemsAtIndexPaths:@[selectedIndex]];
                    //[selectedLine.collectionView reloadData];
                }];
                
            }
            //服务器数据操作
            if(!self.targetLine.disbaleDraggingIn){
                if (_dragManView.man.semployeeid && self.targetLine.hall.hallName)
                {
                    NSMutableDictionary *changeDic = [NSMutableDictionary dictionary];
                    [changeDic setObject:_dragManView.man.semployeeid?:@"" forKey:@"salemanID"];
                    //            [changeDic setObject:self.targetLine.hall.hallId?:@"" forKey:@"hallId"];
                    [changeDic setObject:self.targetLine.hall.hallName?:@"" forKey:@"hallName"];
                    [self changeHall:changeDic];
                }else{
                    NSLog(@"数据不全 不能同步数据");
                }
            }else{
                NSLog(@"禁止拖入队列不交换服务器数据");
            }

           
        }
       [_dragManView removeFromSuperview];
        _dragManView = nil;
    }
    
    
}
/**
 *  @author Jakey, 15-12-10 11:12:20
 *
 *  @brief  超出边界 自动滚动
 */
-(void)autoScrollViews{
    int oneRowCount = self.targetLine.collectionView.width/_dragManView.frame.size.width;

    CGFloat leftTargetX = [self.targetLine.superview convertPoint:self.targetLine.collectionView.frame.origin toView:self.view].x;
    CGFloat rightTargetX = leftTargetX +self.targetLine.collectionView.width;
    CGFloat leftSourceX = [self.sourceLine.superview convertPoint:self.sourceLine.collectionView.frame.origin toView:self.view].x;

    //向左滑动
    if ((_dragManView.frame.origin.x < leftTargetX) && [self.targetLine.collectionView numberOfItemsInSection:0]>oneRowCount) {
        _dragManView.direction = DragDirectionLeft;
        NSLog(@"左");
        [self autoScroll];
    }
    if((CGRectGetMaxX(_dragManView.frame)>rightTargetX) && [self.targetLine.collectionView numberOfItemsInSection:0]>oneRowCount){
        _dragManView.direction = DragDirectionRight;
        NSLog(@"右");
        [self autoScroll];
    }
    
    //上下滚动
    if((_dragManView.frame.origin.y  < self.scrollPanel.frame.origin.y) &&(_dragManView.frame.origin.x>leftSourceX) && (CGRectGetMaxY(_dragManView.frame)  > self.scrollPanel.frame.origin.y)){
        _dragManView.direction = DragDirectionUp;
        NSLog(@"上");
        [self autoScroll];
    }
    if(_dragManView.frame.origin.y + _dragManView.frame.size.height > self.scrollPanel.frame.size.height + self.scrollPanel.frame.origin.y){
        _dragManView.direction = DragDirectionDown;
        NSLog(@"下");
        
        [self autoScroll];
    }
    
}
-(void)autoScroll{
  
    CGPoint next;
    switch (_dragManView.direction) {
        case DragDirectionUp:
        {
            next = CGPointMake(self.scrollPanel.contentOffset.x, self.scrollPanel.contentOffset.y-10);
            if (next.y<0)
            {
                next.y=0;
                return;
            }
        }
            break;
        case DragDirectionDown:
        {
            next = CGPointMake(self.scrollPanel.contentOffset.x, self.scrollPanel.contentOffset.y+10);
            if (self.scrollPanel.contentOffset.y > self.scrollPanel.contentSize.height  -self.scrollPanel.height)
            {
                next.y  = self.scrollPanel.contentSize.height  -self.scrollPanel.height;
                return;
            }
        }
            break;
        case DragDirectionLeft:
        {
             next = CGPointMake(self.targetLine.collectionView.contentOffset.x-10,self.targetLine.collectionView.contentOffset.y);
             if (next.x<0)
             {
                 next.x = 0;
                 return;

             }
        }
            break;
        case DragDirectionRight:
        {
            next = CGPointMake(self.targetLine.collectionView.contentOffset.x+10,self.targetLine.collectionView.contentOffset.y);
           if (next.x > [self.targetLine.hall.salemanlist count] * 80)
             {
                 next.x = [self.targetLine.hall.salemanlist count] * 80;
                 return;

             }

        }
            break;
        default:
        {
            NSLog(@"no direction");
        }
            break;
    }
    NSLog(@"next:%@", NSStringFromCGPoint(next));
//    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(autoScroll) object:nil];

    if (_dragManView.direction == DragDirectionUp || _dragManView.direction == DragDirectionDown) {
        self.scrollPanel.contentOffset = next;
        [self performSelector:@selector(autoScrollViews) withObject:nil afterDelay:0.2];
    }else{
        self.targetLine.collectionView.contentOffset = next;
       [self performSelector:@selector(autoScrollViews) withObject:nil afterDelay:0.1];

    }
    
}


-(void)showBarMessage:(NSString*)message{
    self.notiLabel.text = message;
    self.notiLabel.transform=  CGAffineTransformIdentity;
    [self hiddenBarMessage:[NSNumber numberWithBool:NO]];
    [UIView animateWithDuration:0.5 animations:^{
        self.notiLabel.transform = CGAffineTransformMakeTranslation(0,CGRectGetHeight(self.notiLabel.frame));
    } completion:^(BOOL finished) {
        [self performSelector:@selector(hiddenBarMessage:) withObject:[NSNumber numberWithBool:YES] afterDelay:1.5];
    }];
}
-(void)hiddenBarMessage:(NSNumber*)animated{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hiddenBarMessage:) object:[NSNumber numberWithBool:YES]];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hiddenBarMessage:) object:[NSNumber numberWithBool:NO]];

    if ([animated boolValue]) {
        [UIView animateWithDuration:0.5 animations:^{
            self.notiLabel.transform=  CGAffineTransformIdentity;
        }];
    }else{
        self.notiLabel.transform=  CGAffineTransformIdentity;

    }
}
#pragma -mark ----interface data  接口请求
//获取展厅中顾问
- (void)getHallsSalemenList:(void (^)(NSArray *hallList))success{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [TaskBoard getHallsSalemenList:^(NSArray *hallList) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (success) {
            success(hallList);
        }
        } Failure:^(NSError *error) {
          [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
     
}
//创建展厅
-(void)createHall:(NSString*)hallName{
    TaskHall *ahall = [[TaskHall alloc]init];
    ahall.hallName = hallName;
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [TaskBoard editHall:ahall Success:^(NSDictionary *collection) {
        if ([collection boolForKey:@"sucess"]) {
            ahall.hallId = [collection stringForKey:@"hallID"];
            NSLog(@"add hall id:%@",[collection stringForKey:@"hallID"]);
            _tempHallLine.hall = ahall;
            _tempHallLine.index = [self.hallLines count];
            [self.hallLines addObject:_tempHallLine];
            [_tempHallLine updateButtonIcon];
            _tempHallLine = [self addHallline:nil];
            [_tempHallLine updateButtonIcon];
            
        }else{
            NSLog(@"新建展厅失败");
            NSString *errString = [collection errorMessages];
            [JKAlert showMessage:errString];
            //BUG #35976::【DSPA】【客户体验】【任务看板】点击最后“展厅列表”按钮，点击【添加看板】输入超过8个字符，提示“展厅名称不能大于8个字符”
            [_tempHallLine updateButtonIcon];
            //            textFieldTemp.enabled = YES;
            //            [textFieldTemp becomeFirstResponder];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        //        [self loadDataAgain];
    } Failure:^(NSError *error) {
        [_tempHallLine updateButtonIcon];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        
    }];
    

}
//更新展厅
-(void)updateHall:(TaskLineView*)lineView  withName:(NSString*)name{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    TaskHall *modfiyHall = [lineView.hall copy];
    modfiyHall.hallName = name;
    [TaskBoard editHall:modfiyHall Success:^(NSDictionary *collection) {
        if ([collection boolForKey:@"sucess"]) {
            NSLog(@"更新展厅成功");
            lineView.hall = modfiyHall;
        }else{
            [lineView updateButtonIcon];
            NSLog(@"更新展厅失败");
            NSString *errString = [collection errorMessages];
            [JKAlert showMessage:errString];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];

    }];
    
}
//分配展厅
-(void)changeHall:(NSDictionary*)changeDic{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [TaskBoard updateTaskLeisure:changeDic Success:^(NSDictionary *collection)
    {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if ([collection boolForKey:@"success"])
        {
            NSLog(@"拖动顾问更新展厅成功");
        }else{
            NSLog(@"拖动顾问更新展厅失败");
            NSString *errString = [collection errorMessages];
            NSLog(@"%@",errString);
            //[CRMUtil showAlertViewWithTitle:@"提示" message:errString delegate:nil];
        }
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];

    }];
}

@end
