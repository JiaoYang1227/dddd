//
//  TaskAssignViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "TaskLineView.h"
#import "TaskDragManView.h"


@interface TaskAssignViewController : BaseViewController<UITextFieldDelegate>
{
    TaskLineView *_tempHallLine;
    TaskDragManView *_dragManView;
}
@property (weak, nonatomic) IBOutlet UIView *unAssignPanel;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollPanel;
@property (strong, nonatomic) NSMutableArray *hallLines;

////拖动的头像所在的源展厅Line
@property (strong, nonatomic) TaskLineView *sourceLine;
@property (strong, nonatomic) TaskLineView *targetLine;

@property (weak, nonatomic) IBOutlet UILabel *notiLabel;

@end
