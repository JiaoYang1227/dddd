//
//  TaskUtil.m
//  DSPA2015
//
//  Created by Jakey on 15/12/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskUtil.h"
@implementation TaskUtil
+(TaskLineView*)findLineWithSender:(UILongPressGestureRecognizer *)sender
                         hallLines:(NSArray*)hallLines
                            inView:(UIView*)view{
    //    for (int i=0; i<self.hallLines.count; i++) {
    //        TaskLineView *l = [self.hallLines objectWithIndex:i];
    //        CGPoint p = [sender locationInView:l.collectionView];
    //        p.x -= l.collectionView.contentOffset.x;
    //        NSLog(@"touch in :x%lf,y%lf",p.x,p.y);
    //
    //        if (CGRectContainsPoint(l.collectionView.frame, p)) {   //找到目标TaskLineView
    //           return  l;
    //        }
    //    }
    CGPoint pInView = [sender locationInView:view];
    //    NSLog(@"touch in :x%lf,y%lf",p.x,p.y);
    for (int i=0; i<hallLines.count; i++) {
        TaskLineView *l = [hallLines objectWithIndex:i];
        //        pInView.x -= l.collectionView.contentOffset.x;
        CGRect rect = [l.collectionView.superview convertRect:l.collectionView.frame toView:view];
        if (CGRectContainsPoint(rect, pInView)) {   //找到目标TaskLineView
            return  l;
        }
        //        //如果都没找到就放到最后一行
        //        if (i==self.hallLines.count-1 && pInView.y>l.origin.y) {
        //            return  l;
        //        }
        
    }
    
    
    return nil;
}

+ (void)highlightLine:(TaskLineView *)selectedLine
            hallLines:(NSArray*)hallLines
{
    
    for (int i=0; i<hallLines.count; i++) {
        TaskLineView *l = [hallLines objectWithIndex:i];
        l.backgroundColor = [UIColor clearColor];
    }
    
    if (selectedLine) {
        //        [selected setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"Task_lineBG.png"]]];
        if([[selectedLine.hall.hallName description] isEqualToString:@"等待排队"]){
            UIImage * buttonBackgroundImage = [[UIImage imageNamed:@"task_hall_over_waitbg.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0,25,0,25)];
            
            
            [selectedLine setBackgroundColor:[UIColor colorWithPatternImage:buttonBackgroundImage]];

        }else{
            [selectedLine setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"task_hall_over_bg.png"]]];
        }
    }
    if (selectedLine.disbaleDraggingIn) {
//        [selectedLine setBackgroundColor:[UIColor colorWithRed:0.702 green:0.000 blue:0.173 alpha:0.540]];
        
    }
}
@end
