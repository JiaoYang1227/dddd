//
//  TaskBoardViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "TaskSaleman.h"
#import "TaskHall.h"
#import "TaskLineView.h"
#import "TaskDragManView.h"
typedef NS_ENUM(NSUInteger, TaskBoardRole) {
    TaskBoardRoleUnknow,
    TaskBoardRoleReceptionist,
    TaskBoardRoleConsultant,
};
@interface TaskBoardViewController : BaseViewController
{
    __weak IBOutlet SelectButton *_hallNameSelectButton;

    //展厅分组
    NSMutableArray *_groupNameArray;
    TaskBoardRole _role;
    //line views
    NSMutableArray *_hallLines;
    TaskDragManView *_dragManView;
    
    BOOL _isDragging;
    
    JKAlert *_receptionAlert;

}
-(instancetype)initWithRole:(TaskBoardRole)role;
- (IBAction)groupButtonTouched:(id)sender;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollPanel;
@property (weak, nonatomic) IBOutlet UILabel *notiLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
//等待view
@property (weak, nonatomic) IBOutlet UIView *waitPanel;
@property(strong,nonatomic)  UIView *coverView;


#pragma mark -- RoleConsultant
@property (weak, nonatomic) IBOutlet UIButton *receptionButton;
- (IBAction)receptionDoneTouched:(id)sender;

#pragma mark -- RoleReceptionist
@property (weak, nonatomic) IBOutlet UIButton *assignButton;
@property (weak, nonatomic) IBOutlet UIButton *InitButton;
@property (weak, nonatomic) IBOutlet UIButton *oldCustomerButton;


- (IBAction)InitButtonTouched:(id)sender;
- (IBAction)assignButtonTouched:(id)sender;
- (IBAction)oldCustomerButtonTouched:(id)sender;
- (IBAction)manualRefreshTouched:(id)sender;

////拖动的头像所在的源展厅Line
@property (strong, nonatomic) TaskLineView *sourceLine;
@property (strong, nonatomic) TaskLineView *targetLine;
@end
