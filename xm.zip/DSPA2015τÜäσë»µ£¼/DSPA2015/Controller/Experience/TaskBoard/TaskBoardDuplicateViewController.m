//
//  TaskBoardDuplicateViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/12/14.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskBoardDuplicateViewController.h"
#import "TaskBoardViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "Validator.h"
#import "TMCache.h"

#import "TaskBoard.h"
@interface TaskBoardDuplicateViewController ()

@end

@implementation TaskBoardDuplicateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.textField.text = [[TMCache sharedCache]objectForKey:@"OLD_CUSTOMER"]?:@"";
    self.title = @"客户接待查重(首页)";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)dismissTouched:(id)sender {
   [self dismissDSPAPopup:^{
       
   }];
}
- (IBAction)numberClickAction:(UIButton *)sender {
    
    NSString *num = [NSString stringWithFormat:@"%zd",sender.tag];
  
    
    if (sender.tag == 12) {
        num = @"";
    }
    
    if (![num isEqualToString:@""] && ![num isEqualToString:@"."]) {
        NSString *str = [NSString stringWithFormat:@"%@%@",self.textField.text,num];
        if (str.length > 11) {
            return ;
        }
        self.textField.text = str;
    }else if([num isEqualToString:@""]){
        if (self.textField.text.length != 0){
           self.textField.text = [self.textField.text substringToIndex:self.textField.text.length -1];
        }
    }
    
}
-(void)taskBoardDuplicateDone:(TaskBoardDuplicateDone)taskBoardDuplicateDone{
    _taskBoardDuplicateDone = [taskBoardDuplicateDone copy];
}

- (IBAction)cleanTouched:(id)sender {
    self.textField.text = @"";
}
- (IBAction)okTouched:(id)sender {
    
    if ([Validator isMobile:self.textField.text]) {
        [[TMCache sharedCache] setObject:self.textField.text forKey:@"OLD_CUSTOMER"];
    }
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [TaskBoard getCustomerListInfo:self.textField.text Success:^(NSMutableArray *customer) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        [self dismissTouched:sender];
        if (_taskBoardDuplicateDone) {
            _taskBoardDuplicateDone(self.textField.text,customer);
        }
    } Failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        [self dismissTouched:sender];

    }];
}
@end
