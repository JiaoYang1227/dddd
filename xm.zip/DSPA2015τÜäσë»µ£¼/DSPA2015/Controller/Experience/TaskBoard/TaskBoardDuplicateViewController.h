//
//  TaskBoardDuplicateViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/12/14.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
typedef void(^TaskBoardDuplicateDone)(NSString *mobile,id data);
@interface TaskBoardDuplicateViewController : BaseViewController
{
    TaskBoardDuplicateDone _taskBoardDuplicateDone;
}
@property (weak, nonatomic) IBOutlet UITextField *textField;
- (IBAction)okTouched:(id)sender;
-(void)taskBoardDuplicateDone:(TaskBoardDuplicateDone)taskBoardDuplicateDone;
- (IBAction)cleanTouched:(id)sender;
@end
