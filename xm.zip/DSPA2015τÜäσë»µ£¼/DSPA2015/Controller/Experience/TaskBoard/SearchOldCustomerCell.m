//
//  SearchCustomerSelectCell.m
//  DSPA2015
//
//  Created by Jakey on 15/12/24.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "SearchOldCustomerCell.h"
#import "Customer.h"
#import "CustomerReception.h"
@implementation SearchOldCustomerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCell:(id)item{
    if ([item isKindOfClass:[Customer class]]) {
        Customer *i = (Customer*)item;
//        self.mobileLabel.text = i.custMobile;
        self.mobileLabel.text = [i.dormancy boolValue]?@"休眠":@"未休眠";
        self.nameLabel.text = i.custName;
        self.timeLabel.text = [DateManager date_YMDHMS_WithTimeIntervalSince1970:i.createDate];
        self.typeLabel.text = @"客户";
        self.ownnerLabel.text = i.ownerName;
    }
    if ([item isKindOfClass:[CustomerReception class]]) {
        CustomerReception *i = (CustomerReception*)item;
//        self.mobileLabel.text = i.mobile;
        self.mobileLabel.text = [i.transFlag boolValue]?@"已转化":@"未转化";
        self.nameLabel.text = i.collectCustName;
        self.timeLabel.text = [DateManager date_YMDHMS_WithTimeIntervalSince1970:i.collectDate];
        self.ownnerLabel.text = i.saleman;
        self.typeLabel.text = @"客户接待";
    }
}

@end
