//
//  TaskCell.h
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TaskLineView.h"
#import "RemoteImageView.h"
@interface TaskCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;                 //头像背景图片
@property (weak, nonatomic) IBOutlet RemoteImageView *personImageView;             //人物头像
@property (weak, nonatomic) IBOutlet UILabel     *personNameTitle;             //顾问名称
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UIButton *numButton;
-(void)configCell:(id)item  withMode:(TaskLineViewMode)mode;
//@property (weak, nonatomic) IBOutlet UIImageView *leftIndicate;
//@property (weak, nonatomic) IBOutlet UIImageView *rightIndicate;
@end
