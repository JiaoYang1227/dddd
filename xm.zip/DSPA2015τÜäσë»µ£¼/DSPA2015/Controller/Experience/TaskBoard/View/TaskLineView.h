//
//  TaskLineView.h
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TaskHall.h"
typedef NS_ENUM(NSUInteger, TaskLineViewMode) {
    TaskLineViewModeEdit, //前台分配
    TaskLineViewModeDisable, //顾问看板 前台看板
    TaskLineViewModeFloating, //未分配 等待配对
    TaskLineViewModeAssignFloating, //未分配 等待配对
    TaskLineViewModeADCFloating, //未分配 ADC等待配对

};
@class TaskLineView;

typedef void(^DidEditdHallName)(TaskLineView *line,NSString *name,NSInteger index,id item);
typedef void(^DidTouchedTaskSaleman)(TaskLineView *line,NSInteger row,id item);

@interface TaskLineView : UIView<UICollectionViewDataSource,UICollectionViewDelegate,UITextFieldDelegate>
{
    DidEditdHallName _didEditdHallName;
    DidTouchedTaskSaleman _didTouchedTaskSaleman;
    TaskLineViewMode _mode;
}
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSString *iconImage;
@property (nonatomic, strong) NSIndexPath *indicatePath;

//被拖入
@property (nonatomic, assign) BOOL disbaleDraggingIn;
//被拖出
@property (nonatomic, assign) BOOL disbaleDraggingOut;

@property (nonatomic, assign) BOOL isADC;

@property(strong,nonatomic)  TaskHall *hall;
@property(assign,nonatomic) NSInteger index;

-(instancetype)initWithFrame:(CGRect)frame  __attribute__((unavailable("Forbidden use init!")));
-(instancetype)initWithFrame:(CGRect)frame andMode:(TaskLineViewMode)mode;
-(void)didEditdHallName:(DidEditdHallName)didEditdHallName;
-(void)didTouchedTaskSaleman:(DidTouchedTaskSaleman)didTouchedTaskSaleman;
-(void)updateButtonIcon;
@end
