//
//  TaskLineView.m
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskLineView.h"
#import "TaskCell.h"
#import "FullyHorizontalFlowLayout.h"
#define CELL_HEIGHT 90
#define CELL_WIDTH 80


static NSString *TaskCellIdentifier = @"TaskCellIdentifier";
@interface TaskLineView()
@property (nonatomic, strong) UIImageView *icon;
@property (nonatomic, strong) UIImageView *nameBackground;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UITextField *inputTextField;
@property (nonatomic, strong) UIImageView *lineImageView;
@property (nonatomic, strong) UIImageView *indicateView;
@end

@implementation TaskLineView
-(BOOL)isADC{
    if ([self.hall.hallName rangeOfString:@"ADC"].location !=NSNotFound) {
        return YES;
    }else{
        
        return NO;
    }
}
-(instancetype)initWithFrame:(CGRect)frame andMode:(TaskLineViewMode)mode{
    if (self = [super initWithFrame:frame]) {
        _mode = mode;
        [self buildViews];
    }
    return self;
}
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [self buildViews];
    }
    return self;
}
-(void)setHall:(TaskHall *)hall{
    _hall = hall;
    self.nameLabel.text = _hall.hallName;
    [self updateButtonIcon];
    
    FullyHorizontalFlowLayout *flowLayout = (FullyHorizontalFlowLayout*)self.collectionView.collectionViewLayout;
    if(_mode == TaskLineViewModeFloating) {
        int count  = ceil([self.hall.salemanlist count]/2.0);
        flowLayout.nbColumns = count;
    }
  
    
    [self.collectionView reloadData];
}
-(void)updateButtonIcon{
    if (!self.hall.hallId) {
        self.nameBackground.image = [UIImage imageNamed:@"task_assign_add_bg"];
        self.icon.hidden = YES;
    }else{
        self.nameBackground.image = nil;
        self.icon.hidden = NO;
    }
}
-(void)buildViews{
//    self.backgroundColor = [UIColor colorWithRed:229/255.0 green:233/255.0 blue:234/255.0 alpha:1];
    [self addSubview:self.nameBackground];
    [self addSubview:self.nameLabel];
   
    [self addSubview:self.collectionView];
    [self addSubview:self.lineImageView];
//    [self addSubview:self.indicateView]; //暂时隐藏

    [self addSubview:self.icon];
    [self addSubview:self.inputTextField];
    if (_mode == TaskLineViewModeDisable) {
        self.inputTextField.userInteractionEnabled = NO;
    }
   
    if(_mode == TaskLineViewModeFloating || _mode ==  TaskLineViewModeADCFloating|| _mode ==  TaskLineViewModeAssignFloating){
        self.inputTextField.userInteractionEnabled = NO;
        self.nameBackground.hidden = YES;
        self.lineImageView.hidden = YES;
        
    }

}
-(void)setIndicatePath:(NSIndexPath *)indicatePath{
    _indicatePath = indicatePath;
    self.indicateView.left = _indicatePath.row * CELL_WIDTH;
    
}
-(void)setIconImage:(NSString *)iconImage{
    _iconImage = iconImage;
    _icon.image = [UIImage imageNamed:_iconImage];
}
-(UIImageView *)icon{
    if(!_icon){
        CGRect rect = CGRectMake(21, (self.frame.size.height-21)/2, 21, 21);
        _icon  = [[UIImageView alloc]initWithFrame:rect];
        _icon.image = [UIImage imageNamed:@"task_hall_status_icon_default.png"];
    }
    return _icon;
}
-(UILabel *)nameLabel{
    if (!_nameLabel) {
        CGRect rect = CGRectMake(50, 0, 90, CGRectGetHeight(self.frame));
        
        _nameLabel = [[UILabel alloc]initWithFrame:rect];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.textColor = [UIColor colorWithRed:0.522 green:0.082 blue:0.149 alpha:1.000];
        _nameLabel.font = [UIFont boldSystemFontOfSize:14.0];
        
        _nameLabel.shadowOffset = CGSizeMake(0, 1);
        //        _nameLabel.shadowRadius = 2;
        //        _nameLabel.layer.shadowOpacity = 1;
        _nameLabel.shadowColor = [UIColor whiteColor];
        
        [_nameLabel setNumberOfLines:0];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        self.nameLabel.lineBreakMode = NSLineBreakByCharWrapping;
        
    }
    return _nameLabel;
}
-(UICollectionView *)collectionView{
    if(!_collectionView){
        FullyHorizontalFlowLayout *flowLayout=[[FullyHorizontalFlowLayout alloc] init];

        [flowLayout setScrollDirection: UICollectionViewScrollDirectionHorizontal];
        flowLayout.minimumLineSpacing = 1;
        flowLayout.minimumInteritemSpacing = 1;
        
        CGRect rect;
        if(_mode == TaskLineViewModeFloating || _mode ==  TaskLineViewModeADCFloating|| _mode ==  TaskLineViewModeAssignFloating){
            rect = CGRectMake(CGRectGetMaxX(self.nameLabel.frame), 0, self.frame.size.width-CGRectGetMaxX(self.nameLabel.frame), CGRectGetHeight(self.frame)+2);
            flowLayout.itemSize=CGSizeMake(CELL_WIDTH,CELL_HEIGHT);

        }else{
            rect = CGRectMake(CGRectGetMaxX(self.nameLabel.frame), 0, self.frame.size.width-CGRectGetMaxX(self.nameLabel.frame), CELL_HEIGHT);
            flowLayout.itemSize=CGSizeMake(CELL_WIDTH,CELL_HEIGHT);

        }
       
        _collectionView = [[UICollectionView alloc]initWithFrame:rect collectionViewLayout:flowLayout];
        _collectionView.backgroundColor = [UIColor  clearColor];
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.dataSource = self;
        _collectionView.delegate = self ;
        _collectionView.showsVerticalScrollIndicator = NO;
        [_collectionView registerNib:[UINib nibWithNibName:@"TaskCell" bundle:nil] forCellWithReuseIdentifier:TaskCellIdentifier];
    }
    return _collectionView;
   
}
-(UIImageView *)lineImageView{
    if(!_lineImageView){
        CGRect rect = CGRectMake(0, CGRectGetMaxY(self.collectionView.frame)-1, self.frame.size.width, 1);
        _lineImageView  = [[UIImageView alloc]initWithFrame:rect];
        _lineImageView.image = [UIImage imageNamed:@"task_assign_cell_line.png"];
    }
    return _lineImageView;
}


-(UITextField *)inputTextField{
    if (!_inputTextField) {
        _inputTextField = [[UITextField alloc]initWithFrame:CGRectMake(50, 0, 100, CELL_HEIGHT)];
        _inputTextField.textAlignment = NSTextAlignmentLeft;
        _inputTextField.delegate = self;
        _inputTextField.textColor = [UIColor colorWithWhite:0.199 alpha:1.000];
//        _inputTextField.placeholder = @"输入展厅名称";
    }
    return _inputTextField;
}
-(UIImageView *)nameBackground{
    if (!_nameBackground) {
        _nameBackground  = [[UIImageView alloc]initWithFrame:CGRectMake(20, (CELL_HEIGHT-34)/2, 101, 34)];
        _nameBackground.image = nil;
    }
    return _nameBackground;
}
-(UIImageView *)indicateView{
    if (!_indicateView) {
        _indicateView  = [[UIImageView alloc]initWithFrame:CGRectMake(self.collectionView.left, (CELL_HEIGHT-5)/2, 1, 5)];
        _indicateView.backgroundColor = [UIColor redColor];
    }
    return _indicateView;
}
#pragma mark - KVO
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    self.nameLabel.hidden = YES;
    if (!self.hall.hallId) {
        self.icon.hidden = YES;
    }
    textField.text = self.nameLabel.text;
    self.nameBackground.image = nil;
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
//    self.nameBackground.image = [UIImage imageNamed:@"task_button_hall_name_add"];
    if (!self.hall.hallId) {
        self.icon.hidden = YES;
    }
    self.nameLabel.hidden = NO;
    if (_didEditdHallName) {
        _didEditdHallName(self,textField.text,self.index,self.hall);
    }
    self.inputTextField.text = @"";
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    self.nameLabel.text = self.hall.hallName;

    return [self.hall.salemanlist count];
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    TaskCell *cell = (TaskCell *)[collectionView dequeueReusableCellWithReuseIdentifier:TaskCellIdentifier forIndexPath:indexPath];
    
    TaskSaleman *man = [self.hall.salemanlist objectWithIndex:indexPath.row];
    [cell configCell:man withMode:_mode];
//    cell.personNameTitle.text = [@(indexPath.row) stringValue];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (_didTouchedTaskSaleman) {
        _didTouchedTaskSaleman(self,indexPath.row,[self.hall.salemanlist objectWithIndex:indexPath.row]);
    }
}
-(void)didEditdHallName:(DidEditdHallName)didEditdHallName{
    _didEditdHallName = [didEditdHallName copy];
}
-(void)didTouchedTaskSaleman:(DidTouchedTaskSaleman)didTouchedTaskSaleman{
    _didTouchedTaskSaleman = [didTouchedTaskSaleman copy];
}
@end
