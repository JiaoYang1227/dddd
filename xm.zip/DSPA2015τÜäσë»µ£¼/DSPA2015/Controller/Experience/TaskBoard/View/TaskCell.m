//
//  TaskCell.m
//  DSPA2015
//
//  Created by Jakey on 15/12/8.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskCell.h"
#import "TaskSaleman.h"
#import "AppDelegate.h"
@implementation TaskCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)configCell:(TaskSaleman*)man withMode:(TaskLineViewMode)mode{
//    self.backgroundColor = [UIColor redColor];
    
    self.personNameTitle.text = man.semployeename;
    self.time.text = [DateManager formaterTimeRangeToHM:[man.dtaskbegin intValue]];
    
    if ([man.bIsADC boolValue]) {
        [self.bgImageView setImage:[UIImage imageNamed:@"task_personImage_blue_bg.png"]];
    } else {
        //指示灯
        if ([man.dtaskbegin intValue] <= 30) {
            [self.bgImageView setImage:[UIImage imageNamed:@"task_personImage_bg.png"]];
        } else if ([man.dtaskbegin intValue] >30 && [man.dtaskbegin intValue] <= 60) {
            self.time.textColor = [UIColor colorWithRed:0.424 green:0.675 blue:0.451 alpha:1.000];
            [self.bgImageView setImage:[UIImage imageNamed:@"task_personImage_green_bg.png"]];
        } else {
            self.time.textColor = [UIColor colorWithRed:0.800 green:0.000 blue:0.200 alpha:1.000];
            [self.bgImageView setImage:[UIImage imageNamed:@"task_personImage_red_bg.png"]];
        }
    }
    if (mode == TaskLineViewModeFloating || mode == TaskLineViewModeADCFloating || mode == TaskLineViewModeEdit || (mode ==  TaskLineViewModeAssignFloating)) {
        self.time.hidden = YES;
        [self.bgImageView setImage:[UIImage imageNamed:@"task_personImage_bg.png"]];
        self.bgImageView.top  = 18-6;
        self.personImageView.top = 22-6;
        self.personNameTitle.top =70-6;
        if ([man.bIsADC boolValue]) {
            [self.bgImageView setImage:[UIImage imageNamed:@"task_personImage_blue_bg.png"]];
        }

    }

    self.personImageView.layer.cornerRadius = self.personImageView.width/2;//(值越大，角就越圆)
    self.personImageView.layer.masksToBounds = YES;
    if(man.imgpath && ![man.imgpath isEqualToString:@""] && man.imgpath.length>0){
        NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
        [self.personImageView downImageFromURLString:[baseInterface stringByAppendingString:man.imgpath?:@""] loadCache:YES scale:YES completionHandler:^(UIImage *image, NSError *error) {
            
        }];
    }else{
        self.personImageView.image = nil;
    }
    if(mode == TaskLineViewModeFloating || mode == TaskLineViewModeDisable){
        self.numButton.hidden = NO;
    }else{
        self.numButton.hidden = YES;
    }
    [self.numButton setTitle:man.num forState:UIControlStateNormal];
    
    //    cell.personImageView.imageURL = requestUrl;
}
@end
