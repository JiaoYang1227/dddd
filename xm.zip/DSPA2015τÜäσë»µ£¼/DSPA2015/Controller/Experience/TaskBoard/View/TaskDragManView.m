//
//  TaskDragManView.m
//  DSPA2015
//
//  Created by Jakey on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskDragManView.h"

@implementation TaskDragManView


-(void)cloneViewsFromTaskCell:(TaskCell*)aTaskCell{
    self.contentView = aTaskCell.contentView;
    self.backgroundColor = [UIColor clearColor];

}
//clone views
- (void)drawRect:(CGRect)rect
{
    [self.contentView.layer renderInContext:UIGraphicsGetCurrentContext()];
}
@end
