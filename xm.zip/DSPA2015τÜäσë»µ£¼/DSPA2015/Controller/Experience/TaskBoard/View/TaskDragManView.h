//
//  TaskDragManView.h
//  DSPA2015
//
//  Created by Jakey on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "TaskSaleman.h"
#import "TaskCell.h"

typedef NS_ENUM(NSUInteger, DragDirection) {
    DragDirectionLeft,
    DragDirectionRight,
    DragDirectionUp,
    DragDirectionDown

};

@interface TaskDragManView : UIView
@property (strong, nonatomic) UIView *contentView;

@property (strong, nonatomic) TaskSaleman *man;
@property (assign, nonatomic) DragDirection direction;

//BUG #36331::【客户体验】【任务看板】，将销售人员，等待中，横向向后拖拽，系统崩溃。
@property (strong, nonatomic) NSIndexPath *sourceIndexPath;
@property (strong, nonatomic) NSIndexPath *targetIndexPath;


@property (assign, nonatomic) CGPoint  lastLocation;
-(void)cloneViewsFromTaskCell:(TaskCell*)aTaskCell;
@end
