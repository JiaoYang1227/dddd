//
//  BindDeviceViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/7/7.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BindDeviceViewController.h"
#import "KeychainManager.h"
#import "UIViewController+MJPopupViewController.h"
#import "AppDelegate.h"
#import "VersionManager.h"
#import "VerifyManager.h"
@interface BindDeviceViewController ()

@end

@implementation BindDeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
   
    self.title = @"设备绑定";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)dealloc{
    NSLog(@"BindDeviceViewController dealloc");
}
-(void)dismiss{
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationSlideTopBottom];
}
- (IBAction)submitTouched:(id)sender {
    
    if ([self.code.text isEqualToString:@"demo"]) {
      __unused  BOOL success =  VerifyManager->saveActiveStatus(@"demo");
        MBProgressHUD *hud = [MBProgressHUD showHUDForSuccessAddedTo:self.view animated:YES];
        hud.detailsLabelText = @"演示版本激活成功";
        [hud hide:YES afterDelay:2];
        [self performSelector:@selector(dismiss) withObject:nil afterDelay:2];
        return;
    }
    if([self.udid.text isEqualToString:@""] || !self.udid.text){
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"UDID不能为空"];
        [alert addCancleButtonWithTitle:@"取消" handler:^(JKAlertItem *item) {
            
        }];
        [alert addCommonButtonWithTitle:@"去获取" handler:^(JKAlertItem *item) {
            [self openSafariTouched:nil];
        }];
        [alert show];
        return;
    }
    [VersionManager registerDevice:self.code.text?:@"" udid:self.udid.text?:@"" Success:^(id responseObject) {
        if ([responseObject boolForKey:@"success"]) {
            BOOL success =  VerifyManager->saveActiveStatus(self.udid.text);
            if (success) {
                MBProgressHUD *hud = [MBProgressHUD showHUDForSuccessAddedTo:self.view animated:YES];
                hud.detailsLabelText = [responseObject stringForKey:@"message"];
                [hud hide:YES afterDelay:2];
                [self performSelector:@selector(dismiss) withObject:nil afterDelay:2];
            }else{
                MBProgressHUD *hud = [MBProgressHUD showHUDForFailureAddedTo:self.view animated:YES];
                [hud hide:YES afterDelay:2];
                hud.detailsLabelText =@"保存激活状态失败!";
            }
        }else
        {
            MBProgressHUD *hud = [MBProgressHUD showHUDForFailureAddedTo:self.view animated:YES];
            [hud hide:YES afterDelay:2];
            hud.detailsLabelText = [responseObject stringForKey:@"message"];
        }
        
    } Failure:^(NSError *error) {
        MBProgressHUD *hud = [MBProgressHUD showHUDForFailureAddedTo:self.view animated:YES];
        [hud hide:YES afterDelay:2];
        hud.labelText = @"在线验证失败";
    }];

    
}

- (IBAction)cancleTouched:(id)sender {
    [[AppDelegate APP] exitApplication];
}

- (IBAction)openSafariTouched:(id)sender {
    [VersionManager openUrl:[DEVICE_MANAGER_URI stringByAppendingString:DEVICE_UDID_PROFILE]];
//    NSURL *url = [NSURL URLWithString:@"http://dev.skyfox.org/udid"];
//    [[UIApplication sharedApplication] openURL:url];
}
@end
