//
//  BindDeviceViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/7/7.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//


@interface BindDeviceViewController : UIViewController

- (IBAction)submitTouched:(id)sender;
- (IBAction)cancleTouched:(id)sender;
- (IBAction)openSafariTouched:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *code;
@property (weak, nonatomic) IBOutlet UITextField *udid;
@end
