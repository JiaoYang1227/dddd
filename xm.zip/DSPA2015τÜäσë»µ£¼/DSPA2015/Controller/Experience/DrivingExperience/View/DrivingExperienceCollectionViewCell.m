//
//  DrivingExperienceCollectionViewCell.m
//  DSPA2015
//
//  Created by gavin on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceCollectionViewCell.h"
#import "DateManager.h"

@implementation DrivingExperienceCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


//  8:00~8:30    ---- indexPath.row 0
//  8:30~9:00    ---- indexPath.row 1
//  9:00~9:30    ---- indexPath.row 2
//  9:30~10:00   ---- indexPath.row 3
//  10:00~10:30  ---- indexPath.row 4
//  10:30~11:00  ---- indexPath.row 5
//  11:00~12:30  ---- indexPath.row 6
//  12:30~13:00  ---- indexPath.row 7


- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath{
    
}

@end
