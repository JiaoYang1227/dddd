//
//  DrivingExperienceRightCell.h
//  DSPA2015
//
//  Created by gavin on 15/12/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrivingExperienceModel.h"


typedef void(^onDrivingExperienceCellButtonCallBack)(id , BOOL yuyue);

@interface DrivingExperienceRightCell : UITableViewCell

@property (nonatomic , strong) DrivingExperienceModel *drivingExperienceModel;

@property (nonatomic , copy) onDrivingExperienceCellButtonCallBack callBackCellButtonClick;

+(UINib*)nib;


- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath;




@end
