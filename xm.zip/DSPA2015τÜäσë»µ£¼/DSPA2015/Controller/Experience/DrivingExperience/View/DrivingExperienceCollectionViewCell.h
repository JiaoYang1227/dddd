//
//  DrivingExperienceCollectionViewCell.h
//  DSPA2015
//
//  Created by gavin on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrivingExperienceModel.h"

@interface DrivingExperienceCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) IBOutlet UIImageView *driveShowImage;
- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath;

@end
