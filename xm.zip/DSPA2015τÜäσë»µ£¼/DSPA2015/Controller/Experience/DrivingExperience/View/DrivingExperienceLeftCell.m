//
//  DrivingExperienceLeftCell.m
//  DSPA2015
//
//  Created by gavin on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceLeftCell.h"

@implementation DrivingExperienceLeftCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


+(UINib*)nib{
    return  [UINib nibWithNibName:NSStringFromClass([self class]) bundle:nil];
}


- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath{
    self.engineNumber.text = [model.carmodel description];
    self.plateNumber.text = [model.driveLicensePlate description];
    
    if ([model.czt isEqualToString:@"01"]) {
        self.engineNumber.alpha = .55;
        self.plateNumber.alpha = .55;
        
    }else{
        self.engineNumber.alpha = 1;
        self.plateNumber.alpha = 1;
    }
    
}


@end
