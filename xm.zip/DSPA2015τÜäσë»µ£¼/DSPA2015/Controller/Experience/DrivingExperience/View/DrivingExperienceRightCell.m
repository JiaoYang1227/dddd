//
//  DrivingExperienceRightCell.m
//  DSPA2015
//
//  Created by gavin on 15/12/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceRightCell.h"
#import "AppDelegate.h"
#import "DrivingUIButton.h"

@implementation DrivingExperienceRightCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
+(UINib*)nib{
    return  [UINib nibWithNibName:NSStringFromClass([self class]) bundle:nil];
}

// 164像素对应是30分钟 164-->30*60   ： 1秒对应0.091111像素

- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath{
    
//    NSLog(@"----> %zd",model.driveViewStartX);
//    NSLog(@"====> %zd",model.driveViewWidth);
    
    for (DrivingUIButton *bts in [self subviews]) {
        if (bts.tag == indexPath.row && [bts isKindOfClass:[DrivingUIButton class]]) {
            [bts removeFromSuperview];
        }
    }
    
//    NSLog(@"%@",[DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:model.driveStartTime]]);
//    
//    NSLog(@"%@",[DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:model.driveEndTime]]);
    
    int arrIndex = 0;
    int arrIndexYuYue = 0;
    for (DrivingTimerModel *timerList in model.time) {
        model.arrIndex = arrIndex;
        DrivingUIButton *button = [[DrivingUIButton alloc] init];
        
        
        button.backgroundColor = [UIColor clearColor];
        
        
//        01 试驾中  02 取消试驾  03 试驾结束  04 预约试驾
        
        //BUG #36370::【客户体验-试乘试驾】CRM中已还车，IPAD端还可以还车
        NSString *state = [timerList.tryoutState stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([state isEqualToString:@"03"]) {//试驾结束
            button = [[DrivingUIButton alloc] initWithFrame:CGRectMake(timerList.driveViewStartX*0.091111 /2 , 0,
                                                                       timerList.driveViewWidth*0.091111 / 2, 92)];
            button.backgroundColor = [UIColor lightGrayColor];
        }
        
        if ([state isEqualToString:@"01"]) {//试驾中
            button = [[DrivingUIButton alloc] initWithFrame:CGRectMake(timerList.driveViewStartX*0.091111 /2 , 0,
                                                                       timerList.driveViewWidth*0.091111 / 2, 92)];
            button.backgroundColor = [UIColor redColor];
        }
        
        
        if ([state isEqualToString:@"04"]) {//预约试驾
            button = [[DrivingUIButton alloc] initWithFrame:CGRectMake(timerList.driveViewStartX*0.091111 /2 , 0,
                                                                       timerList.driveViewWidth*0.091111 / 2, 92)];
            button.backgroundColor = [UIColor yellowColor];
        }
        
        // 判断是否过期
        //        if (timerList.endtime < [DateManager timeIntervalWithDate:[NSDate date]]) {
        //            button.backgroundColor = [UIColor yellowColor];
        //        }else{
        //            button.backgroundColor = [UIColor colorWithRed:198./255 green:105./255 blue:119./255 alpha:1];
        //        }
        
        button.tag = indexPath.row;
        button.index = arrIndex;
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchDown];
        
        button.alpha = .6;
        [self addSubview:button];
        
        
        UILabel *lableName = [[UILabel alloc] initWithFrame:CGRectMake(1, 55, 80, 10)];
        lableName.font = [UIFont boldSystemFontOfSize:10.0f];
        lableName.textColor = [UIColor darkGrayColor];
//        lableName.text = [AppDelegate APP].user.userName?:[AppDelegate APP].user.salesConsultantName?:@"暂无";
        lableName.text = timerList.salesConsultantName?:@"暂无";
        [button addSubview:lableName];
        
        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(1, 70, 80, 10)];
        lable.font = [UIFont boldSystemFontOfSize:10.0f];
        lable.textColor = [UIColor darkGrayColor];
        lable.text = [NSString stringWithFormat:@"%@%@%@",[DateManager stringConvert_HM_FromDate:[DateManager dateWithTimeStamp:timerList.begintime]] , @"~",[DateManager stringConvert_HM_FromDate:[DateManager dateWithTimeStamp:timerList.endtime]]];
        [button addSubview:lable];
        
        self.drivingExperienceModel = model;
        arrIndex ++;
    }
    
    
    // 预约数组
    for (DrivingYuYueTimerModel *yuyueTimerList in model.yuyuetime) {
        model.arrIndex = arrIndexYuYue;
        DrivingUIButton *button = [[DrivingUIButton alloc] init];
        
        button.backgroundColor = [UIColor clearColor];

        button = [[DrivingUIButton alloc] initWithFrame:CGRectMake(yuyueTimerList.reservationDriveViewStartX*0.091111 /2 , 0,
                                                                       yuyueTimerList.reservationDriveViewWidth*0.091111 / 2, 92)];
        button.backgroundColor = [UIColor greenColor];
      
        button.tag = indexPath.row;
        button.index = arrIndexYuYue;
        [button addTarget:self action:@selector(yuyueButtonClick:) forControlEvents:UIControlEventTouchDown];
        
        button.alpha = .6;
        [self addSubview:button];
        
        UILabel *lableName = [[UILabel alloc] initWithFrame:CGRectMake(1, 55, 80, 10)];
        lableName.font = [UIFont boldSystemFontOfSize:10.0f];
        lableName.textColor = [UIColor darkGrayColor];
//        lableName.text = [AppDelegate APP].user.userName?:[AppDelegate APP].user.salesConsultantName?:@"暂无";
        lableName.text = yuyueTimerList.salesConsultantName?:@"暂无";
        [button addSubview:lableName];
        
        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(1, 70, 80, 10)];
        lable.font = [UIFont boldSystemFontOfSize:10.0f];
        lable.textColor = [UIColor darkGrayColor];
        lable.text = [NSString stringWithFormat:@"%@%@%@",[DateManager stringConvert_HM_FromDate:[DateManager dateWithTimeStamp:yuyueTimerList.tryoutstartdate]] , @"~",[DateManager stringConvert_HM_FromDate:[DateManager dateWithTimeStamp:yuyueTimerList.tryoutenddate]]];
        [button addSubview:lable];
        
        self.drivingExperienceModel = model;
        arrIndexYuYue ++;
    }
    
}


- (void)buttonClick:(DrivingUIButton *)sender{
    if (self.callBackCellButtonClick) {
        self.drivingExperienceModel.arrIndex = sender.index;
        self.callBackCellButtonClick(self.drivingExperienceModel , NO);
    }
}



- (void)yuyueButtonClick:(DrivingUIButton *)sender{
    if (self.callBackCellButtonClick) {
        self.drivingExperienceModel.arrIndex = sender.index;
        self.callBackCellButtonClick(self.drivingExperienceModel , YES);
    }
}


@end
