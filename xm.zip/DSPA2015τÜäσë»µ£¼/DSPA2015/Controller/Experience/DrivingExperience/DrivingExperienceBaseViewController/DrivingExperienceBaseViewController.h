//
//  DrivingExperienceBaseViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface DrivingExperienceBaseViewController : BaseViewController

- (IBAction)dismissTouched:(id)sender;


@end
