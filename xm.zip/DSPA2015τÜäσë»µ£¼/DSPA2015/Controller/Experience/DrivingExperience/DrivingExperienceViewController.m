//
//  DrivingExperienceViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/15.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceViewController.h"
#import "DrivingExperienceCollectionViewCell.h"
#import "DrivingExperienceLeftCell.h"
#import "DrivingExperienceRightCell.h"
#import "DrivingMapViewController.h"

#import "AddDrivingExperienceViewController.h"
#import "ReturnDrivingViewController.h"
#import "AlertDrivingViewController.h"
//#import "DrivingExperienceNewViewController.h"
#import "UIViewController+DSPAPopup.h"


#import "DrivingExperienceModel.h"

@interface DrivingExperienceViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate,UIPopoverPresentationControllerDelegate>
{
    //==========
    __weak IBOutlet UITableView         *_leftTableview;    //试驾表头
           IBOutlet UITableView         *_rightTableview;
    __weak IBOutlet UIScrollView        *_scrollView;
                    NSMutableArray      *_dataList;

    //=========
           IBOutlet UIImageView  *_timerTitleBarView;
    __weak IBOutlet UIScrollView *_timerScrollview;
    //=========
    
    __weak IBOutlet SelectButton *_dateSelectOutlet;

}
- (IBAction)getDrivingMapAction:(id)sender;

- (IBAction)dateSelectAction:(id)sender;

@end

@implementation DrivingExperienceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    [self registerNib];
    
    _dateSelectOutlet.value = [DateManager stringConvert_YMD_FromDate:[NSDate date]];
    
    // flag 0 代表试驾看板里车俩信息
    [self loadData:@{@"date":_dateSelectOutlet.value , @"flag":[NSNumber numberWithInt:0]}];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadData:) name:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
    self.title = @"试乘试驾(首页)";
}

/**
 *   load data
 */
- (void)loadData:(NSDictionary *)parmDic{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [DrivingExperienceModel fetchDrivingExperienceList:parmDic Success:^(NSArray *headList, id responseObject) {
        
        if (headList.count > 0) {
            _dataList = [[NSMutableArray alloc] initWithArray:headList];
            [_leftTableview reloadData];
            [_rightTableview reloadData];
        }
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}


/**
 *  registerNib
 */
- (void)registerNib{
    [_leftTableview registerNib:[DrivingExperienceLeftCell nib] forCellReuseIdentifier:NSStringFromClass([DrivingExperienceLeftCell class])];
    
    [self addScrollview];
}

/**
 *  添加滚动视图
 */
- (void)addScrollview{
    CGRect frame = _scrollView.frame;
    _scrollView.showsVerticalScrollIndicator = NO;
    _rightTableview.frame = CGRectMake(0,0, 82*21, frame.size.height);
    _scrollView.contentSize = CGSizeMake(82*21, _rightTableview.frame.size.height);
    [_scrollView addSubview:_rightTableview];
    
    _timerScrollview.contentSize = CGSizeMake(82*21, 35);
    [_timerScrollview addSubview:_timerTitleBarView];
}


#pragma mark 
#pragma tableview -------------------------------

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 92;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _rightTableview) {
        
        NSString *CellIdentifier = [NSString stringWithFormat:@"cell%ld",indexPath.row];
        
        UINib * nib = [UINib nibWithNibName:@"DrivingExperienceRightCell" bundle:nil];
        [tableView registerNib:nib forCellReuseIdentifier:CellIdentifier];
        DrivingExperienceRightCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (!cell) {
            cell = [[DrivingExperienceRightCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        DrivingExperienceModel *model = _dataList[indexPath.row];
        [cell configData:model withIndexPath:indexPath];
        
        __weak __typeof(self)weakSelf = self;
        cell.callBackCellButtonClick = ^(id model , BOOL yuyue){
            
            
            
            /* 列表点击操作取消 */
            
            return ;
            
            
            DrivingExperienceModel *dmodel = model;
            DrivingYuYueTimerModel *dtmodel = [dmodel.yuyuetime firstObject];
            NSString *state = [dtmodel.tryoutState stringByReplacingOccurrencesOfString:@" " withString:@""];
            if ([AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot && [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot){
                if ([state isEqualToString:@"预约中"] && yuyue) {
                    AddDrivingExperienceViewController *add = [[AddDrivingExperienceViewController alloc] init];
                    DrivingExperienceModel *dem = dmodel;
                    //czt为0的时候代表试驾车辆被占用
                    if ([dem.czt isEqualToString:@"01"]) {
                        [JKAlert showMessage:@"试驾车辆目前被占用！"];
                        add.drivingCarUse = YES;
                        return;
                    }
                    
                    // 领车得需要是当前的销售顾问才可以进行操作
                    if (![dtmodel.userID isEqualToString:[AppDelegate APP].user.userID]) {
                        [JKAlert showMessage:[NSString stringWithFormat:@"请切换销售顾问为%@进行操作",dtmodel.salesConsultantName?:@"暂无"]];
                        return;
                    }
                    
                    add.havedYuYue = YES;
                    dem.driveTestID = dtmodel.driveTestID;
                    add.model = dem;
//                    [weakSelf presentModelDetail:add];
                    [weakSelf presentDSPAPopup:add parentViewController:self touchCallBack:^{
                        
                    } haveMask:YES includeNavgation:YES alignTop:NO];
                    return;
                }
                
                
                DrivingTimerModel *dtm = [dmodel.time objectWithIndex:dmodel.arrIndex];
                // 领车得需要是当前的销售顾问才可以进行操作
                if (![dtm.userID isEqualToString:[AppDelegate APP].user.userID]) {
                    [JKAlert showMessage:[NSString stringWithFormat:@"请切换销售顾问为%@进行操作",dtm.salesConsultantName?:@"暂无"]];
                    return;
                }
                
                
                AlertDrivingViewController*advc = [[AlertDrivingViewController alloc] init];
                advc.drivingExperienceModel = model;
//                [weakSelf presentModelDetail:advc];
                [weakSelf presentDSPAPopup:advc parentViewController:self touchCallBack:^{
                    
                } haveMask:YES includeNavgation:YES alignTop:NO];
                
            }else{
                 [JKAlert showMessage:@"请匹配客户或者线索"];
            }
        };
        return cell;
        
    }else{
        static NSString * identifier = @"DrivingExperienceLeftCell";
        DrivingExperienceLeftCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell configData:_dataList[indexPath.row] withIndexPath:indexPath];
        return cell;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
//    if ([AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot && [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot) {
//
//
//        /* 需求变更：超过18点可以进行领车 ，但是超过18点的 在试驾看板中不显示 */
//        /*
//        //超过当日18：00 不允许领车试驾
//        NSDate *now = [NSDate date];
//
//        NSCalendar *cal = [NSCalendar currentCalendar];
//        NSDateComponents *comps = [cal
//                                   components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay
//                                   fromDate:now];
//        comps.hour = 18;
//        comps.second = 0;
//        comps.minute = 0;
//        comps.nanosecond = 0;
//
//        NSDate *date18hour = [cal dateFromComponents:comps];
//
//        if ([DateManager timeIntervalWithDate:now] > [DateManager timeIntervalWithDate:date18hour]) {
//            [JKAlert showMessage:@"超过当日18：00不允许领车试驾！"];
//            return;
//        }
//        */
//
//        AddDrivingExperienceViewController *add = [[AddDrivingExperienceViewController alloc] init];
//        DrivingExperienceModel *dem = _dataList[indexPath.row];
//        add.model = dem;
//
//        //czt为0的时候代表试驾车辆被占用
//        if ([dem.czt isEqualToString:@"01"]) {
////            [JKAlert showMessage:@"试驾车辆目前被占用！"];
////            return;
//            add.drivingCarUse = YES;
//        }
//
////        [self presentModelDetail:add];
//        [self presentDSPAPopup:add parentViewController:self touchCallBack:^{
//
//        } haveMask:YES includeNavgation:YES alignTop:NO];
//
//    }else{
//        [JKAlert showMessage:@"请匹配客户或者线索"];
//    }
}

/**
 *  数据联动
 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == _leftTableview) {
        [self tableView:_rightTableview scrollFollowTheOther:_leftTableview];
    }else{
        [self tableView:_leftTableview scrollFollowTheOther:_rightTableview];
    }
    
    
    if(scrollView == _scrollView)
    {
        _timerScrollview.delegate = nil;
        [_timerScrollview setContentOffset:_scrollView.contentOffset];
        _timerScrollview.delegate = self;
    }else {
        _scrollView.delegate = nil;
        [_scrollView setContentOffset:_timerScrollview.contentOffset];
        _scrollView.delegate = self;
    }
}


- (void)tableView:(UITableView *)tableView scrollFollowTheOther:(UITableView *)other{
    CGFloat offsetY= other.contentOffset.y;
    CGPoint offset=tableView.contentOffset;
    offset.y=offsetY;
    tableView.contentOffset=offset;
}


/**
 *  获取试驾路线图
 */
- (IBAction)getDrivingMapAction:(id)sender {
//    [self presentModelDetail:[[DrivingMapViewController alloc] init]];
    [self presentDSPAPopup:[[DrivingMapViewController alloc] init] parentViewController:self touchCallBack:^{
        
    } haveMask:YES includeNavgation:YES alignTop:NO];
}

/**
 *  日期选择
 */
- (IBAction)dateSelectAction:(SelectButton *)sender {
//    __weak __typeof(self)weakSelf = self;
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        _dateSelectOutlet.value = [DateManager stringConvert_YMD_FromDate:date];
//        [weakSelf loadData:@{@"date":dateYMDString}];
        
    }];
    datePicker.popoverPresentationController.delegate = self;
    [self presentViewController:datePicker animated:YES completion:nil];
}



-(void)reloadData:(NSNotification*)notifacation{
    [self loadData:@{@"date":[DateManager stringConvert_YMD_FromDate:[NSDate date]] , @"flag":[NSNumber numberWithInt:0]}];
}



// UIPopoverPresentationControllerDelegate
- (void)popoverPresentationControllerDidDismissPopover:(UIPopoverPresentationController *)popoverPresentationController{
    [self loadData:@{@"date":_dateSelectOutlet.value , @"flag":[NSNumber numberWithInt:0]}];
}

//begin by owen 20160711
//- (IBAction)pushNewDrivingExperienceViewController:(id)sender {
//    
//    DrivingExperienceNewViewController *drivingNewCat = [[DrivingExperienceNewViewController alloc] init];
//    drivingNewCat.drivingCarResult = [[NSMutableArray alloc] initWithArray:_dataList];
//    [self.navigationController pushViewController:drivingNewCat animated:YES];
//}
//end by owen20160711


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
