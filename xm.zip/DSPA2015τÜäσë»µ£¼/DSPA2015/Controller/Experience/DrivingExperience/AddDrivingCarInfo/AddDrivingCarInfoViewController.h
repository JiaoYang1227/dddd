//
//  AddDrivingCarInfoViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceBaseViewController.h"
#import "DrivingExperienceModel.h"

typedef NS_ENUM(NSUInteger, AddDrivingCarType) {
    AddDrivingCarTypeLingche=0, //领车 其实就是新建试乘试驾
    AddDrivingCarTypeYuyue,  //预约   其实就是新建试乘试驾
    AddDrivingCarTypeYuyue2Lingche, //预约中 领车   其实就是更新试乘试驾状态
    AddDrivingCarTypeHuanche //还车
};
@interface AddDrivingCarInfoViewController : DrivingExperienceBaseViewController
{
    ModuleType _moduleType;
    ShouldReloadParentData _shouldReloadParentData;
    AddDrivingCarType _addDrivingCarType;
}
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
/**
 *  @author Jakey, 16-01-30 16:01:38
 *
 *  <#Description#>
 *
 *  @param moduleType 调用视图所在的模块  首页 客户视图  销售工作
 *  @param andDriverType 试乘试驾 领车还是还车 还是预约

 *  @return <#return value description#>
 */
-(instancetype)initWithModuleType:(ModuleType)moduleType
                    andDriverType:(AddDrivingCarType)addDrivingCarType;

-(void)ShouldReloadParentData:(ShouldReloadParentData)shouldReloadParentData;
@property (nonatomic , strong) DrivingExperienceModel *drivingExperienceModel;
@property (weak, nonatomic) IBOutlet UIView *yueyueView;


@end
