//
//  AddDrivingCarInfoViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/19.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AddDrivingCarInfoViewController.h"
#import "AddDrivingExperienceViewController.h"
#import "UIViewController+MJPopupViewController.h"
#import "DictModel.h"
#import "DrivingExperienceCheck.h"
#import "UIViewController+DSPAPopup.h"

@interface AddDrivingCarInfoViewController ()<UITextFieldDelegate>
{
    //============
    __weak IBOutlet BorderTextField *_customerName;     //客户名称
    __weak IBOutlet BorderTextField *_drivingName;      //试驾人员名称
    __weak IBOutlet BorderTextField *_dringPhone;       //试驾人员电话
    __weak IBOutlet BorderTextField *_drivingNumber;    //试驾人驾驶证号
    __weak IBOutlet BorderTextField *_carNumber;        //车牌号
    __weak IBOutlet BorderTextField *_carStartKM;       //开始里程数
    __weak IBOutlet BorderTextField *_carEndKM;         //结束里程数
    
    __weak IBOutlet BorderTextField *_chassisNo;        //底盘号
    __weak IBOutlet BorderTextField *_customerPhone;    //客户电话
    __weak IBOutlet BorderTextField *_customerOtherPhone;//客户其他电话
    __weak IBOutlet BorderTextField *_brand;            //车系
    __weak IBOutlet BorderTextField *_carModel;         //车型
    
    __weak IBOutlet BorderTextView *_driveCommentTextView; //试驾备注

    __weak IBOutlet SelectButton *_drivingState;        //试驾状态
    __weak IBOutlet SelectButton *_drivingStartTimer;   //试驾开始时间
    __weak IBOutlet SelectButton *_drivingEndTimer;     //试驾结束时间
    
    
    __weak IBOutlet SelectButton *brandOutlet;     //品牌
    
    __weak IBOutlet SelectButton *modelOutlet;     //车型
    
    
    
    //===================
    
    __weak IBOutlet SwitchView *_reservationSwitchView;         //预约开关
    
    __weak IBOutlet SelectButton *_reservationButtonOutlet;     //预约时间
    
    __weak IBOutlet UILabel *_reservationLable;                 //预约时间前lable
    
}


- (IBAction)reservationButtonAction:(SelectButton *)sender; //预约时间

//==========
- (IBAction)drivingStateAction:(id)sender;      //试驾状态
- (IBAction)drivingStartTimerAction:(id)sender; //试驾开始时间
- (IBAction)drivingEndTimerAction:(id)sender;   //试驾结束时间

- (IBAction)brandAction:(SelectButton *)sender; //车型
- (IBAction)modelAction:(SelectButton *)sender; //车系
//=========
- (IBAction)backButtonTouch:(id)sender;
- (IBAction)saveAction:(id)sender;

@end

@implementation AddDrivingCarInfoViewController

-(instancetype)initWithModuleType:(ModuleType)moduleType andDriverType:(AddDrivingCarType)addDrivingCarType
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _moduleType = moduleType;
        _addDrivingCarType = addDrivingCarType;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self bringData:self.drivingExperienceModel];
    
    if (_moduleType != ModuleTypeIndex) {
        [_customerName setEnabled:YES];
        [_chassisNo setEnabled:YES];
        [_drivingEndTimer setEnabled:YES];
        [_carStartKM setEnabled:YES];
        [_drivingState setEnabled:YES];
        [_drivingStartTimer setEnabled:YES];
        [_drivingEndTimer setEnabled:YES];
        [_carEndKM setEnabled:YES];
        [brandOutlet setEnabled:YES];
        [modelOutlet setEnabled:YES];
        
    }
    if (_moduleType == ModuleTypeIndex){
        self.title = @"试乘试驾领车(首页)";
    }
    if (_moduleType == ModuleTypeClient){
        self.title = @"试乘试驾领车(客户视图)";
    }
    if (_moduleType == ModuleTypeService){
        self.title = @"试乘试驾领车(销售工作)";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [_reservationSwitchView didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
        if (on) {
            _reservationButtonOutlet.hidden = NO;
            _reservationButtonOutlet.enabled = YES;
            _reservationLable.hidden = NO;
            _reservationButtonOutlet.value = [DateManager stringConvert_YMDHMS_FromDate:[NSDate date]];
            _drivingState.value = @"预约中";
            _drivingExperienceModel.ifyuyue = YES;
            _drivingExperienceModel.tryOutDate = [DateManager timeIntervalWithDate:[NSDate date]];
        }else{
            _reservationButtonOutlet.hidden = YES;
            _reservationLable.hidden = YES;
            _drivingState.value = @"试驾中";
            _drivingExperienceModel.ifyuyue = NO;
            _drivingExperienceModel.tryOutDate = 0;
        }
    }];

    
    
    if (_addDrivingCarType == AddDrivingCarTypeYuyue) {
        _reservationSwitchView.on = YES;
        
        _reservationSwitchView.userInteractionEnabled = NO; //禁止改变
        self.yueyueView.hidden = YES;

        _reservationButtonOutlet.hidden = NO;
        _reservationButtonOutlet.enabled = YES;
        _reservationLable.hidden = NO;
        _reservationButtonOutlet.value = [DateManager stringConvert_YMDHMS_FromDate:[NSDate date]];
        _drivingState.value = @"预约中";
        self.titleLabel.text = @"预约试驾";
        
        _drivingExperienceModel.ifyuyue = YES;
        _drivingExperienceModel.tryOutDate = [DateManager timeIntervalWithDate:[NSDate date]];
    }else{

        _reservationSwitchView.userInteractionEnabled = NO; //禁止改变
        _reservationButtonOutlet.enabled = NO;
        _reservationButtonOutlet.hidden = YES;
        _reservationLable.hidden = YES;
        _drivingState.value = @"试驾中";
        
        self.titleLabel.text = @"领车试驾";
        self.yueyueView.hidden = YES;


    }
    
    
    
    
    
//    // 如果是从预约试驾带入过来的数据那么不允许在编辑预约功能
//    if (self.drivingExperienceModel.isReservationDriveFlag) {
//        _reservationSwitchView.userInteractionEnabled = NO;
//    }else{
//        _reservationSwitchView.userInteractionEnabled = YES;
//    }
    
}



- (IBAction)reservationButtonAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        _reservationButtonOutlet.value = [DateManager stringConvert_YMDHMS_FromDate:date];
        _drivingExperienceModel.tryOutDate = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}


/**
 *  试驾状态
 */
- (IBAction)drivingStateAction:(SelectButton *)sender {
    [self showSearchSelectController:sender withData:@[@"试驾结束",@"试驾中"] selectItem:^(id item, NSString *key, NSString *value) {
        sender.value = value;
        sender.key = key;

    }];
}
/**
 *  试驾开始时间
 */
- (IBAction)drivingStartTimerAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        sender.value = [DateManager stringConvert_YMDHMS_FromDate:date];;
        _drivingExperienceModel.driveStartTime = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}
/**
 *  试驾结束时间
 */
- (IBAction)drivingEndTimerAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        
        sender.value = [DateManager stringConvert_YMDHMS_FromDate:date];
        _drivingExperienceModel.driveEndTime = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}



/**
 *  品牌
 */
- (IBAction)brandAction:(SelectButton *)sender{
    [DictModel getDictionary:DIC_NAME_CAR_BRAND Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            sender.key = key;
            

        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  车型
 */
- (IBAction)modelAction:(SelectButton *)sender{
    if (![brandOutlet hasKey]) {
        [JKAlert showMessage:@"请选择车系"];
        return ;
    }
    
    [DictModel getCascadeDict:@[@"model",brandOutlet.key] Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            sender.key = key;

        }];
    } failure:^(NSError *error) {
        
    }];
}



- (void)bringData:(DrivingExperienceModel *)model{
    _customerName.text = model.custName;     //客户名称
    _drivingName.text = model.driverName?:model.custName;      //试驾人员名称
    _dringPhone.text = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.customer.custMobile?:@"";       //试驾人员电话 默认带入客户电话
    
    if (model.driverMobile) {
        _dringPhone.text = model.driverMobile;
    }
    
    _drivingNumber.text = model.driverLicenseNo;    //试驾人驾驶证号
    _carNumber.text = model.driveLicensePlate;        //车牌号
    _carStartKM.text = model.driveStartKM;       //开始里程数
//    _carEndKM;         //结束里程数
    
    _chassisNo.text = model.chassisNo;        //底盘号
    _customerPhone.text = model.custMobile;    //客户电话
    _customerOtherPhone.text = model.custOtherPhone;//客户其他电话
    _brand.text = model.carBrand;            //车系
    _carModel.text = model.carModel;         //车型
    
    _driveCommentTextView.text = model.driveComment; //试驾备注
    
//    _drivingStartTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:model.driveStartTime]];
    _drivingStartTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[NSDate date]];
    
    long long endDate = [DateManager timeIntervalWithDate:[NSDate date]] + 30*60*1000;
    
    _drivingEndTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:endDate]];
    
    _drivingState.value = @"试驾中";
    
    _customerPhone.text = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.customer.custMobile?:@"";    //客户电话
    _customerOtherPhone.text = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.customer.custOtherPhone?:@"";//客户其他电话
    brandOutlet.value = model.carbrand;     //品牌
    modelOutlet.value = model.carmodel;     //车型
    
}



/**
 *  赋值
 */
- (void)getValue{
    _drivingExperienceModel.custName = _customerName.text;              //客户名称
    _drivingExperienceModel.driverName =  _drivingName.text;            //试驾人员名称
    _drivingExperienceModel.driverMobile = _dringPhone.text;            //试驾人员电话
    _drivingExperienceModel.driverLicenseNo = _drivingNumber.text;      //试驾人驾驶证号
    _drivingExperienceModel.driveLicensePlate = _carNumber.text;        //车牌号
    _drivingExperienceModel.driveStartKM = _carStartKM.text;            //开始里程数
//    driveLicensePlate.dri _carEndKM;         //结束里程数
    
    _drivingExperienceModel.driveChassisNo = _chassisNo.text;           //底盘号
    _drivingExperienceModel.custMobile = _customerPhone.text;           //客户电话
    _drivingExperienceModel.custOtherPhone = _customerOtherPhone.text;  //客户其他电话
//    _drivingExperienceModel.brandCode _brand;                         //车系
//    _carModel;         //车型
    
    _drivingExperienceModel.driveStatus = _drivingState.value;          //试驾状态
    
    _drivingExperienceModel.driveComment  = _driveCommentTextView.text; //试驾备注

    // bug fix 创建试乘试驾的时候，将projectID传递过去
    _drivingExperienceModel.projectID = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.projectID?:@"";
    _drivingExperienceModel.custID = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.customerID?:@"";
    
    
    //======= 是否预约
//    if (_reservationSwitchView.on) {
     if (_addDrivingCarType == AddDrivingCarTypeYuyue) {
        _drivingExperienceModel.reservation = YES;
        _drivingExperienceModel.reservationTimer = _reservationButtonOutlet.value;
        
    }else{
        _drivingExperienceModel.reservation = NO;
        _drivingExperienceModel.reservationTimer = nil;
    }
 
    
    
    //======== 试驾列表来得预约时间是可以进行编辑
//    _drivingExperienceModel.driveStartTime = [DateManager timeIntervalWithDate:[NSDate date]];
//    
//    _drivingExperienceModel.driveEndTime =[DateManager timeIntervalWithDate:[NSDate date]] + 30*60*1000;
    
    _drivingExperienceModel.driveStartTime = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMDHMS_String:_drivingStartTimer.value]];
    
    _drivingExperienceModel.driveEndTime =[DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMDHMS_String:_drivingEndTimer.value]];
    
    
}


/**
 *  添加试驾信息
 */
- (IBAction)saveAction:(id)sender {
    [self getValue];
    
   
    NSString *error = [DrivingExperienceCheck drivingExperienceCheck:_drivingExperienceModel withOrigin:NO];
    
    if (error != nil) {
        [JKAlert showMessage:error];
        return;
    }
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:[_drivingExperienceModel toDictionary]];
    //statisticstype   int 类型  0  销售工作 1 客户视图 2 设置 3 首页
    [dic setValue:[NSNumber numberWithInt:3] forKey:@"statisticstype"];
    
    
    
    if (_addDrivingCarType == AddDrivingCarTypeYuyue2Lingche) {
        //  预约情况下领车操作
        
        [dic setObject:@"试驾中" forKey:@"driveStatus"];
        
        [DrivingExperienceModel addDrivingExperienceFromYuYue:dic Success:^(NSArray *headList, id responseObject) {
            
            NSDictionary *errorDic = [responseObject dictionaryForKey:@"validate_error"];
            [JKAlert showMessage:[[errorDic allValues] firstObject]];
            
            if ([responseObject boolForKey:@"success"]) {
                [JKAlert showMessage:@"新建试驾成功"];
                if(_moduleType ==ModuleTypeIndex){
                    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationSlideTopBottom];
                    
                }else{
                    //刷新列表页
                    if (_shouldReloadParentData) {
                        _shouldReloadParentData(YES,nil);
                    }
                    [self dismissDSPAPopup:^{
                        
                    }];
                }
                [[NSNotificationCenter defaultCenter]postNotificationName:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
            }
            
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        } Failure:^(NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        }];

    }else{
        
        //  试驾没有预约的情况下领车
        
        [DrivingExperienceModel addDrivingExperience:dic Success:^(NSArray *headList, id responseObject) {
            
            NSDictionary *errorDic = [responseObject dictionaryForKey:@"validate_error"];
            [JKAlert showMessage:[[errorDic allValues] firstObject]];
            
            if ([responseObject boolForKey:@"success"]) {
                [JKAlert showMessage:@"新建试驾成功"];
                if(_moduleType ==ModuleTypeIndex){
                    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationSlideTopBottom];
                    
                }else{
                    //刷新列表页
                    if (_shouldReloadParentData) {
                        _shouldReloadParentData(YES,nil);
                    }
                    [self dismissDSPAPopup:^{
                        
                    }];
                }
                [[NSNotificationCenter defaultCenter]postNotificationName:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
            }
            
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        } Failure:^(NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        }];
    }

}


-(void)ShouldReloadParentData:(ShouldReloadParentData)shouldReloadParentData{
    _shouldReloadParentData = [shouldReloadParentData copy];
}

/**
 *  关闭
 */
- (IBAction)backButtonTouch:(id)sender {
    if (_moduleType == ModuleTypeIndex) {
        [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationSlideTopBottom];

        
    }else{
        [self dismissDSPAPopup:^{
            
        }];
    }
}



#pragma mark --textField

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _carStartKM) {
        _carStartKM.keyboardType = UIKeyboardTypeNumberPad;
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
//    NSMutableString *muString = [[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"%@",textField.text?:@""]];
//    [muString replaceCharactersInRange:range withString:string];
    
    if (textField == _drivingNumber) {
        _drivingNumber.limit = LIMIT_CARDNUM;
    }
    
    return YES;
}


@end
