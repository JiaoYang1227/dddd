//
//  DrivingFeedbackTableViewCell.h
//  DSPA2015
//
//  Created by runlin on 2018/1/13.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioButton.h"


@interface DrivingFeedbackTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet RadioButton *cellRadioButtonOutlet;


- (void)configCellData:(id)obj withIndex:(NSIndexPath *)index;

@end
