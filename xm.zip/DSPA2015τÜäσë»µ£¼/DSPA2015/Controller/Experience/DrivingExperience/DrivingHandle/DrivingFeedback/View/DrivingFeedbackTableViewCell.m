//
//  DrivingFeedbackTableViewCell.m
//  DSPA2015
//
//  Created by runlin on 2018/1/13.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingFeedbackTableViewCell.h"
#import "DrivingGetCarNext.h"


@interface DrivingFeedbackTableViewCell ()
{
    
    __weak IBOutlet UIView *_drivingFeedbackView;
    
    __weak IBOutlet UILabel *_drivingFeedbackTitlePoint;

    __weak IBOutlet UILabel *_drivingFeedbackTitleName;
    
    
    DrivingGetCarNext_Sub *_model;
}



@end


@implementation DrivingFeedbackTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)configCellData:(DrivingGetCarNext_Sub *)obj withIndex:(NSIndexPath *)index{
    _model = obj;
    _drivingFeedbackTitlePoint.text = obj.vdescription?:@"";
    
    _drivingFeedbackTitleName.text = obj.title?:@"";
    
    
    if (!obj.info) {
        NSInteger index = obj.tag;
        if (index == 0) {
            index = 1;
        }
        [self.cellRadioButtonOutlet setSelectedWithTag:index];
    }
    
    if (obj.info) {
        NSInteger index = [obj.info.vexpermyd integerValue];
        [self.cellRadioButtonOutlet setSelectedWithTag:index];
    }
    
}


- (IBAction)radioButtonAction:(RadioButton *)sender {
    
    _model.tag = sender.tag;
    
    
    NSLog(@"%@",_model);
}





@end
