//
//  SignatureStroke.m
//  DSPA2015
//
//  Created by runlin on 2018/1/13.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "SignatureStroke.h"

@implementation SignatureStroke
- (void)strokeWithContext:(CGContextRef)context {
    CGContextSetStrokeColorWithColor(context, [_lineColor CGColor]);
    CGContextSetLineWidth(context, _strokeWidth);
    CGContextSetBlendMode(context, _blendMode);
    CGContextBeginPath(context);
    CGContextAddPath(context, _path);
    CGContextStrokePath(context);
}
@end
