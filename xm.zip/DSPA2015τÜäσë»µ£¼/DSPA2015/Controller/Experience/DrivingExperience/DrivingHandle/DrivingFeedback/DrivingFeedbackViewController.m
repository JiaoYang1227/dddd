//
//  DrivingFeedbackViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/13.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//
#import <objc/runtime.h>
#import "DrivingFeedbackViewController.h"

#import "DrivingFeedbackTableViewCell.h"
#import "SignatureDrawBackgoupImageView.h"
#import "DrivingReturnCarViewController.h"
#import "DrivingProtocolViewController.h"


@interface DrivingFeedbackViewController ()
{
    
    __weak IBOutlet UITableView *_drivingFeedbackTableview;
    
    __weak IBOutlet UIView *_signatureDrawView;
    
    SignatureDrawBackgoupImageView *_drawBackgourp;
    
    __weak IBOutlet UIImageView *_tempImgView;
    
}
@property(nonatomic,strong)NSDictionary *dataDict;
@property(nonatomic,strong)NSArray *dataArr;
@property(nonatomic,strong)NSMutableArray *isOpenArr;
@property(nonatomic,strong)NSArray *sectionNameArr;
@end

@implementation DrivingFeedbackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _drivingFeedbackTableview.sectionFooterHeight=0;//从第二个开始，每个section之间的距离
    
    NSArray*  firstDataArr=@[@"空凋01",@"空凋03",@"空调04"];
    NSArray*  secondArr=@[@"空凋01",@"空调02",@"空凋03",@"空调04"];
    NSArray*  thirdArr=@[@"空凋01",@"空调04"];
    _sectionNameArr=@[@"动力性",@"动力性",@"动力性"];
    self.isOpenArr=[[NSMutableArray alloc] init];

    self.dataArr=@[firstDataArr,secondArr,thirdArr];
    for (int i=0; i<self.dataArr.count; i++) {
        NSString*  state=@"close";
        [self.isOpenArr addObject:state];
    }
    
    
    _drawBackgourp = [SignatureDrawBackgoupImageView initWithImage:nil frame:_signatureDrawView.bounds lineWidth:1.0 lineColor:[UIColor blackColor]];
    [_signatureDrawView addSubview:_drawBackgourp];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)ClickSection:(UIButton*)sender{
    NSString *state=[self.isOpenArr objectAtIndex:sender.tag-100];
    if ([state isEqualToString:@"open"]) {
        state=@"close";
    }else
    {
        state=@"open";
    }
    self.isOpenArr[sender.tag-100]=state;
    NSIndexSet *indexSet = [[NSIndexSet alloc] initWithIndex:sender.tag-100];
    [_drivingFeedbackTableview reloadSections:indexSet withRowAnimation:UITableViewRowAnimationFade];
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // return self.dataDict.allKeys.count;
    return self.dataArr.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString*  state=[self.isOpenArr objectAtIndex:section];
    if ([state isEqualToString:@"open"]) {
        NSArray*  arr=[self.dataArr objectAtIndex:section];
        return arr.count;
    }
    return 0;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *CollectionCellIdentifier = [NSString stringWithFormat:@"%@%zd%zd",@"DrivingFeedbackTableViewCell",indexPath.section,indexPath.row];
    [tableView registerNib:[UINib nibWithNibName:@"DrivingFeedbackTableViewCell" bundle:nil] forCellReuseIdentifier:CollectionCellIdentifier];
    DrivingFeedbackTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CollectionCellIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView*  sectionBackView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, _drivingFeedbackTableview.frame.size.width, 50)];
    sectionBackView.backgroundColor=[UIColor yellowColor];
    if (section % 2 == 0) {
        sectionBackView.backgroundColor=[UIColor whiteColor];
    }else{
        sectionBackView.backgroundColor=[UIColor colorWithWholeRed:230 green:230 blue:230];
    }
    sectionBackView.layer.borderWidth = 1.;
    sectionBackView.layer.borderColor = [[UIColor colorWithWholeRed:152 green:152 blue:152] CGColor];
    
    UILabel*  nameLabel=[[UILabel alloc] initWithFrame:CGRectMake(169+30, 0, 100, 50)];
    nameLabel.text=[_sectionNameArr objectAtIndex:section];
    [sectionBackView addSubview:nameLabel];
    
    
    
    UIButton*  button=[UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:CGRectMake(0, 0, 896, 50)];
    button.tag=100+section;
    [button addTarget:self action:@selector(ClickSection:) forControlEvents:UIControlEventTouchUpInside];
    [sectionBackView addSubview:button];
    
    
    UIImageView* stateImage=[[UIImageView alloc] initWithFrame:CGRectMake(169, 25-7.5, 15, 15)];
    if ([[_isOpenArr objectAtIndex:section] isEqualToString:@"open"]) {
        [stateImage setImage:[UIImage imageNamed:@"checked.png"]];
    }
    else if ([[_isOpenArr objectAtIndex:section] isEqualToString:@"close"]) {
        [stateImage setImage:[UIImage imageNamed:@"unchecked.png"]];
    }
    [sectionBackView addSubview:stateImage];
    return sectionBackView;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}



- (void)cellButtonAction:(UIButton *)sender{
    NSLog(@"%zd",sender.tag);
}

- (IBAction)saveTemp:(id)sender {
    _tempImgView.image = [_drawBackgourp getImage];
}

- (IBAction)clearAction:(id)sender {
    [_drawBackgourp clearScreen];
}



//试驾协议
- (IBAction)shijiaxieyiButtonAction:(id)sender {
    [self.navigationController pushViewController:[DrivingProtocolViewController new] animated:YES];
}
//试驾反馈
- (IBAction)shijiafankuiButtonAction:(id)sender {
}


//试驾换车
- (IBAction)shijiahuancheButtonAction:(id)sender {
    [self.navigationController pushViewController:[DrivingReturnCarViewController new] animated:YES];
}

//试驾结束
- (IBAction)shijiajieshuButtonAction:(id)sender {
    
}

//返回
- (IBAction)fanhuiButtonAction:(id)sender {
    Class class = NSClassFromString(@"DrivingExperienceNewViewController");
    NSAssert(class != nil,@"Class YES");
    UIViewController *vc = [[NSClassFromString(@"DrivingExperienceNewViewController") alloc] init];
    
    [self.navigationController pushViewController:vc animated:YES];
}


@end
