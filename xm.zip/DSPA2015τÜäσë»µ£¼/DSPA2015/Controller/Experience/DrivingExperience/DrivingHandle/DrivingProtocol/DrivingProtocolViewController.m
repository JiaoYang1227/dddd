//
//  DrivingProtocolViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/16.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingProtocolViewController.h"
#import "DrivingFeedbackViewController.h"
#import "DrivingReturnCarViewController.h"

@interface DrivingProtocolViewController ()

@end

@implementation DrivingProtocolViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//试驾协议
- (IBAction)shijiaxieyiButtonAction:(id)sender {
}
//试驾反馈
- (IBAction)shijiafankuiButtonAction:(id)sender {
    [self.navigationController pushViewController:[DrivingFeedbackViewController new] animated:YES];
}


//试驾换车
- (IBAction)shijiahuancheButtonAction:(id)sender {
    [self.navigationController pushViewController:[DrivingReturnCarViewController new] animated:YES];
}

//试驾结束
- (IBAction)shijiajieshuButtonAction:(id)sender {
    
}

//返回
- (IBAction)fanhuiButtonAction:(id)sender {
    Class class = NSClassFromString(@"DrivingExperienceNewViewController");
    NSAssert(class != nil,@"Class YES");
    UIViewController *vc = [[NSClassFromString(@"DrivingExperienceNewViewController") alloc] init];
    
    [self.navigationController pushViewController:vc animated:YES];
}

@end
