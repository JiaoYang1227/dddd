//
//  DrivingPopSignatureViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingPopSignatureViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "SignatureDrawBackgoupImageView.h"


@interface DrivingPopSignatureViewController ()
{
    
    __weak IBOutlet UIView *_signatureDrawView;
    
    SignatureDrawBackgoupImageView *_drawBackgourp;
}
@end

@implementation DrivingPopSignatureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _drawBackgourp = [SignatureDrawBackgoupImageView initWithImage:nil frame:_signatureDrawView.bounds lineWidth:5.0 lineColor:[UIColor blackColor]];
    [_signatureDrawView addSubview:_drawBackgourp];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setDrivingPopSignatureViewCallBack:(DrivingPopSignatureViewCallBack)drivingPopSignatureViewCallBackPar{
    _drivingPopSignatureViewCallBack = [drivingPopSignatureViewCallBackPar copy];
}


- (IBAction)commitButtonAction:(id)sender {
    
    UIImage *img = [_drawBackgourp getImage];
    
    if (!img) {
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"请签名在提交"];
        [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            
        }];

        [alert show7];
    }else{
        if(_drivingPopSignatureViewCallBack){
            _drivingPopSignatureViewCallBack(img);
            [self dismissDSPAPopup:^{
                
            }];
        }
    }
}

- (IBAction)closeButtonAction:(id)sender {
    [self dismissDSPAPopup:^{
        
    }];
}




@end
