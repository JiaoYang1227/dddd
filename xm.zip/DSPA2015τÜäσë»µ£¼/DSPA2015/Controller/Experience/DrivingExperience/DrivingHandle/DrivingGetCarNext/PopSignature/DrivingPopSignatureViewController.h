//
//  DrivingPopSignatureViewController.h
//  DSPA2015
//
//  Created by runlin on 2018/1/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
typedef void(^DrivingPopSignatureViewCallBack)(UIImage *image);

@interface DrivingPopSignatureViewController : BaseViewController

{
    DrivingPopSignatureViewCallBack _drivingPopSignatureViewCallBack;
}

-(void)setDrivingPopSignatureViewCallBack:(DrivingPopSignatureViewCallBack)drivingPopSignatureViewCallBackPar;


@end
