//
//  DrivingGetCarNext.m
//  DSPA2015
//
//  Created by runlin on 2018/1/20.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingGetCarNext.h"
#import "AppDelegate.h"




@implementation DrivingGetCarNext_info
@end


@implementation DrivingGetCarNext_Sub
@end



@implementation DrivingGetCarNext
+ (AFHTTPRequestOperation*)getDICCTryAttentionList:(NSDictionary *)param
                                           Success:(void (^)(NSArray *headList,id responseObject))success
                                           Failure:(void (^)(NSError *error))failue{
    return [APIManager SafePOST:GET_DRIVE_GETDICCTRYATTENTIONLIST parameters:param  appendUserInfo:YES success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSMutableArray *items =[[NSMutableArray alloc] init];
        NSArray *dicList = [responseObject arrayForKey:@"dICCTryAttentionList"];
        
        
//        for (NSDictionary *dic in dicList) {
//            DrivingGetCarNext *obj = [DrivingGetCarNext objectFromDictionary:dic];
//            [items addObject:obj];
//        }
        
        
        for (int i = 0; i<dicList.count; i++) {
            NSDictionary *dic = dicList[i];
            DrivingGetCarNext *obj = [DrivingGetCarNext objectFromDictionary:dic];
            NSArray *objArray = obj.diccTryExperienceList;
            
            for (int j = 0; j<objArray.count; j++) {
                NSDictionary *subDic = [NSDictionary dictionaryWithDictionary:objArray[j]];
                DrivingGetCarNext_Sub *sub = [DrivingGetCarNext_Sub objectFromDictionary:subDic];
                if (j==0) {
                    sub.title = obj.vdescription?:@"";
                }
                [items addObject:sub];
            }
        }
        
        
        success(items,responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        failue(error);
    }];
}







+ (void)uploadButtonAction:(NSDictionary *)par
              withImagePar:(UIImage *)image
         withImageFileName:(NSString *)fileName
                   CompletionHandler:(void (^)(id responseObject, NSError * error))completionHandler
                   {
    
    //    0未上传完毕1已上传完毕
    //    [AppDelegate APP].BaseURL]
    NSString *url = [[AppDelegate APP].BaseURL stringByAppendingPathComponent:GET_DRIVE_SAVEDRIVEFEEDBACKINFO];
    NSDictionary *formParamater=@{@"jsonString":[par?:@{} JSONStringValue]};
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:url parameters:formParamater constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        [formData appendPartWithFileData:UIImageJPEGRepresentation(image, 1) name:fileName fileName:fileName mimeType:@"image/jpeg"];
    } error:nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [APIManager sharedClient].responseSerializer;
    
    NSURLSessionUploadTask *uploadTask;
    
    uploadTask = [manager uploadTaskWithStreamedRequest:request progress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        NSLog(@"%@",responseObject);
        NSLog(@"%@",error);
        completionHandler(responseObject,error);
    }];
    
    [uploadTask resume];
}





@end
