 //
//  DrivingGetCarNextViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//
#import "DrivingGetCarNextViewController.h"
#import "UIViewController+DSPAPopup.h"

#import "DrivingFeedbackViewController.h"
#import "SignatureDrawBackgoupImageView.h"
#import "DrivingFeedbackTableViewCell.h"
#import "DrivingPopSignatureViewController.h"
#import "DrivingGetCarNext.h"
#import "PrintDetailViewController.h"
#import "DateManager.h"
#import "TMCache.h"
#import "RecipePrintPageRenderer.h"
#import "UIImageView+WebCache.h"
#import <JavaScriptCore/JavaScriptCore.h>


@interface DrivingGetCarNextViewController ()<UITableViewDelegate,UITableViewDataSource,RadioButtonDelegate,UIWebViewDelegate>
{
    
    __weak IBOutlet UIView *_drivingGetCarNextTitleView;    //头视图
    __weak IBOutlet UIView *_drivingGetCarNextControllerView; //控制视图
    __weak IBOutlet UIView *_drivingGetCarNextSubView;      //子视图
    
#pragma =================
#pragma mark 试驾协议打印
#pragma =================
    UIWebView *_webview;
    BOOL _isPrint;
    
    NSDictionary *_shijia_tiyandian_xuanze;
    
#pragma =================
#pragma mark 试驾协议打印 end
#pragma =================
    
    
#pragma =================
#pragma mark 试驾反馈
#pragma =================
    
    __weak IBOutlet RadioButton *_trydrivetypeButtonOutlet; //主动试驾 邀约试驾
    IBOutlet UIView *_drivingFeedbackView;
    __weak IBOutlet UIView *_signatureDrawView;
    SignatureDrawBackgoupImageView *_drawBackgourp;
    
    __weak IBOutlet UIImageView *_signatureImage;
    UITableView *_drivingFeedbackTableview;
    __weak IBOutlet UIView *_drivingFeedbackTableviewSuperView;
    //
    NSMutableArray *_drivingFeedbackInfoList;
    NSMutableArray *_drivingFeedbackHeadInfoList;

    //===
    __weak IBOutlet RadioButton *_liuchengzhixing_ButtonOutlet; //流程执行
    __weak IBOutlet RadioButton *_zhuanyezhishi_ButtonOutlet;//专业知识
    __weak IBOutlet RadioButton *_pinpaijiazhi_ButtonOutlet;//品牌价值
    __weak IBOutlet RadioButton *_yiyijieda_ButtonOutlet;//异议解答
    NSMutableDictionary *_itemsFeedbackInfo; //试驾反馈信息选择
    
    
    __weak IBOutlet UIButton *_commitDrivingFeedbackButtonOutlet;
    
    
#pragma =================
#pragma mark 试驾反馈 end
#pragma =================
 
    
#pragma =================
#pragma mark 试驾换车
#pragma =================
    IBOutlet UIView *_returnCarView;
    __weak IBOutlet BorderTextField *_drivingName;
    __weak IBOutlet BorderTextField *_drivingMobile;
    __weak IBOutlet BorderTextField *_drivingAddress;
    __weak IBOutlet BorderTextField *_drivingBeginKM;
    __weak IBOutlet BorderTextField *_drivingKM;
    __weak IBOutlet BorderTextField *_drivingEndKM;
    __weak IBOutlet SelectButton *_drivingBeginTime;
    __weak IBOutlet SelectButton *_drivingEndTimer;
    
    __weak IBOutlet SelectButton *_drivingMapOutlet;
#pragma =================
#pragma mark 试驾换车 end
#pragma =================
    
    __weak IBOutlet UIView *_subView;
    NSInteger currentSelectButton_;
}


@property (strong, nonatomic) JSContext *jsContext;




#pragma =================
#pragma mark 试驾反馈
#pragma =================
@property(nonatomic,strong)NSDictionary *dataDict;
@property(nonatomic,strong)NSMutableArray *dataArray;





#pragma =================
#pragma mark 试驾反馈 end
#pragma =================

@property (weak, nonatomic) IBOutlet UIView *floatView;
@property (weak, nonatomic) IBOutlet UIButton *float_left_buttonOutlet;

@property (weak, nonatomic) IBOutlet UIButton *shijiaxieyiButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *shijiafankuiButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *shijiahuancheButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *shijiaquxiaoButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *fanhuiButtonOutlet;

@property (weak, nonatomic) IBOutlet UIButton *printButtonOutlet;

@end

@implementation DrivingGetCarNextViewController

//试驾领车下一步操作

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    //获取试驾反馈列表数据信息
    [self getDrivingFeedbackInfoList];
    
    
    _itemsFeedbackInfo = [[NSMutableDictionary alloc] init];
    self.dataArray = [[NSMutableArray alloc] init];
    //重置部分按钮下拉背景视图
    [self.shijiaxieyiButtonOutlet addTarget:self action:@selector(drivingState:) forControlEvents:UIControlEventTouchDown];
    [self.shijiafankuiButtonOutlet addTarget:self action:@selector(drivingState:) forControlEvents:UIControlEventTouchDown];
    [self.shijiahuancheButtonOutlet addTarget:self action:@selector(drivingState:) forControlEvents:UIControlEventTouchDown];
    [self.shijiaquxiaoButtonOutlet addTarget:self action:@selector(cancelButtonAction) forControlEvents:UIControlEventTouchDown];
    [self.fanhuiButtonOutlet addTarget:self action:@selector(gobackButtonAction) forControlEvents:UIControlEventTouchDown];
    
    
    switch (self.drivingStateType) {
        case DRIVING_XIEYI:
        {
            
            self.shijiaxieyiButtonOutlet.selected = YES;
            self.printButtonOutlet.hidden = NO;
            [self print];
            [_float_left_buttonOutlet setImage:[UIImage imageNamed:@"DrivingReturnCar_dayin_yes_link"] forState:UIControlStateNormal];
            [_float_left_buttonOutlet removeTarget:self action:@selector(drivingReturnCarButtonAction:) forControlEvents:UIControlEventTouchDown];
            [_float_left_buttonOutlet addTarget:self action:@selector(printButtonAction:) forControlEvents:UIControlEventTouchDown];
        }
            break;
        case DRIVING_FANKUI:
        {
            _shijia_tiyandian_xuanze = [self getWebViewSelectPoint];
            
            
            _floatView.hidden = YES;
            self.shijiafankuiButtonOutlet.selected = YES;
            [_subView addSubview:_drivingFeedbackView];
            [self createDrivingFeedback:_shijia_tiyandian_xuanze];
        }
            break;
        case DRIVING_HUANCHE:
        {
            [_float_left_buttonOutlet removeTarget:self action:@selector(printButtonAction:) forControlEvents:UIControlEventTouchDown];
            [_float_left_buttonOutlet setImage:[UIImage imageNamed:@"DrivingReturnCar_querenhuanche_yes_link"] forState:UIControlStateNormal];
            [_float_left_buttonOutlet addTarget:self action:@selector(drivingReturnCarButtonAction:) forControlEvents:UIControlEventTouchDown];
            self.shijiahuancheButtonOutlet.selected = YES;
            [self bringDataFormDivingRetunCar];
            [_subView addSubview:_returnCarView];
        }
            break;
        default:
            break;
    }
    
    
    
    if (self.driving_ing) {
        _subView.userInteractionEnabled = YES;
        _float_left_buttonOutlet.enabled = YES;
        _shijiaquxiaoButtonOutlet.enabled = YES;
        _commitDrivingFeedbackButtonOutlet.enabled = YES;
    }else{
        _subView.userInteractionEnabled = NO;
        _float_left_buttonOutlet.enabled = NO;
        _shijiaquxiaoButtonOutlet.enabled = NO;
        _commitDrivingFeedbackButtonOutlet.enabled = NO;

    }
    
    
    if (self.drivingStateType == DRIVING_XIEYI) {
        _subView.userInteractionEnabled = YES;
        _float_left_buttonOutlet.enabled = YES;
        self.printButtonOutlet.hidden = NO;
    }
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if (self.client_and_service_form) {
        //头视图
        _drivingGetCarNextTitleView.hidden = YES;
        //控制视图
        CGRect frameController = _drivingGetCarNextControllerView.frame;
        _drivingGetCarNextControllerView.frame =CGRectMake(0, 0, frameController.size.width, frameController.size.height);
        //子视图
        CGRect frameSubView = _drivingGetCarNextSubView.frame;
        _drivingGetCarNextSubView.frame = CGRectMake(frameSubView.origin.x, frameController.size.height, frameSubView.size.width, frameSubView.size.height);
    }
}



- (void)drivingState:(UIButton *)sender{
    [self resetButtonState];
    sender.selected = !sender.selected;
    if(currentSelectButton_ == sender.tag){
        return;
    }
    
    
    currentSelectButton_ = sender.tag;
    [_subView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.printButtonOutlet.hidden = YES;
    _floatView.hidden = NO;
    
    
    
    //试驾中的话，页面可以编辑
    if (self.driving_ing) {
        _subView.userInteractionEnabled = YES;
        _float_left_buttonOutlet.enabled = YES;
        _shijiaquxiaoButtonOutlet.enabled = YES;
    }else{
        _subView.userInteractionEnabled = NO;
        _float_left_buttonOutlet.enabled = NO;
        _shijiaquxiaoButtonOutlet.enabled = NO;

    }
    
    
    
    switch (sender.tag) {
        case DRIVING_XIEYI:
        {
            
            _subView.userInteractionEnabled = YES;
            _float_left_buttonOutlet.enabled = YES;
            
            self.printButtonOutlet.hidden = NO;
            [_float_left_buttonOutlet setImage:[UIImage imageNamed:@"DrivingReturnCar_dayin_yes_link"] forState:UIControlStateNormal];
            [_float_left_buttonOutlet removeTarget:self action:@selector(drivingReturnCarButtonAction:) forControlEvents:UIControlEventTouchDown];
            [_float_left_buttonOutlet addTarget:self action:@selector(printButtonAction:) forControlEvents:UIControlEventTouchDown];
            [self print];
        }
            break;
        case DRIVING_FANKUI:
        {
            
            _shijia_tiyandian_xuanze = [self getWebViewSelectPoint];
            
            _floatView.hidden = YES;
            [_subView addSubview:_drivingFeedbackView];
            [self createDrivingFeedback:_shijia_tiyandian_xuanze];
        }
            break;
        case DRIVING_HUANCHE:
        {
            [_float_left_buttonOutlet setImage:[UIImage imageNamed:@"DrivingReturnCar_querenhuanche_yes_link"] forState:UIControlStateNormal];
            [_float_left_buttonOutlet removeTarget:self action:@selector(printButtonAction:) forControlEvents:UIControlEventTouchDown];
            [_float_left_buttonOutlet addTarget:self action:@selector(drivingReturnCarButtonAction:) forControlEvents:UIControlEventTouchDown];
            [self bringDataFormDivingRetunCar];
            [_subView addSubview:_returnCarView];
        }
            break;
        case DRIVING_JIESHU:
            break;
        case DRIVING_FANHUI:
            break;
        default:
            break;
    }
}

/**
 *    充值所有按钮状态
 */
- (void)resetButtonState{
    self.shijiaxieyiButtonOutlet.selected = NO;
    self.shijiafankuiButtonOutlet.selected = NO;
    self.shijiahuancheButtonOutlet.selected = NO;
    self.shijiaquxiaoButtonOutlet.selected = NO;
    self.fanhuiButtonOutlet.selected = NO;
}


/**
 *  返回按钮点击
 */
- (void)gobackButtonAction{
    JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"确定要退出当前页面吗？"];
    [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
        
        if (self.client_and_service_form) {
            //销售视图和客户视图下直接关闭当前页面
            [self dismissDSPAPopup:^{
                
            }];
        }else{
            //跳转到试驾看板页面
            Class class = NSClassFromString(@"DrivingExperienceNewViewController");
            NSAssert(class != nil,@"Class YES");
            UIViewController *vc = [[NSClassFromString(@"DrivingExperienceNewViewController") alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
        
    }];
    [alert addCancleButtonWithTitle:@"取消" handler:^(JKAlertItem *item) {
    }];
    [alert show7];
}






#pragma =================
#pragma mark 试驾协议打印
#pragma =================

- (void)print{
     _webview = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, _subView.frame.size.width, _subView.frame.size.height - 100)];
    [_subView addSubview:_webview];
    NSURLRequest *request =[self formURL];
    _webview.delegate = self;
    [_webview loadRequest:request];
}



//格式化url
- (NSURLRequest *)formURL {
    NSString *serverUrlPrefix = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    NSMutableString *absUrl = [NSMutableString stringWithString:serverUrlPrefix];
    [absUrl appendString:GET_DRIVE_SELECTTESTDRIVEAGREEMENTINFO];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    DrivingTimerModel *dtm = [_drivingExperienceModel.time firstObject];
    
    [dic setObject:[NSNumber numberWithLongLong:_drivingExperienceModel.driveStartTime?:dtm.begintime] forKey:@"driveStartTime"];
    [dic setObject:_drivingExperienceModel.driveStartKM?:dtm.driveStartKM?:@"" forKey:@"driveStartKM"];
    [dic setObject:_drivingExperienceModel.driverLicenseNo?:@"" forKey:@"driverLicenseNo"];
    [dic setObject:_drivingExperienceModel.driverMobile?:dtm.VRelatePhone?:@"" forKey:@"custMobile"];
    [dic setObject:_drivingExperienceModel.custName?:dtm.VRelateName?:@"" forKey:@"custName"];
    [dic setObject:_drivingExperienceModel.driverName?:dtm.VRelateName?:@"" forKey:@"driverName"];
    
    [dic setObject:_drivingExperienceModel.vTryCarPath?:dtm.vTryCarPath?:@"" forKey:@"driveRoute"];
    
    if (![[dic objectForKey:@"driveRoute"] hasPrefix:@"TryDriveRoute"]) {
        [dic setObject:_drivingExperienceModel.vTryCarPathCode?:dtm.vTryCarPathCode?:@"" forKey:@"driveRoute"];
    }
    
    
    [dic setObject:_drivingExperienceModel.driveTestID?:dtm.driveTestID?:self.driveTestID?:_drivingExperienceModel.trydriveid?:@"" forKey:@"driveTestID"];
    
    NSDictionary *formParamater=@{@"jsonString":[dic JSONStringValue]?:@""};
    AFHTTPRequestSerializer *serializer = [AFHTTPRequestSerializer serializer];
    NSMutableURLRequest *request =[serializer requestWithMethod:@"POST" URLString:absUrl parameters:formParamater error:nil];
    NSLog(@"url:%@",request.URL.absoluteString);
    if ([request HTTPBody]) {
        NSString *HTTPBody = [[NSString alloc] initWithData:[request HTTPBody] encoding:NSUTF8StringEncoding];
        NSLog(@"HTTPBody:%@",HTTPBody);
    }
    return request;
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSString *requestString = [[[request URL]  absoluteString] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding ];
    //解决iframe打印一半问题！非常重要！！！！！！！！！！！！！！！！！！！！！！！！！！！
    if (_isPrint && [requestString rangeOfString:@"mark=ios"].location == NSNotFound && [requestString rangeOfString:@"vision/ssreport/htmls/"].location != NSNotFound) {
        requestString =  [requestString stringByAppendingString:@"&mark=ios"];
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:requestString]];
        urlRequest.HTTPBody = request.HTTPBody;
        PrintDetailViewController *print = [[PrintDetailViewController alloc]init];
        print.myRequset = urlRequest;
        [self presentDSPAPopupDetail:print];
        _isPrint = NO;
    }
    return YES;
}

//打印点击
- (IBAction)shijiaxieyi_ButtonAction:(id)sender{
    //打印之前保存刷新数据
    [_webview stringByEvaluatingJavaScriptFromString:@"spreadsheetReport.spreadsheetReportWriteBack.doSaveClick()"];
    [_webview stringByEvaluatingJavaScriptFromString:@"spreadsheetReport.doRefresh()"];
    _isPrint = YES;
}




//打印Action
- (IBAction)printButtonAction:(UIButton *)sender
{
    //  解决 弹出窗太大问题
    self.modalPresentationStyle = UIModalPresentationFormSheet;
    //调整箭头方向
//    [printSheet showFromRect:[self.view convertRect:CGRectMake(0, 0, 93, 42) fromView:self.view] inView:self.view animated:YES];
    NSLog(@"%@",NSStringFromCGRect(sender.frame));
    
    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
    
    if(!controller){
        NSLog(@"Couldn't get shared UIPrintInteractionController!");
        return;
    }
    UIPrintInteractionCompletionHandler completionHandler =
    ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
        if(!completed && error){
            NSLog(@"FAILED! due to error in domain %@ with error code %zd", error.domain, error.code);
        }
    };
    
    
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    printInfo.outputType = UIPrintInfoOutputGeneral;
    printInfo.duplex = UIPrintInfoDuplexLongEdge;
    controller.printInfo = printInfo;
    controller.showsPageRange = YES;
    UIViewPrintFormatter *viewFormatter = [_webview viewPrintFormatter];
    
    //有头打印
    RecipePrintPageRenderer * uiPage= [[RecipePrintPageRenderer alloc] initWithPrintFormatter:viewFormatter];
    [uiPage addPrintFormatter:viewFormatter startingAtPageAtIndex:0];

//    //去头打印
//    UIPrintPageRenderer *uiPage = [[UIPrintPageRenderer alloc] init];
//    [uiPage addPrintFormatter:viewFormatter startingAtPageAtIndex:0];
//
    controller.printPageRenderer = uiPage;
    presentFromRect:inView:animated:completionHandler:
    [controller presentFromRect:sender.frame inView:self.view animated:YES completionHandler:completionHandler];
}



#pragma =================
#pragma mark 试驾协议打印 end
#pragma =================



#pragma =================
#pragma mark 试驾反馈
#pragma =================

- (void)bringDataFormDrivingFeedback:(NSMutableArray *)array{
    for (NSDictionary *dict in array) {
        if ([[dict objectForKey:@"vexpercode"] isEqualToString:@"01"]) { //代表第一个按钮
            NSInteger index = [[dict objectForKey:@"vexpermyd"] integerValue];
            if (index == 0) {
                index = 1;
            }
            [_liuchengzhixing_ButtonOutlet setSelectedWithTag:index]; //流程执行
        }else if ([[dict objectForKey:@"vexpercode"] isEqualToString:@"02"]){
            NSInteger index = [[dict objectForKey:@"vexpermyd"] integerValue];
            if (index == 0) {
                index = 1;
            }
            [_zhuanyezhishi_ButtonOutlet setSelectedWithTag:index]; //专业知识
        }else if ([[dict objectForKey:@"vexpercode"] isEqualToString:@"03"]){
            NSInteger index = [[dict objectForKey:@"vexpermyd"] integerValue];
            if (index == 0) {
                index = 1;
            }
            [_pinpaijiazhi_ButtonOutlet setSelectedWithTag:index]; //品牌价值
        }else if([[dict objectForKey:@"vexpercode"] isEqualToString:@"04"]){
            NSInteger index = [[dict objectForKey:@"vexpermyd"] integerValue];
            if (index == 0) {
                index = 1;
            }
            [_yiyijieda_ButtonOutlet setSelectedWithTag:index]; //异议解答
        }
    }
}


- (IBAction)showSignatureButtonAction:(id)sender {
    DrivingPopSignatureViewController *pop = [[DrivingPopSignatureViewController alloc] init];
    [pop setDrivingPopSignatureViewCallBack:^(UIImage *image) {
        _signatureImage.image = image;
    }];
    [self presentDSPAPopup:pop parentViewController:self touchCallBack:^{
        
    } haveMask:YES includeNavgation:YES alignTop:NO];
}

/**
 *   获取试驾反馈列表
 */

- (void)getDrivingFeedbackInfoList{
    
    //如果换车的话，需要把试驾ID带过去，没换车不需要传递试驾ID
    
    DrivingTimerModel *dtm =[_drivingExperienceModel.time firstObject];
    NSString *key = [NSString stringWithFormat:@"%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"driveTestID"];
    
    NSString *keyImag = [NSString stringWithFormat:@"%@%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"",@"IMG"];
    NSDictionary *dicCache = (NSDictionary *)[[TMDiskCache sharedCache] objectForKey:key];
    UIImage *image = (UIImage *)[[TMDiskCache sharedCache] objectForKey:keyImag];
    
    
    NSMutableArray *dataArrayCache = (NSMutableArray *)[[TMDiskCache sharedCache] objectForKey:[NSString stringWithFormat:@"%@dataArrayCache",key]];

    
    
    if (dicCache.count > 0) {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        NSArray *dicList = [dicCache objectForKey:@"feedInfo"];
        NSMutableArray *items = [[NSMutableArray alloc] init];
        NSMutableArray *itemsHead = [[NSMutableArray alloc] init];

        for (int i = 0; i<dicList.count && i < 5; i++) {
            NSDictionary *dic = dicList[i];
            
            if ([[dic objectForKey:@"vattcode"] isEqualToString:@"drive01"]) {
                [itemsHead addObject:dic];
            }
        }
        
        
        for (int i = 0; i<dataArrayCache.count; i++) {
            NSDictionary *dic = dataArrayCache[i];
            DrivingGetCarNext_Sub *sub = [DrivingGetCarNext_Sub objectFromDictionary:dic];
            [items addObject:sub];
        }
        
        
        
        _drivingFeedbackInfoList = [[NSMutableArray alloc] initWithArray:items];
        _drivingFeedbackHeadInfoList = [[NSMutableArray alloc] initWithArray:itemsHead];
        _signatureImage.image = image;
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        
    }else{
        
        NSDictionary *dic;
        if ([_drivingExperienceModel.driveStatusCode isEqualToString:@"03"]) {//试驾完成才传试驾id
            dic = @{@"driveTestID":self.driveTestID?:_drivingExperienceModel.driveTestID?:_drivingModelFormDMS.driveId};
        }else{
            dic = @{};
        }
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [DrivingGetCarNext getDICCTryAttentionList:dic Success:^(NSArray *headList, id responseObject) {
            
            NSString *url = [responseObject objectForKey:@"trydriveqmurl"];
            [_signatureImage sd_setImageWithURL:[NSURL URLWithString:url?:@""]];
            
            NSString *tryDriveType = [[responseObject objectForKey:@"tryDriveType"] description]?:@"0";
            
            
            if ([tryDriveType isEqualToString:@"1"]) {
                [_trydrivetypeButtonOutlet setSelectedWithTag:1];
            }else{
                [_trydrivetypeButtonOutlet setSelectedWithTag:0];
            }
            
            
            
            if (headList.count > 0) {
                _drivingFeedbackInfoList = [[NSMutableArray alloc] initWithArray:headList];
                _drivingFeedbackHeadInfoList = [[NSMutableArray alloc] initWithArray:[responseObject arrayForKey:@"driveInfo"]];
                if (_drivingFeedbackInfoList.count > 0) {
//                    [_shijiafankuiButtonOutlet sendActionsForControlEvents:UIControlEventTouchDown];
                }
                
            }else{
                //读取出本地的缓存
            }
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        } Failure:^(NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }];
    }
}





//提交试驾反馈
- (IBAction)commitDrivingFeedback:(id)sender{
    [self getValueFormDrivingFeedback];
    [self.shijiahuancheButtonOutlet sendActionsForControlEvents:UIControlEventTouchDown];
}
//获取试驾反馈信息参数
- (void)getValueFormDrivingFeedback{
    //===
    NSMutableDictionary *dicPar = [[NSMutableDictionary alloc] init];
    NSMutableArray *item = [[NSMutableArray alloc] init];
    if (_itemsFeedbackInfo) {
        [item addObjectsFromArray:[_itemsFeedbackInfo allValues]];
    }
    
    [item addObject:@{@"vexpercode":@"01", @"vexpermyd":@(_liuchengzhixing_ButtonOutlet.selectedButton.tag), @"vattcode":@"drive01"}];
    [item addObject:@{@"vexpercode":@"02", @"vexpermyd":@(_zhuanyezhishi_ButtonOutlet.selectedButton.tag), @"vattcode":@"drive01"}];
    [item addObject:@{@"vexpercode":@"03", @"vexpermyd":@(_pinpaijiazhi_ButtonOutlet.selectedButton.tag), @"vattcode":@"drive01"}];
    [item addObject:@{@"vexpercode":@"04", @"vexpermyd":@(_yiyijieda_ButtonOutlet.selectedButton.tag), @"vattcode":@"drive01"}];
    
    
    NSMutableArray *dataArrayCache = [[NSMutableArray alloc] init];
    for (DrivingGetCarNext_Sub *model in self.dataArray) {
        
        if (model.tag == 0) {
            model.tag = 1;
        }
        
        NSDictionary *dic = @{@"vexpercode":model.vcode?:@"", @"vexpermyd":@(model.tag), @"vattcode":model.vattcode?:@""};
        [item addObject:dic];
        [dataArrayCache addObject:[model toDictionary]];
    }
    
    
    
    DrivingTimerModel *dtm =[_drivingExperienceModel.time firstObject];
    
    [dicPar setObject:[NSNumber numberWithInteger:_trydrivetypeButtonOutlet.selectedButton.tag] forKey:@"trydrivetype"];
    [dicPar setObject:item forKey:@"feedInfo"];
    [dicPar setObject:_drivingExperienceModel.id?:dtm.driveTestID?:_drivingExperienceModel.driveTestID?:@"" forKey:@"trydriveid"];
    [dicPar setObject:_drivingExperienceModel.custID?:dtm.UCusID?:_drivingExperienceModel.custID?:@"" forKey:@"customerid"];
    [dicPar setObject:_drivingExperienceModel.projectID?:dtm.UProjectID?:_drivingExperienceModel.projectID?:@"" forKey:@"projectid"];
    [dicPar setObject:_drivingExperienceModel.VTryType?:@"1" forKey:@"istake"]; //试驾类型 试乘类型
    [dicPar setObject:_drivingExperienceModel.driverName?:@"" forKey:@"drivingname"];//驾驶证姓名
    [dicPar setObject:@"0" forKey:@"isupdate"];//驾驶证姓名改动标识 驾驶证姓名改动标识 0未改1改动
    //拼接缓存的key
    NSString *key = [NSString stringWithFormat:@"%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"driveTestID"];
    NSString *keyImag = [NSString stringWithFormat:@"%@%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"",@"IMG"];
    //临时缓存本地参数
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [[TMDiskCache sharedCache] setObject:dataArrayCache forKey:[NSString stringWithFormat:@"%@dataArrayCache",key]];
    [[TMDiskCache sharedCache] setObject:dicPar forKey:key];
    [[TMDiskCache sharedCache] setObject:_signatureImage.image?:[UIImage imageNamed:@""] forKey:keyImag];
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}


- (void)saveDrivingFeedbackToService:(NSDictionary *)dicPar withImage:(UIImage *)image{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [DrivingGetCarNext uploadButtonAction:dicPar withImagePar:image withImageFileName:@"imgFile" CompletionHandler:^(id responseObject, NSError *error) {
        
        if ([responseObject objectForKey:@"validate_error"]) {
            NSArray *error = [[responseObject objectForKey:@"validate_error"] allValues];
            [JKAlert showMessage:[error firstObject]];
            
        }else if([responseObject boolForKey:@"success"]){
            
            JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"试驾还车成功"];
            [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
                //拼接缓存的key
                DrivingTimerModel *dtm =[_drivingExperienceModel.time firstObject];

                NSString *key = [NSString stringWithFormat:@"%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"driveTestID"];
                NSString *keyImag = [NSString stringWithFormat:@"%@%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"",@"IMG"];
                //删除本地临时缓存
                [[TMDiskCache sharedCache] removeObjectForKey:key?:@""];
                [[TMDiskCache sharedCache] removeObjectForKey:keyImag?:@""];
                [[TMDiskCache sharedCache] removeObjectForKey:[NSString stringWithFormat:@"%@dataArrayCache",key]];

                
                if (self.client_and_service_form) {
                    //销售视图和客户视图下直接关闭当前页面
                    [self dismissDSPAPopup:^{
                        
                    }];
                }else{
                    //跳转到试驾看板页面
                    //跳转回到试驾看板的首页
                    Class class = NSClassFromString(@"DrivingExperienceNewViewController");
                    NSAssert(class != nil,@"Class YES");
                    UIViewController *vc = [[NSClassFromString(@"DrivingExperienceNewViewController") alloc] init];
                    [self.navigationController pushViewController:vc animated:YES];
                }
            }];
            [alert show7];
            
        }else{
            
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}



- (void)createDrivingFeedback:(NSDictionary *)dictPoint{
    if (_drivingFeedbackInfoList.count > 0) {
        self.dataArray = [[NSMutableArray alloc] init];
        
        NSArray *filterArrayTemp = [NSArray arrayWithArray:_drivingFeedbackInfoList];
        NSMutableArray *temp = [[NSMutableArray alloc] init];
        
        for (NSDictionary *dic in dictPoint) {
            NSString *formatStr = [NSString stringWithFormat:@"vattcode == '%@'",[dic objectForKey:@"id"]?:@""];
            NSPredicate *predicate = [NSPredicate predicateWithFormat:formatStr];
            NSArray *filterArray = [filterArrayTemp filteredArrayUsingPredicate:predicate];
            [temp addObjectsFromArray:filterArray?:@[]];
        }
        
        if (temp.count > 0) {
            self.dataArray = [[NSMutableArray alloc] initWithArray:temp];
        }else{
            self.dataArray = [[NSMutableArray alloc] initWithArray:_drivingFeedbackInfoList];
        }
        
    }

    _drivingFeedbackTableview = [[UITableView alloc] initWithFrame:_drivingFeedbackTableviewSuperView.bounds];
    _drivingFeedbackTableview.delegate = self;
    _drivingFeedbackTableview.dataSource = self;
    _drivingFeedbackTableview.separatorStyle=UITableViewCellSeparatorStyleNone;
    [_drivingFeedbackTableviewSuperView addSubview:_drivingFeedbackTableview];
    
    [_drivingFeedbackTableview reloadData];
    
    _drawBackgourp = [SignatureDrawBackgoupImageView initWithImage:nil frame:_signatureDrawView.bounds lineWidth:1.0 lineColor:[UIColor blackColor]];
    [_signatureDrawView addSubview:_drawBackgourp];
    
    
    //带入试驾反馈数据四个固定部分
    [self bringDataFormDrivingFeedback:_drivingFeedbackHeadInfoList];
    
    
//    tryDriveType
    
    
    
    if (self.driving_ing) {
        _subView.userInteractionEnabled = YES;
        _float_left_buttonOutlet.enabled = YES;
        _shijiaquxiaoButtonOutlet.enabled = YES;
        _commitDrivingFeedbackButtonOutlet.enabled = YES;
    }else{
        _subView.userInteractionEnabled = YES;
        _float_left_buttonOutlet.enabled = NO;
        _shijiaquxiaoButtonOutlet.enabled = NO;
        _commitDrivingFeedbackButtonOutlet.enabled = NO;
        
        
        [self disableView:_subView userInteractionEnabled:NO];

    }
}



-(void)disableView:(UIView *)view userInteractionEnabled:(BOOL)enable
{
    for (UIView *subview in [view subviews])
    {
        if([subview isKindOfClass:[UIButton class]])
        {
            subview.userInteractionEnabled = enable;
        }
        else if ([subview isKindOfClass:[UIView class]])
        {
            [self disableView:subview userInteractionEnabled:enable];
        }
    }
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *CollectionCellIdentifier = [NSString stringWithFormat:@"%@%zd%zd",@"DrivingFeedbackTableViewCell",indexPath.section,indexPath.row];
    [tableView registerNib:[UINib nibWithNibName:@"DrivingFeedbackTableViewCell" bundle:nil] forCellReuseIdentifier:CollectionCellIdentifier];
    DrivingFeedbackTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CollectionCellIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    DrivingGetCarNext_Sub *sub = [self.dataArray objectAtIndex:indexPath.row];
    [cell configCellData:sub withIndex:indexPath];

    
    if (!self.driving_ing) {
        [self disableView:cell userInteractionEnabled:NO];
    }


    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 33;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


- (void)radioButtonSelectDelegate:(id)obj{
    RadioButton *button = obj;
    DrivingGetCarNext_Sub *dgc = [DrivingGetCarNext_Sub objectFromDictionary:[button.obj objectAtIndex:button.indexRow]];
    NSString *key = [NSString stringWithFormat:@"%@%@",dgc.vdescription,dgc.vattcode];
    [_itemsFeedbackInfo setObject:@{@"vexpercode":dgc.vcode?:@"", @"vexpermyd":@(button.tag), @"vattcode":dgc.vattcode} forKey:key];
}

#pragma =================
#pragma mark 试驾反馈 end
#pragma =================






#pragma =================
#pragma mark 试驾换车
#pragma =================


// 试驾路线
- (IBAction)vTryCarPathAction:(SelectButton *)sender {
    NSDictionary *dic = @{@"试驾路线1":@"TryDriveRoute1" , @"试驾路线2":@"TryDriveRoute2",@"个性化路线":@"TryDriveRoute3"};
    [self showSearchSelectController:sender withData:@[@"试驾路线1",@"试驾路线2",@"个性化路线"] selectItem:^(id item, NSString *key, NSString *value) {
        sender.key = [dic stringForKey:key];
        sender.value = key;
    }];
}

- (IBAction)beginTimeButtonAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    datePicker.minDate  = [DateManager dateConvertFrom_YMD_String:@"1900-01-01"];
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        
        sender.value =[DateManager stringConvert_YMDHMS_FromDate:date];
        sender.timeStamp = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}


- (IBAction)endTimeButtonAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    datePicker.minDate  = [NSDate date]; //苏鹏确认换车时间只能选择当前时间往回
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        
        sender.value =[DateManager stringConvert_YMDHMS_FromDate:date];
        sender.timeStamp = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}


- (void)bringDataFormDivingRetunCar{
    //数据带入分为两种
    //1是从试驾看板带入进来的数据
    //2是从销售线索下带入进来的数据
    
    NSDictionary *dic = @{@"TryDriveRoute1":@"试驾路线1" , @"TryDriveRoute2":@"试驾路线2",@"TryDriveRoute3":@"个性化路线"};

    
    long long tryoutBegintime;
    long long drivingEndTime;
    if (self.client_and_service_form) {
        
        _drivingName.text = _drivingExperienceModel.driverName?:@"";
        _drivingMobile.text = _drivingExperienceModel.driverMobile?:@"";
        _drivingAddress.text = _drivingExperienceModel.vCusAddr?:@"";
        _drivingBeginKM.text = _drivingExperienceModel.driveStartKM;
        _drivingEndKM.text = _drivingExperienceModel.driveEndKM?:_drivingExperienceModel.endMileage?:@"";

        tryoutBegintime = self.drivingExperienceModel.driveStartTime;
        drivingEndTime = self.drivingExperienceModel.driveEndTime;
        
        if (drivingEndTime == 0) {
            
            drivingEndTime = [DateManager timeIntervalWithDate:[NSDate date]];
        }
        
        _drivingMapOutlet.value = [dic objectForKey:_drivingExperienceModel.vTryCarPath?:@""];
        _drivingMapOutlet.key = _drivingExperienceModel.vTryCarPath?:@"";
        
        if ([_drivingExperienceModel.vTryCarPath isEqualToString:@"试驾路线1"] || [_drivingExperienceModel.vTryCarPath isEqualToString:@"试驾路线2"] || [_drivingExperienceModel.vTryCarPath isEqualToString:@"个性化路线"]) {
            
            NSDictionary *dicSub = @{@"试驾路线1":@"TryDriveRoute1" , @"试驾路线2":@"TryDriveRoute2",@"个性化路线":@"TryDriveRoute3"};

            _drivingMapOutlet.key = [dicSub objectForKey:_drivingExperienceModel.vTryCarPath?:@""];
            _drivingMapOutlet.value = _drivingExperienceModel.vTryCarPath?:@"";
        }

        
    }else{
        
        DrivingTimerModel *dtm =[_drivingExperienceModel.time firstObject];
        
        _drivingName.text = _drivingExperienceModel.driverName?:dtm.VRelateName?:@"";
        _drivingMobile.text = _drivingExperienceModel.driverMobile?:dtm.VRelatePhone?:@"";
        _drivingAddress.text = _drivingExperienceModel.vCusAddr?:dtm.VCusAddr?:@"";
        _drivingBeginKM.text = _drivingExperienceModel.driveStartKM?:dtm.driveStartKM?:@"";
        _drivingEndKM.text = _drivingExperienceModel.endMileage?:_drivingExperienceModel.driveEndKM?:@"";
        
        tryoutBegintime = self.drivingModelFormDMS.tryoutBegintime?:dtm.begintime;
        drivingEndTime = dtm.endtime;
        
        if (drivingEndTime == 0) {
            
            drivingEndTime = [DateManager timeIntervalWithDate:[NSDate date]];
        }
        
        if (_drivingExperienceModel.vTryCarPath && _drivingExperienceModel.vTryCarPathCode) {
            
            
            if ([_drivingExperienceModel.vTryCarPath isEqualToString:@"试驾路线1"] || [_drivingExperienceModel.vTryCarPath isEqualToString:@"试驾路线2"] || [_drivingExperienceModel.vTryCarPath isEqualToString:@"个性化路线"]) {
                
                _drivingMapOutlet.value = _drivingExperienceModel.vTryCarPath?:@"";
                _drivingMapOutlet.key = _drivingExperienceModel.vTryCarPathCode?:@"";
                [_drivingMapOutlet setTitle:_drivingExperienceModel.vTryCarPath?:@"" forState:UIControlStateNormal];
            }else{
                
                
                _drivingMapOutlet.value = [dic objectForKey:_drivingExperienceModel.vTryCarPath?:@""];
                _drivingMapOutlet.key = _drivingExperienceModel.vTryCarPathCode?:@"";
                [_drivingMapOutlet setTitle:[dic objectForKey:_drivingExperienceModel.vTryCarPath?:@""] forState:UIControlStateNormal];
                
            }

            
        }else{
            _drivingMapOutlet.value = [dic objectForKey:_drivingExperienceModel.vTryCarPath?:dtm.vTryCarPath?:@""];
            _drivingMapOutlet.key = _drivingExperienceModel.vTryCarPath?:dtm.vTryCarPath?:@"";
        }
        
        
    }
    
    if (!self.driving_ing) {
        float drivingBenginKm = [_drivingBeginKM.text floatValue];
        float drivingEndKM = [_drivingEndKM.text floatValue];
        if (drivingEndKM > drivingBenginKm) {
            _drivingKM.text = [NSString stringWithFormat:@"%.2f",(drivingEndKM - drivingBenginKm)];
        }
    }
    
    
    
    if (_drivingEndKM.text.length>0 && _drivingBeginKM.text.length>0) {
        float startKM = [_drivingBeginKM.text floatValue];
        float endKM = [_drivingEndKM.text floatValue];
        
        if (endKM >= startKM) {
            _drivingKM.text = [NSString stringWithFormat:@"%.2f",(endKM - startKM)];
        }
    }
    
    _drivingBeginTime.value = [DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:tryoutBegintime]];
    _drivingBeginTime.timeStamp = tryoutBegintime;
    
    _drivingEndTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:drivingEndTime]];
    _drivingEndTimer.timeStamp = drivingEndTime;

}

- (void)getDataFormDivingRetunCar{

    _drivingExperienceModel.driverName = _drivingName.text;
    _drivingExperienceModel.driverMobile = _drivingMobile.text;
    _drivingExperienceModel.vCusAddr = _drivingAddress.text;
    
    _drivingExperienceModel.driveStartTime = _drivingBeginTime.timeStamp;
    _drivingExperienceModel.driveEndTime = _drivingEndTimer.timeStamp;
    _drivingExperienceModel.driveStartKM = _drivingBeginKM.text;
    _drivingExperienceModel.endMileage = _drivingEndKM.text;
//    _drivingExperienceModel.driveEndKM = _drivingEndKM.text;    //用哪个？
    _drivingExperienceModel.vTryCarPath = _drivingMapOutlet.key;
    
    _drivingExperienceModel.tryoutState = @"试驾结束";
}


/**
 *  试驾还车点击
 */
- (IBAction)drivingReturnCarButtonAction:(id)sender {
    
    [self getDataFormDivingRetunCar];
    
    _drivingExperienceModel.endMileage = _drivingEndKM.text?:@"";
    
    //试驾人姓名
    
    if(_drivingName.text.length == 0){
        [JKAlert showMessage:@"试驾试驾人姓名不能为空"];
        return;
    }
    //试驾人电话
    if(_drivingMobile.text.length != 11){
        [JKAlert showMessage:@"请输入正确的试驾人电话"];
        return;
    }
    //试驾人地址
    if(_drivingAddress.text.length == 0){
        [JKAlert showMessage:@"试驾人地址不能为空"];
        return;
    }
    
    
    if(!_drivingExperienceModel.endMileage || [_drivingExperienceModel.endMileage isEqualToString:@""]){
        [JKAlert showMessage:@"试驾结束里程不能为空"];
        return;
    }
    
    
    
    if (!_drivingExperienceModel.driveEndTime || _drivingExperienceModel.driveEndTime==0) {
        [JKAlert showMessage:@"试驾结束时间不能为空"];
        return;
    }
    
    
    
    //    if (_drivingBeginTime.timeStamp >= _drivingEndTimer.timeStamp) {
    //        [JKAlert showMessage:@"试驾结束时间不能小于当前时间"];
    //        return;
    //    }
    
    
    
    DrivingTimerModel *dtm =[_drivingExperienceModel.time firstObject];

    
    NSString *key = [NSString stringWithFormat:@"%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"driveTestID"];
    
    NSString *keyImag = [NSString stringWithFormat:@"%@%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"",@"IMG"];
    
    NSDictionary *dic = (NSDictionary *)[[TMDiskCache sharedCache] objectForKey:key];
    UIImage *image = (UIImage *)[[TMDiskCache sharedCache] objectForKey:keyImag];
    
    
    if (!dic || !image) {
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"试驾还车前请先进行试驾反馈操作"];
        [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            [_shijiafankuiButtonOutlet sendActionsForControlEvents:UIControlEventTouchDown];
        }];
        [alert show7];
        return;
    }
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    DrivingTimerModel *timeModel = [_drivingExperienceModel.time firstObject];
    
    DrivingExperienceModel *model = [_drivingExperienceModel copy];
    if (!model.trydriveid) {
        model.trydriveid = timeModel.driveTestID?:_drivingExperienceModel.driveTestID;
    }
    
    

//    /updateReturnDrive.do//还车接口
//        paramString("endMileage");//试驾结束历程
//    paramString("driveStartKM");
//    paramString("tryoutState");
//    paramString("trydriveid");
//    paramString("customerid");//客户ID
//    paramString("projectid");//线索ID
//    paramString("trydrivetype");//试驾类型ID。1:邀请客户试驾?0：客户要求试驾
//    paramString("istake");//1是0否(VTryType)
//    paramString("isupdate");//驾驶证姓名改动标识
//    paramString("drivingname")//驾驶证姓名
//    paramArray("feedInfo");//试驾反馈选择
    

    
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    
    [params addEntriesFromDictionary:dic?:@{}]; //试驾反馈选择
    
    [params setValue:model.endMileage?:model.driveEndKM?:@"" forKey:@"endMileage"];
    [params setValue:model.driveStartKM?:@"" forKey:@"driveStartKM"];
    [params setObject:model.tryoutState?:@"" forKey:@"tryoutState"];//试驾状态  试乘 还是 试驾
    [params setObject:model.trydriveid?:@"暂无试驾ID" forKey:@"trydriveid"];//试驾ID
    [params setObject:model.custID?:@"暂无客户ID" forKey:@"customerid"];//客户ID
    [params setObject:model.projectID?:@"暂无销售线索ID" forKey:@"projectid"];//线索ID
    [params setObject:[NSNumber numberWithInteger:_trydrivetypeButtonOutlet.selectedButton.tag] forKey:@"trydrivetype"];//试驾类型ID。1:邀请客户试驾?0：客户要求试驾
    [params setObject:@(1)forKey:@"istake"];//1是0否(VTryType)
    [params setObject:@(0) forKey:@"isupdate"];//驾驶证姓名改动标识
//    [params setObject:_drivingName.text?:@"" forKey   :@"drivingname"];//驾驶证姓名
    [params setValue:[_drivingName.text description]?:@"" forKey:@"driverName"];//驾驶证姓名
    
    [params setValue:_drivingAddress.text?:@"" forKey:@"vCusAddr"];//驾驶证姓名
    [params setValue:_drivingMobile.text?:@"暂无手机号" forKey:@"driverMobile"];//驾驶证电话
    
    [params setObject:[NSNumber numberWithLongLong:model.driveStartTime] forKey:@"driveStartTime"];
    [params setObject:[NSNumber numberWithLongLong:model.driveEndTime] forKey:@"driveEndTime"];
    
    [params setObject:_drivingMapOutlet.value?:@"" forKey:@"vTryCarPath"]; // 王晋凯
    [params setObject:_drivingMapOutlet.key?:@"" forKey:@"vTryCarPathCode"]; // 王晋凯 不需要
    
    if ([[params objectForKey:@"driverMobile"] isEqualToString:@"暂无手机号"]) {
        [params setValue:[_drivingMobile.text description] forKey:@"driverMobile"];
    }
    
    if ([[params objectForKey:@"trydriveid"] isEqualToString:@"暂无试驾ID"]) {
        [params setValue:model.trydriveid?:@"暂无试驾ID" forKey:@"trydriveid"];
    }
    
    
    if ([[params objectForKey:@"customerid"] isEqualToString:@"暂无客户ID"]) {
        [params setValue:model.custID?:@"暂无客户ID" forKey:@"customerid"];
    }
    
    
    if ([[params objectForKey:@"projectid"] isEqualToString:@"暂无销售线索ID"]) {
        [params setValue:model.projectID?:@"暂无销售线索ID" forKey:@"projectid"];
    }
    
    if ([[params objectForKey:@"projectid"] isEqualToString:@"暂无销售线索ID"]) {
        [params setValue:model.projectID?:@"暂无销售线索ID" forKey:@"projectid"];
    }
    
    
    
    
    
//    JKAlert *al = [JKAlert alertWithTitle:@"DEBUG数据查看" andMessage:[params description]];
//
//    [al addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
//
//    }];
//
//    [al show7];

    
    [DrivingExperienceModel uploadReturnDriving:params
                                   withImagePar:image
                              withImageFileName:@"imgFile"
                                  uploadSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                                      
                                      
                                      if ([responseObject objectForKey:@"validate_error"]) {
                                          NSArray *error = [[responseObject objectForKey:@"validate_error"] allValues];
                                          [JKAlert showMessage:[error firstObject]];
                                          
                                      }else if([responseObject boolForKey:@"success"]){
                                          
                                          JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"试驾还车成功"];
                                          [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
                                              //拼接缓存的key
                                              DrivingTimerModel *dtm =[_drivingExperienceModel.time firstObject];
                                              
                                              NSString *key = [NSString stringWithFormat:@"%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"driveTestID"];
                                              NSString *keyImag = [NSString stringWithFormat:@"%@%@",self.driveTestID?:self.drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"",@"IMG"];
                                              //删除本地临时缓存
                                              [[TMDiskCache sharedCache] removeObjectForKey:key?:@"driveTestID"];
                                              [[TMDiskCache sharedCache] removeObjectForKey:keyImag?:@""];
                                              
                                              
                                              
                                              if (self.driving_yuliu) {
                                                  [self dismissDSPAPopup:^{
                                                      
                                                  }];
                                                  
                                                  [[NSNotificationCenter defaultCenter] postNotificationName:@"DRIVINGGETCAR_INFONOTIFICATION" object:nil];
                                                  
                                                  return ;
                                              }
                                              
                                              
                                              if (self.client_and_service_form) {
                                                  //销售视图和客户视图下直接关闭当前页面
                                                  [self dismissDSPAPopup:^{
                                                      
                                                  }];
                                              }else{
                                                  //跳转到试驾看板页面
                                                  //跳转回到试驾看板的首页
                                                  Class class = NSClassFromString(@"DrivingExperienceNewViewController");
                                                  NSAssert(class != nil,@"Class YES");
                                                  UIViewController *vc = [[NSClassFromString(@"DrivingExperienceNewViewController") alloc] init];
                                                  [self.navigationController pushViewController:vc animated:YES];
                                              }
                                          }];
                                          [alert show7];
                                          
                                      }else{
                                          
                                          NSString *errorStr = [responseObject?:@"" description];
                                          if (errorStr.length > 0) {
                                              
                                              [JKAlert showMessage:errorStr];
                                              
                                          }else{

                                              [JKAlert showMessage:errorStr?:@"换车失败"];
                                          }
                                      }
                                      
                                      [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                                      
                                      
        
    } uploadError:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSDictionary *userInfo = error.userInfo?:@{@"userInfo":@"nil没有失败信息"};//错误信息
        NSString *localizedFailureReason = error.localizedFailureReason?:@"nil没有失败原因";//获取失败原因
        NSString *errorStr = [NSString stringWithFormat:@"%@%@%@",localizedFailureReason ,@"********换行*********" ,[userInfo description]];
        [JKAlert showMessage:errorStr?:@"换车失败"];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        
        
        
//        NSDictionary * errorInfo = error.userInfo;
//        if ([[errorInfo allKeys] containsObject: @"com.alamofire.serialization.response.error.data"]){
//            NSData * errorData = errorInfo[@"com.alamofire.serialization.response.error.data"];
//            NSDictionary * errorDict =  [NSJSONSerialization JSONObjectWithData:errorData options:NSJSONReadingAllowFragments error:nil];
//            NSNumber * errorCodeNum = errorDict[@"err_code"];
//            NSLog(@"=====%@====", errorCodeNum);
//
//
//            NSString *result =[[ NSString alloc] initWithData:errorData encoding:NSUTF8StringEncoding];
//            NSLog(@"=====%@====", result);
//
//        }
        
        
    }];
    
    
    
//    [DrivingExperienceModel uploadReturnDriving:params withImagePar:image withImageFileName:@"imgFile" CompletionHandler:^(id responseObject, NSError *error) {
//
//    }];
    

}






- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    if (textField == _drivingKM) {
        if ([_drivingKM.text floatValue] > 0) {
            float sum = [_drivingKM.text floatValue] + [_drivingBeginKM.text floatValue];
            _drivingEndKM.text = [NSString stringWithFormat:@"%.2f",sum];
            _drivingExperienceModel.endMileage = _drivingEndKM.text;

        }else{
            [JKAlert showMessage:@"试驾里程不能小于0"];
        }
    }
    
    if (textField == _drivingEndKM) {
        if ([_drivingEndKM.text floatValue] > [_drivingKM.text floatValue]) {
            float sum = [_drivingEndKM.text floatValue] - [_drivingBeginKM.text floatValue];
            _drivingKM.text = [NSString stringWithFormat:@"%.2f",sum];
            
            if ([_drivingKM.text floatValue] > 10.) {
                [JKAlert showMessage:@"您输入的试驾公里数大于10公里，请确认是否继续保存！"];
            }
            
            _drivingExperienceModel.endMileage = _drivingEndKM.text;
            
        }else{
            [JKAlert showMessage:@"试驾结束里程不能小于试驾开始里程"];
        }
    }
    
    if (textField == _drivingKM) {
        if ([_drivingKM.text floatValue] > 10.) {
            [JKAlert showMessage:@"您输入的试驾公里数大于10公里，请确认是否继续保存！"];
        }
    }

    
    if (textField == _drivingAddress) {
        _drivingExperienceModel.vCusAddr = _drivingAddress.text;
    }
}

#pragma =================
#pragma mark 试驾换车 end
#pragma =================



#pragma =================
#pragma mark 试驾取消
#pragma =================
/***
 *   试驾取消按钮点击
 */
- (void)cancelButtonAction{
    JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"确定要进行试驾取消操作吗"];
    [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
        [self cancelDrivingAction:nil];
    }];
    [alert addCancleButtonWithTitle:@"取消" handler:^(JKAlertItem *item) {
    }];
    [alert show7];
}


/**
 *  取消试驾
 */
- (IBAction)cancelDrivingAction:(id)sender {
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"取消中...";
    DrivingTimerModel *dtm = [_drivingExperienceModel.time firstObject];
    //重新new一个DrivingExperienceModel来传参
    DrivingExperienceModel *model = [_drivingExperienceModel copy];
    //将状态重置
    model.driveStartTime = dtm.begintime;
    model.tryoutState = @"试驾取消";
    if (!model.trydriveid) {
        model.trydriveid = _drivingExperienceModel.id?:_drivingExperienceModel.driveTestID?:dtm.driveTestID?:@"";
    }
    
    
    [DrivingExperienceModel updateDrivingExperience:[model toDictionary] Success:^(NSArray *headList, id responseObject) {
        
        if ([responseObject objectForKey:@"validate_error"]) {
            NSArray *error = [[responseObject objectForKey:@"validate_error"] allValues];
            
            JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:[error firstObject]?:@"取消失败"];
            [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            }];
            [alert show7];
            
        }else if([responseObject boolForKey:@"success"]){
            
            
            if (self.driving_yuliu) {
                [self dismissDSPAPopup:^{
                    
                }];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"DRIVINGGETCAR_INFONOTIFICATION" object:nil];

                
                return ;
            }
            
            
            
            if (self.client_and_service_form) {
                //销售视图和客户视图下直接关闭当前页面
                [self dismissDSPAPopup:^{
                    
                }];
            }else{
                //跳转到试驾看板页面
                //跳转回到试驾看板的首页
                Class class = NSClassFromString(@"DrivingExperienceNewViewController");
                NSAssert(class != nil,@"Class YES");
                UIViewController *vc = [[NSClassFromString(@"DrivingExperienceNewViewController") alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
            }

        }
        
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}

#pragma =================
#pragma mark 试驾取消 end
#pragma =================

/**
 *   获取webview上试驾体验店
 */
- (NSDictionary *)getWebViewSelectPoint{
    
    JSContext *context = [_webview valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    
    JSValue *function = [context objectForKeyedSubscript:@"getAttentionInfo"];
    JSValue *result = [function callWithArguments:nil];
    NSString *str = [result toString];

    NSDictionary *dict = [self dictionaryWithJsonString:str];
    
    NSLog(@"%@",dict);
    return dict;
}

- (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString
{
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err)
    {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}


@end
