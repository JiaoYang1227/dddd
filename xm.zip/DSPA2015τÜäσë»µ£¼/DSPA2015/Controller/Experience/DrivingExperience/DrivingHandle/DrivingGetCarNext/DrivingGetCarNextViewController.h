//
//  DrivingGetCarNextViewController.h
//  DSPA2015
//
//  Created by runlin on 2018/1/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//
typedef enum : NSUInteger {
    DRIVING_XIEYI = 10000,
    DRIVING_FANKUI = 10001,
    DRIVING_HUANCHE = 10002,
    DRIVING_JIESHU = 10003,
    DRIVING_FANHUI = 10004
} DRIVING_STATE_BUTTON;




#import "BaseViewController.h"
#import "DrivingExperienceModel.h"
#import "SalesLead.h"
#import "DrivingModelFormDMS.h"


@interface DrivingGetCarNextViewController : BaseViewController
@property (nonatomic , copy) DrivingExperienceModel *drivingExperienceModel;
@property (nonatomic , copy) DrivingModelFormDMS *drivingModelFormDMS;
@property (nonatomic , copy) SalesLead *salesLead;
@property (nonatomic , copy) NSString *driveTestID;


@property (nonatomic , assign) DRIVING_STATE_BUTTON drivingStateType; //试驾切换类型

@property (nonatomic , assign) BOOL client_and_service_form; //是否是从客户视图和销售视图调起


@property (nonatomic , assign) BOOL driving_ing; //是否试驾中

@property (nonatomic , assign) BOOL driving_yuliu; //是否试驾预留

@end
