//
//  DrivingGetCarNext.h
//  DSPA2015
//
//  Created by runlin on 2018/1/20.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseModel.h"



@interface DrivingGetCarNext_info : BaseModel
@property (nonatomic,copy)NSString *createby;
@property (nonatomic,copy)NSString *createon;
@property (nonatomic,copy)NSString *customerid;
@property (nonatomic,copy)NSString *dealercode;
@property (nonatomic,copy)NSString *nbid;
@property (nonatomic,copy)NSString *projectid;
@property (nonatomic,copy)NSString *trydriveid;
@property (nonatomic,copy)NSString *trydriveqmurl;
@property (nonatomic,copy)NSString *trydrivetype;
@property (nonatomic,copy)NSString *uid;
@property (nonatomic,copy)NSString *vattcode;
@property (nonatomic,copy)NSString *vexpercode;
@property (nonatomic,copy)NSString *vexpermyd;
@end



@interface DrivingGetCarNext_Sub : BaseModel
@property (nonatomic,copy)NSString *bstop;
@property (nonatomic,copy)NSString *dcreate;
@property (nonatomic,copy)NSString *uid;
@property (nonatomic,copy)NSString *vattcode;
@property (nonatomic,copy)NSString *vcode;
@property (nonatomic,copy)NSString *vdescription;
@property (nonatomic) DrivingGetCarNext_info *info;

@property (nonatomic , assign)NSInteger tag;
@property (nonatomic , copy)NSString *title;

@end


@interface DrivingGetCarNext : BaseModel

@property (nonatomic,copy)NSString *bstop;
@property (nonatomic,copy)NSString *dcreate;
@property (nonatomic,copy)NSString *uid;
@property (nonatomic,copy)NSString *vattcode;
@property (nonatomic,copy)NSString *vcode;
@property (nonatomic,copy)NSString *vdescription;

@property (nonatomic,copy)NSString *trydriveqmurl; //签名地址



@property (nonatomic) NSArray <DrivingGetCarNext_Sub *> *diccTryExperienceList;


@property (nonatomic) NSArray *driveInfo;

/**
 *  获取试驾反馈信息列表
 */
+ (AFHTTPRequestOperation*)getDICCTryAttentionList:(NSDictionary *)param
                                           Success:(void (^)(NSArray *headList,id responseObject))success
                                           Failure:(void (^)(NSError *error))failue;





+ (void)uploadButtonAction:(NSDictionary *)par
              withImagePar:(UIImage *)image
         withImageFileName:(NSString *)fileName
         CompletionHandler:(void (^)(id responseObject, NSError * error))completionHandler
                   ;

@end
