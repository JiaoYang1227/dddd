//
//  DrivingPopViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/15.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingPopViewController.h"
#import "DrivingGetCarViewController.h"
#import "SalesLead.h"

#import "CustomerReception.h"
#import "SearchCustomerSelectViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "DrivingSalesLeadViewController.h"
#import "DrivingReturnCarViewController.h"
#import "DrivingGetCarNextViewController.h"
#import "AppDelegate.h"


@interface DrivingPopViewController ()<UITextFieldDelegate>
{
    
    __weak IBOutlet SelectButton *beginTimer;
    __weak IBOutlet SelectButton *endTimer;
    
    __weak IBOutlet BorderTextField *_salesLeadTextField;
    __weak IBOutlet BorderTextField *_customerNameTextField;
    
    
    //
    SalesLead *_salesLead;
}
@property (weak, nonatomic) IBOutlet UIButton *leftButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *rightButtonOutlet;
@end

@implementation DrivingPopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self.leftButtonOutlet addTarget:self action:@selector(leftButtonAction) forControlEvents:UIControlEventTouchDown];
    [self.rightButtonOutlet addTarget:self action:@selector(rightButtonAction) forControlEvents:UIControlEventTouchDown];
    
     _customerNameTextField.returnKeyType = UIReturnKeySearch;//变为搜索按钮
    
    
    if (_salesLead) {
        _salesLead = [[SalesLead alloc] init];
    }
    
    
    _salesLeadTextField.text = [AppDelegate APP].user.userName?:[AppDelegate APP].user.salesConsultantName?:@"";
    _customerNameTextField.text = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.custName?:@"";
    
    if ([AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot) {
        _salesLead = [[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot copy];
        _customerNameTextField.enabled = NO;
    }
    
    
    beginTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[NSDate date]];
    long long endDate = [DateManager timeIntervalWithDate:[NSDate date]] + 30*60*1000;
    endTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:endDate]];
    
    //如果车辆状态为试驾中，左侧显示为换车字样，其他情况显示为领车字样
    // czt 01 空闲
    // czt 02 占用
    
    if ([self.drivingExperienceModel.czt isEqualToString:@"02"]) {
        [_leftButtonOutlet setTitle:@"还车" forState:UIControlStateNormal];
    }else{
        [_leftButtonOutlet setTitle:@"领车" forState:UIControlStateNormal];
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [_customerNameTextField resignFirstResponder];//取消第一响应者
    [self getCustomerListInfo];
    return YES;
}




/**
 *  获取客户信息列表
 */
- (void)getCustomerListInfo{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CustomerReception getCustomerListInfo:_customerNameTextField.text isFromVoice:NO  Success:^(NSDictionary *customer) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            //TODO
        
        //试驾之带入客户信息，客户接待信息不带入
        //没有客户信息就视为新建一条客户接待信息
        NSArray *customerList = [customer arrayForKey:@"customer"];
        if (customerList.count == 0) {
            
            JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"暂无该客户信息"];
            [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
                [self dismissDSPAPopup:^{
                    
                }];
            }];
            [alert show7];
            
            return ;
        }
        
        
        if (customerList.count == 1) {
            
            Customer *custom = [customerList firstObject];
            _customerNameTextField.text = custom.custName?:@"";
            [self getSelectSalesLeadList:custom];
            
        }else{
            SearchCustomerSelectViewController *show = [[SearchCustomerSelectViewController alloc] initWithSearchCustomerSelectType:SearchCustomerSelectTypeDriving];
            
            [show searchCustomerSelectOne:^(BOOL isCustomer, id model) {
                NSLog(@"%@",model);
                Customer *custom=(Customer *)model;
                _customerNameTextField.text = custom.custName?:@"";
                [self getSelectSalesLeadList:custom];
            }];
            
            show.customerList = customer;
            [self presentDSPAPopup:show parentViewController:self touchCallBack:^{
                //TODO
            } haveMask:YES includeNavgation:YES alignTop:NO];
        }
        
        

        
    } Failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


/**
 *  获取选择的客户信息下的销售线索
 */
- (void)getSelectSalesLeadList:(Customer *)model {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [Customer getCustomerProjectList:model.customerID?:@""
                       orderByUpdate:YES
                              userID:[AppDelegate APP].user.userID
                             Success:^(NSArray *collection, id responseObject) {

                                 [MBProgressHUD hideHUDForView:self.view animated:NO];
                                 NSLog(@"%@",collection);
                                 if (collection.count == 1) {
                                     
                                     _salesLead = [SalesLead salesFromDictionary:[collection firstObject]];
                                     _customerNameTextField.enabled = NO;
                                     
                                     
                                 }else{
                                     DrivingSalesLeadViewController *dsv = [DrivingSalesLeadViewController new];
                                     dsv.items = collection;
                                     [self presentDSPAPopup:dsv parentViewController:self touchCallBack:^{
                                         //TODO
                                     } haveMask:YES includeNavgation:YES alignTop:NO];
                                     
                                     [dsv setSearchDrivingSalesLead:^(id model) {
                                         //TODO
                                         _salesLead = [SalesLead salesFromDictionary:model];
                                         _customerNameTextField.enabled = NO;
                                     }];
                                 }
                             
                             } Failure:^(NSError *error) {
                                 [MBProgressHUD hideHUDForView:self.view animated:NO];
                             }];
}

/**
 *  开始时间
 */
- (IBAction)beginTimerAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.minDate = [NSDate date];
    
    
    datePicker.maxDate = [DateManager zero2400Date:[NSDate date]];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        beginTimer.value = [DateManager stringConvert_YMDHMS_FromDate:date];
//        _addDrivingModel.driveStartTime = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}


/**
 *  结束时间
 */
- (IBAction)endTimerAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        endTimer.value = [DateManager stringConvert_YMDHMS_FromDate:date];;
        
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}

/**
 *  赋值
 */
- (void)getValue{
    //客户名称
    _drivingExperienceModel.custName = _salesLead.customer.custName;
    //客户类别
    _drivingExperienceModel.custTypeCode = _salesLead.customer.custTypeCode;
    _drivingExperienceModel.custType = _salesLead.customer.custType;
    
    //客户电话
    _drivingExperienceModel.custMobile = _salesLead.customer.custMobile;           //客户电话
    //预购日期
//    _drivingExperienceModel.dPreBuy = _preorderDate.timeStamp;
    //首次接触
    //=========   根据接待客户信息反查销售线索信息--缺少的字段
    _drivingExperienceModel.vOriginVW = _salesLead.vOriginVWName;
    _drivingExperienceModel.vOriginVWCode = _salesLead.vOriginVW;

    //试驾人名称
    _drivingExperienceModel.driverName =  _salesLead.customer.custName;            //试驾人员名称
    //试驾人电话
    _drivingExperienceModel.driverMobile = _salesLead.customer.custMobile;            //试驾人员电话
    //试驾人地址
    _drivingExperienceModel.vCusAddr = _salesLead.customer.address;          //客户地址
    //试驾开始时间
    _drivingExperienceModel.driveStartTime = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMDHMS_String:beginTimer.value]];
    
    _drivingExperienceModel.tryOutDate = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMDHMS_String:beginTimer.value]];
    
    _drivingExperienceModel.driveEndTime = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMDHMS_String:endTimer.value]];
    
    //路线
    if(!_drivingExperienceModel.driveChassisNo){
        _drivingExperienceModel.driveChassisNo = _drivingExperienceModel.chassisNo?:@"";
    }
    
    _drivingExperienceModel.ifyuyue = YES;
    _drivingExperienceModel.driveStatus = @"预约中";
}

//试驾预约
- (void)rightButtonAction{
    
    //预约试驾的时候，必须带入老客户信息
    if (!_salesLead) {
        [JKAlert showMessage:@"预约试驾的时候，请在输入框带入老客户信息"];
        return;
    }
    
    [self getValue];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    _drivingExperienceModel.roilandFlag = YES; // liushiwei 要求必须传
    [DrivingExperienceModel addDrivingExperience:[_drivingExperienceModel toDictionary] Success:^(NSArray *headList, id responseObject) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        NSDictionary *errorDic = [responseObject dictionaryForKey:@"validate_error"];
        [JKAlert showMessage:[[errorDic allValues] firstObject]];
        
        if ([responseObject boolForKey:@"success"]) {
            [JKAlert showMessage:@"新建试驾成功"];
            
            [[NSNotificationCenter defaultCenter]postNotificationName:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
            
            [self dismissTouched:nil];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}

//试驾换车or试驾领车
- (void)leftButtonAction{
    
    if ([self.drivingExperienceModel.czt isEqualToString:@"02"]) {
        
        //如果是同一个销售顾问可以进行换车操作
        DrivingTimerModel *timeModel = [self.drivingExperienceModel.time firstObject];
        if (![timeModel.userID isEqualToString:[AppDelegate APP].user.userID]) {
            [JKAlert showMessage:[NSString stringWithFormat:@"请切换销售顾问为%@进行操作",timeModel.salesConsultantName?:@"暂无"]];
            return;
        }
        
        DrivingGetCarNextViewController *dgc = [DrivingGetCarNextViewController new];
        dgc.drivingStateType = DRIVING_XIEYI;
        dgc.salesLead = _salesLead;
        dgc.driving_ing = YES;
        dgc.drivingExperienceModel = self.drivingExperienceModel;
        [self.navigationController pushViewController:dgc animated:YES];

    }else{
        // 领车的时候可以不带入客户信息
        DrivingGetCarViewController *dgc = [DrivingGetCarViewController new];
        dgc.salesLead = _salesLead;
        dgc.drivingExperienceModel = self.drivingExperienceModel;
        dgc.drivingCarType = DRIVINGGETCAR_FORM_HOME;
        [self.navigationController pushViewController:dgc animated:YES];
    }
}


@end
