//
//  DrivingGetCarViewController.h
//  DSPA2015
//
//  Created by runlin on 2018/1/12.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "DrivingExperienceModel.h"
#import "SalesLead.h"

typedef enum : NSUInteger {
    DRIVINGGETCAR_FORM_HOME = 0,
    DRIVINGGETCAR_FORM_CLIENT,
    DRIVINGGETCAR_FORM_YULIU,
    DRIVINGGETCAR_FORM_YUYUE,
    
} DRIVINGGETCAR_FORM_TYPE;


@interface DrivingGetCarViewController : BaseViewController

@property (nonatomic,assign)DRIVINGGETCAR_FORM_TYPE drivingCarType;

@property (nonatomic , strong) DrivingExperienceModel *drivingExperienceModel;

@property (nonatomic , copy) SalesLead *salesLead;





//客户姓名
@property (weak, nonatomic) IBOutlet BorderTextField *custName;
//客户类别
@property (weak, nonatomic) IBOutlet SelectButton *custType;
// 客户移动电话
@property (weak, nonatomic) IBOutlet SelectButton *custMobile;
// 预购日期
@property (weak, nonatomic) IBOutlet SelectButton *preorderDate;
//首次接触
@property (weak, nonatomic) IBOutlet SelectButton *shoucijiechuOutlet;
//首次接触2级
@property (weak, nonatomic) IBOutlet SelectButton *shoucijiechu2Outlet;
//车系
@property (weak, nonatomic) IBOutlet SelectButton *brandOutlet;
//车型
@property (weak, nonatomic) IBOutlet SelectButton *modelOutlet;
//起始里程数
@property (weak ,nonatomic) IBOutlet BorderTextField *carStartKM;

//试驾人名称
@property (weak, nonatomic) IBOutlet BorderTextField *drivingNameTextField;
//驾驶人电话
@property (weak, nonatomic) IBOutlet SelectButton *drivingMobileButtonOutlet;

//驾驶证号
@property (weak, nonatomic) IBOutlet BorderTextField *drivingNumTextField;
//地址
@property (weak, nonatomic) IBOutlet BorderTextField *drivingLocalTextField;
//生日
@property (weak, nonatomic) IBOutlet SelectButton *birthdayButtonOutlet;
//有效期日期
@property (weak, nonatomic) IBOutlet SelectButton *youxiaoqiButtonOutlet;
//领证日期
@property (weak, nonatomic) IBOutlet SelectButton *lingzhengButtonOutlet;
//试驾开始时间
@property (weak, nonatomic) IBOutlet SelectButton *drivingBeginDateButtonOutlet;
//试驾路线
@property (weak, nonatomic) IBOutlet SelectButton *vTryCarPathButtonOutlet;

@property (weak, nonatomic) IBOutlet UIButton *shijiazancun_ButtonOutlet; //试驾暂存


@end
