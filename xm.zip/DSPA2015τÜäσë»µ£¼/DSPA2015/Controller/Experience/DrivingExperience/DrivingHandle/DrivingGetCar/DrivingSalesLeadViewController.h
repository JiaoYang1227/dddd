//
//  DrivingSalesLeadViewController.h
//  DSPA2015
//
//  Created by runlin on 2018/1/15.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
typedef void(^SearchDrivingSalesLead)(id model);

@interface DrivingSalesLeadViewController : BaseViewController
{
    SearchDrivingSalesLead _searchSearchDrivingSalesLead;
}
@property (nonatomic , copy)NSArray *items;

-(void)setSearchDrivingSalesLead:(SearchDrivingSalesLead)searchDrivingSalesLeadPar;


@end
