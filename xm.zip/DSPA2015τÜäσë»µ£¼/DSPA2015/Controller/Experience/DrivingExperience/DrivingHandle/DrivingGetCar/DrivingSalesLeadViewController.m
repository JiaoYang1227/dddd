//
//  DrivingSalesLeadViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/15.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingSalesLeadViewController.h"
#import "DrivingSalesLeadTableViewCell.h"
#import "SalesLead.h"
#import "UIViewController+DSPAPopup.h"


@interface DrivingSalesLeadViewController ()
{
    
    __weak IBOutlet UITableView *_drivingSalesLeadTableview;
}
@end

@implementation DrivingSalesLeadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //根据反查客户信息查出对应客户下的销售线索信息列表
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark ============================
#pragma mark tableview delegate =========
#pragma mark tableview data source ======
#pragma mark ============================
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50.;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *CellIdentifier = @"DrivingSalesLeadTableViewCell";

    [_drivingSalesLeadTableview registerNib:[UINib nibWithNibName:@"DrivingSalesLeadTableViewCell" bundle:nil] forCellReuseIdentifier:@"DrivingSalesLeadTableViewCell"];
    
    DrivingSalesLeadTableViewCell *cell = (DrivingSalesLeadTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(indexPath.row %2==0){
        cell.backgroundColor = [UIColor colorWithRed:0.931 green:0.935 blue:0.956 alpha:1.000];
    }else{
        cell.backgroundColor = [UIColor whiteColor];
    }
    NSDictionary *item = [_items objectAtIndex:indexPath.row];
    SalesLead *salesLead = [SalesLead salesFromDictionary:item];
    [cell configCellData:salesLead];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //    [self.myTableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *item = [_items objectAtIndex:indexPath.row];
    
    if(_searchSearchDrivingSalesLead){
        _searchSearchDrivingSalesLead(item);
        [self dismissDSPAPopup:^{
            
        }];
    }
    
}

-(void)setSearchDrivingSalesLead:(SearchDrivingSalesLead)searchDrivingSalesLeadPar{
    _searchSearchDrivingSalesLead = [searchDrivingSalesLeadPar copy];
}

@end
