//
//  DrivingGetCarViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/12.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//


typedef NS_ENUM(NSInteger, DrivingGetCarJumpOption) {
    DRIVINGGETCARJUMP_FEEDBACK = 1001,
    DRIVINGGETCARJUMP_PROTOCOL = 1002
};


#import "DrivingGetCarViewController.h"
#import "PopoverSearchController.h"
#import "DrivingFeedbackViewController.h"
#import "DictModel.h"
#import "DrivingProtocolViewController.h"
#import "DrivingGetCarNextViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "SearchCustomerSelectViewController.h"
#import "DrivingSalesLeadViewController.h"
#import "Number9Keyboard.h"
#import "UIImageView+WebCache.h"

#import <MobileCoreServices/MobileCoreServices.h>


//#import <DriveLicence/DriverLicenceManager.h>
#import "DriverLicenceManager.h"



#import "DemoViewController.h"


#import "Aspects.h"
#import "UIImage+Wechat.h"


#define AUTHCODE @"4854558580AECA4F42FC"


@interface DrivingGetCarViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate,DriverLicenceManagerDelegate>
{
    PopoverSearchController *_searchControl;

    //==
    NSMutableArray *_carList;
    
    __weak IBOutlet UIView *_getCarTitleView;
    __weak IBOutlet UIView *_gatCarMainView;

    
    __weak IBOutlet UISegmentedControl *_segmentedOutlet;
    NSInteger currentSelectedSegmentIndex_;//当前选择的
    __weak IBOutlet UIView *_customSuperView;
    
    
    UIImagePickerController *imagePickerController;
    UIPopoverController *imagePopoverController;
    UIActionSheet *cameraSheet;
    NSString *_authorizationCode; //授权码
//    DriverLicenceManager *_dlManager;
    
    
    __weak IBOutlet UIImageView *_jiazhao_zhengmian; //驾照正面
    __weak IBOutlet UIImageView *_jiazhao_fanmian;//驾照反面
    
    
    __weak IBOutlet UILabel *_jiazhao_shifouguoqi; //驾照是否过期
    __weak IBOutlet UILabel *_jiazhao_shifoushixiqi;//驾照是否实习期
}

@property (nonatomic, assign) BOOL isFront;


@end

@implementation DrivingGetCarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //初始化驾照识别
//    _dlManager = [[DriverLicenceManager alloc] init];
    _authorizationCode = AUTHCODE;
    
    
    
    
    imagePickerController = [[UIImagePickerController alloc] init];
    imagePopoverController = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
    
    //获取试驾车俩列表
    [self getCarList:nil];
    //部分按钮背景图片重置
    [_custType setImage:[UIImage imageNamed:@"DrivingLicenceUpload_select_button"] forState:UIControlStateNormal];
    [_preorderDate setImage:[UIImage imageNamed:@"DrivingLicenceUpload_select_button"] forState:UIControlStateNormal];
    [_shoucijiechuOutlet setImage:[UIImage imageNamed:@"DrivingLicenceUpload_select_button"] forState:UIControlStateNormal];
    [_shoucijiechu2Outlet setImage:[UIImage imageNamed:@"DrivingLicenceUpload_select_button"] forState:UIControlStateNormal];
    [_custMobile setImage:nil forState:UIControlStateNormal];
    [_drivingMobileButtonOutlet setImage:nil forState:UIControlStateNormal];

    //判断数据来源类型，从而调整页面的frame
    if (self.drivingCarType == DRIVINGGETCAR_FORM_YULIU || self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT) {
        _getCarTitleView.hidden = YES;
        CGRect frameTemp = _gatCarMainView.frame;
        _gatCarMainView.frame = CGRectMake(frameTemp.origin.x, 0, frameTemp.size.width, frameTemp.size.height);
        //如果是从试驾预留来的页面，那么左下角的按钮不可使用
        if (self.drivingCarType == DRIVINGGETCAR_FORM_YULIU) {
            _shijiazancun_ButtonOutlet.enabled = NO;
            
            [self bringDataForm_Shijiayuliu:self.drivingExperienceModel];
            //试驾预留进来的默认算是老客户
            [self _switchCustomState:NO];
            
        }else{
            //_salesLead YES 说明有客户信息带入进来，就默认为老客户
            if (_salesLead) {
                [self _switchCustomState:NO];
            }else{
                [self _switchCustomState:YES];
            }
            self.drivingExperienceModel = [[DrivingExperienceModel alloc] init];
            //带入默认首次接触信息
            if (!_salesLead.vOriginVW && !_salesLead) {
                [self bringDataFormDefault];
            }else{
                [self bringDataFormSalesLead:_salesLead];
            }
        }
    }
    
    
    //试驾看板进入
    if (self.drivingCarType == DRIVINGGETCAR_FORM_HOME) {
        //从试驾看板进来的分为两种情况，一种是带入客户信息进来的，一种是直接点击领车按钮进来的
        //直接点击领车按钮进来的没有查询客户信息，salesLead 为空
        //查询客户信息，点击领车，会带入销售线索信息
        
        if (self.salesLead) {
            _drivingExperienceModel.projectID = _salesLead.projectID;
            _drivingExperienceModel.custID = _salesLead.customerID;
            [self bringDataCustomer:_salesLead withDefault:NO];
            [self _switchCustomState:NO];
        }else{
            [self bringDataCustomer:_salesLead withDefault:YES];
            [self _switchCustomState:YES];
        }
    }
    
    if (self.drivingCarType == DRIVINGGETCAR_FORM_YUYUE) {
        
    }
    
    
    //带入试驾车辆信息
    [self bringDataForCar:_drivingExperienceModel];
    
    
    // 1.注册通知
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(infoNotificationAction:) name:@"DRIVINGGETCAR_INFONOTIFICATION" object:nil];
}


- (void)infoNotificationAction:(NSNotification *)notification{
    [self dismissDSPAPopup:^{
        
    }];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[AppDelegate APP].rootViewController showClientBar:YES];
    
    
    if (self.drivingCarType == DRIVINGGETCAR_FORM_YULIU) {
        [[AppDelegate APP].rootViewController showClientBar:NO];
    }
}


- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    if (self.drivingCarType != DRIVINGGETCAR_FORM_YULIU) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    }
}


#pragma mark =============   带入数据信息 ==================

//带入客户信息
- (void)bringDataCustomer:(SalesLead *)model withDefault:(BOOL)isDefault{
    //客户姓名
    _custName.text = model.customer.custName?:@"";
    //客户电话
    _custMobile.value = model.customer.custMobile?:@"";
    //试驾人名称
    _drivingNameTextField.text = _custName.text;
    //驾驶人电话
    _drivingMobileButtonOutlet.value = _custMobile.value;
    
    if (isDefault) {
        //带入首次接触默认信息
        [DictModel getDictionary:@"vCusFromVW" Success:^(NSArray *collection) {
            if (collection.count > 0) {
                _shoucijiechuOutlet.value = [[collection firstObject] stringForKey:@"value"];
                _shoucijiechuOutlet.key = [[collection firstObject] stringForKey:@"key"];
                
                [DictModel getSecondLevel:@"vcusFromVW" parrentCode:_shoucijiechuOutlet.key Success:^(NSArray *collection) {
                    if ([collection count]>0) {
                        _shoucijiechu2Outlet.value = [[collection firstObject] stringForKey:@"value"];
                        _shoucijiechu2Outlet.key = [[collection firstObject] stringForKey:@"key"];
                    }
                } failure:^(NSError *error) {
                }];
            }
        } failure:^(NSError *error) {
        }];
        
        //带入客户类别信息
        [DictModel getDictionary:DIC_NAME_CUSTOM_TYPE Success:^(NSArray *collection) {
            if ([collection count]>0) {
                _custType.value = [[collection firstObject] stringForKey:@"value"];
                _custType.key = [[collection firstObject] stringForKey:@"key"];
            }
        } failure:^(NSError *error) {
        }];
        //带入预购日期默认时间
        //默认预购日期取当前时间加一个月
        long long mm = 30. * 24. * 60. * 60. * 1000.;
        long long current = [DateManager timeIntervalWithDate:[NSDate date]] + mm;
        
        _preorderDate.value = [DateManager date_YMD_WithTimeIntervalSince1970:current];
        _preorderDate.timeStamp = current;
        
        
    }else{
        //客户类别
        _custType.value = model.customer.custType;
        _custType.key = model.customer.custTypeCode;
        //预购日期
        _preorderDate.timeStamp = model.purchaseCarIntent.preorderDate;
        _preorderDate.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.purchaseCarIntent.preorderDate]];
        //首次接触
        _shoucijiechuOutlet.value = model.vOriginVWName?:model.purchaseCarIntent.vOriginVW;
        _shoucijiechuOutlet.key = model.vOriginVW?:model.purchaseCarIntent.vOriginVWCode;
        _shoucijiechu2Outlet.value = model.custFrom?:model.purchaseCarIntent.vOrigin;
        _shoucijiechu2Outlet.key = model.custFromCode?:model.purchaseCarIntent.vOriginCode;
    }
}


//带入客户信息
- (void)bringDataYuyue:(DrivingExperienceModel *)model{
    //客户姓名
//    _custName.text = model.customer.custName?:@"";
//    //客户电话
//    _custMobile.value = model.customer.custMobile?:@"";
//    //试驾人名称
//    _drivingNameTextField.text = _custName.text;
//    //驾驶人电话
//    _drivingMobileButtonOutlet.value = _custMobile.value;
//
//    if (isDefault) {
//        //带入首次接触默认信息
//        [DictModel getDictionary:@"vCusFromVW" Success:^(NSArray *collection) {
//            if (collection.count > 0) {
//                _shoucijiechuOutlet.value = [[collection firstObject] stringForKey:@"value"];
//                _shoucijiechuOutlet.key = [[collection firstObject] stringForKey:@"key"];
//
//                [DictModel getSecondLevel:@"vcusFromVW" parrentCode:_shoucijiechuOutlet.key Success:^(NSArray *collection) {
//                    if ([collection count]>0) {
//                        _shoucijiechu2Outlet.value = [[collection firstObject] stringForKey:@"value"];
//                        _shoucijiechu2Outlet.key = [[collection firstObject] stringForKey:@"key"];
//                    }
//                } failure:^(NSError *error) {
//                }];
//            }
//        } failure:^(NSError *error) {
//        }];
//
//        //带入客户类别信息
//        [DictModel getDictionary:DIC_NAME_CUSTOM_TYPE Success:^(NSArray *collection) {
//            if ([collection count]>0) {
//                _custType.value = [[collection firstObject] stringForKey:@"value"];
//                _custType.key = [[collection firstObject] stringForKey:@"key"];
//            }
//        } failure:^(NSError *error) {
//        }];
//        //带入预购日期默认时间
//        _preorderDate.value = [DateManager stringConvert_YMD_FromDate:[NSDate date]];
//        _preorderDate.timeStamp = [DateManager timeIntervalWithDate:[NSDate date]];
//
//
//    }else{
//        //客户类别
//        _custType.value = model.customer.custType;
//        _custType.key = model.customer.custTypeCode;
//        //预购日期
//        _preorderDate.timeStamp = model.purchaseCarIntent.preorderDate;
//        _preorderDate.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.purchaseCarIntent.preorderDate]];
//        //首次接触
//        _shoucijiechuOutlet.value = model.vOriginVWName?:model.purchaseCarIntent.vOriginVW;
//        _shoucijiechuOutlet.key = model.vOriginVW?:model.purchaseCarIntent.vOriginVWCode;
//        _shoucijiechu2Outlet.value = model.custFrom?:model.purchaseCarIntent.vOrigin;
//        _shoucijiechu2Outlet.key = model.custFromCode?:model.purchaseCarIntent.vOriginCode;
//    }
}


#pragma mark =============   带入数据信息 end ==================



- (void)bringDataForCar:(DrivingExperienceModel *)model{
    _carStartKM.text = model.driveStartKM;          //开始里程数
    _drivingExperienceModel.driveLicensePlate = model.driveLicensePlate;
    _drivingExperienceModel.carbrand = model.carbrand;
    _drivingExperienceModel.carmodel = model.carmodel;
    _drivingExperienceModel.chassisNo = model.chassisNo;
    _drivingExperienceModel.ccp = model.ccp;
    _drivingExperienceModel.driveChassisNo = model.chassisNo;
    
    
    //车系
    _brandOutlet.value = model.carbrand;
    _brandOutlet.key = model.brandCode;
    //车型
    _modelOutlet.value = model.driveLicensePlate;
    //起始里程数
    _carStartKM.text = model.driveStartKM;
    //试驾开始时间
    _drivingBeginDateButtonOutlet.value = [DateManager stringConvert_YMDHMS_FromDate:[NSDate date]];
    //试驾路线
    
    NSDictionary *dic = @{@"TryDriveRoute1":@"试驾路线1" , @"TryDriveRoute2":@"试驾路线2",@"TryDriveRoute3":@"个性化路线"};    
    _vTryCarPathButtonOutlet.value = [dic objectForKey:_drivingExperienceModel.vTryCarPathCode?:@""];
    _vTryCarPathButtonOutlet.key = _drivingExperienceModel.vTryCarPathCode?:@"";
    
    
    if (_vTryCarPathButtonOutlet.value.length == 0) {
        _vTryCarPathButtonOutlet.value = @"试驾路线1";
        _vTryCarPathButtonOutlet.key = @"TryDriveRoute1";
    }
    
    
}


- (void)bringDataFormDefault{
    [DictModel getDictionary:@"vCusFromVW" Success:^(NSArray *collection) {
        if (collection.count > 0) {
            _shoucijiechuOutlet.value = [[collection firstObject] stringForKey:@"value"];
            _shoucijiechuOutlet.key = [[collection firstObject] stringForKey:@"key"];
            
            [DictModel getSecondLevel:@"vcusFromVW" parrentCode:_shoucijiechuOutlet.key Success:^(NSArray *collection) {
                if ([collection count]>0) {
                    _shoucijiechu2Outlet.value = [[collection firstObject] stringForKey:@"value"];
                    _shoucijiechu2Outlet.key = [[collection firstObject] stringForKey:@"key"];
                }
            } failure:^(NSError *error) {
            }];
        }
    } failure:^(NSError *error) {
    }];
    
    //带入客户类别信息
    [DictModel getDictionary:DIC_NAME_CUSTOM_TYPE Success:^(NSArray *collection) {
        if ([collection count]>0) {
            _custType.value = [[collection firstObject] stringForKey:@"value"];
            _custType.key = [[collection firstObject] stringForKey:@"key"];
        }
    } failure:^(NSError *error) {
    }];
    //带入预购日期默认时间
    _preorderDate.value = [DateManager stringConvert_YMD_FromDate:[NSDate date]];
    _preorderDate.timeStamp = [DateManager timeIntervalWithDate:[NSDate date]];
    //客户名称
    _custName.text = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.custName?:@"";
    //客户电话
    _custMobile.value = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.custMobile?:@"";
    //试驾人名称
    _drivingNameTextField.text = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.custName?:@"";
    //试驾人电话
    _drivingMobileButtonOutlet.value = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.custMobile?:@"";
}



//直接领车，带入默认数据
- (void)bringDataFormSalesLead:(SalesLead *)salesLead{
    //客户名称
    _custName.text = salesLead.customer.custName;
    //客户类别
    _custType.value = salesLead.customer.custType;
    _custType.key = salesLead.customer.custTypeCode;
    //客户电话
    _custMobile.value = salesLead.customer.custMobile;
    //预购日期
    _preorderDate.timeStamp = salesLead.purchaseCarIntent.preorderDate;
    _preorderDate.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:salesLead.purchaseCarIntent.preorderDate]];
    //首次接触
    _shoucijiechuOutlet.value = salesLead.vOriginVWName?:salesLead.purchaseCarIntent.vOriginVW;
    _shoucijiechuOutlet.key = salesLead.vOriginVW?:salesLead.purchaseCarIntent.vOriginVWCode;
    _shoucijiechu2Outlet.value = salesLead.custFrom?:salesLead.purchaseCarIntent.vOrigin;
    _shoucijiechu2Outlet.key = salesLead.custFromCode?:salesLead.purchaseCarIntent.vOriginCode;
    //试驾人名称
    if (_drivingNameTextField.text.length == 0) {
        _drivingNameTextField.text = salesLead.customer.custName;  //试驾人员名称
    }
    
    //试驾人电话
    _drivingMobileButtonOutlet.value = salesLead.customer.custMobile;            //试驾人员电话
    //试驾开始时间
    _drivingExperienceModel.driveStartTime = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMDHMS_String:_drivingBeginDateButtonOutlet.value]];
}

//直接领车，带入默认数据
- (void)bringDataForm_Shijiayuliu:(DrivingExperienceModel *)model{
    //客户名称
    _custName.text = model.custName;
    //客户类别
    _custType.value = model.custType;
    _custType.key = model.custTypeCode;
    //客户电话
    _custMobile.value = model.custMobile;
    //预购日期
    _preorderDate.timeStamp = model.dPreBuy;
    _preorderDate.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.dPreBuy]];
    //首次接触
    _shoucijiechuOutlet.value = model.vOriginVW;
    _shoucijiechuOutlet.key = model.vOriginVWCode;
    
    _shoucijiechu2Outlet.value = model.vOrigin;
    _shoucijiechu2Outlet.key = model.vOriginCode;
    
    //试驾人名称
    _drivingNameTextField.text = model.driverName;  //试驾人员名称
    //试驾人电话
    _drivingMobileButtonOutlet.value = model.driverMobile;            //试驾人员电话
    //驾驶证号
    _drivingNumTextField.text = model.driverLicenseNo;      //试驾人驾驶证号
    //试驾人地址
    _drivingLocalTextField.text = model.vCusAddr;          //客户地址
    //试驾人生日
    _birthdayButtonOutlet.timeStamp = model.sjrbirth;
    _birthdayButtonOutlet.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.sjrbirth]];
    //驾照有效期
    _youxiaoqiButtonOutlet.timeStamp = model.jzoverdate;
    _youxiaoqiButtonOutlet.value =  [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.jzoverdate]];
    //驾照领证日期
    _lingzhengButtonOutlet.timeStamp = model.jzgetdate;
    _lingzhengButtonOutlet.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.jzgetdate]];
    //试驾开始时间
    _drivingBeginDateButtonOutlet.timeStamp = model.driveStartTime;
    _drivingBeginDateButtonOutlet.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.driveStartTime]];
    //试驾里程
    _carStartKM.text = model.driveStartKM;            //开始里程数
    //车系
    _brandOutlet.value = model.carbrand;
    _brandOutlet.key = model.brandCode;
    //试驾车牌照号
    _modelOutlet.value = model.driveLicensePlate;
    //路线
    
    _vTryCarPathButtonOutlet.key = model.vTryCarPathCode;
    
    NSDictionary *dic = @{@"TryDriveRoute1":@"试驾路线1" , @"TryDriveRoute2":@"试驾路线2",@"TryDriveRoute3":@"个性化路线"};
    _vTryCarPathButtonOutlet.value = [dic objectForKey:_drivingExperienceModel.vTryCarPathCode?:@""];
    
    
    
    //试驾车底盘号
    

    //驾照正反面
    [_jiazhao_zhengmian sd_setImageWithURL:[NSURL URLWithString:model.vdriLcsUrlUp?:@"DrivingGetCar_ camera"] placeholderImage:[UIImage imageNamed:@""]];
    [_jiazhao_fanmian sd_setImageWithURL:[NSURL URLWithString:model.vdriLcsUrlDown?:@"DrivingGetCar_ camera"] placeholderImage:[UIImage imageNamed:@""]];
    
    
    
    long long current = [DateManager timeIntervalWithDate:[NSDate date]];
    long long youxiaoqi = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMD_String:_youxiaoqiButtonOutlet.value?:@""]];
    if (current <= youxiaoqi) {
        _jiazhao_shifouguoqi.text = @"正常";
        _jiazhao_shifouguoqi.backgroundColor = [UIColor colorWithWholeRed:68 green:144 blue:86];
    }else{
        _jiazhao_shifouguoqi.text = @"已过期";
        _jiazhao_shifouguoqi.backgroundColor = [UIColor colorWithWholeRed:175 green:42 blue:42];
    }
    
    
    long long shixiqi = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMD_String:_lingzhengButtonOutlet.value?:@""]];
    
    long long mm = 365. * 24. * 60. * 60. * 1000.;
    long long timeYeah = shixiqi + mm; //一年的秒数
    
    //时间大小比较
    if (current >= timeYeah) {
        _jiazhao_shifoushixiqi.text = @"正常";
        _jiazhao_shifoushixiqi.backgroundColor = [UIColor colorWithWholeRed:68 green:144 blue:86];
    }else{
        _jiazhao_shifoushixiqi.text = @"实习期";
        _jiazhao_shifoushixiqi.backgroundColor = [UIColor colorWithWholeRed:175 green:42 blue:42];
    }
    
    
}


- (IBAction)switchCustomeActionT:(UISegmentedControl *)sender {
    
    if (sender.selectedSegmentIndex == 0) {
        //
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"如果切换成新客户建立的话，那么将不允许再次切换成老客户"];
        [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            _segmentedOutlet.selectedSegmentIndex = 0;
            [self _switchCustomState:YES];

        }];
        [alert addCommonButtonWithTitle:@"取消" handler:^(JKAlertItem *item) {
            
            _segmentedOutlet.selectedSegmentIndex = 1;
            [self _switchCustomState:NO];
        }];
        [alert show];
 
    }else{
        
        _segmentedOutlet.selectedSegmentIndex = 0;
        [JKAlert showMessage:@"新客户建立，不允许切换成老客户"];
        [self _switchCustomState:YES];
    }
}


- (void)_switchCustomState:(BOOL)state{
    if (state) {
        _customSuperView.userInteractionEnabled = YES;
        _segmentedOutlet.selectedSegmentIndex = 0;
    }else{
        _segmentedOutlet.selectedSegmentIndex = 1;
        _customSuperView.userInteractionEnabled = NO;
    }
}



/**
 *   获取车型
 */
- (void)getCarList:(NSDictionary *)parmDic{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    // flag 1 的话代表试驾车辆
    [DrivingExperienceModel fetchDrivingExperienceList:@{@"flag":[NSNumber numberWithInt:1]} Success:^(NSArray *headList, id responseObject) {
        if (headList.count > 0) {
            _carList = [[NSMutableArray alloc] initWithArray:headList];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}



//客户移动电话
- (IBAction)mobielTouched:(SelectButton *)sender {
    
    [self  show9Keyboard:sender selectItem:^(id item) {
        if (![item isEqualToString:@""] && ![item isEqualToString:@"."]) {
            NSString *str = [NSString stringWithFormat:@"%@%@",sender.value?:@"",item];
            if (str.length > LIMIT_MOBILE) {
                return ;
            }
            
            sender.value = str;
        }else if([item isEqualToString:@""]){
            if (sender.value.length >0){
                sender.value = [sender.value substringToIndex:sender.value.length -1];
            }
        }
        NSLog(@"sender.value:%@",[sender.value description]);
    } popoverDismissCallBack:^(id item) {
        if(_custMobile.value.length > 0){
            [self getCustomerListInfo:_custMobile.value];
            
            if (_custMobile.value.length == 11) {
                [self isExistProjectWithMobile:_custMobile.value];
            }
        }
    }];
}


//客户类别
- (IBAction)custTypeTouched:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_CUSTOM_TYPE Success:^(NSArray *collection) {
        [self showCommonSearchSelect:sender withData:collection selectItem:^(id item){
            sender.value = [item stringForKey:@"value"];
            sender.key = [item stringForKey:@"key"];
        }];
    } failure:^(NSError *error) {
        
    }];
    
}
//首次接触
- (IBAction)shoucijiechuActtion:(id)sender {
    [DictModel getDictionary:@"vCusFromVW" Success:^(NSArray *collection) {
        [self showCommonSearchSelect:sender withData:collection selectItem:^(id item){
            _shoucijiechuOutlet.value = [item stringForKey:@"value"];
            _shoucijiechuOutlet.key = [item stringForKey:@"key"];
            
            [_shoucijiechu2Outlet reset];
        }];
    } failure:^(NSError *error) {
        
    }];
}

- (IBAction)shoucijiechuTwoActtion:(id)sender {
    if ([_shoucijiechuOutlet.key isEqualToString:@""] || _shoucijiechuOutlet.key == nil) {
        [JKAlert showMessage:@"请先选择首次接触"];
        return;
    }
    [DictModel getSecondLevel:@"vcusFromVW" parrentCode:_shoucijiechuOutlet.key Success:^(NSArray *collection) {
        if ([collection count]==0) {
            return ;
        }
        [self showCommonSearchSelect:sender withData:collection selectItem:^(id item){
            _shoucijiechu2Outlet.value = [item stringForKey:@"value"];
            _shoucijiechu2Outlet.key = [item stringForKey:@"key"];
        }];
    } failure:^(NSError *error) {
        
    }];
    
}

// 试驾路线
- (IBAction)vTryCarPathAction:(SelectButton *)sender {
    NSDictionary *dic = @{@"试驾路线1":@"TryDriveRoute1" , @"试驾路线2":@"TryDriveRoute2",@"个性化路线":@"TryDriveRoute3"};
    [self showSearchSelectController:sender withData:@[@"试驾路线1",@"试驾路线2",@"个性化路线"] selectItem:^(id item, NSString *key, NSString *value) {
        sender.key = [dic stringForKey:key];
        sender.value = key;
    }];
}
// 预购日期
- (IBAction)preorderDateTouched:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        _preorderDate.value = [DateManager stringConvert_YMD_FromDate:date];
        _preorderDate.timeStamp = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}

/**
 *  品牌
 */
- (IBAction)brandAction:(SelectButton *)sender{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSMutableArray *brandList = [[NSMutableArray alloc] init];
    for (DrivingExperienceModel *model in _carList) {
        if (model.carbrand) {
            [brandList addObject:model.carbrand];
        }
    }
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    NSSet *set;
    if (brandList) {
        set = [NSSet setWithArray:[NSArray arrayWithArray:brandList]];
    }
    
    [self showSearchSelectController:sender withData:[set allObjects] selectItem:^(DrivingExperienceModel *item, NSString *key, NSString *value) {
        sender.value = value;
        sender.key = key;
        _brandOutlet.value = value;
        
        [_modelOutlet reset];
        _modelOutlet.value = nil;
        _carStartKM.text = nil;
        _drivingExperienceModel.driveLicensePlate = nil;

    }];
}
/**
 *  车型
 */
- (IBAction)modelAction:(SelectButton *)sender{
    if (!_brandOutlet.value) {
        [JKAlert showMessage:@"请选择车系"];
        return ;
    }
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSMutableArray *carModelList = [[NSMutableArray alloc] init];
    for (DrivingExperienceModel *model in _carList) {
        if ([model.carbrand isEqualToString:_brandOutlet.value]) {
            [carModelList addObject:model];
        }
    }
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    __weak typeof(self) weakSelf = self;
    PopoverSearchController *search = [self showSearchSelectController:sender withData:carModelList selectItem:^(DrivingExperienceModel *item, NSString *key, NSString *value) {
        
        //01 空闲 02 占用
        if ([item.czt isEqualToString:@"02"]) {
            //            [JKAlert showMessage:@"试驾车辆目前被占用！"];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"试驾车辆目前被占用！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
            
            _modelOutlet.value = nil;
            _brandOutlet.value = nil;
            return;
        }
        //代入试驾车辆信息
        _drivingExperienceModel.carmodel = item.carmodel;
        _modelOutlet.value = item.carmodel;
        
    }];
    
    [search hiddenSearchBar:YES];
    
    [search didSelectSearchItem:^(id item, NSString *key, NSString *value) {
        DrivingExperienceModel *model = (DrivingExperienceModel *)item;
        
        //01 空闲 02 占用
        if ([model.czt isEqualToString:@"02"]) {
            //            [JKAlert showMessage:@"试驾车辆目前被占用！"];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"试驾车辆目前被占用！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
            
            _modelOutlet.value = nil;
            _brandOutlet.value = nil;
            
            return;
        }
        
        sender.value = model.driveLicensePlate;
        
        [weakSelf bringDataForCar:model];
    }];
    [search titleForSelectSearchItem:^NSString *(NSInteger index, DrivingExperienceModel *item) {
        //01 空闲 02 占用
        NSString *name;
        if ([item.czt isEqualToString:@"02"]) {
             name = [NSString stringWithFormat:@"%@%@",item.driveLicensePlate,@"  占用"];
        }else{
            name = [NSString stringWithFormat:@"%@%@",item.driveLicensePlate,@"  空闲"];
        }
        
        return name;
    }];
}

//试驾人移动电话
- (IBAction)drivingMobielTouched:(SelectButton *)sender {
    [self  show9Keyboard:sender selectItem:^(id item) {
        if (![item isEqualToString:@""] && ![item isEqualToString:@"."]) {
            NSString *str = [NSString stringWithFormat:@"%@%@",sender.value?:@"",item];
            if (str.length > LIMIT_MOBILE) {
                return ;
            }
            
            sender.value = str;
        }else if([item isEqualToString:@""]){
            if (sender.value.length >0){
                sender.value = [sender.value substringToIndex:sender.value.length -1];
            }
        }
    } popoverDismissCallBack:^(id item) {
        
    }];
}

/**
 *  生日
 */
- (IBAction)birthdayButtonAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
//    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    datePicker.minDate  = [DateManager dateConvertFrom_YMD_String:@"1900-01-01"];
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {

        _birthdayButtonOutlet.value =[DateManager stringConvert_YMD_FromDate:date];
        sender.timeStamp = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}


/**
 *  有效期
 */
- (IBAction)youxiaoqiButtonAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
//    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        
        _youxiaoqiButtonOutlet.value = [DateManager stringConvert_YMD_FromDate:date];
        sender.timeStamp = timeStamp;

        
        long long current = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMD_String:[DateManager stringConvert_YMD_FromDate:[NSDate date]]]];
        
        
        //时间大小比较
        if (current > timeStamp) {
            _jiazhao_shifouguoqi.text = @"已过期";
            _jiazhao_shifouguoqi.backgroundColor = [UIColor colorWithWholeRed:175 green:42 blue:42];
        }else{
            _jiazhao_shifouguoqi.text = @"正常";
            _jiazhao_shifouguoqi.backgroundColor = [UIColor colorWithWholeRed:68 green:144 blue:86];
        }
        
        _jiazhao_shifouguoqi.layer.cornerRadius = 15.;
        
        
        
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}
/**
 *  领证日期
 */
- (IBAction)lingzhengButtonAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
//    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        
        _lingzhengButtonOutlet.value = [DateManager stringConvert_YMD_FromDate:date];
        sender.timeStamp = timeStamp;

        long long current = [DateManager timeIntervalWithDate:[NSDate date]];
        
        long long mm = 365. * 24. * 60. * 60. * 1000.;
        long long timeYeah = [DateManager timeIntervalWithDate:date] + mm; //一年的秒数
        
        //时间大小比较
        if (current >= timeYeah) {
            _jiazhao_shifoushixiqi.text = @"正常";
            _jiazhao_shifoushixiqi.backgroundColor = [UIColor colorWithWholeRed:68 green:144 blue:86];
        }else{
            _jiazhao_shifoushixiqi.text = @"实习期";
            _jiazhao_shifoushixiqi.backgroundColor = [UIColor colorWithWholeRed:175 green:42 blue:42];
            
            
        }
        _jiazhao_shifoushixiqi.layer.cornerRadius = 15.;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}

/**
 *  试驾开始时间
 */
- (IBAction)drivingBeginDateButtonAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    datePicker.minDate = [NSDate date];
    datePicker.maxDate = [DateManager zero2400Date:[NSDate date]];
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        
            _drivingBeginDateButtonOutlet.value = [DateManager stringConvert_YMDHMS_FromDate:date];
        //        _drivingExperienceModel.tryOutDate = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}






/**
 *  赋值
 */
- (void)getValue{
    //客户名称
    _drivingExperienceModel.custName = _custName.text;
    //客户类别
    _drivingExperienceModel.custType = _custType.value;
    _drivingExperienceModel.custTypeCode = _custType.key;
    
    //客户电话
    _drivingExperienceModel.custMobile = _custMobile.value;           //客户电话
    //预购日期
    _drivingExperienceModel.dPreBuy = _preorderDate.timeStamp;
    //首次接触
    _drivingExperienceModel.vOriginVW = _shoucijiechuOutlet.value;
    _drivingExperienceModel.vOriginVWCode = _shoucijiechuOutlet.key;
    
    _drivingExperienceModel.vOrigin = _shoucijiechu2Outlet.value;
    _drivingExperienceModel.vOriginCode = _shoucijiechu2Outlet.key;
    
    
    //试驾人名称
    _drivingExperienceModel.driverName =  _drivingNameTextField.text;            //试驾人员名称
    //试驾人电话
    _drivingExperienceModel.driverMobile = _drivingMobileButtonOutlet.value;            //试驾人员电话
    //驾驶证号
    _drivingExperienceModel.driverLicenseNo = _drivingNumTextField.text;      //试驾人驾驶证号
    //试驾人地址
    _drivingExperienceModel.vCusAddr = _drivingLocalTextField.text;          //客户地址

    //试驾人生日
    _drivingExperienceModel.sjrbirth  = _birthdayButtonOutlet.timeStamp;
    //驾照有效期
    _drivingExperienceModel.jzoverdate = _youxiaoqiButtonOutlet.timeStamp;
    //驾照领证日期
    _drivingExperienceModel.jzgetdate = _lingzhengButtonOutlet.timeStamp;
    //试驾开始时间
    _drivingExperienceModel.driveStartTime = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMDHMS_String:_drivingBeginDateButtonOutlet.value]];
    //试驾里程
    _drivingExperienceModel.driveStartKM = _carStartKM.text;            //开始里程数
    //车系
    _drivingExperienceModel.carbrand = _brandOutlet.value;
    _drivingExperienceModel.carmodel = _modelOutlet.value;
    //试驾车牌照号
    //路线
    _drivingExperienceModel.vTryCarPath = _vTryCarPathButtonOutlet.value;
    _drivingExperienceModel.vTryCarPathCode = _vTryCarPathButtonOutlet.key;

    if(!_drivingExperienceModel.driveChassisNo || _drivingExperienceModel.driveChassisNo.length == 0){
        _drivingExperienceModel.driveChassisNo = _drivingExperienceModel.chassisNo?:@"";
    }
    
    _drivingExperienceModel.roilandFlag = YES; //liushiwei 要求增加的标识永远为YES
}


//试驾暂存
- (IBAction)shijiazancun_ButtonAction:(id)sender {
    [self getValue];
    [self saveShijiayuliuToService:nil];
}

//试乘领车
- (IBAction)shichenglingche_ButtonAction:(id)sender {
    
    [self getValue];
    _drivingExperienceModel.VTryType = @"1"; //试乘领车标识
    
    NSString *error = [self checkRequired:_drivingExperienceModel];
    if (error) {
        [JKAlert showMessage:error?:@""];
        return;
    }
    
    
    JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"只试乘不试驾不记为一次有效试驾"];
    [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
        
        //如果是新建客户接待的话，要先调用创建客户信息接口
        if (_segmentedOutlet.selectedSegmentIndex == 0) {
            // 创建信号量
            dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
            // 创建全局并行
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            dispatch_group_t group = dispatch_group_create();
            dispatch_group_async(group, queue, ^{
                NSMutableDictionary *dicPar = [self getCreateDriverProjectPar];
                ////
                [SalesLead createDriverProject:dicPar Success:^(NSDictionary *collection, id responseObject) {
                    
                    //返回客户ID和销售线索ID,在领车的时候传入新返回的客户ID和销售线索ID
                    if ([collection boolForKey:@"success"]) {
                        _drivingExperienceModel.projectID = [collection stringForKey:@"projectID"];
                        _drivingExperienceModel.custID = [collection stringForKey:@"customerID"];
                    }
                    dispatch_semaphore_signal(semaphore);
                    
                } Failure:^(NSError *error) {
                }];
            });
            
            dispatch_group_notify(group, queue, ^{
                // 信号等待
                dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
                dispatch_async(dispatch_get_main_queue(), ^{
                    //跳转到试驾反馈
                    [self saveAction:DRIVINGGETCARJUMP_PROTOCOL];
                });
            });
        }else{
            //跳转到试驾反馈
            [self saveAction:DRIVINGGETCARJUMP_PROTOCOL];
        }
    }];
    
    [alert show];
}

//试驾领车
- (IBAction)shijialingche_ButtonAction:(id)sender {
    [self getValue];
    _drivingExperienceModel.VTryType = @"0";//试驾领车标识

    NSString *error = [self checkRequired:_drivingExperienceModel];
    if (error) {
        [JKAlert showMessage:error?:@""];
        return;
    }
    //如果是新建客户接待的话，要先调用创建客户信息接口
    if (_segmentedOutlet.selectedSegmentIndex == 0) {
        
        //判断是否新建成功过，如果成功过了，就不需要再次调用创建createDriverProject
        if (_drivingExperienceModel.projectID && _drivingExperienceModel.custID) {
            [self saveAction:DRIVINGGETCARJUMP_PROTOCOL];
            return;
        }
        
        
        // 创建信号量
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        // 创建全局并行
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_group_t group = dispatch_group_create();
        dispatch_group_async(group, queue, ^{
            NSMutableDictionary *dicPar = [self getCreateDriverProjectPar];
            ////
            [SalesLead createDriverProject:dicPar Success:^(NSDictionary *collection, id responseObject) {
                
                //返回客户ID和销售线索ID,在领车的时候传入新返回的客户ID和销售线索ID
                if ([collection boolForKey:@"success"]) {
                    _drivingExperienceModel.projectID = [collection stringForKey:@"projectID"];
                    _drivingExperienceModel.custID = [collection stringForKey:@"customerID"];
                }
                dispatch_semaphore_signal(semaphore);
                
            } Failure:^(NSError *error) {

            }];
        });
        
        dispatch_group_notify(group, queue, ^{
            // 信号等待
            dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
            dispatch_async(dispatch_get_main_queue(), ^{
                [self saveAction:DRIVINGGETCARJUMP_PROTOCOL];
            });
        });
        
    }else{
        [self saveAction:DRIVINGGETCARJUMP_PROTOCOL];
    }
}

//返回
- (IBAction)fanhui_ButtonAction:(id)sender {
    if (self.drivingCarType == DRIVINGGETCAR_FORM_YULIU || self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT) {
        
        [self dismissDSPAPopup:^{
        }];

    }else{
        [self backButtonTouched:nil];
    }
}


/**
 *  添加试驾信息
 */
- (IBAction)saveAction:(DrivingGetCarJumpOption)jumpOption {
    [self getValue];
    
    if (self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT) {
        if (!_drivingExperienceModel.projectID) {
            _drivingExperienceModel.projectID = _salesLead.projectID?:@"";
        }
        if (!_drivingExperienceModel.custID) {
            _drivingExperienceModel.custID = _salesLead.customerID?:_salesLead.customer.customerID?:@"";
        }
    }
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:[_drivingExperienceModel toDictionary]];
    //statisticstype   int 类型  0  销售工作 1 客户视图 2 设置 3 首页
    [dic setValue:[NSNumber numberWithInt:1] forKey:@"statisticstype"];
    //试驾中
    [dic setValue:@"试驾中" forKey:@"driveStatus"];
    
    
    //0未上传完毕1已上传完毕
    NSData *data_zheng = UIImagePNGRepresentation(_jiazhao_zhengmian.image);
    NSData *data_fan = UIImagePNGRepresentation(_jiazhao_fanmian.image);
    
    if (data_zheng.length < 8000 && data_fan.length < 8000){//7038
        [dic setValue:@"1" forKey:@"BIsUpload"];
    }else{
        [dic setValue:@"0" forKey:@"BIsUpload"];
    }
    
    if (data_zheng.length < 8000) {
        _jiazhao_zhengmian.image = nil;
    }
    
    if (data_fan.length < 8000) {
        _jiazhao_fanmian.image = nil;
    }
    

    
//    JKAlert *al = [JKAlert alertWithTitle:@"DEBUG数据查看" andMessage:[dic description]];
//    [al addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
//    }];
//
//    [al show7];
    [DrivingExperienceModel addDrivingExperience:dic
                                       withImage:[_jiazhao_zhengmian.image wcSessionCompress]
                                     withFuImage:[_jiazhao_fanmian.image wcSessionCompress]
                                   uploadSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                                       
                                       
                                       [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                                       
                                       NSDictionary *errorDic = [responseObject dictionaryForKey:@"validate_error"];
                                       [JKAlert showMessage:[[errorDic allValues] firstObject]];
                                       
                                       if ([responseObject boolForKey:@"success"]) {
                                           
                                           NSDictionary *dic = [responseObject objectForKey:@"shijia"];
                                           DrivingModelFormDMS *drivingModelDMS = [DrivingModelFormDMS objectFromDictionary:dic];
                                           
                                           
                                           
                                           if (!_drivingExperienceModel.projectID) {
                                               _drivingExperienceModel.projectID = _salesLead.projectID?:@"";
                                           }
                                           
                                           if (!_drivingExperienceModel.custID) {
                                               _drivingExperienceModel.custID = _salesLead.customerID?:drivingModelDMS.customerno?:@"";
                                           }
                                           
                                           //试驾id重新复制，
                                           if (!_drivingExperienceModel.trydriveid) {
                                               _drivingExperienceModel.trydriveid = drivingModelDMS.id; //将dms返回试驾id赋值给试驾id
                                           }
                                           
                                           
                                           if (!_drivingExperienceModel.driveTestID) {
                                               _drivingExperienceModel.driveTestID = drivingModelDMS.id;
                                           }
                                           
                                           
                                           
                                           
                                           //试驾预留
                                           if (self.drivingCarType == DRIVINGGETCAR_FORM_YULIU) {
                                               _drivingExperienceModel.trydriveid = drivingModelDMS.id?:@"";
                                               _drivingExperienceModel.projectID = drivingModelDMS.projectId?:@"";
                                               _drivingExperienceModel.custID = drivingModelDMS.customerno?:@"";
                                               _drivingExperienceModel.driveTestID = drivingModelDMS.id;
                                               _drivingExperienceModel.id = drivingModelDMS.id;
                                               
                                               DrivingGetCarNextViewController *dgc = [DrivingGetCarNextViewController new];
                                               dgc.drivingStateType = DRIVING_XIEYI;
                                               dgc.drivingExperienceModel = _drivingExperienceModel;
                                               dgc.drivingModelFormDMS = drivingModelDMS;
                                               dgc.driving_ing = YES;
                                               dgc.driving_yuliu = YES;
                                               dgc.client_and_service_form = YES;
                                               
                                               //                [self.navigationController pushViewController:dgc animated:YES];
                                               [self presentDSPAPopup:dgc parentViewController:self touchCallBack:^{
                                                   //TODO
                                                   
                                               } haveMask:YES includeNavgation:YES alignTop:NO];
                                               return ;
                                           }
                                           
                                           
                                           
                                           if (self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT) {
                                               
                                               switch (jumpOption) {
                                                   case DRIVINGGETCARJUMP_FEEDBACK:
                                                   {
                                                       
                                                       DrivingGetCarNextViewController *dgc = [DrivingGetCarNextViewController new];
                                                       dgc.client_and_service_form = YES;
                                                       dgc.drivingStateType = DRIVING_XIEYI;
                                                       dgc.drivingExperienceModel = _drivingExperienceModel;
                                                       dgc.driving_ing = YES;
                                                       [self presentDSPAPopup:dgc parentViewController:self touchCallBack:^{
                                                           //TODO
                                                           
                                                       } haveMask:YES includeNavgation:YES alignTop:NO];
                                                       
                                                   }
                                                       break;
                                                   case DRIVINGGETCARJUMP_PROTOCOL:
                                                   {
                                                       //试驾打印
                                                       DrivingGetCarNextViewController *dgc = [DrivingGetCarNextViewController new];
                                                       dgc.client_and_service_form = YES;
                                                       dgc.drivingStateType = DRIVING_XIEYI;
                                                       dgc.drivingExperienceModel = _drivingExperienceModel;
                                                       dgc.driving_ing = YES;
                                                       
                                                       [self presentDSPAPopup:dgc parentViewController:self touchCallBack:^{
                                                           //TODO
                                                       } haveMask:YES includeNavgation:YES alignTop:NO];
                                                       
                                                   }
                                                       break;
                                                   default:
                                                       break;
                                               }
                                               
                                           }else{
                                               
                                               switch (jumpOption) {
                                                   case DRIVINGGETCARJUMP_FEEDBACK:
                                                   {
                                                       DrivingGetCarNextViewController *dgc = [DrivingGetCarNextViewController new];
                                                       dgc.drivingStateType = DRIVING_XIEYI;
                                                       dgc.drivingExperienceModel = _drivingExperienceModel;
                                                       dgc.drivingModelFormDMS = drivingModelDMS;
                                                       dgc.driving_ing = YES;
                                                       [self.navigationController pushViewController:dgc animated:YES];
                                                   }
                                                       break;
                                                   case DRIVINGGETCARJUMP_PROTOCOL:
                                                   {
                                                       //试驾打印
                                                       DrivingGetCarNextViewController *dgc = [DrivingGetCarNextViewController new];
                                                       dgc.drivingStateType = DRIVING_XIEYI;
                                                       dgc.drivingExperienceModel = _drivingExperienceModel;
                                                       dgc.drivingModelFormDMS = drivingModelDMS;
                                                       dgc.driving_ing = YES;
                                                       [self.navigationController pushViewController:dgc animated:YES];
                                                   }
                                                       break;
                                                   default:
                                                       break;
                                               }
                                           }
                                       }
                                       
                                       
                                       
                                   } uploadError:^(AFHTTPRequestOperation *operation, NSError *error) {
                                       [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                                       [JKAlert showMessage:@"试驾领车失败"];
                                   }];

    
}

//保存试驾预留到服务器
- (void)saveShijiayuliuToService:(NSMutableDictionary *)dicTestDrive{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    if (self.salesLead.projectID && self.salesLead.customerID) {
        _drivingExperienceModel.projectID = self.salesLead.projectID?:@"";
        _drivingExperienceModel.custID = self.salesLead.customerID?:@"";
    }else{
        _drivingExperienceModel.projectID = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.projectID?:@"";
        _drivingExperienceModel.custID = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.customerID?:@"";
    }
    
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:[_drivingExperienceModel toDictionary]];
    //statisticstype   int 类型  0  销售工作 1 客户视图 2 设置 3 首页
    [dic setValue:[NSNumber numberWithInt:1] forKey:@"statisticstype"];
    
    
    
    NSData *data_zheng = UIImagePNGRepresentation(_jiazhao_zhengmian.image);
    NSData *data_fan = UIImagePNGRepresentation(_jiazhao_fanmian.image);
    
    
    if (data_zheng.length < 8000){//7038
        _jiazhao_zhengmian.image = nil;
    }
    
    
    if (data_fan.length < 8000){//7038
        _jiazhao_fanmian.image = nil;
    }

    //根据判断，是否需要上传正副本的image
    [DrivingExperienceModel createDriveObligateImage:dic withImage:[_jiazhao_zhengmian.image wcSessionCompress] withFuImage:[_jiazhao_fanmian.image wcSessionCompress] Response:^(id responseObject) {
        
        NSDictionary *errorDic = [responseObject dictionaryForKey:@"validate_error"];
        if ([[errorDic allValues] firstObject]) {
            JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:[[errorDic allValues] firstObject]];
            [alert addCommonButtonWithTitle:@"确定" handler:nil];
            [alert show7];
        }
        
        if ([responseObject boolForKey:@"success"]) {
            //TODO
            JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"试驾暂存成功"];
            [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            NSLog(@"%@",item);
            }];
            
            [alert show7];
        }
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];

    }];
}


/**
 *  获取客户信息列表
 */
- (void)getCustomerListInfo:(NSString *)searchSTR{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CustomerReception getCustomerListInfo:searchSTR?:@"" isFromVoice:NO  Success:^(NSDictionary *customer) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        //TODO
        
        //试驾之带入客户信息，客户接待信息不带入
        //没有客户信息就视为新建一条客户接待信息
        NSArray *customerList = [customer arrayForKey:@"customer"];
        if (customerList.count == 0) {
//            新客户建立 的页签全部去掉   必须老客户才可以做试驾
//            JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"暂无该客户信息"];
                 JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"没有该客户手机号对应销售机会，请先创建销售线索"];
            [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
                //TODO
                //新客户建立
                //[self _switchCustomState:YES];
            }];
            [alert show7];
            return ;
        }
        if (customerList.count == 1) {
            
            Customer *custom = [customerList firstObject];
            [self getSelectSalesLeadList:custom];
            
        }else{
            SearchCustomerSelectViewController *show = [[SearchCustomerSelectViewController alloc] initWithSearchCustomerSelectType:SearchCustomerSelectTypeDriving];
            
            [show searchCustomerSelectOne:^(BOOL isCustomer, id model) {
                Customer *custom=(Customer *)model;
                //            _customerNameTextField.text = custom.custName?:@"";
                [self getSelectSalesLeadList:custom];
            }];
            
            show.customerList = customer;
            [self presentDSPAPopup:show parentViewController:self touchCallBack:^{
                //TODO
            } haveMask:YES includeNavgation:YES alignTop:NO];
        }
        
        
    } Failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


/***
 *   校验手机号码是否被建立过销售线索信息，有的话给出提示，仅仅提示而已（苏鹏）
 */

- (void)isExistProjectWithMobile:(NSString *)mobil{
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:[AppDelegate APP].user.userID?:@"" forKey:@"userID"];
    [dict setObject:mobil?:@"" forKey:@"otherPhone"];
    [dict setObject:[AppDelegate APP].user.dealerOrgID?:@"" forKey:@"dealerOrgID"];
    [dict setObject:mobil?:@"" forKey:@"mobileNumber"];
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [SalesLead isExistProjectWithMobile:dict Success:^(NSDictionary *collection) {
        
        NSLog(@"%@",collection);
        if ([collection boolForKey:@"isExisting"]) {
            
            NSString *str =[NSString stringWithFormat:@"客户 %@ 被其他销售顾问创建过，近期接待人是 %@",[collection objectForKey:@"custName"]?:@"",[collection objectForKey:@"userName"]?:@""];
            [JKAlert showMessage:str];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}





/**
 *  获取选择的客户信息下的销售线索
 */
- (void)getSelectSalesLeadList:(Customer *)model {
    [MBProgressHUD showHUDAddedTo:self.view animated:NO];
    [Customer getCustomerProjectList:model.customerID?:@""
                       orderByUpdate:YES
                              userID:[AppDelegate APP].user.userID
                             Success:^(NSArray *collection, id responseObject) {
                                 
                                 [MBProgressHUD hideHUDForView:self.view animated:NO];
                                 NSLog(@"%@",collection);
                                 if (collection.count == 1) {
                                     
                                     _salesLead = [SalesLead salesFromDictionary:[collection firstObject]];
                                     _drivingExperienceModel.projectID = _salesLead.projectID?:_salesLead.customer.projectID;
                                     _drivingExperienceModel.custID = _salesLead.customerID?:_salesLead.customer.customerID;
                                     [self bringDataFormSalesLead:_salesLead];
                                     [self _switchCustomState:NO];
                                     _segmentedOutlet.selectedSegmentIndex = 1;
                                     
                                     //Debug 数据查看
//                                     [JKAlert showMessage:[[_salesLead toDictionary] description]];
                                     
                                 }else{
                                     
                                     DrivingSalesLeadViewController *dsv = [DrivingSalesLeadViewController new];
                                     dsv.items = collection;
                                     [self presentDSPAPopup:dsv parentViewController:self touchCallBack:^{
                                         //TODO
                                     } haveMask:YES includeNavgation:YES alignTop:NO];
                                     
                                     [dsv setSearchDrivingSalesLead:^(id model) {
                                         
                                         //TODO
                                         _salesLead = [SalesLead salesFromDictionary:model];
                                         _drivingExperienceModel.projectID = _salesLead.projectID?:_salesLead.customer.projectID;
                                         _drivingExperienceModel.custID = _salesLead.customerID?:_salesLead.customer.customerID;
                                         [self bringDataFormSalesLead:_salesLead];
                                         [self _switchCustomState:NO];
                                         _segmentedOutlet.selectedSegmentIndex = 1;
                                         
                                        //Debug 数据查看
//                                        [JKAlert showMessage:[[_salesLead toDictionary] description]];
                                         
                                     }];
                                 }
                                 
                             } Failure:^(NSError *error) {
                                 [MBProgressHUD hideHUDForView:self.view animated:NO];
                             }];
}





//新建立客户接待信息
- (void)createDriverProject{

    NSMutableDictionary *dicPar = [self getCreateDriverProjectPar];

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [SalesLead createDriverProject:dicPar Success:^(NSDictionary *collection, id responseObject) {
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        //返回客户ID和销售线索ID,在领车的时候传入新返回的客户ID和销售线索ID
        //TODO
        
        
        
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}


-(NSMutableDictionary *)getCreateDriverProjectPar{
    NSMutableDictionary *dicPar = [[NSMutableDictionary alloc] init];
    [dicPar setObject:_custName.text?:@"" forKey:@"collectCustName"];//客户名称
    [dicPar setObject:_custType.key?:@"" forKey:@"custType"];//客户类别
    [dicPar setObject:_custMobile.value?:@"" forKey:@"mobile"];//客户电话
    [dicPar setObject:_brandOutlet.key?:_drivingExperienceModel.ccp?:@"" forKey:@"brandCode"];//车系代码
    [dicPar setObject:_shoucijiechuOutlet.value?:@"" forKey:@"vCusFromVW"];//首次接触途径一级name
    [dicPar setObject:_shoucijiechuOutlet.key?:@"" forKey:@"vCusFromVWCode"];//首次接触途径一级code
    [dicPar setObject:_shoucijiechu2Outlet.value?:@"" forKey:@"vCusFrom"];//首次接触途径二级name
    [dicPar setObject:_shoucijiechu2Outlet.key?:@"" forKey:@"vCusFromCode"];//首次接触途径二级code
    
    
    [dicPar setObject:_drivingLocalTextField.text?:@"" forKey:@"cusAddress"];//带入客户地址
    
    
    return dicPar;
}





#pragma mark
//扫描识别
- (IBAction)saomiaoshibie_buttonAction:(UIButton *)sender {
    [self showAudioFront];
}
//拍照识别
- (IBAction)paizhaoshibie_buttonAction:(UIButton *)sender {
    self.isFront = YES;
    [self popCameraView:0 withButton:sender];
}
//照片识别（相册导入）
- (IBAction)zhaopianshibie_buttonAction:(UIButton *)sender {
    self.isFront = YES;
    [self popCameraView:1 withButton:sender];
}
//拍照留存
- (IBAction)paizhaoliucun_buttonAction:(UIButton *)sender {
    self.isFront = NO;
    [self popCameraView:0 withButton:sender];
}
//照片留存（相册导入）
- (IBAction)zhaopianliucun_buttonAction:(UIButton *)sender {
    self.isFront = NO;
    [self popCameraView:1 withButton:sender];
}



#pragma mark - Delegate

//MARK:从相册选择了一张照片调用
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage * image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    if (self.isFront) {
        if (self.drivingCarType != DRIVINGGETCAR_FORM_CLIENT) {
            [[AppDelegate APP].rootViewController showClientBar:NO];
        }
        
        _jiazhao_zhengmian.image = image;
        
//        _dlManager.delegate = self;
        [DriverLicenceManager sharedDLManager].delegate = self;
        
        
        if (self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT || self.drivingCarType == DRIVINGGETCAR_FORM_YULIU) {
            //模态弹出
//            [_dlManager recognizeDriverLicenceWithController:self licencePhoto:image isNeedTailor:YES isUsePush:NO authCode:_authorizationCode andIsFrontPage:YES];
            
            [[DriverLicenceManager sharedDLManager] recognizeDriverLicenceWithController:self licencePhoto:image isNeedTailor:YES isUsePush:NO authCode:_authorizationCode andIsFrontPage:YES];
            
        }else{
//            [_dlManager recognizeDriverLicenceWithController:self licencePhoto:image isNeedTailor:YES isUsePush:YES authCode:_authorizationCode andIsFrontPage:YES];
            
            [[DriverLicenceManager sharedDLManager] recognizeDriverLicenceWithController:self licencePhoto:image isNeedTailor:YES isUsePush:YES authCode:_authorizationCode andIsFrontPage:YES];
            
        }
  
    }else{
        _jiazhao_fanmian.image = image;
    }
}


//视频正面扫描识别
- (void)showAudioFront {
    
    if (self.drivingCarType != DRIVINGGETCAR_FORM_CLIENT) {
        [[AppDelegate APP].rootViewController showClientBar:NO];
    }
    
//    _dlManager.delegate = self;
    
    
    [DriverLicenceManager sharedDLManager].delegate = self;
    
    if (self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT || self.drivingCarType == DRIVINGGETCAR_FORM_YULIU) {
        [NSClassFromString(@"DriverLicenceCameraController") aspect_hookSelector:@selector(shouldAutorotate) withOptions:AspectPositionInstead usingBlock:^(id<AspectInfo>info){
            
            NSLog(@"%@",info);

        } error:nil];
        
        //模态弹出
        [[DriverLicenceManager sharedDLManager] recognizeDriverLicenceByAudioWithController:self isOneDirectionRecognize:NO isUsePush:NO authCode:_authorizationCode isFrontPage:YES];
        
//        [_dlManager recognizeDriverLicenceByAudioWithController:self isUsePush:NO authCode:_authorizationCode isFrontPage:YES];
        
    }else{
        [[DriverLicenceManager sharedDLManager] recognizeDriverLicenceByAudioWithController:self isOneDirectionRecognize:NO isUsePush:YES authCode:_authorizationCode isFrontPage:YES];
//        [_dlManager recognizeDriverLicenceByAudioWithController:self isUsePush:YES authCode:_authorizationCode isFrontPage:YES];
    }
}



-(void)popCameraView:(NSInteger)buttonIndex withButton:(UIButton *)button{
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = YES;
    //    imagePickerController.wantsFullScreenLayout = YES;
    switch (buttonIndex) {
        case 0:
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                imagePickerController.sourceType  = UIImagePickerControllerSourceTypeCamera;
                imagePickerController.showsCameraControls = YES;
            }
            break;
        case 1:
            imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        default:
            return;
            break;
    }
    CGRect rect = [self.view convertRect:button.frame fromView:button.superview];
    [imagePopoverController presentPopoverFromRect:rect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [imagePopoverController  dismissPopoverAnimated:YES];
}


/**
 有裁剪的导入/拍照识别回调
 
 @param editController 裁剪控制器
 @param resultDic 识别结果
 @param errorCode 错误码
 */
//- (void)editController:(UIViewController *)editController photoRecognizeFinishWithResult:(NSDictionary *)resultDic andErrorCode:(int)errorCode{
//    [self.navigationController popViewControllerAnimated:YES];
//    NSLog(@"photoResultDic:%@",resultDic);
//    [self bringDrivingInfo:resultDic];
//}

- (void)editController:(UIViewController *)editController photoRecognizeFinishWithResult:(NSDictionary *)resultDic errorCode:(int)errorCode andCroppedImage:(UIImage *)croppedImage{
    
    if (croppedImage) {
        _jiazhao_zhengmian.image = croppedImage;
    }
    
    if (self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT || self.drivingCarType == DRIVINGGETCAR_FORM_YULIU) {
        [editController dismissViewControllerAnimated:YES completion:nil];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    NSLog(@"photoResultDic:%@",resultDic);
    NSLog(@"%@",croppedImage);
    [self bringDrivingInfo:resultDic];
}


/**
 无裁剪的导入/拍照识别回调
 
 @param resultDic 识别结果
 @param errorCode 错误码
 */
- (void)photoRecognizeFinishWithResult:(NSDictionary *)resultDic andErrorCode:(int)errorCode{
    
}


/**
 视频流识别回调
 
 @param cameraController 自定义相机控制器
 @param resultDic 识别结果
 @param licenceImage 驾驶证图片
 */
- (void)cameraController:(UIViewController *)cameraController audioRecognizeFinishWithResult:(NSDictionary *)resultDic andLicenceImage:(UIImage *)licenceImage{

    if (self.drivingCarType == DRIVINGGETCAR_FORM_CLIENT || self.drivingCarType == DRIVINGGETCAR_FORM_YULIU) {
        [cameraController dismissViewControllerAnimated:YES completion:nil];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    _jiazhao_zhengmian.image = licenceImage;
    [self bringDrivingInfo:resultDic];
}




- (void)bringDrivingInfo:(NSDictionary *)dic{
    //试驾人名称
    _drivingNameTextField.text = [dic objectForKey:@"姓名"];
    //驾驶证号
    _drivingNumTextField.text = [dic objectForKey:@"证号"];
    //地址
    _drivingLocalTextField.text = [dic objectForKey:@"住址"];
    //生日
    _birthdayButtonOutlet.value = [dic objectForKey:@"出生日期"];
    //有效期日期
    _youxiaoqiButtonOutlet.value = [dic objectForKey:@"有效期限"];
    //领证日期
    _lingzhengButtonOutlet.value = [dic objectForKey:@"初次领证日期"];
    
    
    long long current = [DateManager timeIntervalWithDate:[NSDate date]];
    long long youxiaoqi = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMD_String:_youxiaoqiButtonOutlet.value?:@""]];
    if (current <= youxiaoqi) {
        _jiazhao_shifouguoqi.text = @"正常";
        _jiazhao_shifouguoqi.backgroundColor = [UIColor colorWithWholeRed:68 green:144 blue:86];
    }else{
        _jiazhao_shifouguoqi.text = @"已过期";
        _jiazhao_shifouguoqi.backgroundColor = [UIColor colorWithWholeRed:175 green:42 blue:42];
    }
    
    
    long long shixiqi = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMD_String:_lingzhengButtonOutlet.value?:@""]];
    
    long long mm = 365. * 24. * 60. * 60. * 1000.;
    long long timeYeah = shixiqi + mm; //一年的秒数
    
    //时间大小比较
    if (current >= timeYeah) {
        _jiazhao_shifoushixiqi.text = @"正常";
        _jiazhao_shifoushixiqi.backgroundColor = [UIColor colorWithWholeRed:68 green:144 blue:86];
    }else{
        _jiazhao_shifoushixiqi.text = @"实习期";
        _jiazhao_shifoushixiqi.backgroundColor = [UIColor colorWithWholeRed:175 green:42 blue:42];
    }
    
    //生日
    _birthdayButtonOutlet.timeStamp = [DateManager timeIntervalWithDate:[DateManager dateConvertFrom_YMD_String:_birthdayButtonOutlet.value?:@""]];
    //有效期日期
    _youxiaoqiButtonOutlet.timeStamp = youxiaoqi;
    //领证日期
    _lingzhengButtonOutlet.timeStamp = shixiqi;
    
    
}


#pragma mark =========== check ==========
- (NSString *)checkRequired:(DrivingExperienceModel *)model{
    
    //新建客户的话
    if (_segmentedOutlet.selectedSegmentIndex == 0) {
        
        //客户电话
        if (model.custMobile.length == 0 || !model.custMobile) {
            return @"请输入客户电话";
        }
        if (model.custMobile.length != 11) {
            return @"请输入正确的客户电话";
        }
        //客户姓名
        if (model.custName.length == 0 || !model.custName) {
            return @"请输入客户姓名";
        }
        
        
        //客户类别
        if (model.custTypeCode.length == 0 || !model.custTypeCode) {
            return @"请选择客户类别";
        }
        //预购日期
        if (model.dPreBuy == 0 || !model.dPreBuy) {
            return @"请选择预购日期";
        }
        
        //首次接触
        if (model.vOriginVWCode.length == 0 || !model.vOriginVWCode) {
            return @"请选择首次接触";
        }
        if (model.vOriginCode.length == 0 || !model.vOriginCode) {
            return @"请选择首次接触二级";
        }
    }
    
    
    
    //试驾人姓名
    if (model.driverName.length == 0 || !model.driverName) {
        return @"试驾人姓名不能为空";
    }
    //试驾人电话
    if (model.driverMobile.length == 0 || !model.driverMobile) {
        return @"试驾人电话不能为空";
    }
    //驾驶证号
    if (model.driverLicenseNo.length == 0 || !model.driverLicenseNo) {
        return @"驾驶证号不能为空";
    }
    
    //试驾开始时间
    if (model.driveStartTime == 0 || !model.driveStartTime) {
        return @"请选择试驾开始时间";
    }
    //试驾起始里程
    if (model.driveStartKM.length == 0 || !model.driveStartKM) {
//        return @"试驾起始里程不能为空";
        return @"试驾起始里程不能为空，请先选择车系及车牌信息！";
    }
    //车系model.
    if (model.carbrand.length == 0 || !model.carbrand) {
        return @"车系不能为空";
    }
    //车牌号
    if(!model.driveLicensePlate){
        return @"请选择试驾车牌号";
    }
    
    //路线
    if (model.vTryCarPathCode.length == 0 || !model.vTryCarPathCode) {
        return @"路线不能为空";
    }
    
    
    //如果是试驾领车必须要带有驾照
    if ([model.VTryType isEqualToString:@"0"]) {
        NSData *data_zheng = UIImagePNGRepresentation(_jiazhao_zhengmian.image);
        NSData *data_fan = UIImagePNGRepresentation(_jiazhao_fanmian.image);
        
        
        if (data_zheng.length < 8000){//7038
            return @"请选择驾照正本";
        }
        
        
        if (data_fan.length < 8000){//7038
            return @"请选择驾照副本";
        }
    }

    
    return nil;
}


#pragma mark --- ------ SelectButton Acition  ------------------
- (void)show9Keyboard:(SelectButton *)sender selectItem:(void (^)(id item))selectItem popoverDismissCallBack:(PopoverDismissCallBack)popoverDismissCallBack{
    
    
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];

    
    //    __weak __typeof(self)weakSelf = self;
    Number9Keyboard *keyboardView = [Number9Keyboard loadNumber9KeyboardView];
    keyboardView.callBackDidSelectNumber = ^(NSInteger index,NSString *num){
        selectItem(num);
    };
    
    PopoverController *popNumber = [[PopoverController alloc] initWithContentView:keyboardView];
    UIButton *btn = (UIButton *)sender;
    popNumber.popoverPresentationController.sourceView = btn;
    popNumber.popoverPresentationController.sourceRect = btn.bounds;
    [popNumber popoverDismissCallBack:popoverDismissCallBack];
    [self presentViewController:popNumber animated:YES completion:nil];
}


#pragma mark -------------下拉菜单-----------------------------
#pragma mark show pop view
/**
 *  统一处理弹出框
 *
 *  @param sender sender description
 *  @param array  array description
 */
-(void)showCommonSearchSelect:(SelectButton*)sender withData:(NSArray*)array selectItem:(void (^)(id item))selectItem{
    _searchControl = [[PopoverSearchController alloc]initWithSender:sender andItems:array];
    
    [_searchControl hiddenSearchBar:NO];
    
    [_searchControl reverseIndexWithValue:sender.value];
    [_searchControl didSelectSearchItem:^(id item, NSString *key, NSString *value) {
        [sender setTitle:value forState:UIControlStateNormal];
        sender.obj = item;
        sender.key = key;
        sender.value = value;
        selectItem(item);
        
    }];
    [self presentViewController:_searchControl animated:YES completion:nil];
}

@end
