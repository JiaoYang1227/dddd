//
//  DrivingSalesLeadTableViewCell.m
//  DSPA2015
//
//  Created by runlin on 2018/1/15.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingSalesLeadTableViewCell.h"
@interface DrivingSalesLeadTableViewCell ()
{
    
    __weak IBOutlet UILabel *_cellText;
}
@end
@implementation DrivingSalesLeadTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)configCellData:(SalesLead *)model{
    _cellText.text = model.purchaseCarIntent.brand;
}
@end
