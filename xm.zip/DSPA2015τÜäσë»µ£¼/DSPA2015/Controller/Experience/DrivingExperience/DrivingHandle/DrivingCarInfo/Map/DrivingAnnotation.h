//
//  DrivingAnnotation.h
//  DSPA2015
//
//  Created by runlin on 2018/1/11.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
@interface DrivingAnnotation : NSObject<MKAnnotation>
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, copy) NSString *icon;

@end
