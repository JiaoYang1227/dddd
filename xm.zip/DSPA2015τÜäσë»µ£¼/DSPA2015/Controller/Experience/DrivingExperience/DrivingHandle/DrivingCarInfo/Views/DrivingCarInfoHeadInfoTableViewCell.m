//
//  DrivingCarInfoHeadInfoTableViewCell.m
//  DSPA2015
//
//  Created by runlin on 2018/1/11.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingCarInfoHeadInfoTableViewCell.h"
@interface DrivingCarInfoHeadInfoTableViewCell ()
{
    __weak IBOutlet UILabel *_cellName;
    __weak IBOutlet UILabel *_cellNameFlag;
    __weak IBOutlet UILabel *_cellMobile;
    
}
@end

@implementation DrivingCarInfoHeadInfoTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



- (void)configCellData:(DrivingTimerModel *)model{
    if (model) {
        _cellName.hidden = NO;
        _cellNameFlag.hidden = NO;
        _cellMobile.hidden = NO;
        
        _cellName.text = model.salesConsultantName;
        _cellMobile.text = model.saleManMobile;
        
    }else{
        _cellName.hidden = YES;
        _cellNameFlag.hidden = YES;
        _cellMobile.hidden = YES;
    }
}
@end
