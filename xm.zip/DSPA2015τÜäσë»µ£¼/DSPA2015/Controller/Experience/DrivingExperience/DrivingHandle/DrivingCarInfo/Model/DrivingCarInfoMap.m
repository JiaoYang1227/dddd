//
//  DrivingCarInfoMap.m
//  DSPA2015
//
//  Created by runlin on 2018/1/26.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingCarInfoMap.h"

@implementation DrivingCarInfoMap
+ (AFHTTPRequestOperation*)getDrivingCarInfoMapFormCar:(NSDictionary *)option
                              Success:(void (^)(id responseObject))success
                              Failure:(void (^)(NSError *error))failue{
    
    
    return [APIManager SafePOST:GET_DRIVE_CARLOCATION parameters:option appendUserInfo:YES
                        success:^(AFHTTPRequestOperation *operation, id responseObject) {
                            
                            success(responseObject);
                            
                        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                            failue(error);
                        }];
    
}



+ (AFHTTPRequestOperation*)getDrivingCarInfoMapFormShop:(NSDictionary *)option
                                               Success:(void (^)(id responseObject))success
                                               Failure:(void (^)(NSError *error))failue{
    
    
    return [APIManager SafePOST:GET_DRIVE_DEALERLOCATION parameters:option appendUserInfo:YES
                        success:^(AFHTTPRequestOperation *operation, id responseObject) {
                            
                            success(responseObject);
                        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                            failue(error);
                        }];
    
}





//获取试驾车辆状态信息
+ (AFHTTPRequestOperation*)getDrivingCarInfoState:(NSDictionary *)option
                                                Success:(void (^)(id responseObject))success
                                                Failure:(void (^)(NSError *error))failue{
    
    
    return [APIManager SafePOST:GET_DRIVE_DEALERLOCATION parameters:option appendUserInfo:YES
                        success:^(AFHTTPRequestOperation *operation, id responseObject) {
                            
                            success(responseObject);
                        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                            failue(error);
                        }];
}


@end
