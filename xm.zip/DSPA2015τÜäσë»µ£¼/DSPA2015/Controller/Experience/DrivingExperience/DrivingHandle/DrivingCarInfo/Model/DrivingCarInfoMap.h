//
//  DrivingCarInfoMap.h
//  DSPA2015
//
//  Created by runlin on 2018/1/26.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseModel.h"

@interface DrivingCarInfoMap : BaseModel



+ (AFHTTPRequestOperation*)getDrivingCarInfoMapFormCar:(NSDictionary *)option
                                        Success:(void (^)(id responseObject))success
                                        Failure:(void (^)(NSError *error))failue;


+ (AFHTTPRequestOperation*)getDrivingCarInfoMapFormShop:(NSDictionary *)option
                                                Success:(void (^)(id responseObject))success
                                                Failure:(void (^)(NSError *error))failue;



//获取试驾车辆状态信息
+ (AFHTTPRequestOperation*)getDrivingCarInfoState:(NSDictionary *)option
                                          Success:(void (^)(id responseObject))success
                                          Failure:(void (^)(NSError *error))failue;

@end
