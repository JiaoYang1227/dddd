//
//  DrivingCarInfoHeadNumberTableViewCell.m
//  DSPA2015
//
//  Created by runlin on 2018/1/11.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingCarInfoHeadNumberTableViewCell.h"
@interface DrivingCarInfoHeadNumberTableViewCell ()
{
    __weak IBOutlet UILabel *_cellCarNum;
    __weak IBOutlet UILabel *_cellCarState;
    
    
    
    __weak IBOutlet UILabel *_cell_qidongzhuangtai;
    __weak IBOutlet UILabel *_cell_yinqingzhuansu;
    __weak IBOutlet UILabel *_cell_xingshisudu;
}
@end
@implementation DrivingCarInfoHeadNumberTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)configCellData:(DrivingExperienceModel *)model{
    _cellCarNum.text = model.driveLicensePlate?:@"";
    if ([model.czt isEqualToString:@"02"]) {
        _cellCarState.text = @"试驾中";
    }else{
        _cellCarState.text = @"空闲";
    }
//    vehicleStatus     车辆状态(1：行车中；2：驻车中；3：熄火（0：表示未采集到数据）
    if ([model.vehicleStatus intValue]  == 0) {
        _cell_qidongzhuangtai.text = @"表示未采集到数据";
    }else if([model.vehicleStatus intValue] == 1){
        _cell_qidongzhuangtai.text = @"行车中";

    }else if([model.vehicleStatus intValue] == 2){
        _cell_qidongzhuangtai.text = @"驻车中";

    }else if([model.vehicleStatus intValue] == 3){
        _cell_qidongzhuangtai.text = @"熄火";
    }
    
    _cell_qidongzhuangtai.adjustsFontSizeToFitWidth = YES;

    
    _cell_yinqingzhuansu.text = [NSString stringWithFormat:@"%@",model.engineSpeed];
    _cell_xingshisudu.text = [NSString stringWithFormat:@"%@",model.speed];
}

@end
