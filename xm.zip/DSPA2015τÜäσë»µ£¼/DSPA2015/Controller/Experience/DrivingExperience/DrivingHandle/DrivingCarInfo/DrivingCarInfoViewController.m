//
//  DrivingCarInfoViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/11.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingCarInfoViewController.h"

#import "DrivingCarInfoHeadNumberTableViewCell.h"
#import "DrivingCarInfoHeadInfoTableViewCell.h"
#import "DrivingCarInfoHeadStateTableViewCell.h"

#import "DrivingCarInfoHeadNumberTableViewCell_HeadView.h"
#import "DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo.h"
#import <MapKit/MapKit.h>
#import "DrivingAnnotation.h"
#import "UIViewController+DSPAPopup.h"
#import "DrivingMapViewController.h"
#import "DrivingCarInfoMap.h"
#import "DrivingGetCarViewController.h"

@interface DrivingCarInfoViewController ()<MKMapViewDelegate>
{
    __weak IBOutlet UITableView *_carInfoTableview;
    __weak IBOutlet UIImageView *_carImage;
    NSMutableDictionary *_ccpDic;
    
    NSArray *_items;
    
    __weak IBOutlet MKMapView *_mapView;
    
}
@end

@implementation DrivingCarInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"drivingCarBrand" ofType:@"plist"];
    _ccpDic = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    _items = _drivingExperienceModel.yuyuetime;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"首页试乘试驾_车辆状态查看"];
    //    tryoutState  试驾状态
    //    01 试驾中  02 取消试驾  03 试驾结束  04 预约试驾
    _carImage.image = [UIImage imageNamed:[_ccpDic stringForKey:self.drivingExperienceModel.ccp?:@""]];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"首页试乘试驾_车辆状态查看"];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self getDrivingCarInfoMapLocation];
}


- (void)createMapLocation:(id)responseObjectFormCar withShopLocal:(id)responseObjectFormShop{
    
    
    self.drivingExperienceModel.speed = [responseObjectFormCar objectForKey:@"speed"]?:@"";
    self.drivingExperienceModel.engineSpeed = [responseObjectFormCar objectForKey:@"engineSpeed"]?:@"";
    self.drivingExperienceModel.vehicleStatus = [responseObjectFormCar objectForKey:@"vehicleStatus"]?:@"0";
    
    

    double latitude = [[responseObjectFormCar objectForKey:@"latitude"] doubleValue];
    double longitude = [[responseObjectFormCar objectForKey:@"longitude"] doubleValue];
    
    double latitude_shop = [[responseObjectFormShop objectForKey:@"latitude"] doubleValue];
    double longitude_shop = [[responseObjectFormShop objectForKey:@"longitude"] doubleValue];

    DrivingAnnotation *one = [[DrivingAnnotation alloc] init];
    one.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    one.title = @"4s店位置";
    [_mapView addAnnotation:one];
    
    DrivingAnnotation *two = [[DrivingAnnotation alloc] init];
    two.coordinate = CLLocationCoordinate2DMake(latitude_shop, longitude_shop);
    two.title = @"车辆位置";
    [_mapView addAnnotation:two];
    _mapView.delegate = self;
    _mapView.userInteractionEnabled = YES;
    
    //以车辆位置进行缩放
//    MKCoordinateRegion region = MKCoordinateRegionMake(two.coordinate, MKCoordinateSpanMake(0.01, 0.01));
//    [_mapView setRegion:region animated:YES];
    
    [_carInfoTableview reloadData];
}



- (void)getDrivingCarInfoMapLocation {

    __block id responseObjectFormCar;
    __block id responseObjectFormShop;
    
    // 创建信号量
    dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
    // 创建全局并行
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_group_t group = dispatch_group_create();
    dispatch_group_async(group, queue, ^{
        
        //获取车辆位置信息
        [DrivingCarInfoMap getDrivingCarInfoMapFormCar:@{@"vin":_drivingExperienceModel.chassisNo?:@""} Success:^(id responseObject) {
            responseObjectFormCar = responseObject;
            dispatch_semaphore_signal(semaphore);
        } Failure:^(NSError *error) {
        }];
        
    });
    dispatch_group_async(group, queue, ^{
        
        //获取展厅位置信息
        [DrivingCarInfoMap getDrivingCarInfoMapFormShop:@{} Success:^(id responseObject) {
            responseObjectFormShop = responseObject;
            dispatch_semaphore_signal(semaphore);

        } Failure:^(NSError *error) {
        }];
    });

    dispatch_group_notify(group, queue, ^{
        // 三个请求对应三次信号等待
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        
        //在这里 进行请求后的方法，回到主线程
        dispatch_async(dispatch_get_main_queue(), ^{
            [self createMapLocation:responseObjectFormCar withShopLocal:responseObjectFormShop];
        });
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    //由于当前位置的标注也是一个大头针，所以此时需要判断，此代理方法返回nil使用默认大头针视图
    if ([annotation isKindOfClass:[DrivingAnnotation class]]) {
        static NSString  * key1 = @"Annotation";
        MKAnnotationView * annotationView = [mapView dequeueReusableAnnotationViewWithIdentifier:key1];
        if (!annotationView) {
            annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:key1];
            annotationView.canShowCallout = NO;              //允许交互点击
            annotationView.calloutOffset = CGPointMake(0, 0);  //定义详情视图偏移量
            annotationView.leftCalloutAccessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@""]];
        }
        annotationView.annotation = annotation;
        if ([annotation.title isEqualToString:@"4s店位置"]) {
            annotationView.image = [UIImage imageNamed:@"DrivingExperience_map_car"];    //设置大头针视图的图片
        }else{
            annotationView.image = [UIImage imageNamed:@"DrivingExperience_map_shop"];    //设置大头针视图的图片
        }
        
        return annotationView;
    }else{
        return nil;
    }
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case 0:
        case 1:
            return 1;
        case 2:
            return [_items count];
        default:
            break;
    }
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 2) {
        return 100.;
    }
    return 50.;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}
- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    switch (section) {
        case 0:
        {
            DrivingCarInfoHeadNumberTableViewCell_HeadView *view = [[DrivingCarInfoHeadNumberTableViewCell_HeadView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 50)];
            view.layer.borderWidth = 1.;
            view.layer.borderColor = [[UIColor colorWithWholeRed:214 green:214 blue:214] CGColor];
            return view;
        }
            break;
        case 1:
        {
            DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo *view= [[DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 50)withSection:section];
            return view;
        }
        case 2:
        {
            DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo *view= [[DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 100)withSection:section];
            return view;
        }
        default:
            return nil;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    switch (indexPath.section) {
        case 0:
        {
            NSString *CollectionCellIdentifier = @"DrivingCarInfoHeadNumberTableViewCell";
            [tableView registerNib:[UINib nibWithNibName:@"DrivingCarInfoHeadNumberTableViewCell" bundle:nil] forCellReuseIdentifier:CollectionCellIdentifier];
            DrivingCarInfoHeadNumberTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CollectionCellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell configCellData:self.drivingExperienceModel];
            return cell;
        }
            
        case 1:
        {
            NSString *CollectionCellIdentifier = @"DrivingCarInfoHeadInfoTableViewCell";
            [tableView registerNib:[UINib nibWithNibName:@"DrivingCarInfoHeadInfoTableViewCell" bundle:nil] forCellReuseIdentifier:CollectionCellIdentifier];
            DrivingCarInfoHeadInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CollectionCellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            if (_drivingExperienceModel.time.count > 0) {
                DrivingTimerModel *tm = [_drivingExperienceModel.time firstObject];
                [cell configCellData:tm];
            }
            
            return cell;
        }
        case 2:
        {
            NSString *CollectionCellIdentifier = @"DrivingCarInfoHeadStateTableViewCell";
            [tableView registerNib:[UINib nibWithNibName:@"DrivingCarInfoHeadStateTableViewCell" bundle:nil] forCellReuseIdentifier:CollectionCellIdentifier];
            DrivingCarInfoHeadStateTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CollectionCellIdentifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            DrivingYuYueTimerModel *ym = [_drivingExperienceModel.yuyuetime objectAtIndex:indexPath.row];
            [cell configCellData:ym];
            [cell.cellGetCarButtouOutlet addTarget:self action:@selector(getGetCarButtonAction:) forControlEvents:UIControlEventTouchDown];
            return cell;
        }
        default:
            return nil;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

/***
 *  领车按钮点击
 */
- (void)getGetCarButtonAction:(UIButton *)sender{
    
    
    // 无未识别出角色  前台不允许领车操作
    if ([AppDelegate APP].user.role == UserRoleReceptionist || [AppDelegate APP].user.role == UserRoleUnrecognized) {
        
        [JKAlert showMessage:@"您的权限不足，暂时无法领车操作"];
        return;
    }
    
    
    
    DrivingGetCarViewController *dgc = [DrivingGetCarViewController new];
    dgc.drivingCarType = DRIVINGGETCAR_FORM_HOME;
    dgc.drivingExperienceModel = self.drivingExperienceModel;
    [self.navigationController pushViewController:dgc animated:YES];
}



/**
 *  获取试驾路线图
 */
- (IBAction)getDrivingMapAction:(id)sender {
    
    [self presentDSPAPopup:[[DrivingMapViewController alloc] init] parentViewController:self touchCallBack:^{
        
    } haveMask:YES includeNavgation:YES alignTop:NO];
}
@end
