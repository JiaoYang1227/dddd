//
//  DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo.m
//  DSPA2015
//
//  Created by runlin on 2018/1/11.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo.h"

@implementation DrivingCarInfoHeadNumberTableViewCell_HeadViewCarInfo

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype)initWithFrame:(CGRect)frame withSection:(NSInteger )section{
    if (self = [super initWithFrame:frame]) {
        
        [self buildView:section];
    }
    return self;
}

- (void)buildView:(NSInteger)section{
    UILabel *lable1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 50)];
    lable1.textAlignment = NSTextAlignmentCenter;
    switch (section) {
        case 1:
            lable1.text = @"车辆占用信息";
            break;
        case 2:
            lable1.text = @"预约状况";
            break;
        default:
            break;
    }
    lable1.layer.borderColor = [[UIColor colorWithWholeRed:214 green:214 blue:214] CGColor];
    lable1.layer.borderWidth = 1.;
    lable1.backgroundColor = [UIColor colorWithWholeRed:246 green:246 blue:246];

    
    [self addSubview:lable1];
    
    
    if (section == 2) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 50, self.frame.size.width, 50)];
        imgView.image =[UIImage imageNamed:@"DrivingCarInfo_cell_bg"];
        [self addSubview:imgView];
    }
    
}
@end
