//
//  DrivingCarInfoHeadNumberTableViewCell_HeadView.m
//  DSPA2015
//
//  Created by runlin on 2018/1/11.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingCarInfoHeadNumberTableViewCell_HeadView.h"

@implementation DrivingCarInfoHeadNumberTableViewCell_HeadView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        [self buildView];
    }
    return self;
}

- (void)buildView{
//    UILabel *lable1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width/2, self.frame.size.height)];
//    lable1.textAlignment = NSTextAlignmentCenter;
//    lable1.text = @"车牌";
//    lable1.backgroundColor = [UIColor colorWithWholeRed:246 green:246 blue:246];
//    [self addSubview:lable1];
//
//    UILabel *lable2 = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.width/2, 0, self.frame.size.width/2, self.frame.size.height)];
//    lable2.textAlignment = NSTextAlignmentCenter;
//    lable2.text = @"状态";
//    lable2.backgroundColor = [UIColor colorWithWholeRed:246 green:246 blue:246];
//    [self addSubview:lable2];
//
//    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(self.frame.size.width/2, 10, 0.5, self.frame.size.height-20)];
//    line.backgroundColor = [UIColor lightGrayColor];
//    [self addSubview:line];
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:self.bounds];
    imgView.image = [UIImage imageNamed:@"DrivingGetCar_section_view"];
    
    [self addSubview:imgView];
    
}

@end
