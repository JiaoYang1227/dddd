//
//  DrivingCarInfoHeadStateTableViewCell.m
//  DSPA2015
//
//  Created by runlin on 2018/1/11.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingCarInfoHeadStateTableViewCell.h"
#import "AppDelegate.h"

@interface DrivingCarInfoHeadStateTableViewCell ()
{
    
    __weak IBOutlet UILabel *cell_yuyueren;
    __weak IBOutlet UILabel *cell_jianlishijian;
    __weak IBOutlet UILabel *cell_kaishishijian;
    __weak IBOutlet UILabel *cell_lianxishijian;
    __weak IBOutlet UIButton *cell_lingche_buttonOutlet;
    
    
    
}
@end
@implementation DrivingCarInfoHeadStateTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)configCellData:(DrivingYuYueTimerModel *)model{
    cell_yuyueren.text = model.salesConsultantName?:@"";
    cell_lianxishijian.text = model.saleManMobile?:@"";
    cell_jianlishijian.text = model.DCreate;
    cell_kaishishijian.text = model.DAppointBegin;
    
    cell_jianlishijian.adjustsFontSizeToFitWidth = YES;
    cell_kaishishijian.adjustsFontSizeToFitWidth = YES;
    
    
    
    //如果是同一个销售顾问可以进行换车操作
    if (![model.userID isEqualToString:[AppDelegate APP].user.userID]) {
        cell_lingche_buttonOutlet.hidden = YES;
    }else{
        cell_lingche_buttonOutlet.hidden = NO;
    }
    
    
}
@end
