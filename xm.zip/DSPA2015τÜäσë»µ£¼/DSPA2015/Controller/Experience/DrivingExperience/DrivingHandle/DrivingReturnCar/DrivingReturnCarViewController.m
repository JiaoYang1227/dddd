//
//  DrivingReturnCarViewController.m
//  DSPA2015
//
//  Created by runlin on 2018/1/12.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DrivingReturnCarViewController.h"
#import "DrivingFeedbackViewController.h"
#import "DrivingProtocolViewController.h"

@interface DrivingReturnCarViewController ()

@end

@implementation DrivingReturnCarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// 试驾路线
- (IBAction)vTryCarPathAction:(SelectButton *)sender {
    NSDictionary *dic = @{@"试驾路线1":@"TryDriveRoute1" , @"试驾路线2":@"TryDriveRoute2",@"试驾路线3":@"TryDriveRoute3"};
    [self showSearchSelectController:sender withData:@[@"试驾路线1",@"试驾路线2",@"试驾路线3"] selectItem:^(id item, NSString *key, NSString *value) {
        sender.key = [dic stringForKey:key];
        sender.value = key;
    }];
}



//试驾协议
- (IBAction)shijiaxieyiButtonAction:(id)sender {
    [self.navigationController pushViewController:[DrivingProtocolViewController new] animated:YES];
}
//试驾反馈
- (IBAction)shijiafankuiButtonAction:(id)sender {
    [self.navigationController pushViewController:[DrivingFeedbackViewController new] animated:YES];
}
//试驾结束
- (IBAction)shijiajieshuButtonAction:(id)sender {
}

//返回
- (IBAction)fanhuiButtonAction:(id)sender {
    Class class = NSClassFromString(@"DrivingExperienceNewViewController");
    NSAssert(class != nil,@"Class YES");
    UIViewController *vc = [[NSClassFromString(@"DrivingExperienceNewViewController") alloc] init];
    
    [self.navigationController pushViewController:vc animated:YES];
}
@end
