//
//  AlertDrivingViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/17.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AlertDrivingViewController.h"
#import "UIViewController+MJPopupViewController.h"
#import "ReturnDrivingViewController.h"
#import "UIViewController+DSPAPopup.h"

@interface AlertDrivingViewController ()
{
    //========
    
    __weak IBOutlet UILabel *_drivingState;     //状态
    __weak IBOutlet UILabel *_salesAdviser;     //销售顾问
}

@property (weak, nonatomic) IBOutlet UIButton *retrunCarOutlet;
@property (weak, nonatomic) IBOutlet UIButton *cancelOutlet;


- (IBAction)retrunCatAction:(id)sender;
- (IBAction)cancelDrivingAction:(id)sender;
@end

@implementation AlertDrivingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    DrivingTimerModel *dtm = [_drivingExperienceModel.time objectWithIndex:_drivingExperienceModel.arrIndex];
    
    _drivingState.text = dtm.tryoutState;
    _salesAdviser.text = [AppDelegate APP].user.userName?:[AppDelegate APP].user.salesConsultantName?:@"";
    
    NSString *state = [dtm.tryoutState stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([state isEqualToString:@"试驾结束"]) {
        self.retrunCarOutlet.hidden = YES;
        self.cancelOutlet.hidden = YES;
    }
    
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadData:) name:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
}

/**
 *  还车
 */
- (IBAction)retrunCatAction:(id)sender {
    
    DrivingTimerModel *dtm = [_drivingExperienceModel.time objectWithIndex:_drivingExperienceModel.arrIndex];

    ReturnDrivingViewController *returnCar = [[ReturnDrivingViewController alloc] init];
    returnCar.drivingExperienceModel =  _drivingExperienceModel;
    returnCar.dtm = dtm;
    [self presentPopupViewController:returnCar animationType:MJPopupViewAnimationSlideBottomTop];
}

/**
 *  取消试驾
 */
- (IBAction)cancelDrivingAction:(id)sender {

    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"取消中...";
    DrivingTimerModel *dtm = [_drivingExperienceModel.time objectWithIndex:_drivingExperienceModel.arrIndex];
    _drivingExperienceModel.driveStartTime = dtm.begintime;
    _drivingExperienceModel.tryoutState = @"试驾取消";
    [DrivingExperienceModel updateDrivingExperience:[_drivingExperienceModel toDictionary] Success:^(NSArray *headList, id responseObject) {
        
        if ([responseObject objectForKey:@"validate_error"]) {
            NSArray *error = [[responseObject objectForKey:@"validate_error"] allValues];
            [JKAlert showMessage:[error firstObject]];
        }else if([responseObject boolForKey:@"success"]){
            [[NSNotificationCenter defaultCenter]postNotificationName:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
            [self dismissTouched:nil];
        }
        
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}


-(void)reloadData:(NSNotification*)notifacation{
    [self dismissTouched:nil];
}

- (void)dismissTouched:(id)sender{
    [self dismissDSPAPopup:^{
        
    }];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
