//
//  AddDrivingExperienceViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AddDrivingExperienceViewController.h"
#import "AddDrivingCarInfoViewController.h"
#import "UIViewController+MJPopupViewController.h"
#import "UIViewController+DSPAPopup.h"

@interface AddDrivingExperienceViewController ()
{
    //=========
    __weak IBOutlet SelectButton *beginTimer;
    __weak IBOutlet SelectButton *endTimer;
    
    __weak IBOutlet BorderTextField *_salesLeadTextField;
    __weak IBOutlet BorderTextField *_customerNameTextField;
    
    //===========
    DrivingExperienceModel *_addDrivingModel;
}

//===========
- (IBAction)beginTimerAction:(SelectButton *)sender;
- (IBAction)endTimerAction:(SelectButton *)sender;

@property (weak, nonatomic) IBOutlet UIButton *addCarOutlet;

- (IBAction)addCarAction:(id)sender;

- (IBAction)appointmentAction:(id)sender;

@end

@implementation AddDrivingExperienceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor whiteColor];
    _addDrivingModel = [[DrivingExperienceModel alloc] init];
    _addDrivingModel = _model;
    
    beginTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[NSDate date]];
    _addDrivingModel.driveStartTime =[DateManager timeIntervalWithDate:[NSDate date]];
    
    long long endDate = [DateManager timeIntervalWithDate:[NSDate date]] + 30*60*1000;
    
    endTimer.value = [DateManager stringConvert_YMDHMS_FromDate:[DateManager dateWithTimeStamp:endDate]];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadData:) name:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
    
    self.title = @"新建试乘试驾(首页)";
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    _salesLeadTextField.text = [AppDelegate APP].user.userName?:[AppDelegate APP].user.salesConsultantName?:@"";
    
    _customerNameTextField.text = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.custName?:@"";
    
    
    if (self.drivingCarUse) {
        self.addCarOutlet.enabled = NO;
    }else{
        self.addCarOutlet.enabled = YES;
    }
    
}


/**
 *  开始时间
 */
- (IBAction)beginTimerAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        beginTimer.value = [DateManager stringConvert_YMDHMS_FromDate:date];
        _addDrivingModel.driveStartTime = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}


/**
 *  结束时间
 */
- (IBAction)endTimerAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        endTimer.value = [DateManager stringConvert_YMDHMS_FromDate:date];;

    }];
    [self presentViewController:datePicker animated:YES completion:nil];
    
}
/**
 *  @author Jakey, 16-03-19 12:03:16
 *
 *  领车
 *
 *  @param sender <#sender description#>
 */
- (IBAction)addCarAction:(id)sender {
    
    if (!_salesLeadTextField.text) {
        [JKAlert showMessage:@"销售顾问姓名不能为空"];
        return;
    }
    
    if (!_customerNameTextField.text) {
        [JKAlert showMessage:@"客户姓名不能为空"];
        return;
    }
    
    _addDrivingModel.salesLeadName = _salesLeadTextField.text;
    _addDrivingModel.custName = _customerNameTextField.text;
    
    
    AddDrivingCarInfoViewController *add;

    if(self.havedYuYue){
        add = [[AddDrivingCarInfoViewController alloc] initWithModuleType:ModuleTypeIndex andDriverType:AddDrivingCarTypeYuyue2Lingche];
        NSLog(@"预约状态下领车");
    }else{
        add = [[AddDrivingCarInfoViewController alloc] initWithModuleType:ModuleTypeIndex andDriverType:AddDrivingCarTypeLingche];
        NSLog(@"直接领车");
    }
    
    
    add.drivingExperienceModel = _addDrivingModel;
    [self presentPopupViewController:add animationType:MJPopupViewAnimationSlideBottomTop];

}

/**
 *  预约试驾
 */
- (IBAction)appointmentAction:(id)sender {

    if (!_salesLeadTextField.text) {
        [JKAlert showMessage:@"销售顾问姓名不能为空"];
        return;
    }
    
    if (!_customerNameTextField.text) {
        [JKAlert showMessage:@"客户姓名不能为空"];
        return;
    }
    
    _addDrivingModel.salesLeadName = _salesLeadTextField.text;
    _addDrivingModel.custName = _customerNameTextField.text;
    
    AddDrivingCarInfoViewController *add;
    if(self.havedYuYue){
        add = [[AddDrivingCarInfoViewController alloc] initWithModuleType:ModuleTypeIndex andDriverType:AddDrivingCarTypeYuyue];
        NSLog(@"预约状态下再预约");
    }else{
        add = [[AddDrivingCarInfoViewController alloc] initWithModuleType:ModuleTypeIndex andDriverType:AddDrivingCarTypeYuyue];
        NSLog(@"直接预约");
    }
    
    
    add.drivingExperienceModel = _addDrivingModel;
    
    
    [self presentPopupViewController:add animationType:MJPopupViewAnimationSlideBottomTop];
}


-(void)reloadData:(NSNotification*)notifacation{
    [self dismissTouched:nil];
}



- (void)dismissTouched:(id)sender{
    [self dismissDSPAPopup:^{
        
    }];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
