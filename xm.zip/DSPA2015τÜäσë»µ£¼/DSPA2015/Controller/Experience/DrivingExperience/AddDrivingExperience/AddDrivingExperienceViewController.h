//
//  AddDrivingExperienceViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//


#import "DrivingExperienceBaseViewController.h"
#import "DrivingExperienceModel.h"

@interface AddDrivingExperienceViewController : DrivingExperienceBaseViewController
//@property(strong,nonatomic)  UIView *coverView;

@property (nonatomic , strong) DrivingExperienceModel *model;


@property (nonatomic , assign) BOOL drivingCarUse;// 试驾车辆是否被占用


@property (nonatomic , assign) BOOL havedYuYue;//是否预约的试驾来的

@end
