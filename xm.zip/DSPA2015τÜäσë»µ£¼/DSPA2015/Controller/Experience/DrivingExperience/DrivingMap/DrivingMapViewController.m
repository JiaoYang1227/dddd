//
//  DrivingMapViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/17.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "DrivingMapViewController.h"
#import "JKScrollFocus.h"
#import "DrivingExperienceMapModel.h"
#import "UIImageView+AFNetworking.h"
#import "UIViewController+DSPAPopup.h"


@interface DrivingMapViewController ()
{
    //=========
    
    __weak IBOutlet JKScrollFocus *_loopMapView;
    
    NSMutableArray *_dataList;
}
@end

@implementation DrivingMapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
//    _loopMapView.imageArray = @[@"http://img.ivsky.com/img/bizhi/co/201508/23/sinbawa-002.jpg"];
//    [_loopMapView downloadFocusItem:^(id downloadItem, UIImageView *currentImageView) {
//        [currentImageView setImageWithURL:[NSURL URLWithString:downloadItem]];
//    }];
    [self loadData];
    self.title = @"试乘试驾路线图(首页)";
}

- (void)loadData{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [DrivingExperienceMapModel fetchDrivingExperienceMapList:@{} Success:^(NSArray *headList , NSArray *imgList, id responseObject) {
        if (imgList.count > 0) {
            
            _loopMapView.imageArray = imgList;
            _loopMapView.titleArray = imgList;
            [_loopMapView downloadFocusItem:^(id downloadItem, UIImageView *currentImageView) {
                [currentImageView setImageWithURL:[NSURL URLWithString:downloadItem]];
            }];
        }
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)dismissTouched:(id)sender{
    [self dismissDSPAPopup:^{
        
    }];
}

@end
