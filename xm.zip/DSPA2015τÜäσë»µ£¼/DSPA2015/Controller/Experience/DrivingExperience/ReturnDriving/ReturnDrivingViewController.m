//
//  ReturnDrivingViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ReturnDrivingViewController.h"
#import "UIViewController+MJPopupViewController.h"

@interface ReturnDrivingViewController ()
{
    
    __weak IBOutlet SelectButton *returnCarTimerOutlet;
    __weak IBOutlet BorderTextField *_beginMilTextField;
    __weak IBOutlet BorderTextField *_drivingMilTextFiled;  //试驾里程
    __weak IBOutlet BorderTextField *_endMilTextFiled;      //归还里程
}

- (IBAction)returnCarTimerAction:(SelectButton *)sender;

- (IBAction)commitAction:(id)sender;

- (IBAction)cancelAction:(id)sender;    //取消
@end

@implementation ReturnDrivingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self bringDate:self.drivingExperienceModel withDrivingTimerModel:self.dtm];
    self.title = @"试乘试驾还车(首页)";
}

- (void)bringDate:(DrivingExperienceModel *)model withDrivingTimerModel:(DrivingTimerModel *)dtm{
    returnCarTimerOutlet.value = [DateManager stringConvert_YMDHM_FromDate:[NSDate date]];
    _beginMilTextField.text = dtm.driveStartKM;
}

/**
 *  返还时间
 */
- (IBAction)returnCarTimerAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        NSLog(@"%@",date);
        returnCarTimerOutlet.value = [DateManager stringConvert_YMDHMS_FromDate:date];
        //        preDeliveryDateOutlet.value = [dateFormatter stringFromDate:date];
        _drivingExperienceModel.driveEndTime = timeStamp;

    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}

- (IBAction)commitAction:(id)sender {

    if(_drivingMilTextFiled.text.length <= 0 && ![_drivingMilTextFiled.text isEqualToString:@""]){
        [JKAlert showMessage:@"试驾里程不能为空"];
        return;
    }
    if(_endMilTextFiled.text.length <=0 && ![_endMilTextFiled.text isEqualToString:@""]){
        [JKAlert showMessage:@"归还里程不能为空"];
        return;
    }
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    DrivingTimerModel *dtm = [_drivingExperienceModel.time objectWithIndex:_drivingExperienceModel.arrIndex];
    _drivingExperienceModel.driveStartTime = dtm.begintime;
    _drivingExperienceModel.endMileage = _endMilTextFiled.text;
    
    _drivingExperienceModel.tryoutState = @"试驾结束";
    
    [DrivingExperienceModel updateDrivingExperience:[_drivingExperienceModel toDictionary] Success:^(NSArray *headList, id responseObject) {
        
        if ([responseObject objectForKey:@"validate_error"]) {
            NSArray *error = [[responseObject objectForKey:@"validate_error"] allValues];
            [JKAlert showMessage:[error firstObject]];
            
        }else if([responseObject boolForKey:@"success"]){
            
        [[NSNotificationCenter defaultCenter]postNotificationName:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
            [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationSlideTopBottom];
            
            [JKAlert showMessage:@"试驾还车成功"];
        }
        
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
    
}

- (IBAction)cancelAction:(id)sender {
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationSlideTopBottom];
}


- (void)textFieldDidEndEditing:(UITextField *)textField{
//    __weak IBOutlet BorderTextField *_drivingMilTextFiled;
//    __weak IBOutlet BorderTextField *_endMilTextFiled;
    
    
    if (textField == _drivingMilTextFiled) {
        if ([_drivingMilTextFiled.text floatValue] > 0) {
            float sum = [_drivingMilTextFiled.text floatValue] + [self.dtm.driveStartKM floatValue];
            _endMilTextFiled.text = [NSString stringWithFormat:@"%.1f",sum];
            
        }else{
            [JKAlert showMessage:@"试驾里程不能小于0"];
        }
    }
    
    
    if (textField == _endMilTextFiled) {
        if ([_endMilTextFiled.text floatValue] > [_drivingMilTextFiled.text floatValue]) {
            float sum = [_endMilTextFiled.text floatValue] - [self.dtm.driveStartKM floatValue];
            _drivingMilTextFiled.text = [NSString stringWithFormat:@"%.1f",sum];
            
        }else{
            [JKAlert showMessage:@"试驾结束里程不能小于试驾开始里程"];
        }
    }
    
    
    if (textField == _drivingMilTextFiled) {
        if ([_drivingMilTextFiled.text floatValue] > 10.) {
            [JKAlert showMessage:@"您输入的试驾公里数大于10公里，请确认是否继续保存！"];
        }
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
