//
//  ReturnDrivingViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/16.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceBaseViewController.h"
#import "DrivingExperienceModel.h"

@interface ReturnDrivingViewController : DrivingExperienceBaseViewController
@property (nonatomic , strong) DrivingExperienceModel *drivingExperienceModel;

@property (nonatomic , strong) DrivingTimerModel *dtm;

@end
