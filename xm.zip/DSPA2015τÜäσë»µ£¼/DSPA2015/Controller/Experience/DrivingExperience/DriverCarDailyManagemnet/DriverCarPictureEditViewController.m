//
//  DriverCarPictureEditViewController.m
//  DSPA2015
//
//  Created by Cluy on 2018/1/10.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DriverCarPictureEditViewController.h"

@interface DriverCarPictureEditViewController ()

@end

@implementation DriverCarPictureEditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _itemsSelectbtn.value = @"";
    [_backImgView setImage:[UIImage imageNamed:@"DrivingLicenceUpload_img_bg.png"]];
    [self initView];
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
-(void)initView{
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [NSString stringWithFormat:@"%@/DriverCarDaily/%@",documentUrl,_item.carid];
    //正车头
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/frontpicture.png",filePath]]) {
        _head.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/frontpicture.png",filePath]];
    }else{
        _head.image = [UIImage imageNamed:@"CarDaily_head_picture"];
        
    }
     //正右侧
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/rightfrontpicture.png",filePath]]) {
        _headRight45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/rightfrontpicture.png",filePath]];
    }else{
         _headRight45.image = [UIImage imageNamed:@"CarDaily_rightfront_picture"];
    }
    //中控区域
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/leftfrontpicture.png",filePath]]) {
        _leftHead45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/leftfrontpicture.png",filePath]];
    }else{
        _leftHead45.image = [UIImage imageNamed:@"CarDaily_leftfront_picture"];
    }
    //正后
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/rearpicture.png",filePath]]) {
        _tail.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/rearpicture.png",filePath]];
    }else{
        _tail.image = [UIImage imageNamed:@"CarDaily_tail_picture"];
    }
     //正左侧
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/rightrearpicture.png",filePath]]) {
        _rightTail45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/rightrearpicture.png",filePath]];
    }else{
        _rightTail45.image = [UIImage imageNamed:@"CarDaily_rightrear_picture"];
    }
    //后排座椅
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/leftrearpicture.png",filePath]]) {
        _leftTail45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/leftrearpicture.png",filePath]];
    }else{
        _leftTail45.image = [UIImage imageNamed:@"CarDaily_leftrear_picture"];
    }
    //车辆信息
    self.carmodel.text = _item.vsaleTypeName;
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"drivingCarBrand" ofType:@"plist"];
    NSMutableDictionary *ccpDic = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    self.carImg.image = [UIImage imageNamed:[ccpDic stringForKey:_item.series?:@""]];
    self.carStateLable.layer.cornerRadius = 2.0;
    if ([_item.carStatus isEqualToString:@"空闲"]) {
        [self.carStateLable setBackgroundColor:[UIColor colorWithWholeRed:21 green:171 blue:56]];
    }
    if ([_item.carStatus isEqualToString:@"占用"]) {
        [self.carStateLable setBackgroundColor: [UIColor colorWithWholeRed:171 green:21 blue:43]];
    }
    if ([_item.carStatus isEqualToString:@"预约中"]) {
        [self.carStateLable setBackgroundColor:[UIColor yellowColor]];
    }
    self.plateLabel.text = _item.vlicenseTag;
    self.carStateLable.text =_item.carStatus;
}
- (IBAction)selectdAction:(id)sender {
    [self showCommonSearchSelect:sender withData:@[@"正车头",@"正右侧",@"中控区域",@"正后",@"正左侧",@"后排座椅"] selectItem:^(id item){
        _itemsSelectbtn.value = item;
    }];
}

- (IBAction)cameraAction:(id)sender {
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        //没有摄像头 或者模拟器下使用 跳过
        return;
    }
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = NO;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:imagePickerController animated:YES completion:^{
        
    }];
    
}
#pragma mark UIImagePickerControllerDelegate event handler
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
       [_backImgView setImage:[UIImage imageNamed:@"CarDaily_picture_BG.png"]];
       UIImage *tempImg = [info valueForKey:UIImagePickerControllerOriginalImage];
        [_tempPicture setImage:tempImg];
        [picker dismissViewControllerAnimated:YES completion:nil];

}
//完成并返回
- (IBAction)saveAndBack:(id)sender {
    [DriverCarDailyManagemnet saveimg:_head.image withNameKEY:@"frontpicture" withCarid:_item.carid];
    [DriverCarDailyManagemnet saveimg:_headRight45.image withNameKEY:@"rightfrontpicture" withCarid:_item.carid];
    [DriverCarDailyManagemnet saveimg:_leftHead45.image withNameKEY:@"leftfrontpicture" withCarid:_item.carid];
    [DriverCarDailyManagemnet saveimg:_tail.image withNameKEY:@"rearpicture" withCarid:_item.carid];
    [DriverCarDailyManagemnet saveimg:_leftTail45.image withNameKEY:@"leftrearpicture" withCarid:_item.carid];
    [DriverCarDailyManagemnet saveimg:_rightTail45.image withNameKEY:@"rightrearpicture" withCarid:_item.carid];
    [super backButtonTouched:sender];
}

- (IBAction)saveAction:(id)sender {
    if(_tempPicture.image ==nil){
        return;
    }
    if(_itemsSelectbtn.value == nil){
        [JKAlert showMessage:@"请选择要放在的位置"];
    }
    [_backImgView setImage:[UIImage imageNamed:@"DrivingLicenceUpload_img_bg.png"]];
    //保存图片到本地
    NSString *item = _itemsSelectbtn.value;
    if ([item isEqualToString:@"正车头"]) {
        _head.image = _tempPicture.image;
        
    }
    if ([item isEqualToString:@"正右侧"]) {
        _headRight45.image = _tempPicture.image;
    }
    if ([item isEqualToString:@"中控区域"]) {
        _leftHead45.image = _tempPicture.image;
    }
    if ([item isEqualToString:@"正后"]) {
        _tail.image = _tempPicture.image;
    }
    if ([item isEqualToString:@"正左侧"]) {
        _rightTail45.image = _tempPicture.image;
    }
    if ([item isEqualToString:@"后排座椅"]) {
         _leftTail45.image = _tempPicture.image;
    }
    _tempPicture.image = nil;
}

- (IBAction)dismissView:(id)sender {
    [super backButtonTouched:sender];
}
#pragma mark -------------下拉菜单-----------------------------
#pragma mark show pop view
/**
 *  统一处理弹出框
 *
 *  @param sender sender description
 *  @param array  array description
 */
-(void)showCommonSearchSelect:(SelectButton*)sender withData:(NSArray*)array selectItem:(void (^)(id item))selectItem{
    _searchControl = [[PopoverSearchController alloc]initWithSender:sender andItems:array];
    [_searchControl hiddenSearchBar:YES];
    [_searchControl reverseIndexWithValue:sender.value];
    [_searchControl didSelectSearchItem:^(id item, NSString *key, NSString *value) {
        [sender setTitle:value forState:UIControlStateNormal];
        sender.value = item;
        selectItem(item);
    }];
    [self presentViewController:_searchControl animated:YES completion:nil];
}
@end
