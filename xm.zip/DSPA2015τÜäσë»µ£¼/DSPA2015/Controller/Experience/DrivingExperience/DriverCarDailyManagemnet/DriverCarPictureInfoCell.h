//
//  DriverCarPictureInfoCell.h
//  DSPA2015
//
//  Created by Cluy on 2018/1/9.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DriverCarDailyManagemnet.h"
#import "LDProgressView.h"
@protocol PictureActionDelegate
-(void)editPictures:(int)indexValue;
-(void)uploadPictures:(int)indexValue;
@end
@interface DriverCarPictureInfoCell : UITableViewCell
@property (strong)id <PictureActionDelegate>actionDelegate;
@property (weak, nonatomic) IBOutlet UIView *line;
@property (weak, nonatomic) IBOutlet UILabel *brand;
@property (weak, nonatomic) IBOutlet UILabel *model;
@property (weak, nonatomic) IBOutlet UILabel *plate;
@property (weak, nonatomic) IBOutlet UILabel *carStatus;
@property (weak, nonatomic) IBOutlet UILabel *updateDate;
@property (weak, nonatomic) IBOutlet UILabel *updateStatus;
@property (weak, nonatomic) IBOutlet UIButton *updateBtn;
@property (weak, nonatomic) IBOutlet UIButton *pictureBtn;
@property (weak, nonatomic) IBOutlet LDProgressView *progressView;


- (IBAction)updateAction:(id)sender;
- (IBAction)picturesAction:(id)sender;

- (void)congfigCell:(DriverCarDailyManagemnet *)item withIndex:(int)iValue;

@end
