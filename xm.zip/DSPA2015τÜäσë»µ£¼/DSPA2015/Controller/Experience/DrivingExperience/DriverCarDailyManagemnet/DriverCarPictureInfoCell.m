//
//  DriverCarPictureInfoCell.m
//  DSPA2015
//
//  Created by Cluy on 2018/1/9.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DriverCarPictureInfoCell.h"

@implementation DriverCarPictureInfoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _progressView.color = [UIColor redColor];
    _progressView.flat = @YES;
    _progressView.showBackgroundInnerShadow = @NO;
    _progressView.progress = 0.00;
    _progressView.animate = @YES;
    _progressView.animateDirection = LDAnimateDirectionBackward;
    _progressView.hidden = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)updateAction:(id)sender {
    UIButton *temp = sender;
    int indexValue = temp.tag -2000;
    [_actionDelegate uploadPictures:indexValue];
}

- (IBAction)picturesAction:(id)sender {
    UIButton *temp = sender;
    int indexValue = temp.tag -1000;
    [_actionDelegate editPictures:indexValue];
}

- (void)congfigCell:(DriverCarDailyManagemnet *)item withIndex:(int)iValue{
    _progressView.animate = [NSNumber numberWithBool:NO];
    NSLog(@"progress   =    %f",item.progress);
    [_pictureBtn setTag:1000+iValue];
    [_updateBtn setTag:2000+iValue];
    if (item.progress !=0 && item.progress!= 1) {
//        _updateStatus.text= @"上传中";
        _updateBtn.enabled = NO;
//        _updateBtn.hidden = YES;
        _progressView.hidden = NO;
        _updateStatus.hidden = YES;
        _progressView.progress = item.progress;
    }else
    {
        _updateBtn.enabled = YES;
//        _updateBtn.hidden = NO;
        _progressView.hidden = YES;
        _updateStatus.hidden = NO;
        _updateStatus.text = item.statusUpload;
    }
    _pictureBtn.hidden = NO;

    _brand.text = item.vseriesName?:@"";
    _model.text = item.vsaleTypeName?:@"";
    _plate.text = item.vlicenseTag?:@"";
    _carStatus.text = item.carStatus?:@"";
    _updateDate.text = [DateManager date_YMDHMS_WithTimeIntervalSince1970:[item.updateOn longLongValue]];
   
    
}
@end
