//
//  DriverCarPictureEditViewController.h
//  DSPA2015
//
//  Created by Cluy on 2018/1/10.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "DriverCarDailyManagemnet.h"

@interface DriverCarPictureEditViewController : BaseViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>{
    PopoverSearchController *_searchControl;

}
@property (weak, nonatomic) IBOutlet SelectButton *itemsSelectbtn;
@property (weak, nonatomic) IBOutlet UIImageView *tempPicture;
@property (weak, nonatomic) IBOutlet UIButton *cameraBtn;
@property (weak, nonatomic) IBOutlet UIImageView *backImgView;


@property (weak, nonatomic) IBOutlet UIImageView *head;
@property (weak, nonatomic) IBOutlet UIImageView *headRight45;
@property (weak, nonatomic) IBOutlet UIImageView *leftHead45;
@property (weak, nonatomic) IBOutlet UIImageView *tail;
@property (weak, nonatomic) IBOutlet UIImageView *rightTail45;
@property (weak, nonatomic) IBOutlet UIImageView *leftTail45;
@property (weak, nonatomic) IBOutlet UIImageView *carImg;

@property (weak, nonatomic) IBOutlet UILabel *carmodel;          //车辆信息
@property (weak, nonatomic) IBOutlet UILabel *carStateLable;
@property (weak, nonatomic) IBOutlet UILabel *plateLabel;

@property (nonatomic,strong)DriverCarDailyManagemnet *item;
@end
