//
//  AudiCheckNoticeDetialViewController.m
//  DSPA2015
//
//  Created by Cluy on 2018/2/23.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "AudiCheckNoticeDetialViewController.h"

@interface AudiCheckNoticeDetialViewController ()

@end

@implementation AudiCheckNoticeDetialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"奥迪抽检通知";
    _context.text = _checkContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)dismissTouched:(id)sender {
    [super dismissTouched:sender];
}

@end
