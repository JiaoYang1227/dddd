//
//  DriverCarDailyManagemnetViewController.m
//  DSPA2015
//
//  Created by Cluy on 2018/1/8.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DriverCarDailyManagemnetViewController.h"
#import "AudiCheckNoticeDetialViewController.h"

@interface DriverCarDailyManagemnetViewController ()

@end

@implementation DriverCarDailyManagemnetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (_checkDic!=nil) {
        [_checkBtn setTitle:@" 奥迪检查通知 (1)" forState:UIControlStateNormal];
 
    }else{
        [_checkBtn setTitle:@" 奥迪检查通知 (0)" forState:UIControlStateNormal];
    }
    self.picturesBtn.selected = NO;
    self.checkItemsButton.selected = YES;
    self.checkViewContrl = [[DriverCarCheckItemsViewController alloc]init];
    self.checkViewContrl.view.frame = self.contentView.frame;
    [self addChildViewController:self.checkViewContrl];
    [self.view addSubview:self.checkViewContrl.view];
    self.currentViewController = self.checkViewContrl;
    [CBTracking trackEvent:@"首页试乘试驾_奥迪检查项_日常检车项"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//检车照片
- (IBAction)picturesAction:(id)sender {
    [CBTracking trackEvent:@"首页试乘试驾_奥迪检查项_照片检车项"];
    if (!self.pictureViewContrl) {
        self.pictureViewContrl = [[DriverCarPicturesViewController alloc]init];
        self.pictureViewContrl.view.frame = self.contentView.frame;
    }
    [self addChildViewController:self.pictureViewContrl];
    if(self.currentViewController == self.pictureViewContrl){
        return;
    }
    self.picturesBtn.selected = YES;
    self.checkItemsButton.selected = NO;
    [self transitionFromViewController:self.currentViewController toViewController:self.pictureViewContrl duration:0.1 options:UIViewAnimationOptionTransitionNone animations:^{
        
    } completion:^(BOOL finished) {
        self.currentViewController = self.pictureViewContrl;
    }];
}
//日常检车项
- (IBAction)checkItemsAction:(id)sender {
    [CBTracking trackEvent:@"首页试乘试驾_奥迪检查项_日常检车项"];
    if(self.currentViewController == self.checkViewContrl){
        return;
    }
    self.picturesBtn.selected = NO;
    self.checkItemsButton.selected = YES;
    [self transitionFromViewController:self.currentViewController toViewController:self.checkViewContrl duration:0.1 options:UIViewAnimationOptionTransitionNone animations:^{
    } completion:^(BOOL finished) {
        self.currentViewController = self.checkViewContrl;
    }];
}
//奥迪检查通知
- (IBAction)onClickAudiCheckNotice:(id)sender {
    if(!_checkDic){
        return;
    }
    AudiCheckNoticeDetialViewController *noticeDetail = [[AudiCheckNoticeDetialViewController alloc]init];
    noticeDetail.checkContent = [_checkDic objectForKey:@"checkcontent"];
    [self presentDSPAPopup:noticeDetail parentViewController:self touchCallBack:nil haveMask:YES includeNavgation:YES alignTop:NO];
}
@end
