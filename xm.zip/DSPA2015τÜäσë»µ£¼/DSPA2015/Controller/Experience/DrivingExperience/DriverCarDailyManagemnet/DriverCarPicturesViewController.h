//
//  DriverCarPicturesViewController.h
//  DSPA2015
//
//  Created by Cluy on 2018/1/8.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "DriverCarPictureInfoCell.h"
#import "DriverCarDailyManagemnet.h"
@interface DriverCarPicturesViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource,PictureActionDelegate>
@property (nonatomic,strong)NSArray *listArr;
@property (weak, nonatomic) IBOutlet UITableView *listTable;
@property (weak, nonatomic) IBOutlet UIImageView *head;
@property (weak, nonatomic) IBOutlet UIImageView *headRight45;
@property (weak, nonatomic) IBOutlet UIImageView *leftHead45;
@property (weak, nonatomic) IBOutlet UIImageView *tail;
@property (weak, nonatomic) IBOutlet UIImageView *rightTail45;
@property (weak, nonatomic) IBOutlet UIImageView *leftTail45;
@property (weak, nonatomic) IBOutlet UIImageView *carImg;


@property (weak, nonatomic) IBOutlet UILabel *carmodel;          //车辆信息
@property (weak, nonatomic) IBOutlet UILabel *carStateLable;
@property (weak, nonatomic) IBOutlet UILabel *plateLabel;

@property(weak,nonatomic)DriverCarDailyManagemnet *pictureSelectdItem;//照片维护界面数据


@end
