//
//  DriverCarCheckItemsViewController.h
//  DSPA2015
//
//  Created by Cluy on 2018/1/8.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface DriverCarCheckItemsViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UICollectionView *collectionVview;

@property (weak, nonatomic) IBOutlet SelectButton *dateSelectBtn;

- (IBAction)dateSelectedAction:(id)sender;

@property (nonatomic,strong) NSDictionary *titleItems;

@end
