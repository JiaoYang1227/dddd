//
//  DriverCarCheckItemsCell.h
//  DSPA2015
//
//  Created by Cluy on 2018/1/12.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DriverCarCheckItemsCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIButton *checkButton;

@end
