//
//  DriverCarCheckItemsViewController.m
//  DSPA2015
//
//  Created by Cluy on 2018/1/8.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DriverCarCheckItemsViewController.h"
#import "DriverCarCheckItemsNameCell.h"
#import "DriverCarCheckItemsCell.h"
#import "JKCollectionViewExcelLayout.h"

#import "NSDictionary+SafeAccess.h"
#import "DriverCarDailyItems.h"
#import "DateManager.h"
#import "MBProgressHUD.h"
@interface DriverCarCheckItemsViewController ()<JKCollectionViewExcelLayoutDelegate>
{
    NSMutableArray *_items;
}
@end

@implementation DriverCarCheckItemsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    JKCollectionViewExcelLayout *layout = (id)self.collectionVview.collectionViewLayout;
    layout.delegate = self;
    [self.collectionVview registerNib:[UINib nibWithNibName:@"DriverCarCheckItemsCell" bundle:nil] forCellWithReuseIdentifier:@"DriverCarCheckItemsCell"];
    [self.collectionVview registerNib:[UINib nibWithNibName:@"DriverCarCheckItemsNameCell" bundle:nil] forCellWithReuseIdentifier:@"DriverCarCheckItemsNameCell"];
    _titleItems= @{@"vchecka":@"试乘试驾车的里程（低于3万公里）",@"vcheckb":@"车辆内饰整洁完好",@"vcheckc":@"车辆外观整洁完好",@"vcheckd":@"全车玻璃不能贴膜",@"vchecke":@"不摆放非原厂的装饰和精品",@"vcheckf":@"车贴保存完好",@"vcheckg":@"车况保持良好"};
    _dateSelectBtn.key = [DateManager nowTimeStampString];
    _dateSelectBtn.value = [DateManager nowYMDString];
    [self search:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"首页试乘试驾_奥迪检查项_日常检车项"];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"首页试乘试驾_奥迪检查项_日常检车项"];
}
#pragma mark -
#pragma mark Collection view data source
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    //    [collectionView.collectionViewLayout invalidateLayout];
    return [_titleItems count]+1;  //items count
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [_items count]+1; //竖着是section
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        if (indexPath.row == 0)
        {
            //左侧第一个头
            //车的数据
            DriverCarCheckItemsNameCell *cell = (DriverCarCheckItemsNameCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"DriverCarCheckItemsNameCell" forIndexPath:indexPath];
            cell.backgroundColor = [UIColor whiteColor];
            cell.nameLabel.text = [NSString stringWithFormat:@"检查项目 %@",_dateSelectBtn.value];
            return cell;
        }
        else
        {
            //顶部头部（内容）
            DriverCarCheckItemsCell *cell = (DriverCarCheckItemsCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"DriverCarCheckItemsCell" forIndexPath:indexPath];
            cell.backgroundColor = [UIColor whiteColor];
            
            NSDictionary *dic =  [_items objectAtIndex:indexPath.row-1];
            cell.contentLabel.text = [dic objectForKey:@"vlicenseTag"];
            [cell.checkButton addTarget:self action:@selector(checkButtonTouched:) forControlEvents:UIControlEventTouchUpInside];
            cell.checkButton.selected = [self isSelectAll:[dic objectForKey:@"carItems"]];
            return cell;
        }
    }
    else
    {
        if (indexPath.row == 0)
        {
            //左侧头部其他
            DriverCarCheckItemsNameCell *cell = (DriverCarCheckItemsNameCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"DriverCarCheckItemsNameCell" forIndexPath:indexPath];
            cell.nameLabel.text = [[_titleItems allValues]objectAtIndex:indexPath.section-1];
            if (indexPath.section % 2 != 0) {
                cell.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:239/255.0 alpha:1];
            }
            else
            {
                cell.backgroundColor =[UIColor whiteColor];
                
            }
            return cell;
        }
        
        else
        {
            //内容cell
            DriverCarCheckItemsCell *cell = (DriverCarCheckItemsCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"DriverCarCheckItemsCell" forIndexPath:indexPath];
            NSDictionary *dic = [_items objectAtIndex:indexPath.row-1];
            cell.contentLabel.text = @"通过";
            [cell.checkButton addTarget:self action:@selector(checkButtonTouched:) forControlEvents:UIControlEventTouchUpInside];
            
            NSDictionary *itemValues = [dic objectForKey:@"carItems"];
            NSString *keyStr = [[_titleItems allKeys]objectAtIndex:indexPath.section-1];
            cell.checkButton.selected = [[itemValues objectForKey:keyStr] boolValue];
            
            if (indexPath.section % 2 != 0) {
                cell.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:239/255.0 alpha:1];
            }
            else
            {
                cell.backgroundColor =[UIColor whiteColor];
            }
            return cell;
        }
    }
}
//查找是否已经全选
-(BOOL)isSelectAll:(NSDictionary *)dic{
    __block int trueArrcount = 0;
    [[dic allValues]enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isEqualToString:@"1"]) {
            trueArrcount = trueArrcount+1;
        }
    }];
    if ([dic allValues].count == trueArrcount) {
        return YES;
    }else{
        return NO;
    }
}
-(void)checkButtonTouched:(UIButton*)sender{
    sender.selected = !sender.selected;
    NSIndexPath *indexPath = [self findIndexPath:sender];
    //全选
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            return;
        }
        NSMutableDictionary *mudic = [[_items objectAtIndex:indexPath.row-1] mutableCopy];
        NSMutableDictionary *tempDic = [[NSMutableDictionary alloc]init];
        if (![self isSelectAll:[mudic objectForKey:@"carItems"]]) {
            [[_titleItems allKeys] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [tempDic setObject:@"1" forKey:obj];
            }];
        }else{
            [[_titleItems allKeys] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [tempDic setObject:@"0" forKey:obj];
            }];
        }
         [mudic setObject:tempDic forKey:@"carItems"];
         [_items replaceObjectAtIndex:indexPath.row-1 withObject:mudic];
        [self.collectionVview reloadData];
    }else{
        if (indexPath.row == 0) {
            return;
        }
        //单个选中
        NSMutableDictionary *mudic = [[_items objectAtIndex:indexPath.row-1] mutableCopy];
        NSMutableDictionary *item = [mudic objectForKey:@"carItems"];
        NSString *key = [[_titleItems allKeys]objectAtIndex:indexPath.section-1];
        NSString *value = [item objectForKey:key];
        if ([value isEqualToString:@"1"]) {
             [item setObject:@"0" forKey:key];
            
        }else{
            [item setObject:@"1" forKey:key];
        }
        [mudic setObject:item forKey:@"carItems"];
        [_items replaceObjectAtIndex:indexPath.row-1 withObject:mudic];
        [self.collectionVview reloadData];
    }
    
}
-(NSIndexPath*)findIndexPath:(UIView *)view{
    UIView *temp = view.superview;
    while (![temp isKindOfClass:[UICollectionViewCell class]]) {
        temp = temp.superview;
    }
    UICollectionViewCell *cell = (UICollectionViewCell*)temp;
    NSIndexPath *indexPath =  [self.collectionVview  indexPathForCell:cell];
    return indexPath;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}

#define COLLECTION_SPACE 260
#define COLLECTION_COUNT 5
#define COLLECTION_CELL_HEGIHT 40
- (CGSize)jk_collectionView:(UICollectionView *)collectionView layout:(JKCollectionViewExcelLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row == 0){
        return CGSizeMake(COLLECTION_SPACE, COLLECTION_CELL_HEGIHT);
    }else{
        CGFloat width = (collectionView.bounds.size.width - COLLECTION_SPACE) / COLLECTION_COUNT;
        return CGSizeMake(width, COLLECTION_CELL_HEGIHT);
    }
    
}
#pragma mark Actions
- (IBAction)dateSelectedAction:(id)sender {
    PopoverDateController *dateController =  [self showDatePickerController:sender completion:nil];
    dateController.datePickerMode = UIDatePickerModeDate;
}
-(PopoverDateController*)showDatePickerController:(SelectButton*)sender  completion:(void (^)(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString))completion{
    
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        
        //当completion block 不为nil的时候 需要手动赋值
        if (completion) {
            completion(date,dateYMDString,timeStamp,timeStampString);
        }else
        {
            if (datePicker.datePickerMode == UIDatePickerModeDateAndTime) {
                sender.value =[DateManager date_YMDHM_WithTimeIntervalSince1970:timeStamp];
                sender.key =timeStampString;
            }else{
                sender.value =dateYMDString;
                sender.key =timeStampString;
            }
        }
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
    return datePicker;
    
}
- (IBAction)search:(id)sender {
    if (_dateSelectBtn.value == nil) {
        [JKAlert showMessage:@"请输入查询日期"];
        return;
    }
    [DriverCarDailyItems getItemDatalist:_dateSelectBtn.value Success:^(NSArray *collection, id responseObject) {
        _items = [[NSMutableArray alloc]init];
        _items = (NSMutableArray *)collection;
        [_collectionVview reloadData];
    } Failure:^(NSError *error) {
        [self getLocalData];
    }];
}
- (IBAction)saveandupload:(id)sender {
    if(![_dateSelectBtn.value isEqualToString:[DateManager nowYMDString]]){
         [JKAlert showMessage:@"非当前日期不可保存"];
        return;
    }
    
  
    NSLog(@"%@",_items);
   
    NSMutableArray *paramArr = [[NSMutableArray alloc]init];
    [_items enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        NSMutableDictionary *itemDic = [[NSMutableDictionary alloc]init];
        NSMutableDictionary *carItemDic = [obj objectForKey:@"carItems"];
     
        [carItemDic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            if ([obj boolValue]) {
                 [carItemDic setObject:@"true" forKey:key];
            }else{
                  [carItemDic setObject:@"false" forKey:key];
            }
        }];
        [itemDic addEntriesFromDictionary:carItemDic];
        [itemDic setObject:[obj objectForKey:@"vlicenseTag"] forKey:@"vlicenseTag"];
        [itemDic setObject:_dateSelectBtn.value forKey:@"dcreate"];
        [paramArr addObject:itemDic];
    }];
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setObject:paramArr forKey:@"checkinfo"];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [DriverCarDailyItems uploadItemDatalist:param Success:^(NSArray *collection, id responseObject) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if( [responseObject hasKey:@"result"]){
             if( [[responseObject objectForKey:@"result"]boolValue]){
                 //上传成功，查看本地是否有数据，有则删除
                 [JKAlert showMessage:@"上传成功"];
                 [self deleteLocalData];
             }else{
                 [self saveLoclData];
             }
        }
        
    } Failure:^(NSError *error) {
         [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
         [self saveLoclData];
    }];
}
-(void)saveLoclData{
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *fileName = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist",_dateSelectBtn.value]];
    [_items writeToFile:fileName atomically:YES];
    [JKAlert showMessage:@"上传失败，为您保存到本地"];
}
//获取本地数据
-(void)getLocalData
{
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *fileName = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist",_dateSelectBtn.value]];
    if ([[FileManager sharedManager]fileExistsAtPath:fileName]) {
        _items = (NSMutableArray *)[NSArray arrayWithContentsOfFile:fileName];
        [_collectionVview reloadData];
    }else
    {
        [JKAlert showMessage:@"暂无此日期缓存数据"];
    }
   
}
//删除本地数据
-(void)deleteLocalData{
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *fileName = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist",_dateSelectBtn.value]];
    if ([[FileManager sharedManager]fileExistsAtPath:fileName]) {
        [[FileManager sharedManager] removeFileAtPath:fileName];
    }
}
@end
