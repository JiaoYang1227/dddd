//
//  DriverCarCheckItemsNameCell.m
//  DSPA2015
//
//  Created by Cluy on 2018/1/12.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DriverCarCheckItemsNameCell.h"

@implementation DriverCarCheckItemsNameCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
