//
//  CustomCollectionViewLayout.h
//  Brightec
//
//  Created by JOSE MARTINEZ on 03/09/2014.
//  Copyright (c) 2014 Brightec. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JKCollectionViewExcelLayout;

@protocol JKCollectionViewExcelLayoutDelegate <NSObject>
@optional
- (CGSize)jk_collectionView:(UICollectionView *)collectionView layout:(JKCollectionViewExcelLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath;


@end

@interface JKCollectionViewExcelLayout : UICollectionViewLayout
@property (nonatomic, weak) id <JKCollectionViewExcelLayoutDelegate> delegate;
@end
