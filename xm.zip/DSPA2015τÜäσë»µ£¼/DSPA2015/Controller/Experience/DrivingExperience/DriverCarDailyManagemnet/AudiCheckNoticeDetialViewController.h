//
//  AudiCheckNoticeDetialViewController.h
//  DSPA2015
//
//  Created by Cluy on 2018/2/23.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseSearchViewController.h"
@interface AudiCheckNoticeDetialViewController : BaseSearchViewController
@property (weak, nonatomic) IBOutlet UITextView *context;
@property (strong, nonatomic)NSString *checkContent;
@end
