//
//  DriverCarDailyManagemnetViewController.h
//  DSPA2015
//
//  Created by Cluy on 2018/1/8.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "DriverCarCheckItemsViewController.h"
#import "DriverCarPicturesViewController.h"
#import "UIViewController+DSPAPopup.h"
@interface DriverCarDailyManagemnetViewController : BaseViewController
@property (strong, nonatomic) DriverCarCheckItemsViewController *checkViewContrl;
@property (strong, nonatomic) DriverCarPicturesViewController *pictureViewContrl;
@property (strong, nonatomic)UIViewController *currentViewController;
@property (weak, nonatomic) IBOutlet UIView *contentView;

@property (weak, nonatomic) IBOutlet UIButton *picturesBtn;
@property (weak, nonatomic) IBOutlet UIButton *checkItemsButton;
//奥迪检查像通知
@property (weak, nonatomic) IBOutlet UIButton *checkBtn;
//奥迪检车数据
@property(strong,nonatomic)NSDictionary *checkDic;

@end
