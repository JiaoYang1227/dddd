//
//  DriverCarPicturesViewController.m
//  DSPA2015
//
//  Created by Cluy on 2018/1/8.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "DriverCarPicturesViewController.h"
#import "DriverCarPictureInfoCell.h"
#import "DriverCarPictureEditViewController.h"
#import "FileManager.h"
#import "UIImage+SuperCompress.h"
#import "UploadManager.h"
#import "AppDelegate.h"
#import "UIImageView+WebCache.h"
#define CELL_INDENTIFIER @"DriverCarPictureInfoCell"

@interface DriverCarPicturesViewController ()

@end

@implementation DriverCarPicturesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UINib *nib = [UINib nibWithNibName:CELL_INDENTIFIER bundle:nil];
    [self.listTable registerNib:nib forCellReuseIdentifier:CELL_INDENTIFIER];
    [self loadData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"首页试乘试驾_奥迪检查项_照片检车项"];
    if(_pictureSelectdItem !=nil){
        [self initView:_pictureSelectdItem];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"首页试乘试驾_奥迪检查项_照片检车项"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)initView:(DriverCarDailyManagemnet *)item{
    _head.image = nil;
    _headRight45.image= nil;
    _leftHead45.image= nil;
    _tail.image= nil;
    _rightTail45.image= nil;
    _leftTail45.image= nil;
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [NSString stringWithFormat:@"%@/DriverCarDaily/%@",documentUrl,item.carid];
    //正车头
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/frontpicture.png",filePath]]) {
        _head.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/frontpicture.png",filePath]];
    }else{
        _head.image = [UIImage imageNamed:@"CarDaily_head_picture"];
    }
    //正右侧
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/rightfrontpicture.png",filePath]]) {
        _headRight45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/rightfrontpicture.png",filePath]];
    }
    else{
        _headRight45.image = [UIImage imageNamed:@"CarDaily_rightfront_picture"];

    }
    //中控区域
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/leftfrontpicture.png",filePath]]) {
        _leftHead45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/leftfrontpicture.png",filePath]];
    }else{
         _leftHead45.image = [UIImage imageNamed:@"CarDaily_leftfront_picture"];
    }
    //正后
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/rearpicture.png",filePath]]) {
        _tail.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/rearpicture.png",filePath]];
    }else{
         _tail.image = [UIImage imageNamed:@"CarDaily_tail_picture"];
    }
    //正左侧
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/rightrearpicture.png",filePath]]) {
        _rightTail45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/rightrearpicture.png",filePath]];
    }else{
         _rightTail45.image = [UIImage imageNamed:@"CarDaily_rightrear_picture"];
    }
    //后排座椅
    if ([[FileManager sharedManager]fileExistsAtPath:[NSString stringWithFormat:@"%@/leftrearpicture.png",filePath]]) {
        _leftTail45.image = [UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/leftrearpicture.png",filePath]];
    }else{
          _leftTail45.image = [UIImage imageNamed:@"CarDaily_leftrear_picture"];
    }
    //车辆信息
    self.carmodel.text = item.vsaleTypeName;
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"drivingCarBrand" ofType:@"plist"];
    NSMutableDictionary *ccpDic = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    self.carImg.image = [UIImage imageNamed:[ccpDic stringForKey:item.series?:@""]];
    self.carStateLable.layer.cornerRadius = 2.0;
    if ([item.carStatus isEqualToString:@"空闲"]) {
        [self.carStateLable setBackgroundColor:[UIColor colorWithWholeRed:21 green:171 blue:56]];
    }
    if ([item.carStatus isEqualToString:@"占用"]) {
        [self.carStateLable setBackgroundColor: [UIColor colorWithWholeRed:171 green:21 blue:43]];
    }
    if ([item.carStatus isEqualToString:@"预约中"]) {
        [self.carStateLable setBackgroundColor:[UIColor yellowColor]];
    }
    _plateLabel.text = item.vlicenseTag;
    self.carStateLable.text =item.carStatus;
}
-(void)loadData{
    _listArr = [[NSArray alloc]init];
    [DriverCarDailyManagemnet getDailylistSuccess:^(NSArray *collection, id responseObject) {
        _listArr = collection;
        if ([_listArr count]>0) {
            //todo 存缓存数据
            [DriverCarDailyManagemnet createDailyCarInfoTable:_listArr];
            //todo  存储图片
//            [_listArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//                [DriverCarDailyManagemnet saveImgs:obj];
//            }];
            [_listTable reloadData];
            [_listTable selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionNone];
            DriverCarDailyManagemnet *item = [_listArr objectAtIndex:0];
            [self initView:item];
        }
        
    } Failure:^(NSError *error) {
        //todo 取缓存数据
        _listArr = [DriverCarDailyManagemnet getDailyLocallist];
        if ([_listArr count]>0) {
            [_listTable reloadData];
            [_listTable selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionNone];
            DriverCarDailyManagemnet *item = [_listArr objectAtIndex:0];
            [self initView:item];
        }
    }];
}
#pragma mark TableView Delegate&DataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_listArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DriverCarPictureInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_INDENTIFIER forIndexPath:indexPath];
    cell.actionDelegate = self;
    DriverCarDailyManagemnet *item = [_listArr objectAtIndex:indexPath.row];
    if (indexPath.row % 2 != 0) {
        cell.backgroundColor = [UIColor colorWithRed:239/255.0 green:239/255.0 blue:239/255.0 alpha:1];
    }
    else
    {
        cell.backgroundColor =[UIColor whiteColor];
    }
    [cell congfigCell:item withIndex:indexPath.row];
     
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DriverCarDailyManagemnet *item = [_listArr objectAtIndex:indexPath.row];
    [self initView:item];
   
}

#pragma mark pictureActionDelegate
-(void)editPictures:(int)indexValue{
    _pictureSelectdItem = [_listArr objectAtIndex:indexValue];
    DriverCarPictureEditViewController *viewControl = [[DriverCarPictureEditViewController alloc]init];
    viewControl.item = _pictureSelectdItem;
    [self.navigationController pushViewController:viewControl animated:YES];
}
-(void)uploadPictures:(int)indexValue{
    NSLog(@"index = %d",indexValue);
    [_listTable selectRowAtIndexPath:[NSIndexPath indexPathForRow:indexValue inSection:0] animated:YES scrollPosition:UITableViewScrollPositionNone];
    
    //todo 读取本地数据文件看有多少
    DriverCarDailyManagemnet *item = [_listArr objectAtIndex:indexValue];
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [NSString stringWithFormat:@"%@/DriverCarDaily/%@",documentUrl,item.carid];
    NSMutableArray *imgArr = (NSMutableArray
                              *)[[FileManager sharedManager]filesAtDirectoryPath:filePath error:nil];
    if ([imgArr count]<6) {
        [JKAlert showMessage:@"满足6张照片才可上传"];
        return;
    }
    [self uploadImg:0 withArr:imgArr withItem:indexValue];
}
-(void)uploadImg:(int)intValue withArr:(NSMutableArray *)items withItem:(int)indexValue{
    if (items.count == 0) {
        return;
    }
     DriverCarDailyManagemnet *item = [_listArr objectAtIndex:indexValue];
    NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [NSString stringWithFormat:@"%@/DriverCarDaily/%@",documentUrl,item.carid];
    NSString *value = [items objectAtIndex:intValue];
    NSData *documentData = [UIImage compressImage:[UIImage imageWithFileURL:[NSString stringWithFormat:@"%@/%@",filePath,value]]
                                      toMaxLength:512*1024*8 maxWidth:1024];
    if (!documentData) {
        [JKAlert showMessage:@"图片压缩失败!"];
        return;
    }
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
   
    [dic setValue:item.carid forKey:@"carid"];
    NSString *valueTemp = [value stringByReplacingOccurrencesOfString:@".png" withString:@""];
    [dic setValue:valueTemp forKey:@"imgCode"];
    [dic setValue:item.vlicenseTag forKey:@"carplate"];
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    DriverCarPictureInfoCell *cell = [_listTable cellForRowAtIndexPath:[NSIndexPath indexPathForRow:indexValue inSection:0]];
    [UploadManager imageUploadOne:[NSString stringWithFormat:@"%@%@",baseInterface,INTERFACE_DAILY_UPLOAD]
                       withParameters:dic
                        withImageData:documentData
                         withFileName:@"file"
                        uploadSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                        if ([[responseObject objectForKey:@"success"] intValue]==1) {
                            [items removeObjectAtIndex:0];
                            float progressValue = (6-[items count])/6.0;
                            if (progressValue >=1) {
                                progressValue = 1.0;
//                                //删除图片文件
//                                NSString *documentUrl = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
//                                NSString *filePath = [NSString stringWithFormat:@"%@/DriverCarDaily/%@",documentUrl,item.carid];
//                                [[FileManager sharedManager]removeFileAtPath:filePath];
                                //更新本地数据
                                item.updateOn = [DateManager nowTimeStampString];
                                item.statusUpload = @"成功";
                                item.progress = progressValue;
                                [cell congfigCell:item withIndex:indexValue];
                                [_listTable reloadRowsAtIndexPaths:[NSArray arrayWithObjects:[NSIndexPath indexPathForRow:indexValue inSection:0],nil] withRowAnimation:UITableViewRowAnimationNone];
                                if ( [DriverCarDailyManagemnet uploadDailyCarItem:item]) {
                                     [self initView:item];
                                }
                               
                            }else{
                                item.progress = progressValue;
                                [cell congfigCell:item withIndex:indexValue];
                                [_listTable reloadRowsAtIndexPaths:[NSArray arrayWithObjects:[NSIndexPath indexPathForRow:indexValue inSection:0],nil] withRowAnimation:UITableViewRowAnimationNone];
                                [self uploadImg:0 withArr:items withItem:indexValue];
                            }
                            
                        }else{
                            item.statusUpload = @"失败";
                            item.progress = 0;
                            [cell congfigCell:item withIndex:indexValue ];
                            [DriverCarDailyManagemnet uploadDailyCarItem:item];
                        }
                    } uploadError:^(AFHTTPRequestOperation *operation, NSError *error) {
                        item.statusUpload = @"失败";
                        item.progress = 0;
                        [cell congfigCell:item withIndex:indexValue ];
                        [DriverCarDailyManagemnet uploadDailyCarItem:item];
                       
                    }];
}

@end
