//
//  DrivingExperienceNewListViewController.m
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceNewListViewController.h"
#import "DrivingExperienceNewListViewCell.h"
#import "AddDrivingExperienceViewController.h"
#import "AlertDrivingViewController.h"
#import "UIViewController+DSPAPopup.h"

static NSString *CollectionCellIdentifier = @"DrivingExperienceNewListViewCell";

@interface DrivingExperienceNewListViewController ()

@property (weak, nonatomic) IBOutlet UITableView *drivingNewTableview;
@property (weak, nonatomic) IBOutlet UILabel *carUseInfo;


// Action

@property (weak, nonatomic) IBOutlet UIButton *leftButtonOutlet;
- (IBAction)leftButtonAction:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *rightButtonOutlet;
- (IBAction)rightButtonAction:(id)sender;


@end

@implementation DrivingExperienceNewListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSInteger count = self.drivingExperienceModel.time.count + self.drivingExperienceModel.yuyuetime.count;
    self.carUseInfo.text = [NSString stringWithFormat:@"%@%zd%@",@"此车已被",count,@"位客户预约"];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadData:) name:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if ([self.drivingExperienceModel.czt isEqualToString:@"01"]) {
        [self.leftButtonOutlet setTitle:@"预约" forState:UIControlStateNormal];
        [self.rightButtonOutlet setTitle:@"还车" forState:UIControlStateNormal];
        
    }else if(self.drivingExperienceModel.yuyuetime.count > 0){
        [self.leftButtonOutlet setTitle:@"预约" forState:UIControlStateNormal];
        [self.rightButtonOutlet setTitle:@"还车" forState:UIControlStateNormal];
    }else{
        
    }
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.drivingExperienceModel.yuyuetime.count + self.drivingExperienceModel.time.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView registerNib:[UINib nibWithNibName:@"DrivingExperienceNewListViewCell" bundle:nil] forCellReuseIdentifier:CollectionCellIdentifier];
    DrivingExperienceNewListViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CollectionCellIdentifier];
    [cell configData:self.drivingExperienceModel withIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    // 只有预约领车
    // 领车得需要是当前的销售顾问才可以进行操作
    DrivingYuYueTimerModel *dtmodel = [self.drivingExperienceModel.yuyuetime objectWithIndex:indexPath.row];
    if (![dtmodel.userID isEqualToString:[AppDelegate APP].user.userID]) {
        [JKAlert showMessage:[NSString stringWithFormat:@"请切换销售顾问为%@进行操作",dtmodel.salesConsultantName?:@"暂无"]];
        return;
    }
    
    
    AddDrivingExperienceViewController *add = [[AddDrivingExperienceViewController alloc] init];
    DrivingExperienceModel *dem = self.drivingExperienceModel;
    add.havedYuYue = YES;
    dem.driveTestID = dtmodel.driveTestID;
    add.model = dem;

    //czt为02的时候代表试驾车辆被占用
    if ([dem.czt isEqualToString:@"02"]) {
        //            [JKAlert showMessage:@"试驾车辆目前被占用！"];
        //            return;
        add.drivingCarUse = YES;
    }
    
    [self presentDSPAPopup:add parentViewController:self.parentViewController touchCallBack:^{
        
    } haveMask:YES includeNavgation:YES alignTop:NO];
}

-(void)reloadData:(NSNotification*)notifacation{
    [self dismissTouched:nil];
}

- (void)dismissTouched:(id)sender{
    [self dismissDSPAPopup:^{
        
    }];
}

// Action
- (IBAction)leftButtonAction:(id)sender {
    if (self.drivingExperienceModel.time.count > 0 || [self.drivingExperienceModel.czt isEqualToString:@"01"]) {
        if ([AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot && [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot) {
            AddDrivingExperienceViewController *add = [[AddDrivingExperienceViewController alloc] init];
            DrivingExperienceModel *dem = self.drivingExperienceModel;
            add.model = dem;
            
            //czt为02的时候代表试驾车辆被占用
            if ([dem.czt isEqualToString:@"02"]) {
                //            [JKAlert showMessage:@"试驾车辆目前被占用！"];
                //            return;
                add.drivingCarUse = YES;
            }
            
            [self presentDSPAPopup:add parentViewController:self.parentViewController touchCallBack:^{
                
            } haveMask:YES includeNavgation:YES alignTop:NO];
            
        }else{
            [JKAlert showMessage:@"请匹配客户或者线索"];
        }
    }
    
}


- (IBAction)rightButtonAction:(id)sender {
    if (self.drivingExperienceModel.time.count > 0) {
        //---------------------  试驾中 ---------------------------------------------------
        DrivingTimerModel *dtm = [self.drivingExperienceModel.time firstObject];
        // 领车得需要是当前的销售顾问才可以进行操作
        if (![dtm.userID isEqualToString:[AppDelegate APP].user.userID]) {
            [JKAlert showMessage:[NSString stringWithFormat:@"请切换销售顾问为%@进行操作",dtm.salesConsultantName?:@"暂无"]];
            return;
        }
        AlertDrivingViewController*advc = [[AlertDrivingViewController alloc] init];
        advc.drivingExperienceModel = self.drivingExperienceModel;
        [self presentDSPAPopup:advc parentViewController:self.parentViewController touchCallBack:^{
            
        } haveMask:YES includeNavgation:YES alignTop:NO];
        //---------------------  试驾中 ---------------------------------------------------
    }

}
@end
