//
//  DrivingExperienceNewViewController.m
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceNewViewController.h"
#import "DrivingNewCollectionViewCell.h"
#import "DrivingMapViewController.h"
#import "DrivingExperienceNewListViewController.h"
#import "AddDrivingExperienceViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "DateManager.h"
#import "DrivingExperienceViewController.h"

#import "DrivingExperienceModel.h"
#import "Calendar.h"

#import "DriverCarDailyManagemnetViewController.h"
#import "DrivingCarInfoViewController.h"

#import "DrivingGetCarViewController.h"
#import "DrivingFeedbackViewController.h"
#import "DrivingPopViewController.h"
#import "UIViewController+MJPopupViewController.h"

#define DRIVING_COLLECTIONVIEW_CELL_IDENTIFIER @"DrivingNewCollectionViewCell"

@interface DrivingExperienceNewViewController ()
{
    NSMutableDictionary *_ccpDic;
}
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end

@implementation DrivingExperienceNewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self.collectionView registerNib:[UINib nibWithNibName:DRIVING_COLLECTIONVIEW_CELL_IDENTIFIER bundle:nil] forCellWithReuseIdentifier:DRIVING_COLLECTIONVIEW_CELL_IDENTIFIER];
    
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"drivingCarBrand" ofType:@"plist"];
    _ccpDic = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadData:) name:@"reloadDrivingExperienceViewController" object:[NSNumber numberWithBool:YES]];
    
    //begin by owen 20160711 新增页面为主页
    // flag 0 代表试驾看板里车俩信息
    [self loadData:@{@"date":[DateManager stringConvert_YMD_FromDate:[NSDate date]] , @"flag":[NSNumber numberWithInt:0]}];
    [self getAudiCheckCount];
    
    
    
    // 增加特殊权限，默认销售经理有车辆日常检查   苏鹏
    if ([AppDelegate APP].user.role == UserRoleOnlyView) {
        _audiCheckBtn.hidden = NO;
    }else{
        _audiCheckBtn.hidden = YES;
    }
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [CBTracking startTracPage:@"首页试乘试驾"];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracPage:@"首页试乘试驾"];
}

-(void)getAudiCheckCount{
    //     获取奥迪检查通知
    [Calendar getAudiCheckCount:nil Success:^(NSDictionary *dictionary) {
        _audiCheckDic= dictionary;
        if (_audiCheckDic) {
            NSString *titleStr =@" 奥迪检车项 (1)" ;
            [_audiCheckBtn setTitle:titleStr  forState:UIControlStateNormal] ;
        }else{
            [_audiCheckBtn setTitle:@" 奥迪检车项 (0)" forState:UIControlStateNormal];

        }
    } Failure:^(NSError *error) {
        [_audiCheckBtn setTitle:@" 奥迪检车项 (0)" forState:UIControlStateNormal];
    }];
    
    
}

//end by owen

//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.drivingCarResult.count;
}
//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = DRIVING_COLLECTIONVIEW_CELL_IDENTIFIER;
    
    DrivingNewCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath :indexPath];
    DrivingExperienceModel *model = self.drivingCarResult[indexPath.row];
    model.ccpCarName = [_ccpDic stringForKey:model.ccp?:@""];
    [cell configData:model withIndexPath:indexPath];
    [cell.cellCarStateButtonOutlet addTarget:self action:@selector(carStateAction:) forControlEvents:UIControlEventTouchDown];
    cell.cellCarStateButtonOutlet.tag = indexPath.row;
    return cell;
}
//定义每个UICollectionView 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(300, 195);
}
//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(0, 0, 2, 0);
}


- (void)carStateAction:(UIButton *)sender{
    [CBTracking trackEvent:@"车辆状态查看"];
    DrivingExperienceModel *model = self.drivingCarResult[sender.tag];
    DrivingCarInfoViewController *carInfo = [DrivingCarInfoViewController new];
    carInfo.drivingExperienceModel = model;
    [self.navigationController pushViewController:carInfo animated:YES];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    // 无未识别出角色  前台不允许领车操作
    if ([AppDelegate APP].user.role == UserRoleReceptionist || [AppDelegate APP].user.role == UserRoleUnrecognized) {
        
        [JKAlert showMessage:@"您的权限不足，暂时无法领车操作"];
        return;
    }
    
    
    DrivingExperienceModel *model = self.drivingCarResult[indexPath.row];
    DrivingPopViewController *pop = [[DrivingPopViewController alloc] init];
    pop.drivingExperienceModel = model;
    [self presentDSPAPopup:pop parentViewController:self touchCallBack:^{

    } haveMask:YES includeNavgation:YES alignTop:NO];
    
    
    // 01 试驾中
    // 02 取消试驾
    // 03 试驾结束
    // 04 预约试驾
    
    // czt 01 空闲
    // czt 02 占用
    
    
//    DrivingExperienceModel *model = self.drivingCarResult[indexPath.row];
//    if ([model.czt isEqualToString:@"01"] && model.yuyuetime.count == 0 && model.time.count == 0) {
//        if ([AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot && [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot) {
//
//            AddDrivingExperienceViewController *add = [[AddDrivingExperienceViewController alloc] init];
//            DrivingExperienceModel *dem = model;
//            add.model = dem;
//
//            //czt为0的时候代表试驾车辆被占用
//            if (![dem.czt isEqualToString:@"01"]) {
//                //            [JKAlert showMessage:@"试驾车辆目前被占用！"];
//                //            return;
//                add.drivingCarUse = YES;
//            }
//
//            [self presentDSPAPopup:add parentViewController:self touchCallBack:^{
//
//            } haveMask:YES includeNavgation:YES alignTop:NO];
//
//        }else{
//            [JKAlert showMessage:@"请匹配客户或者线索"];
//        }
//
//    }else{
//        DrivingExperienceNewListViewController *drivingList = [[DrivingExperienceNewListViewController alloc] init];
//        drivingList.drivingExperienceModel = model;
//
//        [self presentDSPAPopup:drivingList parentViewController:self touchCallBack:^{
//
//        } haveMask:YES includeNavgation:YES alignTop:NO];
//    }
//
    
    

}

-(void)reloadData:(NSNotification*)notifacation{
    [self loadData:@{@"date":[DateManager stringConvert_YMD_FromDate:[NSDate date]] , @"flag":[NSNumber numberWithInt:0]}];
}

/**
 *   load data
 */
- (void)loadData:(NSDictionary *)parmDic{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [DrivingExperienceModel fetchDrivingExperienceList:parmDic Success:^(NSArray *headList, id responseObject) {
        
        if (headList.count > 0) {
            self.drivingCarResult = [[NSMutableArray alloc] initWithArray:headList];
            [self.collectionView reloadData];
        }
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

- (IBAction)pushNewDrivingExperienceViewController:(id)sender {
    
    DrivingExperienceViewController *drivingCat = [[DrivingExperienceViewController alloc] init];
    [self.navigationController pushViewController:drivingCat animated:YES];
}

#pragma mark 
/**
 *  获取试驾路线图
 */
- (IBAction)getDrivingMapAction:(id)sender {
    
    [self presentDSPAPopup:[[DrivingMapViewController alloc] init] parentViewController:self touchCallBack:^{
        
    } haveMask:YES includeNavgation:YES alignTop:NO];
}


- (void)dismissTouched:(id)sender{
    [self dismissDSPAPopup:^{
        
    }];
}

/**
 *  试驾车辆日常管理
 */
- (IBAction)getDailyManagement:(id)sender {
    [CBTracking trackEvent:@"首页试乘试驾_奥迪检查项"];
    DriverCarDailyManagemnetViewController *dailyManagementVC = [[DriverCarDailyManagemnetViewController alloc]init];
    dailyManagementVC.checkDic = _audiCheckDic;
    [self.navigationController pushViewController:dailyManagementVC animated:YES];
}

@end
