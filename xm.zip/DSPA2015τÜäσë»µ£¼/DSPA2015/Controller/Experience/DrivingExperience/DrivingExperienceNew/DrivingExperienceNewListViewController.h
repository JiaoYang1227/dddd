//
//  DrivingExperienceNewListViewController.h
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceBaseViewController.h"
#import "DrivingExperienceModel.h"

@interface DrivingExperienceNewListViewController : DrivingExperienceBaseViewController

@property (nonatomic , strong) DrivingExperienceModel *drivingExperienceModel;

@end
