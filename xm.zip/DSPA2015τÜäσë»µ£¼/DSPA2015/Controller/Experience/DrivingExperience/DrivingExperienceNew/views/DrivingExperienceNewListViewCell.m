//
//  DrivingExperienceNewListViewCell.m
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceNewListViewCell.h"
#import "DrivingTimerModel.h"
#import "DrivingYuYueTimerModel.h"

@implementation DrivingExperienceNewListViewCell

//- (void)awakeFromNib {
//    // Initialization code
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}







- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row % 2) {
        self.cellViewBG.backgroundColor = [UIColor colorWithRed:249./255 green:249./255 blue:249./255 alpha:1];
    }else{
        self.cellViewBG.backgroundColor = [UIColor colorWithRed:243./255 green:243./255 blue:243./255 alpha:1];
    }
    
    self.cellIndex.text = [NSString stringWithFormat:@"%zd",indexPath.row];
    
    // czt == 02 试驾车辆被占用   01 空闲
    if ([model.czt isEqualToString:@"02"]) {
        self.cellActionImg.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_getcar_no"];
    }else{
        self.cellActionImg.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_getcar_yes"];
    }
    
    
    //预约
    if (indexPath.row < model.yuyuetime.count && model.yuyuetime.count > 0) {
        DrivingYuYueTimerModel *yuyueModel = [model.yuyuetime objectWithIndex:indexPath.row];
        self.cellTimer.text = [DateManager stringConvert_YMDHM_FromDate:[DateManager dateWithTimeStamp:yuyueModel.tryoutstartdate]];//预约时间
        self.cellConsultant.text = yuyueModel.salesConsultantName;     //所属销售顾问
        self.cellCustomerName.text = yuyueModel.customername?:@"";   //客户姓名
        return;
    }
    
    if (model.time.count > 0) {
        NSInteger index = 0;
        if (model.yuyuetime.count == 0) {
            index = indexPath.row;
        }
        
        
        if (model.yuyuetime.count > 0) {
           index = indexPath.row - model.yuyuetime.count;
        }
        
        DrivingTimerModel *timetModel = [model.time objectWithIndex:index];
        self.cellTimer.text = [DateManager stringConvert_YMDHM_FromDate:[DateManager dateWithTimeStamp:timetModel.begintime]];//预约时间
        self.cellConsultant.text = timetModel.salesConsultantName;     //所属销售顾问
        self.cellCustomerName.text = timetModel.customername?:@"";   //客户姓名
    }


}



@end
