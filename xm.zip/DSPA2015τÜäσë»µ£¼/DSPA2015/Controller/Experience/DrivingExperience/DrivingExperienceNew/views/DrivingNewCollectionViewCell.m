//
//  DrivingNewCollectionViewCell.m
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "DrivingNewCollectionViewCell.h"

@implementation DrivingNewCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}


- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath{
    self.carmodel.text = model.carbrand;                    //车辆信息
    self.driveLicensePlate.text = model.driveLicensePlate;  //车牌号
    
    self.carModelImg.image = [UIImage imageNamed:model.ccpCarName];   //车辆图片
//    NSLog(@"model.ccpCarName%@",model.ccpCarName);
    
    
    // 01 试驾中
    // 02 取消试驾
    // 03 试驾结束
    // 04 预约试驾
    
//    if ([model.czt isEqualToString:@"01"]) {
//        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_no"];
//    }else if([model.czt isEqualToString:@"02"]){
//        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_yue"];
//    }else if(model.yuyuetime.count > 0){
//        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_yue"];
//    }else if(![model.czt isEqualToString:@"01"] && model.yuyuetime.count == 0 && model.time.count == 0){
//        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_yes"];
//    }else if (![model.czt isEqualToString:@"01"] && model.yuyuetime.count == 0 && model.time.count > 0){
//        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_yes"];
//    }
    
    
    // czt 01 空闲
    // czt 02 占用
    self.carStateLable.layer.cornerRadius = 2.;
    
//    if ([model.czt isEqualToString:@"02"]) {
////        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_no"];
//        self.carStateLable.text = @"试驾中";
//        self.carStateLable.backgroundColor = [UIColor colorWithWholeRed:171 green:21 blue:43];
//    }else if([model.czt isEqualToString:@"02"]){
////        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_no"];
//        self.carStateLable.text = @"试驾中";
//        self.carStateLable.backgroundColor = [UIColor colorWithWholeRed:171 green:21 blue:43];
//    }else if([model.czt isEqualToString:@"01"] && model.yuyuetime.count == 0 && model.time.count == 0){
////        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_yes"];
//        self.carStateLable.text = @"空闲";
//        self.carStateLable.backgroundColor = [UIColor colorWithWholeRed:21 green:171 blue:56];
//    }else if ([model.czt isEqualToString:@"01"] && model.yuyuetime.count == 0 && model.time.count > 0){
////        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_yes"];
//        self.carStateLable.text = @"空闲";
//        self.carStateLable.backgroundColor = [UIColor colorWithWholeRed:21 green:171 blue:56];
//    }else if ([model.czt isEqualToString:@"01"] && model.yuyuetime.count > 0){
////        self.catState.image = [UIImage imageNamed:@"DrivingExperienceNew_cell_state_yue"];
//        self.carStateLable.text = @"预约中";
//        self.carStateLable.backgroundColor = [UIColor yellowColor];
//    }
    
    
    if ([model.czt isEqualToString:@"02"]) {
            self.carStateLable.text = @"试驾中";
            self.carStateLable.backgroundColor = [UIColor colorWithWholeRed:171 green:21 blue:43];
    }else if([model.yyFlag isEqualToString:@"1"]){
            self.carStateLable.text = @"预约中";
            self.carStateLable.backgroundColor = [UIColor colorWithWholeRed:200 green:174 blue:0];
    }else{
        self.carStateLable.text = @"空闲";
        self.carStateLable.backgroundColor = [UIColor colorWithWholeRed:21 green:171 blue:56];
    }
    
}

@end
