//
//  DrivingExperienceNewListViewCell.h
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrivingExperienceModel.h"

@interface DrivingExperienceNewListViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *cellIndex;          //
@property (weak, nonatomic) IBOutlet UILabel *cellTimer;          //预约时间
@property (weak, nonatomic) IBOutlet UILabel *cellConsultant;     //所属销售顾问
@property (weak, nonatomic) IBOutlet UILabel *cellCustomerName;   //客户姓名

@property (weak, nonatomic) IBOutlet UIImageView *cellActionImg;

@property (weak, nonatomic) IBOutlet UIView *cellViewBG;


- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath;


@end
