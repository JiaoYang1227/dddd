//
//  DrivingNewCollectionViewCell.h
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrivingExperienceModel.h"

@interface DrivingNewCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *carmodel;          //车辆信息
@property (weak, nonatomic) IBOutlet UILabel *driveLicensePlate; //车牌号
@property (weak, nonatomic) IBOutlet UIImageView *carModelImg;   //车辆图片

@property (weak, nonatomic) IBOutlet UIImageView *catState;  //车辆状态

@property (weak, nonatomic) IBOutlet UILabel *carStateLable;


@property (weak, nonatomic) IBOutlet UIButton *cellCarStateButtonOutlet;



- (void)configData:(DrivingExperienceModel *)model withIndexPath:(NSIndexPath *)indexPath;

@end
