//
//  DrivingExperienceNewViewController.h
//  DSPA2015
//
//  Created by runlin on 16/6/27.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "DrivingExperienceBaseViewController.h"

@interface DrivingExperienceNewViewController : DrivingExperienceBaseViewController

@property(strong,nonatomic)  UIView *coverView;


@property (nonatomic , strong) NSMutableArray *drivingCarResult;//试驾车辆

@property (weak, nonatomic) IBOutlet UIButton *audiCheckBtn;
@property (nonatomic,strong)NSDictionary *audiCheckDic;
@end
