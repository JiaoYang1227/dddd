//
//  PrintDetailViewController.h
//  DSPA2015
//
//  Created by runlin on 16/7/16.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface PrintDetailViewController : BaseViewController<UIWebViewDelegate>
{
    UIActionSheet *printSheet;
}
@property (strong, nonatomic) NSURLRequest *myRequset;

@property (weak, nonatomic) IBOutlet UIWebView *myWebView;
@property (weak, nonatomic) IBOutlet UIButton *showButton;
@end
