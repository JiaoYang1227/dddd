//
//  PrintDetailViewController.m
//  DSPA2015
//
//  Created by runlin on 16/7/16.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "PrintDetailViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "RecipePrintPageRenderer.h"
@interface PrintDetailViewController ()

@end

@implementation PrintDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self.myWebView loadRequest:_myRequset];

}
-(void)setMyRequset:(NSURLRequest *)myRequset{
    _myRequset = myRequset;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
//    NSString *requestString = [[[request URL]  absoluteString] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding ];
   
    return YES;
}
-(void)backButtonTouched:(id)sender{
    [self dismissDSPAPopup:^{
        
    }];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self print];
}
//打印
- (void)print{
    
    //  解决 弹出窗太大问题
    self.modalPresentationStyle = UIModalPresentationFormSheet;
    //调整箭头方向
    [printSheet showFromRect:[self.view convertRect:self.showButton.frame fromView:self.showButton.superview] inView:self.view animated:YES];
//    NSLog(@"%@",NSStringFromCGRect(self.printBtn.frame));
    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
    
    if(!controller){
        NSLog(@"Couldn't get shared UIPrintInteractionController!");
        return;
    }
    UIPrintInteractionCompletionHandler completionHandler =
    ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
        if(!completed && error){
            NSLog(@"FAILED! due to error in domain %@ with error code %zd", error.domain, error.code);
        }
    };
    



    [controller presentFromRect:[self.view convertRect:self.showButton.frame fromView:self.showButton.superview] inView:self.view animated:YES completionHandler:completionHandler];
    
    
    
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    printInfo.outputType = UIPrintInfoOutputGeneral;
    printInfo.duplex = UIPrintInfoDuplexLongEdge;
    controller.printInfo = printInfo;
    controller.showsPageRange = YES;
    UIViewPrintFormatter *viewFormatter = [self.myWebView viewPrintFormatter];
    RecipePrintPageRenderer * PrintPageRenderer= [[RecipePrintPageRenderer alloc] initWithPrintFormatter:viewFormatter];
    controller.printPageRenderer = PrintPageRenderer;
    [controller presentFromRect:[self.view convertRect:self.showButton.frame fromView:self.showButton.superview] inView:self.view animated:YES completionHandler:completionHandler];
    
}
@end
