//
//  MemberCenterViewController.m
//  DSPA2015
//
//  Created by sun on 2017/8/7.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "MemberCenterViewController.h"
#import "MembershipViewController.h"
#import "MemberQueryListViewController.h"
@interface MemberCenterViewController ()

@end

@implementation MemberCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)membershipTouched:(id)sender {
     [self.navigationController pushViewController:[[MembershipViewController alloc]init] animated:YES];
}
- (IBAction)MemberQueryTouched:(id)sender {
    [self.navigationController pushViewController:[[MemberQueryListViewController alloc]init] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
