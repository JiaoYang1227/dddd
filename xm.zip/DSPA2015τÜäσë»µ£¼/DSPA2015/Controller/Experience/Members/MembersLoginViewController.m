//
//  MembersLoginViewController.m
//  DSPA2015
//
//  Created by sun on 2017/8/7.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "MembersLoginViewController.h"
#import "MemberCenterViewController.h"
#import "Membership.h"
@interface MembersLoginViewController (){
    
    __weak IBOutlet BorderTextField *_passwordTF;
    __weak IBOutlet BorderTextField *_usernameTF;
    __weak IBOutlet UIButton *_isRememberBTN;
}

@end

@implementation MembersLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_usernameTF setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_passwordTF setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
     _usernameTF.layer.borderColor = [[UIColor clearColor] CGColor];
    _passwordTF.layer.borderColor = [[UIColor clearColor] CGColor];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"membersUserName"]) {
        _usernameTF.text = [defaults objectForKey:@"membersUserName"];
    }
    if ([defaults objectForKey:@"membersPassword"]) {
        _passwordTF.text = [defaults objectForKey:@"membersPassword"];
    }
    
    
    if ([defaults objectForKey:@"membersPassword"]) {
        _isRememberBTN.selected = YES;
    }else{
        _isRememberBTN.selected = NO;
    }
    
}
- (IBAction)loginTouched:(id)sender {
    if (_usernameTF.text.length==0) {
        return;
    }
    if (_passwordTF.text.length==0) {
        return;
    }
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:_usernameTF.text forKey:@"membersUserName"];
    if (_isRememberBTN.selected==YES) {
        [defaults setObject:_passwordTF.text forKey:@"membersPassword"];
    }else{
        [defaults setObject:nil forKey:@"membersPassword"];
    }
    [APIManager reset];
    [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
    [Membership loginWithuserName:_usernameTF.text?:@"" password:_passwordTF.text?:@"" Success:^(BOOL isSuccess, id responseObject) {
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
        if (isSuccess) {
            [defaults setObject:[responseObject stringForKey:@"dealerid"] forKey:@"dealerid"];
            [self.navigationController pushViewController:[[MemberCenterViewController alloc]init] animated:YES];
        }else{
            [JKAlert showMessage:[responseObject stringForKey:@"massage"]];
        }
        
    } Failure:^(NSError *error) {
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    }];
    
}
- (IBAction)rememberTouched:(UIButton *)sender {
    sender.selected = !sender.selected;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
