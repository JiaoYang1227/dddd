//
//  MembersDetailViewController.m
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "MembersDetailViewController.h"
#import "MemberQuery.h"
#import "UIImageView+WebCache.h"
#import "CheckBoxView.h"
#import "KeychainManager.h"
@interface MembersDetailViewController (){
    __weak IBOutlet BorderTextField *_nameTF;//姓名
    __weak IBOutlet BorderTextField *_cardnumberTF;//身份证
    __weak IBOutlet SelectButton *_birthdaySBTN;//生日
    __weak IBOutlet SelectButton *_sexSBTN;
    __weak IBOutlet BorderTextField *_mobileTF;//手机号码
    __weak IBOutlet BorderTextField *_emailTF;//电子邮箱
    __weak IBOutlet BorderTextField *_addressTF;//地址
    __weak IBOutlet SelectButton *_jobSBTN;//行业
    __weak IBOutlet SelectButton *_positionSBTN;//职位
    __weak IBOutlet SelectButton *_educationSBTN;//教育程度

    __weak IBOutlet SelectButton *_ismarriageSBTN;
    __weak IBOutlet SelectButton *_marriedtimeSBTN;//结婚纪念日
    __weak IBOutlet SelectButton *_babybirthdaySBTN;//孩子生日
    __weak IBOutlet BorderTextField *_enlistchannelsTF;
    __weak IBOutlet CheckBoxView *_interestsCBV;//兴趣爱好
    
    __weak IBOutlet NSLayoutConstraint *_interestsChange;
    __weak IBOutlet CheckBoxView *_memberflagCBV;//会员标签
    __weak IBOutlet NSLayoutConstraint *_memberflagChange;
    
    __weak IBOutlet BorderTextField *_usercodeTF;//注册会员经销商
    __weak IBOutlet BorderTextField *_jointimeTF;//入会日期
    __weak IBOutlet UIImageView *_cardfileIMG;//身份证
    MemberQuery *_member;
    NSDictionary *_dicData;
}

@end

@implementation MembersDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [APIManager reset];
     [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
   [MemberQuery selectMemberMSG:self.cardnumber Success:^(BOOL isSuccess, id responseObject) {
       if (isSuccess) {
           _member = [[MemberQuery alloc]initWithDictionary:[responseObject dictionaryForKey:@"member"] error:nil];
           _dicData = [NSDictionary dictionaryWithDictionary:responseObject];
           [self loadData];
       }else{
           [JKAlert showMessage:[responseObject stringForKey:@"massage"]];
       }
       [APIManager reset];
       [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
   } Failure:^(NSError *error) {
       [APIManager reset];
       [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
   }];
}
-(void)loadData{
    if (_member) {
        _nameTF.text = _member.name;
        _cardnumberTF.text = _member.cardnumber;
        _birthdaySBTN.value = _member.birthday;
        _sexSBTN.value = _member.sex;
        _mobileTF.text = _member.mobile;
        _emailTF.text = _member.email;
        _addressTF.text = _member.address;
        _jobSBTN.value = _member.job;
        _positionSBTN.value = _member.position;
        _educationSBTN.value = _member.education;
        _ismarriageSBTN.value = _member.ismarriage;
        _marriedtimeSBTN.value = _member.marriedtime;
        _babybirthdaySBTN.value = _member.babybirthday;
        _enlistchannelsTF.text = _member.enlistchannels;
        _usercodeTF.text = _member.usercode;
        _jointimeTF.text = _member.jointime;
        [_cardfileIMG sd_setImageWithURL:[NSURL URLWithString:_member.filepath] placeholderImage:[UIImage imageNamed:@"Members_button_IdCardPlaceholder"]];
        
        
        NSArray *interestsList = [self dicListWith:[_dicData arrayForKey:@"interestsList"] key:@"id" value:@"name"];
        _interestsCBV.items = interestsList;
        _interestsCBV.itemSize = CGSizeMake(86, 26);
        NSString *keys = [[NSString alloc] init];
        for (NSString *value in [_member.interests componentsSeparatedByString:@","]) {
            for (NSDictionary *dic in interestsList) {
                if ([[dic objectForKey:@"value"]isEqual:value]) {
                    if (keys.length>0) {
                        keys = [NSString stringWithFormat:@"%@^%@",keys,[dic stringForKey:@"key"]];
                    }else{
                        keys = [dic stringForKey:@"key"];
                    }
                }
            }
        }
        _interestsCBV.joinedkeys = keys;
//        [_interestsCBV didSelectCheckBoxViewItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *selectedItems, NSString *joinedkeys) {
//            NSLog(@"%@",selectedItems);
//        }];
        
        NSArray *memberflagList = [self dicListWith:[_dicData arrayForKey:@"memberflagList"] key:@"id" value:@"name"];
        _memberflagCBV.items = memberflagList;
        _memberflagCBV.itemSize = CGSizeMake(86, 26);
        NSString *memberflagListkeys = [[NSString alloc] init];
        for (NSString *value in [_member.memberflag componentsSeparatedByString:@","]) {
            for (NSDictionary *dic in memberflagList) {
                if ([[dic objectForKey:@"value"]isEqual:value]) {
                    if (memberflagListkeys.length>0) {
                        memberflagListkeys = [NSString stringWithFormat:@"%@^%@",memberflagListkeys,[dic stringForKey:@"key"]];
                    }else{
                        memberflagListkeys = [dic stringForKey:@"key"];
                    }
                }
            }
        }
        _memberflagCBV.joinedkeys = memberflagListkeys;
        
        [self updateCustomViewFrame];
    }
}
-(NSArray *)dicListWith:(NSArray *)array key:(NSString *)key value:(NSString *)value{
    NSMutableArray *returnArray = [NSMutableArray array];
    for (NSDictionary *dic in array) {
        NSMutableDictionary *dic1 = [[NSMutableDictionary alloc]init];
        [dic1 setObject:[dic stringForKey:key]?:@"" forKey:@"key"];
        [dic1 setObject:[dic stringForKey:value]?:@"" forKey:@"value"];
        [returnArray addObject:dic1];
    }
    return returnArray;
}
- (void)updateCustomViewFrame{
    _interestsChange.constant = _interestsCBV.frame.size.height+440;
    _memberflagChange.constant = _memberflagCBV.frame.size.height+440;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
