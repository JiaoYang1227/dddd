//
//  MemberQueryCell.h
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MemberQueryCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *cardtype;
@property (weak, nonatomic) IBOutlet UILabel *cardnumber;
@property (weak, nonatomic) IBOutlet UILabel *usercode;
@property (weak, nonatomic) IBOutlet UILabel *mobile;
-(void)configPlanCell:(NSDictionary*)item;
@end
