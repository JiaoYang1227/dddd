//
//  MembersDetailViewController.h
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface MembersDetailViewController : BaseViewController
@property (nonatomic, strong) NSString *cardnumber;//证件号
@end
