//
//  MemberQueryCell.m
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "MemberQueryCell.h"

@implementation MemberQueryCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)configPlanCell:(NSDictionary*)item{
    self.name.text = [item stringForKey:@"name"];
    self.cardtype.text = [item stringForKey:@"cardtype"];
    self.cardnumber.text = [item stringForKey:@"cardnumber"];
    self.usercode.text = [item stringForKey:@"usercode"];
    self.mobile.text = [item stringForKey:@"mobile"];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
