//
//  MemberQueryListViewController.m
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "MemberQueryListViewController.h"
#import "MembersDetailViewController.h"
#import "MemberQueryCell.h"
#import "MemberQuery.h"
@interface MemberQueryListViewController (){
    
    __weak IBOutlet SwitchView *_isPhoneSV;
    __weak IBOutlet BorderTextField *_QueryKeyTF;
    __weak IBOutlet UITableView *_tableview;
    NSMutableArray *_dataList;
}

@end

@implementation MemberQueryListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadData];
    _isPhoneSV.items = @[@{
                             @"value" : @"电话",
                             @"key" : @"0"
                             },
                         @{
                             @"value" : @"姓名",
                             @"key" : @"1"
                             }
                         ];
    _isPhoneSV.on = YES;
    _dataList = [[NSMutableArray alloc] init];
}
- (IBAction)selectTouched:(id)sender {
    [self loadData];
}
-(void)loadData{
    
//    [_isPhoneSV didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
//        
//    }];
    
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    if (_QueryKeyTF.text.length>0) {
        if (_isPhoneSV.on) {
            [param setValue:_QueryKeyTF.text forKey:@"mobile"];
        }else{
            [param setValue:_QueryKeyTF.text forKey:@"name"];
        }
    }
    [APIManager reset];
    [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
    [MemberQuery dealermemberlist:param Success:^(BOOL isSuccess, id responseObject) {
        if (isSuccess) {
            [_dataList setArray:[responseObject arrayForKey:@"toaldatalist2"]];
            [_tableview reloadData];
        }else{
            [JKAlert showMessage:[responseObject stringForKey:@"massage"]];
        }
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    } Failure:^(NSError *error) {
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    }];
}
#pragma mark -
#pragma mark Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MemberQueryCell *cell ;
    NSString *CellIdentifier = [NSString stringWithFormat:@"MemberQueryCell"];
    if (cell == nil) {
        [tableView registerNib:[UINib nibWithNibName:@"MemberQueryCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    }
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
    [cell configPlanCell:[_dataList objectWithIndex:indexPath.row]];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    MembersDetailViewController *member = [[MembersDetailViewController alloc]init];
    NSDictionary *dic = [_dataList objectAtIndex:indexPath.row];
    member.cardnumber = [dic stringForKey:@"cardnumber"];
    [self.navigationController pushViewController:member animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
