//
//  QueryInformationCell.m
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "QueryInformationCell.h"
#import "DateManager.h"
@implementation QueryInformationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)configPlanCell:(Membership*)item{
    self.customerName.text = item.customerName;
    self.cardType.text = item.cardType;
    self.cardId.text = item.cardId;
    self.mobile.text = item.mobile;
    self.closeDate.text = item.closeDate;
//    NSDate *data =[DateManager dateConvertFrom_YMDHMS_String:item.closeDate];
//    self.closeDate.text = [DateManager stringConvert_YMD_FromDate:data];
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
