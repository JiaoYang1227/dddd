//
//  QueryInformationCell.h
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Membership.h"
@interface QueryInformationCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *customerName;
;//姓名
@property (weak, nonatomic) IBOutlet UILabel *mobile;//手机号
@property (weak, nonatomic) IBOutlet UILabel *cardType;//证件类型
@property (weak, nonatomic) IBOutlet UILabel *cardId;//证件号
@property (weak, nonatomic) IBOutlet UILabel *closeDate;//成交日期
-(void)configPlanCell:(Membership*)item;
@end
