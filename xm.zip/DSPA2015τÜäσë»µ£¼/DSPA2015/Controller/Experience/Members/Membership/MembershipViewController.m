//
//  MembershipViewController.m
//  DSPA2015
//
//  Created by sun on 2017/8/7.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "MembershipViewController.h"
#import "CheckBoxView.h"
#import "QueryInformationViewController.h"
#import "Membership.h"
#import "DateManager.h"
#import "Validator.h"
#import "JKToast.h"
#import "CTAssetsPickerController.h"
@interface MembershipViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CTAssetsPickerControllerDelegate>{
    
    __weak IBOutlet BorderTextField *_nameTF;//姓名
    __weak IBOutlet BorderTextField *_cardnumberTF;//身份证
    __weak IBOutlet SelectButton *_birthdaySBTN;//生日
    __weak IBOutlet SwitchView *_sexSV;
    __weak IBOutlet BorderTextField *_mobileTF;//手机号码
    __weak IBOutlet BorderTextField *_emailTF;//电子邮箱
    __weak IBOutlet BorderTextField *_addressTF;//地址
    __weak IBOutlet SelectButton *_jobSBTN;//行业
    __weak IBOutlet SelectButton *_positionSBTN;//职位
    __weak IBOutlet SelectButton *_educationSBTN;//教育程度
    __weak IBOutlet SwitchView *_ismarriageSV;
    __weak IBOutlet SelectButton *_marriedtimeSBTN;//结婚纪念日
    __weak IBOutlet SelectButton *_babybirthdaySBTN;//孩子生日
    __weak IBOutlet CheckBoxView *_interestsCBV;//兴趣爱好
    __weak IBOutlet BorderTextField *_vinTF;//vin
    __weak IBOutlet BorderTextField *_invitationcodeTF;//邀请码
    __weak IBOutlet UIButton *_cardfileBTN;//身份证
    __weak IBOutlet UIButton *_drivinglicensefileBTN;//驾驶证
    __weak IBOutlet UIButton *_vinBTN;
    __weak IBOutlet NSLayoutConstraint *_likeCheckChange;
    
    
    __weak IBOutlet SwitchView *_isOneself;
    NSDictionary *_Joindic;
    
    
    NSArray *_educationList;
    NSArray *_interestsList;
    NSArray *_jobList;
    NSArray *_positionList;
    NSArray *_memberflagList;
    NSMutableArray *_interestsSelsctList;
    
    
    UIImagePickerController *imagePicker;//图片选择器
    BOOL _isIDCard;
    NSData *_carddata;
    NSData *_drivedata;
    BOOL _vinIsSucceed;
    
    
}
@end

@implementation MembershipViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getJoindictionaries];
    _vinIsSucceed = NO;
    _isIDCard = YES;
}

//保存
- (IBAction)saveTouched:(id)sender {
    //必填
    if (_nameTF.text.length==0) {
        [JKAlert showMessage:@"请输姓名!"];
        return;
    }
    if (_nameTF.text.length>8) {
        [JKAlert showMessage:@"姓名长度不能超过8个字符!"];
        return;
    }
    if (_cardnumberTF.text.length==0) {
        [JKAlert showMessage:@"请输证件号!"];
        return;
    }
    if (![Validator isIDCard:_cardnumberTF.text]) {
        [JKAlert showMessage:@"请输有效的证件号!"];
        return;
    }
    if (_mobileTF.text.length==0) {
        [JKAlert showMessage:@"请输正确的手机号!"];
        return;
    }
    if (![Validator isMobile:_mobileTF.text]) {
        [JKAlert showMessage:@"请输有效的手机号!"];
        return;
    }
    if (_vinTF.text.length==0) {
        [JKAlert showMessage:@"请输入VIN码!"];
        return;
    }
    if (!_drivedata) {
        [JKAlert showMessage:@"请上传驾驶证!"];
        return;
    }
    if (!_carddata) {
        [JKAlert showMessage:@"请上传身份证!"];
        return;
    }
    if (_vinIsSucceed == NO) {
         [JKAlert showMessage:@"请先验证VIN码!"];
        return;
    }
    if (_emailTF.text.length>0) {
        if (![Validator isEmail:_emailTF.text]) {
            [JKAlert showMessage:@"请输入正确的有效的邮箱(非必填)!"];
            return;
        }
    }
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    //必填
    [param setValue:_nameTF.text?:@"" forKey:@"name"];
    [param setValue:_cardnumberTF.text?:@"" forKey:@"cardnumber"];
    [param setValue:_mobileTF.text?:@"" forKey:@"mobile"];
    [param setValue:_vinTF.text?:@"" forKey:@"vin"];
    if (_carddata) {
        [param setValue:[_carddata base64EncodedStringWithOptions:0]?:@"" forKey:@"cardfile"];
    }
    if (_drivedata) {
        [param setValue:[_drivedata base64EncodedStringWithOptions:0]?:@"" forKey:@"drivinglicensefile"];//行驶证照片
    }
    
    
    
    
    
    //非必填
    [param setValue:_invitationcodeTF.text?:@"" forKey:@"invitationcode"];
    if (_ismarriageSV.on) {
        [param setValue:@"男" forKey:@"sex"];
    }else{
        [param setValue:@"女" forKey:@"sex"];
    }
    [param setValue:_birthdaySBTN.value?:@"" forKey:@"birthday"];
    [param setValue:_emailTF.text?:@"" forKey:@"email"];
    [param setValue:_addressTF.text?:@"" forKey:@"address"];
    [param setValue:_jobSBTN.value?:@"" forKey:@"job"];
    [param setValue:_positionSBTN.value?:@"" forKey:@"position"];
    [param setValue:_educationSBTN.value?:@"" forKey:@"education"];
    if (_ismarriageSV.on) {
         [param setValue:@"未婚" forKey:@"ismarriage"];
    }else{
        [param setValue:@"已婚" forKey:@"ismarriage"];
    }
   
    [param setValue:_marriedtimeSBTN.value?:@"" forKey:@"marriedtime"];
    [param setValue:_babybirthdaySBTN.value?:@"" forKey:@"babybirthday"];
    
    
    
    
    if (_interestsSelsctList.count>0) {
        NSString *interests = [[NSString alloc] init];
        for (NSDictionary *dic in _interestsSelsctList) {
            if (interests.length==0) {
                interests = [dic stringForKey:@"value"];
            }else{
                interests = [NSString stringWithFormat:@"%@,%@",interests,[dic stringForKey:@"value"]];
            }
        }
         [param setValue:interests?:@"" forKey:@"interests"];
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"上传中";
    [APIManager reset];
    [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
    [Membership applyForMember:param Success:^(BOOL isSuccess, id responseObject) {
        if (!isSuccess) {
            [JKAlert showMessage:[responseObject stringForKey:@"msg"]];
        }else{
            [JKAlert showMessage:@"注册信息已经提交，请在会员管理系统中进行审核"];
            [self.navigationController popViewControllerAnimated:YES];
        }
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}
//生日
- (IBAction)birthdayTouched:(id)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.maxDate  = [NSDate date];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        _birthdaySBTN.value = [DateManager stringConvert_YMD_FromDate:date];
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}
//兴趣爱好
-(void)getInterests{
    _interestsSelsctList = [NSMutableArray array];
    if (_interestsList) {
        _interestsCBV.items = _interestsList;
        _interestsCBV.itemSize = CGSizeMake(86, 26);
        [_interestsCBV didSelectCheckBoxViewItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *selectedItems, NSString *joinedkeys) {
            NSLog(@"%@",selectedItems);
            [_interestsSelsctList setArray:selectedItems];
        }];
        [self updateCustomViewFrame];
    }else{
        [self getJoindictionaries];
    }
    
}
//孩子生日
- (IBAction)babybirthdayTouched:(id)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDate;
     datePicker.maxDate  = [NSDate date];
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        _babybirthdaySBTN.value = [DateManager stringConvert_YMD_FromDate:date];
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}
//结婚纪念日
- (IBAction)marriedtime:(id)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    datePicker.datePickerMode = UIDatePickerModeDate;
     datePicker.maxDate  = [NSDate date];
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        _marriedtimeSBTN.value = [DateManager stringConvert_YMD_FromDate:date];
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}
//教育程度
- (IBAction)educationTouched:(id)sender {
    UIButton *btn = (UIButton *)sender;
    if (_educationList) {
        PopoverSearchController *search = [[PopoverSearchController alloc]initWithSender:btn andItems:_educationList];
        [search didSelectSearchItem:^(id item, NSString *key, NSString *value) {
            _educationSBTN.value = value;
        }];
        [self presentViewController:search animated:YES completion:nil];
    }else{
        [JKToast toastWithText:@"数据加载中!"];
        [self getJoindictionaries];
    }
    
}
//行业
- (IBAction)jobTouched:(id)sender {
    UIButton *btn = (UIButton *)sender;
    if (_jobList) {
        PopoverSearchController *search = [[PopoverSearchController alloc]initWithSender:btn andItems:_jobList];
        [search didSelectSearchItem:^(id item, NSString *key, NSString *value) {
            _jobSBTN.value = value;
        }];
        [self presentViewController:search animated:YES completion:nil];
    }else{
        [JKToast toastWithText:@"数据加载中!"];
        [self getJoindictionaries];
    }
}
//职位
- (IBAction)positionTouched:(id)sender {
    UIButton *btn = (UIButton *)sender;
    if (_positionList) {
        PopoverSearchController *search = [[PopoverSearchController alloc]initWithSender:btn andItems:_positionList];
        [search didSelectSearchItem:^(id item, NSString *key, NSString *value) {
            _positionSBTN.value = value;
        }];
        [self presentViewController:search animated:YES completion:nil];
    }else{
        [JKToast toastWithText:@"数据加载中!"];
        [self getJoindictionaries];
    }
}
//身份证
- (IBAction)IdCardTouched:(id)sender {
    _isIDCard = YES;
    UIActionSheet* mySheet = [[UIActionSheet alloc]
                              initWithTitle:@"请选择图片源"
                              delegate:self
                              cancelButtonTitle:@"取消"
                              destructiveButtonTitle:nil
                              otherButtonTitles:@"使用摄像头",@"从相册选取", nil];
    [mySheet showInView:self.view];
}
//驾驶证
- (IBAction)driverTouched:(id)sender {
    _isIDCard = NO;
    UIActionSheet* mySheet = [[UIActionSheet alloc]
                              initWithTitle:@"请选择图片源"
                              delegate:self
                              cancelButtonTitle:@"取消"
                              destructiveButtonTitle:nil
                              otherButtonTitles:@"使用摄像头",@"从相册选取", nil];
    [mySheet showInView:self.view];
}
//婚姻状况
-(void)getMarriage{
    _ismarriageSV.items = @[@{
                         @"value" : @"未婚",
                         @"key" : @"0"
                         },
                     @{
                         @"value" : @"已婚",
                         @"key" : @"1"
                         }
                     ];
    [_ismarriageSV setOn:YES];
    [_ismarriageSV didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
    }];
}
//性别
-(void)getSex{
    _sexSV.items = @[@{
                         @"value" : @"男",
                         @"key" : @"0"
                         },
                     @{
                         @"value" : @"女",
                         @"key" : @"1"
                         }
                     ];
    [_sexSV setOn:YES];
    [_sexSV didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
    }];
}
//vin码验证
- (IBAction)checkjoinvinTouched:(UIButton*)sender {
    if (_vinTF.text.length>0) {
        [APIManager reset];
        [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
        [Membership checkJoinVin:_vinTF.text Success:^(BOOL isSuccess, id responseObject) {
            if (isSuccess) {
                [_vinBTN setTitle:@"校验成功" forState:UIControlStateNormal];
                _vinIsSucceed = YES;
            }else{
                [_vinBTN setTitle:@"验证失败" forState:UIControlStateNormal];
                _vinIsSucceed = NO;
            }
            sender.enabled = NO;
            [APIManager reset];
            [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
        } Failure:^(NSError *error) {
            _vinIsSucceed = NO;
            [APIManager reset];
            [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
        }];
    }else{
        [JKAlert showMessage:@"请先输入VIN码,再进行验证!"];
    }
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField == _vinTF) {
        _vinBTN.enabled = YES;
        [_vinBTN setTitle:@"查询VIN码" forState:UIControlStateNormal];
    }
    // 删除回退的时候返回yes
    if (string.length == 0 && range.length == 1) {
        return YES;
    }
    
    if (textField == _nameTF) {
        _nameTF.limit=8;
        
    }
    if (textField == _mobileTF) {
        _mobileTF.limit=11;
        
    }
    if (textField == _cardnumberTF) {
        _cardnumberTF.limit=18;
        
    }
    if (textField == _addressTF) {
        _addressTF.limit=100;
        
    }
    if (textField == _cardnumberTF&&textField.text.length==17) {
        NSString*str = [NSString stringWithFormat:@"%@%@",textField.text,string];
        if (str.length==18&&[Validator isIDCard:str]) {
            [self getCheckJoinCardnumber];
            [self getInformation];
        }else{
            [JKAlert showMessage:@"请输入正确的身份证号"];
        }
    }
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _mobileTF) {

        if (_mobileTF.text.length==11&&[Validator isMobile:_mobileTF.text]) {
            [self getCheckJoinMobil];
        }else{
            [JKAlert showMessage:@"请输入正确的手机号"];
        }
    }
//    if (textField == _cardnumberTF) {
//
//        if (_cardnumberTF.text.length==18&&[Validator isIDCard:_cardnumberTF.text]) {
//            [self getCheckJoinCardnumber];
//            [self getInformation];
//        }else{
//            [JKToast toastWithText:@"请输入正确的身份证号"];
//        }
//    }
    
    
}
-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
    [self.coverView removeFromSuperview];
    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
    self.coverView.backgroundColor = [UIColor blackColor];
    self.coverView.alpha = 0;
    [self.view addSubview:self.coverView];
    
    modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, self.view.height, modelDetailViewController.view.width, modelDetailViewController.view.height);
    [self.view addSubview:modelDetailViewController.view];
    [self addChildViewController:modelDetailViewController];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.coverView.alpha = 0.55;
        modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, (self.view.height-modelDetailViewController.view.height)/2, modelDetailViewController.view.width, modelDetailViewController.view.height);
    }];
}
-(void)getInformation{
    _birthdaySBTN.value = [self birthdayStrFromIdentityCard:_cardnumberTF.text];
    [_sexSV setOn:[self getIdentityCardSex:_cardnumberTF.text]];
}
-(void)getJoindictionaries{
    [self getMarriage];
    [self getSex];
    [APIManager reset];
    [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
    [Membership getJoindictionariesWithSuccess:^(NSDictionary *dic, id responseObject) {
        if ([[dic stringForKey:@"success"]isEqual:@"true"]) {
            _Joindic = [[NSDictionary alloc]initWithDictionary:dic];
            [self getDataLoadWthDic];
        }
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    } Failure:^(NSError *error) {
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    }];
}
//校验身份证号
-(void)getCheckJoinCardnumber{
    [APIManager reset];
    [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
    [Membership checkJoinCarnumber:_cardnumberTF.text Success:^(BOOL isSuccess, id responseObject) {
        if (!isSuccess) {
            [JKAlert showMessage:[responseObject stringForKey:@"msg"]];
        }
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    } Failure:^(NSError *error) {
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    }];
}
//校验手机号
-(void)getCheckJoinMobil{
    [APIManager reset];
    [[AppDelegate APP] setBaseURL:[URI_SERVER_MEMBERS_ADDRESS stringByAppendingString:URI_INTERFACE_MEMBERS_ROOT]];
    [Membership checkJoinMobil:_mobileTF.text Success:^(BOOL isSuccess, id responseObject) {
        if (!isSuccess) {
            [JKAlert showMessage:[responseObject stringForKey:@"msg"]];
        }
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    } Failure:^(NSError *error) {
        [APIManager reset];
        [AppDelegate APP].BaseURL = [[AppDelegate APP].ServerIP stringByAppendingString:URI_INTERFACE_ROOT];
    }];
}

//根据身份证号获取生日
-(NSString *)birthdayStrFromIdentityCard:(NSString *)numberStr
{
    NSMutableString *result = [NSMutableString stringWithCapacity:0];
    NSString *year = nil;
    NSString *month = nil;
    
    BOOL isAllNumber = YES;
    NSString *day = nil;
    if([numberStr length]<14)
        return result;
    
    //**截取前14位
    NSString *fontNumer = [numberStr substringWithRange:NSMakeRange(0, 13)];
    
    //**检测前14位否全都是数字;
    const char *str = [fontNumer UTF8String];
    const char *p = str;
    while (*p!='\0') {
        if(!(*p>='0'&&*p<='9'))
            isAllNumber = NO;
        p++;
    }
    if(!isAllNumber)
        return result;
    
    year = [numberStr substringWithRange:NSMakeRange(6, 4)];
    month = [numberStr substringWithRange:NSMakeRange(10, 2)];
    day = [numberStr substringWithRange:NSMakeRange(12,2)];
    
    [result appendString:year];
    [result appendString:@"-"];
    [result appendString:month];
    [result appendString:@"-"];
    [result appendString:day];
    return result;
}
//根据身份证号性别
-(BOOL)getIdentityCardSex:(NSString *)numberStr
{
    int sexInt=[[numberStr substringWithRange:NSMakeRange(16,1)] intValue];
    
    if(sexInt%2!=0)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}
- (IBAction)nameTouched:(id)sender {
    QueryInformationViewController *query = [[QueryInformationViewController alloc]init];
    [self presentModelDetail:query];
    __block typeof(self) weakSelf = self;
    [query shouldReloadParentData:^(BOOL shouldReload, id data) {
        if (shouldReload==YES) {
            Membership *member = (Membership *)data;
            [weakSelf BringUserInformation:member];
        }

    }];
}
-(void)BringUserInformation:(Membership *)member{
    
    _nameTF.text = member.customerName;
    _cardnumberTF.text = member.cardId;
//    if (member.sex) {
//        if ([member.sex isEqual:@"女"]) {
//            _sexSV.on = NO;
//        }else{
//            _sexSV.on = YES;
//        }
//    }else{
//        if ([Validator isIDCard:member.cardId]) {
//            
//            [_sexSV setOn:[self getIdentityCardSex:member.cardId]];
//        }
//    }
    
    if ([Validator isIDCard:member.cardId]) {
        _birthdaySBTN.value = [self birthdayStrFromIdentityCard:member.cardId];
        [_sexSV setOn:[self getIdentityCardSex:member.cardId]];
    }else{
        _birthdaySBTN.value = nil;
        if ([member.sex isEqual:@"女"]) {
            _sexSV.on = NO;
        }else{
            _sexSV.on = YES;
        }

    }
    _emailTF.text = member.mail;
    _addressTF.text = member.address;
}
-(void)getDataLoadWthDic{
    _educationList = [self dicListWith:[_Joindic arrayForKey:@"educationList"] key:@"id" value:@"name"];
    _interestsList = [self dicListWith:[_Joindic arrayForKey:@"interestsList"] key:@"id" value:@"name"];
    _jobList = [self dicListWith:[_Joindic arrayForKey:@"jobList"] key:@"id" value:@"name"];
    _positionList = [self dicListWith:[_Joindic arrayForKey:@"positionList"] key:@"id" value:@"name"];
    _memberflagList = [self dicListWith:[_Joindic arrayForKey:@"memberflagLis"] key:@"id" value:@"name"];
    [self getInterests];
}
-(NSArray *)dicListWith:(NSArray *)array key:(NSString *)key value:(NSString *)value{
    NSMutableArray *returnArray = [NSMutableArray array];
    for (NSDictionary *dic in array) {
        NSMutableDictionary *dic1 = [[NSMutableDictionary alloc]init];
        [dic1 setObject:[dic stringForKey:key]?:@"" forKey:@"key"];
        [dic1 setObject:[dic stringForKey:value]?:@"" forKey:@"value"];
        [returnArray addObject:dic1];
    }
    return returnArray;
}
- (void)updateCustomViewFrame{
    _likeCheckChange.constant = _interestsCBV.frame.size.height+440;
}
#pragma mark -- UIActionSheet delegate
- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){//使用摄像头
        [self pickImageFromCamera];
    }
    if(buttonIndex == 1){//本地相册选取
        CTAssetsPickerController *picker = [[CTAssetsPickerController alloc] init];
        //设置最多选择多少张图片
        picker.maximumNumberOfSelection = 1;
    
        picker.assetsFilter = [ALAssetsFilter allAssets];//只选择图片
        picker.delegate = self;
        if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
        {
            [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                [self presentViewController:picker animated:YES completion:NULL];
            }];
        }
        else{
            [self presentViewController:picker animated:YES completion:NULL];
        }
    }
}
//相机选取
- (void)pickImageFromCamera{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        //没有摄像头 或者模拟器下使用 跳过
        return;
    }
    //创建图像选取控制器
    imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    //设置图像选取控制器的来源模式为相机模式
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    //不允许用户进行编辑
    imagePicker.allowsEditing = NO;
    if([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0)
    {
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            [self presentViewController:imagePicker animated:YES completion:nil];
        }];
    }
    else{
        [self presentViewController:imagePicker animated:YES completion:nil];
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    [imagePicker dismissViewControllerAnimated:YES completion:^() {
        UIImage *portraitImg = [info objectForKey:UIImagePickerControllerOriginalImage];
        NSData *imagedata = UIImageJPEGRepresentation(portraitImg, 1);
        float imgageSize = [imagedata length]/1048576;
        if (imgageSize>=5) {
            imagedata = UIImageJPEGRepresentation(portraitImg, 5/imgageSize);
        }
        if (_isIDCard == YES) {
            [_cardfileBTN setImage:portraitImg forState:UIControlStateNormal];
            _carddata = [NSData dataWithData:imagedata];
            NSLog(@"imageData.length:%ld",(long)[_carddata length]);
        }else{
            [_drivinglicensefileBTN setImage:portraitImg forState:UIControlStateNormal];
            _drivedata = [NSData dataWithData:imagedata];
            NSLog(@"imageData.length:%ld",(long)[_drivedata length]);
        }
    }];
}
#pragma mark - Assets Picker Delegate
//实现 CTAssetsPickerControllerDelegate 的函数 完成选择之后 didFinishPickingAssets
- (void)assetsPickerController:(CTAssetsPickerController *)picker didFinishPickingAssets:(NSArray *)assets
{
    if (assets.count>0) {
        ALAsset *asset=assets[0];
        UIImage *tempImg=[UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
        NSData *imagedata = UIImageJPEGRepresentation(tempImg, 1);
        float imgageSize = [imagedata length]/1048576;
        if (imgageSize>=5) {
            imagedata = UIImageJPEGRepresentation(tempImg, 5/imgageSize);
        }
        if (_isIDCard == YES) {
            [_cardfileBTN setImage:tempImg forState:UIControlStateNormal];
            _carddata = [NSData dataWithData:imagedata];
            NSLog(@"imageData.length:%ld",(long)[_carddata length]);
            
        }else{
            [_drivinglicensefileBTN setImage:tempImg forState:UIControlStateNormal];
             _drivedata = [NSData dataWithData:imagedata];
            NSLog(@"imageData.length:%ld",(long)[_carddata length]);
        }
        
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
