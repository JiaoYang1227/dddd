//
//  QueryInformationViewController.m
//  DSPA2015
//
//  Created by sun on 2017/8/8.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "QueryInformationViewController.h"
#import "QueryInformationCell.h"
#import "MembershipViewController.h"
#import "membership.h"
@interface QueryInformationViewController (){
    NSMutableArray *_array;
    NSInteger _currentPage;
    __weak IBOutlet UITableView *_tableView;
    __weak IBOutlet BorderTextField *_QueryKeyTF;
    __weak IBOutlet SwitchView *_isPhoneSV;
}

@end

@implementation QueryInformationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _currentPage = 1;
    _array = [NSMutableArray array];
    _isPhoneSV.items = @[@{
                             @"value" : @"电话",
                             @"key" : @"0"
                             },
                         @{
                             @"value" : @"姓名",
                             @"key" : @"1"
                             }
                         ];
    _isPhoneSV.on = YES;
    [self loadData:nil startNum:0];
}
- (IBAction)selectTouched:(id)sender {
    if (_QueryKeyTF.text.length>0) {
        [_array removeAllObjects];
    }
    [self loadData:nil startNum:0];
    
}
-(void)loadData:(NSDictionary*)option startNum:(NSInteger)startNum{
    
    NSMutableDictionary *dicParam = [[NSMutableDictionary alloc]init];
    NSNumber *starnum = [NSNumber numberWithInteger:_currentPage];
    [dicParam setValue:starnum forKey:@"pageon"];
    if (_QueryKeyTF.text.length>0) {
        [dicParam setValue:_QueryKeyTF.text forKey:@"selectStr"];
        if (_isPhoneSV.on) {
            [dicParam setValue:@"mobile" forKey:@"selectType"];
            
        }else{
            [dicParam setValue:@"cName" forKey:@"selectType"];
        }
    }
    [Membership selectCustomerInfo:dicParam Success:^(NSArray *array, id responseObject) {
        if(array){
            if(startNum==0){
                [_array removeAllObjects];
                _currentPage = 1;
            }
            [_array addObjectsFromArray:array];
        }else{
            [JKAlert showMessage:[responseObject errorMessages]];
        }
        [_tableView reloadData];
    } Failure:^(NSError *error) {
        [_tableView reloadData];
    }];
}
#pragma mark -
#pragma mark Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _array.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    QueryInformationCell *cell ;
    NSString *CellIdentifier = [NSString stringWithFormat:@"QueryInformationCell"];
    if (cell == nil) {
        [tableView registerNib:[UINib nibWithNibName:@"QueryInformationCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    }
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
    if (indexPath.row%2==1) {
        cell.backgroundColor = [UIColor colorWithHexString:@"f3f3f3"];
    }else{
        cell.backgroundColor = [UIColor colorWithHexString:@"f9f9f9"];
    }
    Membership *member = [_array objectAtIndex:indexPath.row];
    [cell configPlanCell:member];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    _shouldReloadParentData(YES,[_array objectAtIndex:indexPath.row]);
    MembershipViewController *borad = (MembershipViewController*)self.parentViewController;
    [UIView animateWithDuration:0.3 animations:^{
        borad.coverView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
    } completion:^(BOOL finished) {
        [borad.coverView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
    [self dismissTouched:nil];
}
//上拉加载
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSInteger curRowCount = 0;
    for (NSInteger i = 0; i < indexPath.section; i++)
    {
        NSInteger rowCount = [tableView numberOfRowsInSection:i];
        curRowCount += rowCount;
    }
    curRowCount += indexPath.row;
    if (curRowCount+1 == _currentPage*10)
    {
//        NSLog(@"curRowCount = %zd",curRowCount);
        _currentPage++;
        NSLog(@"load page = %zd",_currentPage);
        [self loadData:nil startNum:[_array count]];
    }
}
- (IBAction)onclickGoback:(id)sender {
    _shouldReloadParentData(NO,nil);
    MembershipViewController *borad = (MembershipViewController*)self.parentViewController;
    [UIView animateWithDuration:0.3 animations:^{
        borad.coverView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
    } completion:^(BOOL finished) {
        [borad.coverView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
    [self dismissTouched:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
