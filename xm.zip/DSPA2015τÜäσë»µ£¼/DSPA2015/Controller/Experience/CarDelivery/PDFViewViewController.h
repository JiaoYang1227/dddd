//
//  PDFViewViewController.h
//  22222
//
//  Created by sun on 15/11/10.
//  Copyright (c) 2015年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PDFViewViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak,nonatomic)NSString *strPdf;
@end
