//
//  CarDeliveryViewController.m
//  DSPA2015
//
//  Created by sun on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CarDeliveryViewController.h"
#import "PDFViewViewController.h"
@interface CarDeliveryViewController ()

@end

@implementation CarDeliveryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    PDFViewViewController *pdf=[[PDFViewViewController alloc] initWithNibName:@"PDFViewViewController" bundle:nil];
    pdf.strPdf = @"CarDelivery";
    [_view_ContentEx addSubview:pdf.view];
    self.title = @"交车服务";
}

- (IBAction)buttonView_Click:(id)sender {
    for (UIView *view in [_view_ContentEx subviews]) {
        [view removeFromSuperview];
    }
    UIButton *btn = (UIButton *)sender;
     PDFViewViewController *pdf=[[PDFViewViewController alloc] initWithNibName:@"PDFViewViewController" bundle:nil];
    switch (btn.tag) {
        case 1:
        {
            _buttonselect1 .selected = YES;
            _buttonselect2 .selected = NO;
            _buttonselect3 .selected = NO;
            pdf.strPdf = @"QualityAssurance";
        }
            break;
        case 2:
        {
            _buttonselect2.selected = YES;
            _buttonselect1.selected = NO;
            _buttonselect3.selected = NO;
            pdf.strPdf = @"KeepFit";
        }
            break;
        case 3:
        {   _buttonselect3.selected = YES;
            _buttonselect1.selected = NO;
            _buttonselect2.selected = NO;
            pdf.strPdf = @"QualityAssurance";
            
        }
            break;
        default:
            break;
    }
    [_view_ContentEx addSubview:pdf.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
