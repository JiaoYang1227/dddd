//
//  PDFViewViewController.m
//  22222
//
//  Created by sun on 15/11/10.
//  Copyright (c) 2015年 sun. All rights reserved.
//

#import "PDFViewViewController.h"
#import "FileManager.h"
@interface PDFViewViewController ()

@end

@implementation PDFViewViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createUIImageFromPDF];
}
- (void) createUIImageFromPDF{
    NSString *pdfPath = [[NSBundle mainBundle] pathForResource:self.strPdf ofType:@"pdf"];
    NSURL *url = [NSURL fileURLWithPath:pdfPath];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [_webView loadRequest:request];
}@end
