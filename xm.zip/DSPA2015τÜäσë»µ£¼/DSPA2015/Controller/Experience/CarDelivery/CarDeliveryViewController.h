//
//  CarDeliveryViewController.h
//  DSPA2015
//
//  Created by sun on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface CarDeliveryViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIView *view_ContentEx;
@property (weak, nonatomic) IBOutlet UIButton *buttonselect1;
@property (weak, nonatomic) IBOutlet UIButton *buttonselect2;
@property (weak, nonatomic) IBOutlet UIButton *buttonselect3;

@end
