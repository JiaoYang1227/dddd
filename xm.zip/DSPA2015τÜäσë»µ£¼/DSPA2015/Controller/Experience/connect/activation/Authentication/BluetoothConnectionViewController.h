//
//  BluetoothConnectionViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "CMCC_IDCARD.h"
@interface BluetoothConnectionViewController : BaseViewController<CMCC_IDCARD_DELEGATE>
@property (weak, nonatomic) IBOutlet UITableView *findtable;
@end
