//
//  UploadContractViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "UploadContractViewController.h"
#import "UIImage+SuperCompress.h"
#import "UploadManager.h"
#import "ActivationViewController.h"
@interface UploadContractViewController (){
    
    __weak IBOutlet UIImageView *contractPreview;
}

@end

@implementation UploadContractViewController
- (id)initWithBlock:(UploadSuccessfulBlock)UploadSuccessfulBlock{
    self = [super init];
    
    if (self) {
        self.userInfoBlock = [UploadSuccessfulBlock copy];
    }
    
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [contractPreview setImage:self.contractPreviewimg];
}
- (IBAction)updataTouched:(id)sender {
    NSData *documentData = [UIImage compressImage:self.contractPreviewimg toMaxLength:512*1024*8 maxWidth:1024];
    if (!documentData) {
        [JKAlert showMessage:@"图片压缩失败!"];
        return;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"上传中";
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    //todo
    [dic setValue:[_dicData objectForKey:@"pactId"] forKey:@"pactId"];
    [dic setValue:[_dicData objectForKey:@"reg_name"] forKey:@"reg_name"];
    [dic setValue:[_dicData objectForKey:@"connctId"] forKey:@"connctid"];
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    [UploadManager imageUploadOne:[NSString stringWithFormat:@"%@%@",baseInterface,CONNECT_UPLOADCONTRAN]
                   withParameters:dic
                    withImageData:documentData
                     withFileName:@"file"
                    uploadSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                        NSLog(@"%@",responseObject);
                        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                        self.userInfoBlock();
                        [self dismissTouched:nil];
                    } uploadError:^(AFHTTPRequestOperation *operation, NSError *error) {
                        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                    }];

}
- (IBAction)dismissTouched:(id)sender {
    ActivationViewController *borad = (ActivationViewController*)self.parentViewController;
    
    [UIView animateWithDuration:0.3 animations:^{
        borad.coverView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
        //        [self.referenceViewController viewWillAppear:YES];
    } completion:^(BOOL finished) {
        [borad.coverView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
