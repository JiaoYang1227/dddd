//
//  UploadContractViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
typedef void (^UploadSuccessfulBlock)();
@interface UploadContractViewController : BaseViewController
@property (strong,nonatomic)UIImage *contractPreviewimg;
@property (strong,nonatomic)NSDictionary *dicData;
@property(copy,nonatomic)UploadSuccessfulBlock userInfoBlock;
- (id)initWithBlock:(UploadSuccessfulBlock)UploadSuccessfulBlock;
@end
