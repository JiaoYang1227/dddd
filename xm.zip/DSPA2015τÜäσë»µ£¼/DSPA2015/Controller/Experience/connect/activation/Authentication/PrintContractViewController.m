//
//  PrintContractViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "PrintContractViewController.h"
#import "ActivationViewController.h"
#import "KeychainManager.h"
@interface PrintContractViewController (){
    UIActionSheet *printSheet;
    __weak IBOutlet UIButton *printBTN;
}
@property (weak, nonatomic) IBOutlet UIWebView *contractWeb;

@end

@implementation PrintContractViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURLRequest *request =[self formURL];
//    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@?connctid=%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT,self.connctid]]];

    [self.contractWeb loadRequest:request];
}
//格式化url
- (NSURLRequest *)formURL {
    NSString *serverUrlPrefix = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    NSMutableString *absUrl = [NSMutableString stringWithString:serverUrlPrefix];
    [absUrl appendString:CONNECT_PRINT];
    
    NSMutableDictionary *paramDic = [NSMutableDictionary dictionary];
    [paramDic setObject:self.connctid?:@"" forKey:@"connectid"];
    [paramDic setObject:self.customerType?:@"" forKey:@"customerType"];
    
    //转义
    NSDictionary *formParamater=@{@"jsonString":[paramDic JSONStringValue]?:@""};
//    NSDictionary *formParamater=[paramDic JSONStringValue]?:@"";
    AFHTTPRequestSerializer *serializer = [AFHTTPRequestSerializer serializer];
    NSMutableURLRequest *request =[serializer requestWithMethod:@"POST" URLString:absUrl parameters:formParamater error:nil];
    NSLog(@"url:%@",request.URL.absoluteString);
    if ([request HTTPBody]) {
        NSString *HTTPBody = [[NSString alloc] initWithData:[request HTTPBody] encoding:NSUTF8StringEncoding];
        NSLog(@"HTTPBody:%@",HTTPBody);
    }
    return request;
}
- (IBAction)dismissTouched:(id)sender {
    ActivationViewController *borad = (ActivationViewController*)self.parentViewController;
    
    [UIView animateWithDuration:0.3 animations:^{
        borad.coverView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
        //        [self.referenceViewController viewWillAppear:YES];
    } completion:^(BOOL finished) {
        [borad.coverView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}
//打印方法
- (IBAction)printTouched:(id)sender {
    //  解决 弹出窗太大问题
    self.modalPresentationStyle = UIModalPresentationFormSheet;
    //调整箭头方向
    [printSheet showFromRect:[self.view convertRect:CGRectMake(0, 0, 93, 42) fromView:self.view] inView:self.view animated:YES];
    NSLog(@"%@",NSStringFromCGRect(printBTN.frame));
    
    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
    
    if(!controller){
        NSLog(@"Couldn't get shared UIPrintInteractionController!");
        return;
    }
    UIPrintInteractionCompletionHandler completionHandler =
    ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
        if(!completed && error){
            NSLog(@"FAILED! due to error in domain %@ with error code %zd", error.domain, error.code);
        }
    };
    
    
    // Obtain a printInfo so that we can set our printing defaults.
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    // This application produces General content that contains color.
    printInfo.outputType = UIPrintInfoOutputGeneral;
    // We'll use the URL as the job name.
    //    printInfo.jobName = [self formURL];
    // Set duplex so that it is available if the printer supports it. We
    // are performing portrait printing so we want to duplex along the long edge.
    printInfo.duplex = UIPrintInfoDuplexLongEdge;
    // Use this printInfo for this print job.
    controller.printInfo = printInfo;
    
    // Be sure the page range controls are present for documents of > 1 page.
    controller.showsPageRange = YES;
    //将webview 转换成图片，也可以转换成pdf
    controller.printFormatter = [self.contractWeb viewPrintFormatter];
presentFromRect:inView:animated:completionHandler:
    [controller presentFromRect:printBTN.frame inView:self.view animated:YES completionHandler:completionHandler];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
