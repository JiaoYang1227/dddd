//
//  AuthenticationViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/6.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "CMCC_IDCARD.h"
typedef void (^AuthenticationUserInfoBlock)(NSDictionary *dic);
@interface AuthenticationViewController : BaseViewController<CMCC_IDCARD_DELEGATE>
@property (weak, nonatomic) IBOutlet UITableView *findtable;
- (id)initWithBlock:(AuthenticationUserInfoBlock)UserInfoBlock;
@property(copy,nonatomic)AuthenticationUserInfoBlock userInfoBlock;
@end
