//
//  HistoryActivationViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "HistoryActivationViewController.h"
#import "HistoryActivationCell.h"
#define CELL_IDENTIFIER @"HistoryActivationCell"
#import "HistoryActivation.h"
#import "ActivationViewController.h"
#import "PrintContractViewController.h"
@interface HistoryActivationViewController ()
@property (nonatomic,strong)NSArray *dataList;

@end

@implementation HistoryActivationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:@"HistoryActivationCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER];
    [self loadData];
}
- (void)loadData
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSDictionary *dic = [NSDictionary dictionaryWithObject:_searchWord.text?:@"" forKey:@"mobile"];
    [HistoryActivation getactivationHisList:dic Success:^(NSArray *array, id responseObject) {
        self.dataList = [NSArray arrayWithArray:array];
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        [self.tableView reloadData];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}
- (IBAction)searchAction:(id)sender {
    [self loadData];
    
}
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataList.count;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HistoryActivationCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER forIndexPath:indexPath];
    HistoryActivation *model = [self.dataList objectAtIndex:indexPath.row];
    [cell cell_configuration:model];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HistoryActivation *model = [self.dataList objectAtIndex:indexPath.row];
    PrintContractViewController *print = [[PrintContractViewController alloc]init];
    print.connctid = model.acId;
    [self presentModelDetail:print];
}
/**
 *  present detail
 */
-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
    //    [self presentDSPAPopup:modelDetailViewController parentViewController:self touchCallBack:nil haveMask:YES includeNavgation:NO alignTop:YES];
    
    
    [self.coverView removeFromSuperview];
    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 70, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
    self.coverView.backgroundColor = [UIColor blackColor];
    self.coverView.alpha = 0;
    [self.view addSubview:self.coverView];
    
    modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, self.view.height, modelDetailViewController.view.width, modelDetailViewController.view.height);
    [self.view addSubview:modelDetailViewController.view];
    [self addChildViewController:modelDetailViewController];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.coverView.alpha = 0.55;
        modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, (self.view.height-modelDetailViewController.view.height)/2, modelDetailViewController.view.width, modelDetailViewController.view.height);
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
