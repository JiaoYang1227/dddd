//
//  HistoryActivationViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface HistoryActivationViewController : BaseViewController
@property (weak, nonatomic) IBOutlet BorderTextField *searchWord;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property(strong,nonatomic)  UIView *coverView;
@end
