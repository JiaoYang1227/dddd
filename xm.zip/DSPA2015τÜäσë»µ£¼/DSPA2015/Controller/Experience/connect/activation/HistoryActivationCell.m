//
//  HistoryActivationCell.m
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "HistoryActivationCell.h"

@implementation HistoryActivationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (void)cell_configuration:(HistoryActivation *)model{
    self.name.text = model.lxrName;
    self.phone.text = model.simMobile;
    self.date.text = model.createTime;
    self.enddate.text = model.activeDate;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
