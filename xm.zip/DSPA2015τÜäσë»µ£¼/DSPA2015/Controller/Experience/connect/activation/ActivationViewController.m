//
//  ActivationViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ActivationViewController.h"
#import "AuthenticationViewController.h"
#import "UploadContractViewController.h"
#import "PrintContractViewController.h"
#import "JKToast.h"
#import "HistoryActivationViewController.h"
@interface ActivationViewController ()<UIWebViewDelegate,UIImagePickerControllerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIPickerViewDelegate>{
    UIActionSheet *cameraSheet;
    UIImagePickerController *imagePickerController;
    UIPopoverController *imagePopoverController;
    __weak IBOutlet UIButton *updataContractBTN;
    NSDictionary *_dicData;
}

@end

@implementation ActivationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.isHistory) {
        [self.HistoryBTN setHidden:YES];
    }
    [self initWebView];
    imagePickerController = [[UIImagePickerController alloc] init];
    imagePopoverController = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
     cameraSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil  otherButtonTitles:@"照相机", @"相册", nil];
}
- (void)initWebView
{
    NSURLRequest *request =[self formURL];
    self.webView .delegate = self;
    [self.webView loadRequest:request];
}
//格式化url
- (NSURLRequest *)formURL {
    NSString *serverUrlPrefix = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    NSMutableString *absUrl = [NSMutableString stringWithString:serverUrlPrefix];
    [absUrl appendString:CONNECT_GETCUSTOMER_ACTIVATIONINIT];
    AFHTTPRequestSerializer *serializer = [AFHTTPRequestSerializer serializer];
    NSMutableURLRequest *request =[serializer requestWithMethod:@"GET" URLString:absUrl parameters:nil error:nil];
    return request;
}
//当请求页面出现错误的时候，我们给予提示：
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{  
    if([error code] == NSURLErrorCancelled)
    {
        return;
    }
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:[error localizedDescription]  delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//    [alert show];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    return YES;
}
//激活历史
- (IBAction)HistoryTouched:(id)sender {
    HistoryActivationViewController *history = [[HistoryActivationViewController alloc]init];
    [self.navigationController pushViewController:history animated:YES];
}
//实名认证
- (IBAction)RealnameAuthenticationTouched:(id)sender {
    AuthenticationViewController *activation = [[AuthenticationViewController alloc]initWithBlock:^(NSDictionary *dic) {
        NSString *urlStr = [NSString stringWithFormat:@"reWriteRealNameInfo('%@')",[dic JSONStringValue]];
        urlStr = [urlStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        urlStr = [urlStr stringByReplacingOccurrencesOfString:@" " withString:@""];
        [self.webView stringByEvaluatingJavaScriptFromString: urlStr];
    }];
    [self presentModelDetail:activation];
}
//保存
- (IBAction)saveTouched:(id)sender {
    NSString *str = [self.webView stringByEvaluatingJavaScriptFromString:@"saveInfo()"];
    [self.webView stringByEvaluatingJavaScriptFromString: str];
}
//激活
- (IBAction)activationTouched:(id)sender {
    NSString *str = [self.webView stringByEvaluatingJavaScriptFromString:@"activationCustomer()"];
    [self.webView stringByEvaluatingJavaScriptFromString: str];
    
}
//打印合同
- (IBAction)PrintContractTouched:(id)sender {
    NSString *str = [self.webView stringByEvaluatingJavaScriptFromString:@"getParamForIOS()"];
    if (str.length>0) {
        NSArray *arr = [str componentsSeparatedByString:@","];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
        for (NSString *str1 in arr) {
            NSArray *arr1 = [str1 componentsSeparatedByString:@":"];
            [dic setValue:[arr1 objectAtIndex:1] forKey:[arr1 objectAtIndex:0]];
        }
        if (![dic objectForKey:@"connctId"]) {
//            [JKToast toastWithText:@"请先激活或保存!"];
            return;
        }else{
            PrintContractViewController *print = [[PrintContractViewController alloc]init];
            print.connctid = [dic stringForKey:@"connctId"];
            print.customerType = [dic stringForKey:@"customerType"];
            [self presentModelDetail:print];
        }
    }else{
//        [JKToast toastWithText:@"请进行账号认证"];
        return;
    }

}
//上传合同
- (IBAction)updataContractTouched:(UIButton *)sender {
    NSString *str = [self.webView stringByEvaluatingJavaScriptFromString:@"getParamForIOS()"];
    if (str.length>0) {
        NSArray *arr = [str componentsSeparatedByString:@","];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
        for (NSString *str1 in arr) {
            NSArray *arr1 = [str1 componentsSeparatedByString:@":"];
            [dic setValue:[arr1 objectAtIndex:1] forKey:[arr1 objectAtIndex:0]];
        }
        NSLog(@"%@",dic);
        if (![dic objectForKey:@"reg_name"]) {
//            [JKToast toastWithText:@"没有进行账号认证!"];
            return;
        }
        if (![dic objectForKey:@"pactId"]) {
//            [JKToast toastWithText:@"账号没有激活!"];
            return;
        }
        if (![dic objectForKey:@"connctId"]) {
//            [JKToast toastWithText:@"请先激活或保存!"];
            return;
        }
        _dicData = [NSDictionary dictionaryWithDictionary:dic];
        [cameraSheet showFromRect:[self.view convertRect:sender.frame fromView:sender.superview] inView:self.view animated:YES];
    }else{
        [JKToast toastWithText:@"请进行账号认证"];
    }
}
#pragma mark UIAction Sheet event handler
//动作表响应
- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    [self popCameraView:buttonIndex];
}

-(void)popCameraView:(NSInteger)buttonIndex
{
    imagePickerController.delegate = self;
    imagePickerController.allowsEditing = YES;
    //    imagePickerController.wantsFullScreenLayout = YES;
    switch (buttonIndex) {
        case 0:
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                imagePickerController.sourceType  = UIImagePickerControllerSourceTypeCamera;
                imagePickerController.showsCameraControls = YES;
            }
            break;
        case 1:
            imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        default:
            return;
            break;
    }
    CGRect rect = [self.view convertRect:updataContractBTN.frame fromView:updataContractBTN.superview];
    [imagePopoverController presentPopoverFromRect:rect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
}
#pragma mark UIImagePickerControllerDelegate event handler

//图片选取器
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *saveImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    
    [imagePopoverController  dismissPopoverAnimated:YES];
    
    //上传
    [self savePicToAPI:saveImage];
}
-(void)savePicToAPI:(UIImage *)myImage
{
    if (!myImage) {
        [JKAlert showMessage:@"请先选择图片!"];
        return;
    }
    UploadContractViewController *updata = [[UploadContractViewController alloc]initWithBlock:^{
        NSString *str = [self.webView stringByEvaluatingJavaScriptFromString:@"checkPactUploadFlag()"];
        [self.webView stringByEvaluatingJavaScriptFromString: str];
        
    }];
    updata.contractPreviewimg = myImage;
    updata.dicData = _dicData;
    [self presentModelDetail:updata];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [imagePopoverController  dismissPopoverAnimated:YES];
}
#pragma mark - UIWebViewDelegate

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    self.context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
     __block typeof(self) weakSelf = self;
    self.context[@"isRegistered"] =
    ^(NSString *str)
    {
        JKAlert *alert = [JKAlert alertWithTitle:@"提示" andMessage:@"用户不存在，是否注册"];
        [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            NSString *str = [weakSelf.webView stringByEvaluatingJavaScriptFromString:@"registeredConnectUser();"];
            [weakSelf.webView stringByEvaluatingJavaScriptFromString: str];
        }];
        [alert addCancleButtonWithTitle:@"取消" handler:^(JKAlertItem *item) {
            
        }];
        [alert show];
        
    };

}

-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
    [self.coverView removeFromSuperview];
    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 70, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
    self.coverView.backgroundColor = [UIColor blackColor];
    self.coverView.alpha = 0;
    [self.view addSubview:self.coverView];
    
    modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, self.view.height, modelDetailViewController.view.width, modelDetailViewController.view.height);
    [self.view addSubview:modelDetailViewController.view];
    [self addChildViewController:modelDetailViewController];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.coverView.alpha = 0.55;
        modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, (self.view.height-modelDetailViewController.view.height)/2, modelDetailViewController.view.width, modelDetailViewController.view.height);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
