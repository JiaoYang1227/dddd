//
//  ActivationViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
@protocol ActivationJSExport <JSExport>

@end


@interface ActivationViewController : BaseViewController

@property(assign,nonatomic)BOOL isHistory;
@property (weak, nonatomic) IBOutlet UIButton *HistoryBTN;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property(strong,nonatomic)  UIView *coverView;
@property (strong, nonatomic) JSContext *context;
@end
