//
//  FAQViewController.m
//  DSPA2015
//
//  Created by sun on 16/9/12.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "FAQViewController.h"
#import "FAQListViewController.h"
@interface FAQViewController (){
    NSArray *_typeCodeArr;
}

@end

@implementation FAQViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _typeCodeArr = [NSArray arrayWithObjects:@"01",@"02",@"03",@"04",@"05",@"06",@"07", nil];
}
- (IBAction)FAQListONCLICK:(UIButton *)sender {
    FAQListViewController *FAQ = [[FAQListViewController alloc]init];
    FAQ.type = [_typeCodeArr objectAtIndex:sender.tag];
    [self.navigationController pushViewController:FAQ animated:YES];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
