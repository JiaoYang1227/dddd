//
//  FAQSecondCell.m
//  DSPA2015
//
//  Created by Cluy on 16/7/21.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "FAQSecondCell.h"

@implementation FAQSecondCell

//- (void)awakeFromNib {
//    // Initialization code
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)configCellData:(FAQ *)model isFromLocal:(BOOL)isFromLocal{
    self.answerLabel.text = model.answer;
    self.badButton.selected = NO;
    self.goodBtn.selected = NO;
    if ([model.isagree isEqualToString:@"0"]) {
        self.badButton.selected = YES;
        self.goodBtn.selected = NO;
    }
    if ([model.isagree isEqualToString:@"1"]) {
        self.badButton.selected = NO;
        self.goodBtn.selected = YES;
    }
    if (isFromLocal == YES) {
        self.goodBtn.userInteractionEnabled = NO;
        self.badButton.userInteractionEnabled = NO;
    }else{
        self.goodBtn.userInteractionEnabled = YES;
        self.badButton.userInteractionEnabled = YES;
        if([model.isagree isEqualToString:@"1"]){
            self.goodBtn.selected = YES;
            self.badButton.selected = NO;
            self.goodBtn.userInteractionEnabled = NO;
            self.badButton.userInteractionEnabled = NO;
        }
        if([model.isagree isEqualToString:@"0"]){
            self.goodBtn.selected = NO;
            self.badButton.selected = YES;
            self.goodBtn.userInteractionEnabled = NO;
            self.badButton.userInteractionEnabled = NO;
        }
    }
    
    
}
@end
