//
//  FAQSecondCell.h
//  DSPA2015
//
//  Created by Cluy on 16/7/21.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FAQ.h"
@interface FAQSecondCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *answerLabel;
@property (weak, nonatomic) IBOutlet UIButton *goodBtn;
@property (weak, nonatomic) IBOutlet UIButton *badButton;
- (void)configCellData:(FAQ *)model isFromLocal:(BOOL)isFromLocal;
@end
