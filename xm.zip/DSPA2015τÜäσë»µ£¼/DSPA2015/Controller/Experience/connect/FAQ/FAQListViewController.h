//
//  FAQListViewController.h
//  DSPA2015
//
//  Created by Cluy on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface FAQListViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic)BOOL isFromLocal; //是否获取的本地数据
@property (nonatomic,strong) NSArray *listArr;
@property (nonatomic)float cellHeight;//cell动态高度
@property (weak, nonatomic) IBOutlet UITableView *listTable;
@property (weak, nonatomic) IBOutlet BorderTextField *searchWord;
@property (strong,nonatomic)NSString *type;
@end
