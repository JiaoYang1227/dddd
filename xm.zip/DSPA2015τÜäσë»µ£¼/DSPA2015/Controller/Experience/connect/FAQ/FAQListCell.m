//
//  FAQListCell.m
//  DSPA2015
//
//  Created by Cluy on 16/7/20.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "FAQListCell.h"
#import "AppDelegate.h"
#import "UIImageView+WebCache.h"

@implementation FAQListCell

//- (void)awakeFromNib {
//    // Initialization code
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


- (IBAction)goodBtnTouched:(id)sender {
}

- (IBAction)badButtonTouched:(id)sender {
}

- (void)configCellData:(FAQ *)model isFromLocal:(BOOL)isFromLocal{
    self.answerLabel.text = model.answer;
    
    self.badButton.selected = NO;
    self.goodBtn.selected = NO;
    if ([model.isagree isEqualToString:@"0"]) {
        self.badButton.selected = YES;
        self.goodBtn.selected = NO;
    }
    if ([model.isagree isEqualToString:@"1"]) {
        self.badButton.selected = NO;
        self.goodBtn.selected = YES;
    }
    
    if (![model.imagepath isEqual:[NSNull null]]&& [model.imagepath length]>0) {
        NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
        [self.questionImgView sd_setImageWithURL:[NSURL URLWithString:[baseInterface stringByAppendingPathComponent:model.imagepath]] placeholderImage:[UIImage imageNamed:@"FQA_cell_default.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        }];
    }
    //        else{
    //            self.questionImgView.frame = CGRectMake(self.questionImgView.frame.origin.x,  self.questionImgView.frame.origin.y, self.questionImgView.frame.size.width, 0);
    //            self.answerViewUpImg.frame = CGRectMake(self.answerViewUpImg.frame.origin.x,  self.questionImgView.frame.origin.y, self.answerViewUpImg.frame.size.width, self.answerViewUpImg.frame.size.height);
    //            self.answerView.frame = CGRectMake(self.answerView.frame.origin.x,  self.answerViewUpImg.frame.origin.y + self.answerViewUpImg.frame.size.height, self.answerView.frame.size.width, self.answerView.frame.size.height);
    //        }
    
    
    
    if (isFromLocal == YES) {
        self.goodBtn.userInteractionEnabled = NO;
        self.badButton.userInteractionEnabled = NO;
    }else{
        self.goodBtn.userInteractionEnabled = YES;
        self.badButton.userInteractionEnabled = YES;
        if([model.isagree isEqualToString:@"1"]){
            self.goodBtn.selected = YES;
            self.badButton.selected = NO;
            self.goodBtn.userInteractionEnabled = NO;
            self.badButton.userInteractionEnabled = NO;
        }
        if([model.isagree isEqualToString:@"0"]){
            self.goodBtn.selected = NO;
            self.badButton.selected = YES;
            self.goodBtn.userInteractionEnabled = NO;
            self.badButton.userInteractionEnabled = NO;
        }
    }
    
    
}
@end
