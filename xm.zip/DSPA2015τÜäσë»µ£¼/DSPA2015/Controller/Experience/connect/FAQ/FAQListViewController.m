//
//  FAQListViewController.m
//  DSPA2015
//
//  Created by Cluy on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "FAQListViewController.h"
#import "FAQ.h"
#import "UIImageView+WebCache.h"
#import "JKToast.h"
#import "FAQListCell.h"
#import "FAQSecondCell.h"

#define lineSpace 20
#define questionWidth 981-28
#define answerWidth 720
#define imgWidth 209
@interface FAQListViewController ()

@end

@implementation FAQListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _listArr = [[NSArray alloc]init];
    self.isFromLocal = NO;
    self.listTable.delegate = self;
    self.listTable.dataSource = self;
    self.listTable.showsVerticalScrollIndicator = NO;
    [self.listTable reloadData];
    [self loadDataWithWork:nil];
    
}
- (IBAction)searchAction:(id)sender {
    [self.view endEditing:YES];
    [self loadDataWithWork: [_searchWord.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]];
}
-(NSArray *)convertFAQ:(NSArray*)list{
    NSMutableArray * quoteList = [[NSMutableArray alloc]init];
    for (NSDictionary *item in list) {
        FAQ *faq = [FAQ objectFromDictionary:item];
        [quoteList addObject:faq];
    }
    return quoteList;
}
-(void)loadDataWithWork:(NSString *)searchWord {
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    if (searchWord.length>0) {
        [param setObject:searchWord forKey:@"question"];
    }
    [param setObject:self.type?:@"" forKey:@"type"];
    
    [FAQ FAQListWithOption:param Success:^(NSArray *collection, id responseObject) {
        _isFromLocal = NO;
        _listArr = [[NSArray alloc]init];
        //todo 写入数据库
        [FAQ dropFAQTable];
        [FAQ createFAQTable:collection type:self.type];
        _listArr = [self convertFAQ:collection];
        [_listTable reloadData];
        
    } Failure:^(NSError *error) {
        [JKToast toastWithText:@"请求失败，将为您拉取本地数据！"];
        _isFromLocal = YES;
        _listArr = [self convertFAQ:[FAQ FAQListWithSearchWord:searchWord type:self.type]];
        [_listTable reloadData];
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark -
#pragma mark Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return  10;
}
- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section;{
    UIView * sectionView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 10)];
    [sectionView setBackgroundColor:[UIColor whiteColor]];
    return sectionView;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    FAQ *faq =[_listArr objectWithIndex:section];
    NSString *sectionTitle = faq.question;
    if (sectionTitle == nil) {
        return  nil;
    }
    UIView * sectionView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 50)];
    [sectionView setBackgroundColor:[UIColor colorWithRed:249/255.0 green:249/255.0 blue:249/255.0 alpha:249/255.0]];
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 2, 50)];
    [lineView setBackgroundColor:[UIColor colorWithRed:171/255.0 green:21/255.0 blue:23/255.0 alpha:249/255.0]];
    [sectionView addSubview:lineView];
    
    UILabel * label = [[UILabel alloc] init];
    label.frame = CGRectMake(60, 0, 841, 50);
    label.backgroundColor = [UIColor clearColor];
    label.font=[UIFont boldSystemFontOfSize:15];
    label.textColor = [UIColor blackColor];
    label.text = sectionTitle;
    [sectionView addSubview:label];
    
    UIImageView *expendIMG = [[UIImageView alloc]initWithFrame:CGRectMake(910, 10, 34, 30)];
    if (faq.isExpend == YES) {
        [expendIMG setImage:[UIImage imageNamed:@"FAQ_down.png"]];
    }else{
        [expendIMG setImage:[UIImage imageNamed:@"FAQ_up.png"] ];
    }
    [sectionView addSubview:expendIMG];
    
    UIButton *expendBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 50)];
    expendBtn.tag = section;
    [expendBtn addTarget:self action:@selector(SectionBtnTouched:) forControlEvents:UIControlEventTouchUpInside];
    [sectionView addSubview:expendBtn];
    
    return sectionView;
}
-(IBAction)SectionBtnTouched:(UIButton *)sender
{
    
    FAQ *faq =[_listArr objectWithIndex:sender.tag];
    if (faq.isExpend == YES) {
        faq.isExpend = NO;
    }else{
        faq.isExpend = YES;
        [FAQ isFAQClick:faq.id
                Success:^(id responseObject) {
                } Failure:^(NSError *error) {
                }];
    }
    [_listTable reloadData];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    FAQ *faq =[_listArr objectWithIndex:indexPath.section];
    if (![faq.imagepath isEqual:[NSNull null]]&& [faq.imagepath length]>0){
        return 498;
    }else{
        return 150;
    }
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return  [_listArr count];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    FAQ *faq =[_listArr objectWithIndex:section];
    if (faq.isExpend == YES) {
        return 1;
    }else{
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FAQ *faq =[_listArr objectWithIndex:indexPath.section];
    
    if (![faq.imagepath isEqual:[NSNull null]]&& [faq.imagepath length]>0){
        NSString * identifier =@"FAQListCell";
        UINib * nib = [UINib nibWithNibName:@"FAQListCell" bundle:nil];
        [tableView registerNib:nib forCellReuseIdentifier:identifier];
        
        FAQListCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.goodBtn.tag = [[NSString stringWithFormat:@"1001%zd",indexPath.section]intValue];
        [ cell.goodBtn addTarget:self action:@selector(IsagreeBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.badButton.tag = [[NSString stringWithFormat:@"1002%zd",indexPath.section]intValue];
        [cell.badButton addTarget:self action:@selector(IsagreeBtn:) forControlEvents:UIControlEventTouchUpInside];
        [cell configCellData:faq isFromLocal:_isFromLocal];
        return cell;
    }else{
        NSString * identifier =@"FAQSecondCell";
        UINib * nib = [UINib nibWithNibName:@"FAQSecondCell" bundle:nil];
        [tableView registerNib:nib forCellReuseIdentifier:identifier];
        
        FAQSecondCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        cell.goodBtn.tag = [[NSString stringWithFormat:@"1001%zd",indexPath.section]intValue];
        [ cell.goodBtn addTarget:self action:@selector(IsagreeBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.badButton.tag = [[NSString stringWithFormat:@"1002%zd",indexPath.section]intValue];
        [cell.badButton addTarget:self action:@selector(IsagreeBtn:) forControlEvents:UIControlEventTouchUpInside];
        [cell configCellData:faq isFromLocal:_isFromLocal];
        return cell;
    }
}
-(void)IsagreeBtn:(UIButton*)sender{
    UIButton *btn = sender;
    NSString *tag = [NSString stringWithFormat:@"%ld",(long)btn.tag];
    NSString *indexpath = [tag substringFromIndex:4];
    BOOL isagree = NO;
    if ([[tag substringToIndex:4]intValue] -1000 == 1) {
        isagree = YES;
    };
    FAQ *faq = [_listArr objectWithIndex:[indexpath integerValue]];
    faq.isagree = [NSString stringWithFormat:@"%d",isagree];
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setObject:faq.id?:@"" forKey:@"questionid"];
    [param setObject:faq.isagree?:@"" forKey:@"isagree"];
    [FAQ FAQisAgreeWithOption:param Success:^(id responseObject) {
        if ([[responseObject objectForKey:KEY_SUCCESS]boolValue]) {
            [JKToast toastWithText:@"操作成功！"];
            //将更改的数据插入数据库
            [FAQ UpdateFAQItem:faq];
            NSIndexPath *path =[NSIndexPath indexPathForRow:0 inSection:[indexpath integerValue]];
            FAQListCell * cell  = [_listTable cellForRowAtIndexPath:path];
            [cell configCellData:faq isFromLocal:_isFromLocal];
        }else{
            [JKToast toastWithText:@"操作失败！"];
        }
    } Failure:^(NSError *error) {
        
    }];
}
- (float) getHeightWithText:(NSString*)text withWidth:(int)with
{
    if (text.length == 0)
    {
        return 30;
    }
    CGSize size = CGSizeMake(with, CGFLOAT_MAX);
    NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:14.0f]};
    CGSize labelsize = [text boundingRectWithSize:size options:
                        NSStringDrawingTruncatesLastVisibleLine |
                        NSStringDrawingUsesLineFragmentOrigin |
                        NSStringDrawingUsesFontLeading
                                       attributes:attribute context:nil].size;
    
    return labelsize.height<30?30:labelsize.height;
}




@end
