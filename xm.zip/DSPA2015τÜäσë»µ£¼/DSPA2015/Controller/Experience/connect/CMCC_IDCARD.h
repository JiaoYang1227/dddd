//
//  CMCC_IDCARD.h
//
//  Created by ZhangLi on 15-5-4.
//  Copyright (c) 2015 Routon. All rights reserved.


#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>


@protocol CMCC_IDCARD_DELEGATE <NSObject, CBCentralManagerDelegate>

@optional

#pragma mark 处理成功/失败
- (void) didOpretionSuc:(NSDictionary *) dic;
- (void) didOpretionFail:(NSDictionary *) dic;


- (void) centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral;
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error;

@end



@protocol CMCC_IDCARD <NSObject>
@required

#pragma mark 初始化/连接
- (id) initWithDelegate:(id<CMCC_IDCARD_DELEGATE>)delegate;
- (id) initWithDelegate:(id<CMCC_IDCARD_DELEGATE>)delegate withCBCentralManager:(CBCentralManager *)centralManager;

- (void) connect:(CBPeripheral *)peripheral;
- (void) disconnect;
- (BOOL) isConnected;
- (void) connectByUUID:(NSString *) uuid;
- (void) connectByBTName:(NSString *) BTName;
- (void) connectByBTMAC:(NSString *) BTMAC;


#pragma mark 二代证身份识别设备功能域接口
- (void) openIDCard;
- (void) closeIDCard;
- (void) getIDCardVersion;
- (void) initialIDCard;
- (void) getIdCardInfo;
- (void) getBTMAC;
@end

@interface CMCC_IDCARD_JL_4 : NSObject  <CBCentralManagerDelegate, CMCC_IDCARD>
//@interface RoutonBTService: NSObject  <CBCentralManagerDelegate, CMCC_IDCARD>

    
    
@end
