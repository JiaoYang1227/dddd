//
//  AuthenticationViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/6.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "AuthenticationViewController.h"
#import "CMCC_IDCARD.h"
@interface AuthenticationViewController ()
@property (weak, nonatomic) IBOutlet UITextView *TipsText;
@property (strong)NSMutableArray    *foundPeripherals;
@property (nonatomic, retain) CBCentralManager *centralManager;
@property (strong)CBPeripheral    *Foundperipheral;
@property (strong)id<CMCC_IDCARD> IDCardService ;
@end

@implementation AuthenticationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _foundPeripherals = [[NSMutableArray alloc] init];
    [_findtable reloadData];
    _TipsText.text=@"";
    _Foundperipheral=nil;
    _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    if (_IDCardService)
    {
        _TipsText.text=@"disconnect...";
        [_IDCardService disconnect];
        
        
    }
    [_foundPeripherals removeAllObjects];
    [_findtable reloadData];
    _TipsText.text=@"Finding device...";
    
    [self scanningForDevice];
}
- (IBAction)GetBTMAC:(id)sender {
    if (_IDCardService)
    {
        _TipsText.text=@"getBTMAC...";
        [_IDCardService getBTMAC];
    }
    else
        _TipsText.text=@"Pls Connect First!";
}
- (IBAction)ReadCard:(id)sender {
    if (_IDCardService)
    {
        _TipsText.text=@"getIdCardInfo...";
        [_IDCardService getIdCardInfo];
//         [_IDCardService openIDCard];
//        [NSTimer scheduledTimerWithTimeInterval:3 target: self selector:@selector(getIdCardInfo) userInfo:nil repeats:NO];
    }
    else
        _TipsText.text=@"Pls Connect First!";
}
- (IBAction)OpenIDCard:(id)sender {
    if (_IDCardService)
    {
        _TipsText.text=@"openIDCard...";
        [_IDCardService openIDCard];
    }
    else
        _TipsText.text=@"Pls Connect First!";
}
- (IBAction)DisCon:(id)sender {
    if (_IDCardService)
    {
        _TipsText.text=@"disconnect...";
        [_IDCardService disconnect];
        
        
    }
    else
        _TipsText.text=@"Pls Connect First!";
    
}
- (IBAction)ConByUUID:(id)sender {
    Class serviceClass =  NSClassFromString(@"RoutonBTService");
    NSString *DEVICE_Name = @"j0003036630";
    if (!serviceClass || ![serviceClass conformsToProtocol:@protocol(CMCC_IDCARD)]) {
        NSLog(@"不支持该设备!");
        return;
    }
    
    if (_IDCardService==nil)
        _IDCardService = [[serviceClass alloc] initWithDelegate:self];
    
    if (_IDCardService)
    {
        if (![_IDCardService isConnected])
        {
            _TipsText.text=@"connectByUUID...";
            //            [_IDCardService connectByUUID:DEVICE_MAC];
            [_IDCardService connectByBTName:DEVICE_Name];
        }
        else
            _TipsText.text=@"Connected Already!";
    }
    else
        _TipsText.text=@"Can't Find Service!";
    //NSString * DEVICE_MAC=@"000E0B006E88";
    
    
}
- (IBAction)FindDevice:(id)sender {
    if (_IDCardService)
    {
        _TipsText.text=@"disconnect...";
        [_IDCardService disconnect];
        
        
    }
    [_foundPeripherals removeAllObjects];
    [_findtable reloadData];
    _TipsText.text=@"Finding device...";
    
    [self scanningForDevice];
    
}
#pragma mark -
#pragma mark CBCentralMangerDelegate
//CBCentralMangerDelegate
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    static CBCentralManagerState previousState = -1;
    
    switch ([_centralManager state]) {
        case CBCentralManagerStatePoweredOff:
        {
            break;
        }
            
        case CBCentralManagerStateUnsupported:
        {
            break;
        }
            
        case CBCentralManagerStateUnauthorized:
        {
            /* Tell user the app is not allowed. */
            break;
        }
            
        case CBCentralManagerStateUnknown:
        {
            /* Bad news, let's wait for another event. */
            break;
        }
            
        case CBCentralManagerStatePoweredOn:
        {
            NSLog(@"BluetoothMessageCenter: CBCentralManagerStatePoweredOn");
            [self scanningForDevice];
            
            break;
        }
            
        case CBCentralManagerStateResetting:
        {
            
            break;
        }
    }
    
    previousState = [_centralManager state];
}
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    
    
    NSObject * macvalue=[advertisementData objectForKey:@"kCBAdvDataManufacturerData"];
    if (macvalue!=nil)
    {
        NSLog(@"MAC=%@",macvalue);
    }
    //    if ([[peripheral name] isEqualToString:RoutonDeviceName]||[[peripheral name] isEqualToString:RoutonDeviceName2])
    {
        _Foundperipheral=peripheral;
        
        //CBAdvertisementDataManufactureDataKey
        if (![_foundPeripherals containsObject:peripheral])
        {
            [_foundPeripherals addObject:peripheral];
            NSLog(@"BluetoothMessageCenter: didDiscoverPeripheral found new peripheral");
            _TipsText.text=@"Found Device!";
            //if (messageDelegate!=nil) {
            //[messageDelegate findPeripheral:peripheral];
            //}
            [_findtable reloadData];
        }
        // [self stopScanning];
    }
}
#pragma mark -
#pragma mark own methods
//start scanning for the device
- (void) scanningForDevice
{
    
    [_centralManager scanForPeripheralsWithServices:nil options:nil];
    [NSTimer scheduledTimerWithTimeInterval:5 target: self selector:@selector(stopScanning) userInfo:nil repeats:NO];
    
    
}

//stop scanning for the device
- (void) stopScanning
{
    [_centralManager stopScan];
    NSLog(@"BluetoothMessageCenter: Stop Scanning for devices");
    if (_Foundperipheral==nil)
    {
        
        NSLog(@"Device Not Found!");
        _TipsText.text=@"Device Not Found!";
        
    }
    
    
}

#pragma mark 处理成功/失败
- (void) didOpretionSuc:(NSDictionary *) dic
{
    NSMutableString *Msg=[[NSMutableString alloc] init];
    NSLog(@"didOpretionSuc");
    for (id key in dic)
    {
        [Msg appendFormat:[NSString stringWithFormat:@"%@:%@%@",(NSString *)key ,(NSString *)[dic objectForKey:key],@"\r\n"]];
    }
    if ([(NSString *)[dic objectForKey:@"openIDCard"]isEqual:@"Success"]) {
        
        
    }
    _TipsText.text=Msg;
}
- (void) didOpretionFail:(NSDictionary *) dic
{
    NSLog(@"didOpretionFail");
    NSMutableString *Msg=[[NSMutableString alloc] init];
    for (id key in dic)
    {
        [Msg appendFormat:[NSString stringWithFormat:@"%@:%@,",(NSString *)key ,(NSString *)[dic objectForKey:key]]];
    }
    _TipsText.text=Msg;
   
}


- (void) centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"didConnectPeripheral peripheral name=%@",[peripheral name]);
    _TipsText.text=@"Connect OK!";
    bool isc=[_IDCardService isConnected];
    NSLog(@"isConnected %@",isc?@"YES":@"NO");
    if (isc) {
//        [_IDCardService openIDCard];
        //        [_IDCardService getIdCardInfo];
    }
}
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"didDisconnectPeripheral");
    _TipsText.text=@"Disconnect OK!";
    _IDCardService=nil;
    bool isc=[_IDCardService isConnected];
    NSLog(@"isConnected %@",isc?@"YES":@"NO");
}
#pragma mark -
#pragma mark - TableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [_foundPeripherals count];

    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCell"];
    if(cell == nil){
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyCell"];
    }
    CBPeripheral* peripheral = (CBPeripheral*)[_foundPeripherals objectAtIndex:indexPath.row];
    //CFStringRef add=CFUUIDCreateString(nil, );
    NSString *address = [peripheral name];
    cell.textLabel.text = address;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CBPeripheral	*peripheral;
    
    NSInteger		row	= [indexPath row];
    
    
    peripheral = (CBPeripheral*)[_foundPeripherals objectAtIndex:row];
    
    if (peripheral!=nil)
    {
        
        
        NSString *peripheralName = [peripheral name];
        //NSString * delename=[peripheralName substringToIndex:9];
        //NSString *serviceName = [NSString stringWithFormat:@"CMCC_%@", peripheralName];
        NSString *serviceName = @"RoutonBTService";//[NSString stringWithFormat:@"CMCC_%@", peripheralName];//;@"HMSoft"
        Class serviceClass = NSClassFromString(serviceName);//@"RoutonBTService";
        if (!serviceClass || ![serviceClass conformsToProtocol:@protocol(CMCC_IDCARD)]) {
            NSLog(@"不支持该设备[%@]!", peripheralName);
            _TipsText.text=@"Can't Find Service!";
            return;
        }
        if (_IDCardService==nil)
        {
            _IDCardService = [[serviceClass alloc] initWithDelegate:self];
           
        }
        else
            _TipsText.text=@"Pls Connect First!";
        
        if (![_IDCardService isConnected])
        {
            _TipsText.text=@"connect:peripheral...";
            [_IDCardService connect:peripheral];
        }
        else
            _TipsText.text=@"Connected Already!";
        _TipsText.text=@"getIdCardInfo...";
        [NSTimer scheduledTimerWithTimeInterval:4 target: self selector:@selector(openIDCard) userInfo:nil repeats:NO];
        [NSTimer scheduledTimerWithTimeInterval:7 target: self selector:@selector(getIdCardInfo) userInfo:nil repeats:NO];
    }
    else
    {
        NSLog(@"Device Not Found!");
        _TipsText.text=@"Device Not Found!";
    }
    
    
    
}
-(void)openIDCard{
    if (_IDCardService)
    {
        _TipsText.text=@"openIDCard...";
        [_IDCardService openIDCard];
    }
    else
        _TipsText.text=@"Pls Connect First!";
}
-(void)getIdCardInfo{
    if (_IDCardService)
    {
        _TipsText.text=@"getIdCardInfo...";
        [self.IDCardService getIdCardInfo];
    }
    else
        _TipsText.text=@"Pls Connect First!";
    
}
- (IBAction)validationTouched:(id)sender {
//    urlStr = [NSString stringWithFormat:@"document.getElementById('%@').submit();",self.testDrive.suggestTypeid];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
