//
//  ConnectViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "ConnectViewController.h"
#import "ActivationViewController.h"
#import "FAQViewController.h"
#import "PropagandaShowViewController.h"
@interface ConnectViewController ()

@end

@implementation ConnectViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

//用户激活
- (IBAction)AuthenticationTouched:(id)sender {
    [CBTracking trackEvent:@"Audi connect_用户激活"];
    [self.navigationController pushViewController:[[ActivationViewController alloc]init] animated:YES];
}
//宣传展示
- (IBAction)propagandaShowTouched:(id)sender {
    [CBTracking trackEvent:@"Audi connect_宣传展示"];
    [self.navigationController pushViewController:[[PropagandaShowViewController alloc]init] animated:YES];
}
//FQA
- (IBAction)FAQTouched:(id)sender {
    [CBTracking trackEvent:@"Audi connect_常见问题"];
    FAQViewController *FAQ = [[FAQViewController alloc]init];
    [self.navigationController pushViewController:FAQ animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
