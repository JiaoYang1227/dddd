//
//  PropagandaShowCell.m
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "PropagandaShowCell.h"

@implementation PropagandaShowCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
