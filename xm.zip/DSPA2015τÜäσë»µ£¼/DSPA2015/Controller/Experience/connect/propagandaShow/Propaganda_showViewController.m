//
//  Propaganda_showViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "Propaganda_showViewController.h"
#import "FileManager.h"
#import "PropagandaShowCell.h"
#import "AudiConnectShow.h"
#import "UIImageView+AFNetworking.h"
#define COLLECTIONVIEW_CELL_IDENTIFIER @"PropagandaShowCell"
#import "Propaganda_showViewDetailViewController.h"
#import "JKToast.h"
@interface Propaganda_showViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>{
    __weak IBOutlet UICollectionView *_showListCollectionView;
}
@property (nonatomic, strong) NSMutableArray *showDataList;
@end

@implementation Propaganda_showViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_showListCollectionView registerNib:[UINib nibWithNibName:@"PropagandaShowCell" bundle:nil] forCellWithReuseIdentifier:COLLECTIONVIEW_CELL_IDENTIFIER];
//    UICollectionViewFlowLayout * FlowLayout = [[UICollectionViewFlowLayout alloc]init];
//    [FlowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
//    FlowLayout.itemSize = CGSizeMake(288 , 187);
    self.showDataList = (NSMutableArray *)[AudiConnectShow findAllDownListWithfiletype:@"documentFiles"];
    if (self.showDataList.count == 0) {//没有资源提示
        [_promptImageView setImage:[UIImage imageNamed:@"connect_PromptDownload.png"]];
    }else{
        [_showListCollectionView reloadData];
    }

}
#pragma mark -collectionView delegate && dataSoutce
- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.showDataList.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = COLLECTIONVIEW_CELL_IDENTIFIER;
    PropagandaShowCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    NSDictionary *dic = [self.showDataList objectWithIndex:indexPath.row];
    cell.nameLabel.text = [dic stringForKey:@"filename"];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(170, 187);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 2, 0);
}

- (void) collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.showDataList.count>=indexPath.row+1) {
        NSDictionary *dic = [self.showDataList objectWithIndex:indexPath.row];
        Propaganda_showViewDetailViewController *detail = [[Propaganda_showViewDetailViewController alloc]init];
        NSArray *arr = [[dic objectForKey:@"filepath"] componentsSeparatedByString:@"."];
        detail.filename = [dic stringForKey:@"filename"];
        if (arr.count>=1) {
            detail.fileType = (NSString *)[arr objectAtIndex:1];
        }else{
            [JKToast toastWithText:@"没有找到该资源文件"];
            return;
        }
        [self .navigationController pushViewController:detail animated:YES];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}
@end
