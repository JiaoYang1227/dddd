//
//  Propaganda_showViewDetailViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "Propaganda_showViewDetailViewController.h"
#import "JKToast.h"
@interface Propaganda_showViewDetailViewController ()
@property (weak, nonatomic) IBOutlet UIWebView *showWeb;

@end

@implementation Propaganda_showViewDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *path = [FileManager documentsPath:[NSString stringWithFormat:@"/audiconnectshow/%@/%@.%@",self.filename,self.filename,self.fileType]];
    if (path == nil) {
        [JKToast toastWithText:@"没有找到该资源文件"];
        return;
    }
    NSURL *url = [NSURL fileURLWithPath:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [_showWeb loadRequest:request];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [CBTracking startTracResource:self.filename?:@"" withModuleName:@"Audi connect_宣传展示_文档"];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [CBTracking endTracResource:self.filename?:@"" withModuleName:@"Audi connect_宣传展示_文档"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

@end
