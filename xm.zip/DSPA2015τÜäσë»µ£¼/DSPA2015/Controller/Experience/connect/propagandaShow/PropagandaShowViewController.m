//
//  PropagandaShowViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/11.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "PropagandaShowViewController.h"
#import "Propaganda_videoViewController.h"
#import "Propaganda_showViewController.h"
@interface PropagandaShowViewController ()

@end

@implementation PropagandaShowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)showTouched:(id)sender {
    [CBTracking trackEvent:@"Audi connect_宣传展示_文档"];
    [self.navigationController pushViewController:[[Propaganda_showViewController alloc]init] animated:YES];
}
- (IBAction)videoTouched:(id)sender {
    [CBTracking trackEvent:@"Audi connect_宣传展示_视频"];
    [self.navigationController pushViewController:[[Propaganda_videoViewController alloc]init] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
