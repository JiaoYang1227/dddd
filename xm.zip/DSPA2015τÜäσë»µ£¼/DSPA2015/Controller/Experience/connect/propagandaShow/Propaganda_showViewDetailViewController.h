//
//  Propaganda_showViewDetailViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface Propaganda_showViewDetailViewController : BaseViewController
@property (nonatomic,strong)NSString *filename;
@property (nonatomic,strong)NSString *fileType;
@end
