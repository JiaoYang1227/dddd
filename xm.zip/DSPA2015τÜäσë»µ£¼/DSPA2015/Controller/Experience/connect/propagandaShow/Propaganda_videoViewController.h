//
//  Propaganda_videoViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface Propaganda_videoViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIImageView *promptImageView;
@end
