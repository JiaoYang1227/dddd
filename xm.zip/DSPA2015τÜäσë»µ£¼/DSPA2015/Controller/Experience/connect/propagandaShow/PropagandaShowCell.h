//
//  PropagandaShowCell.h
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PropagandaShowCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@end
