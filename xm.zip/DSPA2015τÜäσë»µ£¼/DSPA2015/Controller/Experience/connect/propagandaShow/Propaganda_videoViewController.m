//
//  Propaganda_videoViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/13.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "Propaganda_videoViewController.h"
#import "XTMoviePlayerController.h"
#import "FileManager.h"
#import "CarVideoListCell.h"
#import "AudiConnectShow.h"
#import "UIImageView+AFNetworking.h"
#import "JKToast.h"
#import <AVFoundation/AVFoundation.h>
#define COLLECTIONVIEW_CELL_IDENTIFIER @"CarVideoListCell"
@interface Propaganda_videoViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>{
    __weak IBOutlet UICollectionView *_videoListCollectionView;
    
    XTMoviePlayerController *player;
}
@property (nonatomic, strong) NSMutableArray *videosDataList;
@end

@implementation Propaganda_videoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_videoListCollectionView registerNib:[UINib nibWithNibName:@"CarVideoListCell" bundle:nil] forCellWithReuseIdentifier:COLLECTIONVIEW_CELL_IDENTIFIER];
    UICollectionViewFlowLayout * FlowLayout = [[UICollectionViewFlowLayout alloc]init];
    [FlowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    FlowLayout.itemSize = CGSizeMake(310. , 200.);
    //documentFiles,videoFiles
    self.videosDataList = (NSMutableArray *)[AudiConnectShow findAllDownListWithfiletype:@"videoFiles"];
    if (self.videosDataList.count == 0) {//没有资源提示
        [_promptImageView setImage:[UIImage imageNamed:@"carVideo_PromptDownload.png"]];
    }else{
        [_videoListCollectionView reloadData];
    }
}
#pragma mark -collectionView delegate && dataSoutce
- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.videosDataList.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = COLLECTIONVIEW_CELL_IDENTIFIER;
    CarVideoListCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    NSDictionary *dic = [self.videosDataList objectWithIndex:indexPath.row];
    cell.title.text = [dic stringForKey:@"filename"];
    [cell.MainImage setImageWithURL:[NSURL URLWithString:[dic stringForKey:@"imgUrl"]] placeholderImage:nil];
    cell.time.text = [dic stringForKey:@"videoDuration"];
     NSString *filepath = [FileManager documentsPath:[NSString stringWithFormat:@"/audiconnectshow/%@/%@.mp4",[dic stringForKey:@"filename"],[dic stringForKey:@"filename"]]];
    cell.time.text = [self getVideoTotalTime:filepath];
    return cell;
}
-(NSString *)getVideoTotalTime:(NSString *)path{
    NSURL *movieURL = [NSURL fileURLWithPath:path];
    NSDictionary *opts = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO]
                                                     forKey:AVURLAssetPreferPreciseDurationAndTimingKey];
    AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:movieURL options:opts];  // 初始化视频媒体文件
    long long  second = 0 ,minute=0;
    second = urlAsset.duration.value / urlAsset.duration.timescale; // 获取视频总时长,单位秒
    if (second >= 60) {
        long long index = second / 60;
        minute = index;
        second = second - index*60;
    }
    return [NSString stringWithFormat:@"%lld分钟%lld秒",minute,second];
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(310, 200);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 2, 0);
}

- (void) collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.videosDataList.count>=indexPath.row+1) {
        NSDictionary *dic = [self.videosDataList objectWithIndex:indexPath.row];
        NSString *fileName = [FileManager documentsPath:[NSString stringWithFormat:@"/audiconnectshow/%@/%@.mp4",[dic stringForKey:@"filename"],[dic stringForKey:@"filename"]]];
        if (fileName == nil) {
            [JKToast toastWithText:@"没有找到该资源文件"];
            return;
        }
        player = [[XTMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:fileName]];
        [player startPlaying:self withBlock:^{
            [CBTracking startTracResource:[dic stringForKey:@"filename"]?:@"" withModuleName:@"Audi connect_宣传展示_视频"];
            NSLog(@"start play movie");
        }];
        [player didPlayFinished:^{
            NSLog(@"finished");
            [CBTracking endTracResource:[dic stringForKey:@"filename"]?:@"" withModuleName:@"Audi connect_宣传展示_视频"];
        }];
        NSLog(@"%f,%f",player.moviePlayer.endPlaybackTime,player.moviePlayer.duration);
        [player didplayField:^(NSError *error) {
            //
        }];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
