//
//  OptionalEquipmentViewController.m
//  DSPA2015
//
//  Created by Cluy on 16/8/8.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "OptionalEquipmentViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "CalculationAndQuote.h"


@interface OptionalEquipmentViewController ()

@end

@implementation OptionalEquipmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURLRequest *request =[self formURL];
    self.webview .delegate = self;
    [self.webview loadRequest:request];
    
}

//格式化url
- (NSURLRequest *)formURL {
    NSString *serverUrlPrefix = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    NSMutableString *absUrl = [NSMutableString stringWithString:serverUrlPrefix];
    [absUrl appendString:@"getCarEquipInfo.do"];
    AFHTTPRequestSerializer *serializer = [AFHTTPRequestSerializer serializer];
    NSMutableURLRequest *request =[serializer requestWithMethod:@"GET" URLString:absUrl parameters:self.param error:nil];
    return request;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark ios8 多次点击webview下拉选框崩溃
-(void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion
{
    if (completion) {
        completion();
    }
    [super dismissViewControllerAnimated:NO completion:nil];
    
}
-(void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completion
{
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_USEC), dispatch_get_main_queue(),
    //                   ^{
    [super presentViewController:viewControllerToPresent animated:flag completion:completion];
    //                   });
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    return YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    // Undocumented access to UIWebView's JSContext
    self.context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    __weak typeof(self) weakSelf = self;
    // todo 选装装备 关闭页面
    self.context[@"OptionalEquipmentDismiss"] = ^(NSDictionary *dic){
        NSLog(@"%@", dic);
        [weakSelf dismissDSPAPopup:^{
    
        }];
    };
    
    // todo 保存并关闭页面
    self.context[@"OptionalEquipmentSaveDismiss"] = ^(NSDictionary *dic){
        NSLog(@"%@", dic);
        if (dic) {
            [weakSelf dismissDSPAPopup:^{
                weakSelf.optionalEquipmentCallback(dic);
            
                
            }];
        }
        
    };
}
-(void)OptionalEquipmentCallback:(OptionalEquipmentCallback)optionalEquipmentCallback{
    self.optionalEquipmentCallback = [optionalEquipmentCallback copy];
}


@end
