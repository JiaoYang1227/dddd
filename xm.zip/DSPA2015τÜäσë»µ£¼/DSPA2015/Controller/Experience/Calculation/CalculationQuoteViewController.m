//
//  CalculationDetailViewController.m
//  D-CARS
//
//  Created by Jakey on 15/10/23.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CalculationQuoteViewController.h"
#import "Util.h"
#import "AppDelegate.h"
#import "UIWebView+AFNetworking.h"
#import "Quotation.h"
#import "SalesLead.h"
#import "UIWebView+ToFile.h"
#import "PrintDetailViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "QRCodeViewController.h"
@interface CalculationQuoteViewController ()

@end

@implementation CalculationQuoteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.quoteWebView.delegate = self;
    if (_isFromHistory == YES){
        _saveQuoteBtn.hidden = YES;
        _importQuoteBtn.enabled = YES;
        _printBtn.enabled = YES;
        [_RQcodeBTN setEnabled:YES];
        [_RQcodeBTN setImage:[UIImage imageNamed:@"Quote_RQcode"] forState:UIControlStateNormal];
        
    }else{
        _saveQuoteBtn.hidden = NO;
        _importQuoteBtn.enabled = NO;
        _printBtn.enabled = YES;
        [_RQcodeBTN setImage:[UIImage imageNamed:@"Quote_RQcode_gray"] forState:UIControlStateNormal];
        [_RQcodeBTN setEnabled:NO];
        
    }
    if (_isImport == YES) {
        _importQuoteBtn.hidden = YES;
    }else{
        _importQuoteBtn.hidden = NO;
        
    }
    [self.quoteWebView loadRequest:self.myRequset];
    
    if ([self.myRequset HTTPBody]) {
        NSString *HTTPBody = [[NSString alloc] initWithData:[self.myRequset HTTPBody] encoding:NSUTF8StringEncoding];
        
        NSLog(@"HTTPBody:%@",HTTPBody);
    }
 
    
//    [self.quoteWebView loadRequest:self.myRequset progress:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
//
//    } success:^NSString *(NSHTTPURLResponse *response, NSString *HTML) {
//        return HTML;
//    } failure:^(NSError *error) {
//        NSString *res = [error.userInfo stringForKey:@"NSLocalizedDescription"];
//        if ([res rangeOfString:@"401"].location !=NSNotFound) {
//           JKAlert *alert =  [JKAlert showMessage:@"提示" message:@"您尚未登录或登录超时,请先登录!"];
//           [alert addCancleButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
//               [AppDelegate APP].user = nil;
//               //                [self dismissAllModalController];
//               [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
//           }];
//            [alert show];
//        }
//    }];
    self.title = @"报价单";
}

-(void)setMyRequset:(NSURLRequest *)myRequset{
    _myRequset = myRequset;
}
-(void)backButtonTouched:(id)sender{
    //刷新回调
    if(_shouldReloadParentData){
        _shouldReloadParentData(YES,nil);
    }
    [self dismissViewControllerAnimated:YES completion:nil];
   
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSString *requestString = [[[request URL]  absoluteString] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding ];
//    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    if ([requestString hasPrefix:@"myapp:"]) {
        NSLog(@"requestString:%@",requestString);
        //如果是自己定义的协议, 再截取协议中的方法和参数, 判断无误后在这里手动调用oc方法
        NSDictionary *param = [Util queryStringToDictionary:requestString];
        NSLog(@"get param:%@",[param description]);
        
        NSString *func = [param objectForKey:@"func"];
        
        if([func isEqualToString:@"getpriceid"])
        {
         
            NSLog(@"报价单保存 = %@",param);
            //如果有priceid  则将保存报价单置灰
            if ([param stringForKey:@"quotepriceid"]!=nil) {
                _priceid = [param stringForKey:@"quotepriceid"];
                _saveQuoteBtn.hidden = YES;
                SalesLead *saleslead = (SalesLead*)[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot;
                if (saleslead.projectID !=nil) {
                    [self importQuotation:nil];
                }else{
                    _importQuoteBtn.enabled = YES;
                }
                
            }
        }
        return NO;
    }
    //解决iframe打印一半问题！非常重要！！！！！！！！！！！！！！！！！！！！！！！！！！！
    if (_isPrint && [requestString rangeOfString:@"mark=ios"].location == NSNotFound && [requestString rangeOfString:@"vision/ssreport/htmls/"].location != NSNotFound) {
        requestString =  [requestString stringByAppendingString:@"&mark=ios"];
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:requestString]];
        urlRequest.HTTPBody = request.HTTPBody;
        PrintDetailViewController *print = [[PrintDetailViewController alloc]init];
        print.myRequset = urlRequest;
        [self presentDSPAPopup:print parentViewController:self touchCallBack:nil haveMask:YES includeNavgation:NO alignTop:YES];
        _isPrint = NO;

    }
    return YES;
}
- (IBAction)showRQcodeTouched:(id)sender {
    QRCodeViewController *qrCode = [[QRCodeViewController alloc]init];
    NSString *HTTPBody = [[self.myRequset URL] absoluteString];
    
    SalesLead *saleslead = (SalesLead*)[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot;
    Customer  *client =(Customer*)[AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot;
   
   
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:saleslead.projectID?:@"" forKey:@"projectid"];
    [params setValue:client.custName?:@"" forKey:@"customerName"];
    [params setValue:client.custMobile?:@"" forKey:@"customerPhone"];
    [params setValue:_priceid?:@"" forKey:@"quotepriceid"];
    [params setValue:_quotetypeid?:@"" forKey:@"typeid"];
    NSArray *arr = [HTTPBody componentsSeparatedByString:@"addquoteprice.html"];
//    HTTPBody = [NSString stringWithFormat:@"%@offline/addquoteprice.html?projectID=%@&customername=%@&customermobile=%@&quotepriceid=%@&typeid=%@",[arr objectAtIndex:0],saleslead.projectID?:@"",client.custName?:@"",client.custMobile?:@"",_priceid?:@"",_quotetypeid?:@""];
    HTTPBody = [NSString stringWithFormat:@"%@offline/addquoteprice.html?jsonString=%@",[arr objectAtIndex:0],[params?:@{} JSONStringValue]];
    NSLog(@"HTTPBody:%@",HTTPBody);
    qrCode.codeStr = HTTPBody;
    [self presentModelDetail:qrCode];
}
//保存报价单
- (IBAction)saveQuot:(id)sender {
    _isPrint = NO;
    
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    [self.quoteWebView stringByEvaluatingJavaScriptFromString:@"actionSubmit()"];
    //begin by sun 20160714 保存修改,保存后刷新(苏鹏)
    NSString *str = [self.quoteWebView stringByEvaluatingJavaScriptFromString:@"spreadsheetReport.spreadsheetReportWriteBack.doSaveClick()"];
    [self.quoteWebView stringByEvaluatingJavaScriptFromString: str];
    NSString *Refresh = [self.quoteWebView stringByEvaluatingJavaScriptFromString:@"spreadsheetReport.doRefresh()"];
    [self.quoteWebView stringByEvaluatingJavaScriptFromString: Refresh];
    //end by sun 20160714
    
    
}
////打印
//- (void)print{
//
//    //  解决 弹出窗太大问题
//    self.modalPresentationStyle = UIModalPresentationFormSheet;
//    //调整箭头方向
//    [printSheet showFromRect:[self.view convertRect:self.printBtn.frame fromView:self.printBtn.superview] inView:self.view animated:YES];
//    NSLog(@"%@",NSStringFromCGRect(self.printBtn.frame));
//    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
//    
//    if(!controller){
//        NSLog(@"Couldn't get shared UIPrintInteractionController!");
//        return;
//    }
//    UIPrintInteractionCompletionHandler completionHandler =
//    ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
//        if(!completed && error){
//            NSLog(@"FAILED! due to error in domain %@ with error code %zd", error.domain, error.code);
//        }
//    };
//    
//    
//    // Obtain a printInfo so that we can set our printing defaults.
//    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
//    // This application produces General content that contains color.
//    printInfo.outputType = UIPrintInfoOutputGeneral;
//    // We'll use the URL as the job name.
//    //    printInfo.jobName = [self formURL];
//    // Set duplex so that it is available if the printer supports it. We
//    // are performing portrait printing so we want to duplex along the long edge.
//    printInfo.duplex = UIPrintInfoDuplexLongEdge;
//    // Use this printInfo for this print job.
//    controller.printInfo = printInfo;
//    
//    // Be sure the page range controls are present for documents of > 1 page.
//    controller.showsPageRange = YES;
//    //将webview 转换成图片，也可以转换成pdf
//    controller.printFormatter = [self.quoteWebView viewPrintFormatter];
//    presentFromRect:inView:animated:completionHandler:
//    [controller presentFromRect:[self.view convertRect:self.printBtn.frame fromView:self.printBtn.superview] inView:self.view animated:YES completionHandler:completionHandler];
//    
//}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    // Undocumented access to UIWebView's JSContext
    self.context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    __weak typeof(self) weakSelf = self;
    self.context[@"callNative"] =
    ^(NSString *str)
    {
        NSLog(@"%@", str);
        if (str) {
            _priceid =str;
            weakSelf.saveQuoteBtn.hidden = YES;
            [weakSelf.RQcodeBTN setImage:[UIImage imageNamed:@"Quote_RQcode"] forState:UIControlStateNormal];
            [weakSelf.RQcodeBTN setEnabled:YES];
            
        }

    };
}
- (IBAction)printAction:(id)sender {
    //打印之前保存刷新数据
    [self.quoteWebView stringByEvaluatingJavaScriptFromString:@"spreadsheetReport.spreadsheetReportWriteBack.doSaveClick()"];
    [self.quoteWebView stringByEvaluatingJavaScriptFromString:@"spreadsheetReport.doRefresh()"];
    _isPrint = YES;
    
//   UIImage *image =  [self.quoteWebView imageRepresentation];
//   UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
//    [self.quoteWebView stringByEvaluatingJavaScriptFromString:@"spreadsheetReport.doPrint(true,false);"];
  //  [self.context evaluateScript:@"spreadsheetReport.doPrint(true,false);"];
}

//导入报价单
- (IBAction)importQuotation:(id)sender {

    //如果 客户存在销售线索 则导入当前客户订单
    if (![[AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.customerID isEqualToString:@""] && [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.customerID!=nil){
        [AppDelegate APP].isFromCale = NO;
        [AppDelegate APP].quoteId = @"";
        
        SalesLead *saleslead = (SalesLead*)[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot;
        Customer  *client =(Customer*)[AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot;
        NSMutableDictionary *params = [NSMutableDictionary dictionary];
        [params setValue:saleslead.projectID?:@"" forKey:@"projectid"];
        [params setValue:client.custName?:@"" forKey:@"customerName"];
        [params setValue:client.custMobile?:@"" forKey:@"customerPhone"];
        [params setValue:_priceid?:@"" forKey:@"priceid"];
        [Quotation importQuote:params Success:^(NSDictionary *result, id responseObject) {
            if ([[result objectForKey:KEY_SUCCESS]boolValue]) {
                [JKAlert showMessage:@"导入当前销售线索成功！"];
                [self dismissAllModalController];
            }else{
                [JKAlert showMessage:[NSString stringWithFormat:@"导入当前销售线索失败,%@",[result objectForKey:@"message"]]];
            }
        } Failure:^(NSError *error) {
        }];
        
    }else{
        [self dismissAllModalController];
        [[AppDelegate APP].rootViewController showPanel:YES];
        ServiceRootViewController *serviceRootViewController = [[ServiceRootViewController alloc]init];
        [[AppDelegate APP].rootViewController replaceViewController:serviceRootViewController animated:NO];
        [AppDelegate APP].isFromCale = YES;
        [AppDelegate APP].quoteId = _priceid;
    }
}
- (void)dismissAllModalController{
    UIViewController *presentViewController = [self presentingViewController];
    UIViewController *lastViewController = self;
    while (presentViewController) {
        id temp = presentViewController;
        presentViewController = [presentViewController presentingViewController];
        lastViewController = temp;
    }
    [lastViewController dismissViewControllerAnimated:YES completion:^{
    }];
}

-(void)shouldReloadParentData:(ShouldReloadParentData)shouldReloadParentData
{
    _shouldReloadParentData = [shouldReloadParentData copy];
}
-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
    [self.coverView removeFromSuperview];
    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 70, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
    self.coverView.backgroundColor = [UIColor blackColor];
    self.coverView.alpha = 0;
    [self.view addSubview:self.coverView];
    
    modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, self.view.height, modelDetailViewController.view.width, modelDetailViewController.view.height);
    [self.view addSubview:modelDetailViewController.view];
    [self addChildViewController:modelDetailViewController];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.coverView.alpha = 0.55;
        modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, (self.view.height-modelDetailViewController.view.height)/2, modelDetailViewController.view.width, modelDetailViewController.view.height);
    }];
}
#pragma mark ios8 多次点击webview下拉选框崩溃
-(void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion
{
    if (completion) {
        completion();
    }
    [super dismissViewControllerAnimated:NO completion:nil];
    
}
-(void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completion
{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_USEC), dispatch_get_main_queue(),
//                   ^{
                       [super presentViewController:viewControllerToPresent animated:flag completion:completion];
//                   });
}
@end
