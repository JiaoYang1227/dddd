//
//  CalculationViewController.m
//  DSPA2015
//
//  Created by Cluy on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CalculationViewController.h"
#import "CalculatorViewController.h"
#import "QuoteHistoryViewController.h"
#import "CalculationAndQuote.h"
#import "CalculationNextViewController.h"
#import "KeychainManager.h"
#import "OptionalEquipmentViewController.h"
#import "UIViewController+DSPAPopup.h"

#import "CalculatorController.h"
@interface CalculationViewController ()

@end

@implementation CalculationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Customer *customer = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot;

    _custName.text = customer.custName;
    _custMobiel.text = customer.custMobile;
    if (customer == nil) {
        CustomerReception *customerReception = [AppDelegate APP].rootViewController.clientRootViewController.customerReceptionForCale;
        _custName.text = customerReception.collectCustName;
        _custMobiel.text = customerReception.mobile;
    }
    
    [CalculationAndQuote getcarServicePlatformurlSuccess:^(NSDictionary *result, id responseObject) {
        NSLog(@"%@",result);
        NSMutableString *url = (NSMutableString *)[result stringForKey:@"url"];
        if (![url isEqualToString:@""]) {
            url = [NSMutableString stringWithFormat:@"%@index_33_0.html?type=1&print",url];
        }
        [self.calculationWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url?:@""]]];
    } Failure:^(NSError *error) {
        
    }];
    
    //    [self.calculationWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://218.25.139.71:8282/car_service_platform/index_33_0.html?type=1&print"]]];
    self.title = @"购车计算";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    NSLog(@"request.URL:%@",request.URL);
    
    NSString *requestString = [[[request URL]  absoluteString] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding ];
    //下一步
    if ([requestString rangeOfString:@"getStuffListInit.do"].location !=NSNotFound) {
        CalculationNextViewController *next = [[CalculationNextViewController alloc]init];
        next.custNameText = _custName.text;
        next.custMobile = _custMobiel.text;
        next.myRequset = [request copy];
        [self.navigationController pushViewController:next animated:YES];
        return NO;
    }
    
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    self.context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    __weak typeof(self) weakSelf = self;
    // todo 选装装备 弹出页面
    self.context[@"OptionalEquipmentPoP"] = ^(NSDictionary *dic){
        NSLog(@"%@", dic);
        if (dic) {
            OptionalEquipmentViewController *optioEquipVC =[[OptionalEquipmentViewController alloc]init];
            optioEquipVC.param = dic;
            [optioEquipVC OptionalEquipmentCallback:^(NSDictionary *values) {
                [weakSelf optionEquipmentValues:values];
            }];
            [weakSelf presentDSPAPopup:optioEquipVC parentViewController:weakSelf touchCallBack:nil
                haveMask:YES includeNavgation:NO alignTop:YES];
        }
        
    };

}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nonnull NSError *)error{
    
}
#pragma mark Actions-------------------------------------------------------------------
//选装装备传值
-(void)optionEquipmentValues:(NSDictionary *)values{
    //服务器地址
    NSString *param = [NSString stringWithFormat:@"setguideprice('%@','%@')",[values objectForKey:@"totalPrice"]?:@"",[values objectForKey:@"tabHTML"]?:@""];
    [_calculationWebView stringByEvaluatingJavaScriptFromString:param];
}

//历史报价单
- (IBAction)historyQuotesAction:(id)sender {
    
    if (![[AppDelegate APP].user.userID isEqualToString:@""] && [AppDelegate APP].user.userID){
        QuoteHistoryViewController *quoteHistory = [[QuoteHistoryViewController alloc]init];
        //        quoteHistory.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        [self presentViewController:quoteHistory animated:YES completion:^{
            //            quoteHistory.view.superview.frame = CGRectMake(0, 0, 1024, 600);
            //  quoteHistory.view.superview.center = CGPointMake(1024/2, 721/2);
            
        }];
    }else{
        //先 登录
        JKAlert *alert = [JKAlert alertWithTitle:@"" andMessage:@"请先登录"];
        [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            [self dismissViewControllerAnimated:YES completion:nil];
            [_currentOperations makeObjectsPerformSelector:@selector(cancel)];
            [[AppDelegate APP].rootViewController showPanel:YES];
        }];
        [alert show];
    }
    
    
}
//计算器
- (IBAction)calculationAction:(id)sender {
    CalculatorViewController *calculatorVC = [[CalculatorViewController alloc]initWithSender:sender];
    [self presentViewController:calculatorVC animated:YES completion:nil];
}
//下一步
- (IBAction)nextStepAction:(id)sender {
    if (![[AppDelegate APP].user.userID isEqualToString:@""] && [AppDelegate APP].user.userID){
        User *user = [AppDelegate APP].user;
        NSString *title = user.dealerOrgName?:@"";
        NSString *salesman = user.salesConsultantName?:@"";
        NSString *salesmobile = user.mobile?:@"";
        NSString *custName =[self EscapingSpecialCharacters:_custName.text];
        NSString *custMobiel = _custMobiel.text;
        
        NSString *projectID = [AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.projectID;
        //服务器地址
        NSString *quotationUrl =[NSString stringWithFormat:@"%@/dspa_crmserver/",[KeychainManager getBaseURL]];
        NSString *param = [NSString stringWithFormat:@"action('%@','%@','%@','%@','%@','%@','%@')",quotationUrl?:@"",title,salesman,salesmobile,custName,custMobiel,projectID?:@""];
        [_calculationWebView stringByEvaluatingJavaScriptFromString:param];
    }else{
        //先 登录
        JKAlert *alert = [JKAlert alertWithTitle:@"" andMessage:@"请先登录"];
        [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            [self dismissViewControllerAnimated:YES completion:nil];
            [_currentOperations makeObjectsPerformSelector:@selector(cancel)];
            [[AppDelegate APP].rootViewController showPanel:YES];
        }];
        [alert show];
    }
}
-(NSString *)EscapingSpecialCharacters:(NSString *)character{
    if ([character rangeOfString:@"'"].location != NSNotFound) {
        character = [character stringByReplacingOccurrencesOfString:@"'" withString:@"\\'"];
    }
    return character;
}
#pragma mark ios8 多次点击webview下拉选框崩溃
-(void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion
{
    if (completion) {
        completion();
    }
    [super dismissViewControllerAnimated:NO completion:nil];
}
-(void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completion
{
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_USEC), dispatch_get_main_queue(),
    //                   ^{
    [super presentViewController:viewControllerToPresent animated:flag completion:completion];
    //
    //                   });
}

@end
