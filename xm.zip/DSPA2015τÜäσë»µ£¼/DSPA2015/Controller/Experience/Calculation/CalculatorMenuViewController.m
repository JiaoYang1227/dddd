//
//  CalculatorMenuViewController.m
//  DSPA2015
//
//  Created by Cluy on 17/7/20.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "CalculatorMenuViewController.h"
#import "CalculationViewController.h"
#import "QuoteHistoryViewController.h"
#import "NewCalculationViewController.h"

#import "UIImage+SuperCompress.h"
#import "UploadManager.h"

@interface CalculatorMenuViewController ()

@end

@implementation CalculatorMenuViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



//奥迪金融

- (IBAction)audiCale:(id)sender {

    [CBTracking trackEvent:@"购车计算_奥迪金融"];
    NewCalculationViewController *calculation = [[NewCalculationViewController alloc]init];
    [self.navigationController pushViewController:calculation animated:YES];
}
//报价历史
- (IBAction)quoteHsitory:(id)sender {
    
    [CBTracking trackEvent:@"购车计算_报价历史"];
    if (![[AppDelegate APP].user.userID isEqualToString:@""] && [AppDelegate APP].user.userID){
        QuoteHistoryViewController *quoteHistory = [[QuoteHistoryViewController alloc]init];
        //        quoteHistory.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        [self presentViewController:quoteHistory animated:YES completion:^{
            //            quoteHistory.view.superview.frame = CGRectMake(0, 0, 1024, 600);
            //  quoteHistory.view.superview.center = CGPointMake(1024/2, 721/2);
            
        }];
    }else{
        //先 登录
        JKAlert *alert = [JKAlert alertWithTitle:@"" andMessage:@"请先登录"];
        [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
            [self dismissViewControllerAnimated:YES completion:nil];
            [_currentOperations makeObjectsPerformSelector:@selector(cancel)];
            [[AppDelegate APP].rootViewController showPanel:YES];
        }];
        [alert show];
    }
    

}

//报价留存
- (IBAction)quoteSave:(id)sender {
    [CBTracking trackEvent:@"购车计算_报价留存"];
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        //没有摄像头 或者模拟器下使用 跳过
        return;
    }
    
    if (![[AppDelegate APP].user.userID isEqualToString:@""] && [AppDelegate APP].user.userID){
        UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
        imagePickerController.delegate = self;
        imagePickerController.allowsEditing = NO;
        imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:imagePickerController animated:YES completion:^{
            [CBTracking startTracPage:@"购车计算_报价留存"];
        }];
     }else{
         //先 登录
         JKAlert *alert = [JKAlert alertWithTitle:@"" andMessage:@"请先登录"];
         [alert addCommonButtonWithTitle:@"确定" handler:^(JKAlertItem *item) {
             [self dismissViewControllerAnimated:YES completion:nil];
             [_currentOperations makeObjectsPerformSelector:@selector(cancel)];
             [[AppDelegate APP].rootViewController showPanel:YES];
         }];
         [alert show];
     }

}

#pragma mark UIImagePickerControllerDelegate event handler
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"是否采用该照片作为该客户报价留存？" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"是" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIImage *saveImage = [info valueForKey:UIImagePickerControllerOriginalImage];
        [self savePicToAPI:saveImage];
        [picker dismissViewControllerAnimated:YES completion:nil];
        [CBTracking endTracPage:@"购车计算_报价留存"];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"否" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [picker dismissViewControllerAnimated:YES completion:nil];
        [CBTracking endTracPage:@"购车计算_报价留存"];
    }];
    [alertController addAction:okAction];

    [alertController addAction:cancelAction];
    
    [picker presentViewController:alertController animated:YES completion:nil];
}

-(void)savePicToAPI:(UIImage *)myImage
{
    if (!myImage) {
        [JKAlert showMessage:@"请先选择图片!"];
        return;
    }
    NSData *documentData = [UIImage compressImage:myImage toMaxLength:512*1024*8 maxWidth:1024];
    if (!documentData) {
        [JKAlert showMessage:@"图片压缩失败!"];
        return;
    }
    
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"上传中";
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setValue:[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.projectID?:@""  forKey:@"projectid"];
    [dic setValue:[AppDelegate APP].user.userID?:@"" forKey:@"salesuserid"];
    [dic setValue:[AppDelegate APP].user.salesConsultantName?:@"" forKey:@"salesman"];
    [dic setValue:[AppDelegate APP].user.mobile?:@""forKey:@"salesmobile"];
    [dic setValue:[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.customer.custName?:@""  forKey:@"customerName"];
    [dic setValue:[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot.customer.custMobile?:@""  forKey:@"customerPhone"];
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    [UploadManager imageUploadOne:[NSString stringWithFormat:@"%@%@",baseInterface,UPLOAD_QUOTE_PRICEPHOTO]
                   withParameters:dic
                    withImageData:documentData
                     withFileName:@"quotepriceimgfile"
                    uploadSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
  
                        if ([[responseObject objectForKey:@"success"] intValue]==1) {
                            [JKAlert showMessage:[responseObject objectForKey:@"报价单上传成功"]];
                            QuoteHistoryViewController *quoteHistory = [[QuoteHistoryViewController alloc]init];
                            [self presentViewController:quoteHistory animated:YES completion:^{
                            }];
                        }else{
                            [JKAlert showMessage:[responseObject objectForKey:@"errors"]];
                        }
                  
                        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                    } uploadError:^(AFHTTPRequestOperation *operation, NSError *error) {
                        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                    }];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
    [CBTracking endTracPage:@"购车计算_报价留存"];
}

@end
