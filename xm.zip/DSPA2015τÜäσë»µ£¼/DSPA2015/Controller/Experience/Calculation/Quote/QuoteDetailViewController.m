//
//  QuoteDetailViewController.m
//  DSPA2015
//
//  Created by Cluy on 17/7/21.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "QuoteDetailViewController.h"
#import "UIImageView+WebCache.h"
@interface QuoteDetailViewController ()

@end

@implementation QuoteDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (_quote.projectid==nil  ||  [_quote.projectid isEqualToString:@""]){
        _importQuote.hidden = NO;
    }else{
        _importQuote.hidden = YES;
    }
     NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    [_quoteImgView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",baseInterface,_quote.quotepriceimgpath]] placeholderImage:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)shouldReloadParentData:(ShouldReloadParentData)shouldReloadParentData
{
    _shouldReloadParentData = [shouldReloadParentData copy];
}
-(void)backButtonTouched:(id)sender{
    //刷新回调
    if(_shouldReloadParentData){
        _shouldReloadParentData(YES,nil);
    }
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
- (IBAction)importQuote:(id)sender {
    [CBTracking trackEvent:@"购车计算_报价历史_关联机会"];
    //如果 客户存在销售线索 则导入当前客户订单
    if (![[AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.customerID isEqualToString:@""] && [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot.customerID!=nil){
        [AppDelegate APP].isFromCale = NO;
        [AppDelegate APP].quoteId = @"";
        
        SalesLead *saleslead = (SalesLead*)[AppDelegate APP].rootViewController.clientRootViewController.salesLeadFromRoot;
        Customer  *client =(Customer*)[AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot;
        NSMutableDictionary *params = [NSMutableDictionary dictionary];
        [params setValue:saleslead.projectID?:@"" forKey:@"projectid"];
        [params setValue:client.custName?:@"" forKey:@"customerName"];
        [params setValue:client.custMobile?:@"" forKey:@"customerPhone"];
        [params setValue:_quote.priceid?:@"" forKey:@"priceid"];
        [Quotation importQuote:params Success:^(NSDictionary *result, id responseObject) {
            if ([[result objectForKey:KEY_SUCCESS]boolValue]) {
                [JKAlert showMessage:@"导入当前销售线索成功！"];
                [self dismissAllModalController];
            }else{
                [JKAlert showMessage:[NSString stringWithFormat:@"导入当前销售线索失败,%@",[result objectForKey:@"message"]]];
            }
        } Failure:^(NSError *error) {
        }];
        
    }else{
        [self dismissAllModalController];
        [[AppDelegate APP].rootViewController showPanel:YES];
        ServiceRootViewController *serviceRootViewController = [[ServiceRootViewController alloc]init];
        [[AppDelegate APP].rootViewController replaceViewController:serviceRootViewController animated:NO];
        [AppDelegate APP].isFromCale = YES;
        [AppDelegate APP].quoteId = _quote.priceid;
    }

}

- (void)dismissAllModalController{
    UIViewController *presentViewController = [self presentingViewController];
    UIViewController *lastViewController = self;
    while (presentViewController) {
        id temp = presentViewController;
        presentViewController = [presentViewController presentingViewController];
        lastViewController = temp;
    }
    [lastViewController dismissViewControllerAnimated:YES completion:^{
    }];
}

@end
