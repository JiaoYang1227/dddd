//
//  QuoteDetailViewController.h
//  DSPA2015
//
//  Created by Cluy on 17/7/21.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "Quotation.h"

@interface QuoteDetailViewController : BaseViewController{
     ShouldReloadParentData _shouldReloadParentData;
}
@property (weak, nonatomic) IBOutlet UIImageView *quoteImgView;
@property (weak, nonatomic) IBOutlet UIButton *importQuote;
@property (strong, nonatomic) Quotation *quote;
-(void)shouldReloadParentData:(ShouldReloadParentData)shouldReloadParentData;
@end
