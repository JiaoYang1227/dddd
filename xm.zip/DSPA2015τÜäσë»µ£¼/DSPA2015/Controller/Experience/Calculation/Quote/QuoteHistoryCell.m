//
//  QuoteHistoryCell.m
//  D-CARS
//
//  Created by Cluy on 15/10/26.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import "QuoteHistoryCell.h"

@implementation QuoteHistoryCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
//删除报价单
- (IBAction)deleteQuote:(id)sender {
    UIButton *btn = (UIButton*)sender;
    [self.quoteCellDelegate deleteQuote:btn.tag];

}
-(void)configCell:(Quotation *)item{
    //客户姓名
   _customerName.text = item.customername;
    //客户电话
   _customerMobile.text = item.customermobile;
    //车系
   _brand.text = item.brandname;
    //报价单总价
    _quotePrice.text = [item.totalcost integerValue]>0?item.totalcost:item.totalfirstMoney;
    //报价单创建日期
   _quoteCreateDate.text = [DateManager date_YMDHM_WithTimeIntervalSince1970:item.addtime];
    //报价单是否已关联
    if(item.projectid == nil || [item.projectid isEqualToString:@""]){
        _quoteimport.text = @"未关联";
        _quoteimport.textColor = [[UIColor alloc]initWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1.0];
    }else{
        _quoteimport.text = @"已关联";
        _quoteimport.textColor = [[UIColor alloc]initWithRed:143/255.0 green:18/255.0 blue:36/255.0 alpha:1.0];
    }
   
    
    
}
@end
