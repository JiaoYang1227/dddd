//
//  QuoteHistoryViewController.m
//  DSPA2015
//
//  Created by Cluy on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "QuoteHistoryViewController.h"
#import "CalculationQuoteViewController.h"
#import "QuoteDetailViewController.h"
#import "CalculationAndQuote.h"
#import "AppDelegate.h"
#import "NewQuotation.h"

#import "NSDictionary+SafeAccess.h"
@interface QuoteHistoryViewController ()

@end

@implementation QuoteHistoryViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    _quoteSearch = [[QuotationSearch alloc]init];
    _listData = [[NSMutableArray alloc]init];
    _currentPage = 1;
    _quoteSearch.startNum = 0;
    [self loadData];
    self.title = @"报价单历史";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
-(void)loadData{
    _quoteSearch.startNum = _currentPage*20-20;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [Quotation getQuotationList:_quoteSearch Success:^(NSArray *array) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        [_listData addObjectsFromArray:array];
        [_quoteHistoryTable reloadData];
    } Failure:^(NSError *error) {
         [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
    
}
#pragma mark -
#pragma mark Table view delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_listData count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"QuoteHistoryCell";
    [tableView registerNib:[UINib nibWithNibName:@"QuoteHistoryCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
    QuoteHistoryCell *cell= [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[QuoteHistoryCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    Quotation *quote = [Quotation objectFromDictionary:[_listData objectWithIndex:indexPath.row]];
    [cell configCell:quote];
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Quotation *quote = [Quotation objectFromDictionary:[_listData objectWithIndex:indexPath.row]];
    if(quote.quotepriceimgpath !=nil && ![quote.quotepriceimgpath isEqualToString:@""]){
        QuoteDetailViewController *quoteImgDetail = [[QuoteDetailViewController alloc]init];
        quoteImgDetail.quote = quote;
        [self presentViewController:quoteImgDetail animated:YES completion:^{
            
        }];
    }else{
        NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
        [param setObject:quote.quotepricetypeid?:@"" forKey:@"typeid"];
        [param setObject:quote.priceid?:@"" forKey:@"quotepriceid"];
        [param setObject: quote.projectid?:@"" forKey:@"projectid"];
        NSURLRequest *request = [Quotation GetQuoteInfo:param];
        
        CalculationQuoteViewController *quoteVC = [[CalculationQuoteViewController alloc]init];
        quoteVC.myRequset = request;
        quoteVC.priceid = quote.priceid;
        quoteVC. quotetypeid= quote.quotepricetypeid;
        quoteVC.isFromHistory = YES;
        if (quote.projectid==nil  ||  [quote.projectid isEqualToString:@""]){
            quoteVC.isImport = NO;
        }else{
            quoteVC.isImport = YES;
        }
        [self presentViewController:quoteVC animated:NO completion:nil];
    }
}

//查看表格滚动的位置
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    int curRowCount = 0;
    curRowCount += (indexPath.row + 1);
    NSLog(@"curRowCount = %d",curRowCount);
    if (curRowCount == _currentPage*20 - 1)
    {
        _currentPage++;
        NSLog(@"page = %ld",(long)_currentPage);
        [self loadData];
    }
}

#pragma mark Actions--------------------------------------------------------------------
//关闭
- (IBAction)closeAction:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
//查询
- (IBAction)searchAction:(id)sender {
    [CBTracking trackEvent:@"购车计算_报价历史_查询"];
    _currentPage = 1;
    _listData = [[NSMutableArray alloc]init];
    _quoteSearch.customerName = self.name.text;
    _quoteSearch.customerPhone = self.telphone.text;
    [self loadData];
}
//车系选择
- (IBAction)carModelTouched:(id)sender {
    [NewQuotation getCarBrandListOfIssuedSuccess:^(NSArray *result, NSString *errorMessage) {
        if (result!= nil) {
            NSMutableArray *collection = [NSMutableArray array];
            [result enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSMutableDictionary *tempDic = [[NSMutableDictionary alloc]init];
                [tempDic setObject:[obj stringForKey:@"brandcode"]?:@"" forKey:@"key"];
                [tempDic setObject:[obj stringForKey:@"brandname"]?:@"" forKey:@"value"];
                [collection addObject:tempDic];
                
            }];
            [self showCommonSearchSelect:sender withData:collection selectItem:^(id item){
                _quoteSearch.brandcode =  [item stringForKey:@"key"];
            }];
        }else{
            [JKAlert showMessage:errorMessage];
        }
        

    } Failure:^(NSError *error) {
        
    }];
    
//    [CalculationAndQuote getcarServicePlatformurlSuccess:^(NSDictionary *result, id responseObject) {
//        NSLog(@"%@",result);
//        NSMutableString *url = (NSMutableString *)[result stringForKey:@"url"];
//        if (![url isEqualToString:@""]) {
//            [CalculationAndQuote getcarBrandWithUrl:url Success:^(NSArray *result, id responseObject) {
//                NSMutableArray *collection = [NSMutableArray array];
//                [result enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//                    NSMutableDictionary *tempDic = [[NSMutableDictionary alloc]init];
//                    [tempDic setObject:[obj stringForKey:@"brandcode"]?:@"" forKey:@"key"];
//                    [tempDic setObject:[obj stringForKey:@"brandname"]?:@"" forKey:@"value"];
//                    [collection addObject:tempDic];
//
//                }];
//                [self showCommonSearchSelect:sender withData:collection selectItem:^(id item){
//                    _quoteSearch.brandcode =  [item stringForKey:@"key"];
//                }];
//
//            } Failure:^(NSError *error) {
//
//            }];
//        }
//
//
//    } Failure:^(NSError *error) {
//
//    }];
    
}
#pragma mark -------------下拉菜单-----------------------------
#pragma mark show pop view
/**
 *  统一处理弹出框
 *
 *  @param sender sender description
 *  @param array  array description
 */
-(void)showCommonSearchSelect:(SelectButton*)sender withData:(NSArray*)array selectItem:(void (^)(id item))selectItem{
    _searchControl = [[PopoverSearchController alloc]initWithSender:sender andItems:array];
    
    [_searchControl hiddenSearchBar:NO];
    
    [_searchControl reverseIndexWithValue:sender.value];
    [_searchControl didSelectSearchItem:^(id item, NSString *key, NSString *value) {
        [sender setTitle:value forState:UIControlStateNormal];
        sender.obj = item;
        sender.key = key;
        sender.value = value;
        selectItem(item);
        
    }];
    [self presentViewController:_searchControl animated:YES completion:nil];
}
@end
