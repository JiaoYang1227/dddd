//
//  QuoteHistoryViewController.h
//  DSPA2015
//
//  Created by Cluy on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "QuoteHistoryCell.h"
#import "Quotation.h"
#import "QuotationSearch.h"

@interface QuoteHistoryViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>{
    NSInteger _currentPage;
    PopoverSearchController *_searchControl;
}
@property (strong,nonatomic) QuotationSearch *quoteSearch;
@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *telphone;
@property (weak, nonatomic) IBOutlet SelectButton *carModel;
@property (weak, nonatomic) IBOutlet UITableView *quoteHistoryTable;
@property (strong, nonatomic)NSMutableArray *listData; //报价单详情数组
@end
