//
//  QuoteHistoryCell.h
//  D-CARS
//
//  Created by Cluy on 15/10/26.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Quotation.h"
@class QuoteHistoryCell;
@protocol QuoteCellDelegate
////导入报价单
//-(void)importQuote:(NSInteger)index;
//删除报价单
-(void)deleteQuote:(NSInteger)index;
@end
@interface QuoteHistoryCell : UITableViewCell
@property (assign)id<QuoteCellDelegate>quoteCellDelegate;
//客户姓名
@property (weak, nonatomic) IBOutlet UILabel *customerName;
//客户电话
@property (weak, nonatomic) IBOutlet UILabel *customerMobile;
//车系
@property (weak, nonatomic) IBOutlet UILabel *brand;
//报价单总价
@property (weak, nonatomic) IBOutlet UILabel *quotePrice;
//报价单创建日期
@property (weak, nonatomic) IBOutlet UILabel *quoteCreateDate;
//报价单是否已关联
@property (weak, nonatomic) IBOutlet UILabel *quoteimport;

-(void)configCell:(Quotation *)item;
@end
