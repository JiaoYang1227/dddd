//
//  CalculationViewController.h
//  DSPA2015
//
//  Created by Cluy on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>

@interface CalculationViewController : BaseViewController<UIWebViewDelegate>
//购车计算webView
@property (weak, nonatomic) IBOutlet UIWebView *calculationWebView;
//客户姓名
@property (weak, nonatomic) IBOutlet BorderTextField *custName;
//客户移动电话
@property (weak, nonatomic) IBOutlet BorderTextField *custMobiel;

@property (strong, nonatomic) JSContext *context;

@end
