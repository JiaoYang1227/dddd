//
//  CalculationNextViewController.h
//  DSPA2015
//
//  Created by Cluy on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface CalculationNextViewController : BaseViewController<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (strong, nonatomic) NSURLRequest *myRequset;
@property (strong, nonatomic)NSString *custNameText;
@property (strong, nonatomic)NSString *custMobile;
//客户姓名
@property (weak, nonatomic) IBOutlet BorderTextField *custName;
//客户移动电话
@property (weak, nonatomic) IBOutlet BorderTextField *custMobiel;

@end
