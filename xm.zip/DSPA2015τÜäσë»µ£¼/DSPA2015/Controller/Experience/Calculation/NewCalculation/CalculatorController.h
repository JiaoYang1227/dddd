//
//  CalculatorController.h
//  DSPA2015
//
//  Created by Cluy on 2018/3/13.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FormulaStringCalcUtility.h"
typedef void(^ConfirmAction)(NSString *result);
@interface CalculatorController : UIViewController{
    ConfirmAction _confirmAction;
    IBOutlet UILabel *calculatorText;
    IBOutlet UILabel *titleText;
    IBOutlet UIButton *oneBtn;
    IBOutlet UIButton *twoBtn;
    IBOutlet UIButton *threeBtn;
    IBOutlet UIButton *fourBtn;
    IBOutlet UIButton *fiveBtn;
    IBOutlet UIButton *sixBtn;
    IBOutlet UIButton *sevenBtn;
    IBOutlet UIButton *eightBtn;
    IBOutlet UIButton *nineBtn;
    IBOutlet UIButton *zeroBtn;
    IBOutlet UIButton *pointBtn;

    IBOutlet UIButton *cBtn;
    IBOutlet UIButton *plusBtn;
    IBOutlet UIButton *minusBtn;
    IBOutlet UIButton *multiBtn;
    IBOutlet UIButton *divideBtn;
    IBOutlet UIButton *deleteBtn;
    IBOutlet UIButton *calcBtn;
    //选中的数字
    int      noperator;
    //是否可以输入小数点
    BOOL     inputPoint;
}
@property(nonatomic,strong)NSString *titleValue;
- (IBAction)onNumBtnsClick:(id)sender;
- (IBAction)onClearBtnsClick:(id)sender;

- (IBAction)onCalcBtnsClick:(id)sender;
-(instancetype)initWithSender:(UIView*)sender withTitle:(NSString *)title withcalculatorText:(NSString *)calculatorText;
-(void)ConfirmAction:(ConfirmAction)confirmAction;

@end
