//
//  CalculatorController.m
//  DSPA2015
//
//  Created by Cluy on 2018/3/13.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "CalculatorController.h"

@interface CalculatorController ()

@end

@implementation CalculatorController
-(instancetype)initWithSender:(UIView*)sender withTitle:(NSString *)title withcalculatorText:(NSString *)calculator{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        self.modalPresentationStyle = UIModalPresentationPopover;
        self.preferredContentSize = self.view.frame.size;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 80000
        self.popoverPresentationController.sourceView = sender;
        self.popoverPresentationController.sourceRect = sender.bounds;
        //        self.popoverPresentationController.popoverBackgroundViewClass = [GIKPopoverBackgroundView class];
        
#endif
        self.automaticallyAdjustsScrollViewInsets = NO;
        if (calculator != nil) {
            if ([calculator rangeOfString:@"."].location!=NSNotFound){
                inputPoint = NO;
            }else{
                inputPoint = YES;
            }
            calculatorText.text = calculator;
        }else{
            calculatorText.text = @"0";
        }
        titleText.text = title;
       
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
//    NSLog(@"标题 %@",_titleValue)
//    [titleText setText:_titleValue];
    [self setBtnsTitleStyle];
    inputPoint = YES;
    noperator = 0;
}
-(void)setBtnsTitleStyle{
    oneBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f  alpha:0.98f];
    twoBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    threeBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    fourBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    fiveBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    sixBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    sevenBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    eightBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    nineBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    zeroBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    pointBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    deleteBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    cBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    plusBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    minusBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    multiBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    divideBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    calcBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}
- (IBAction)onNumBtnsClick:(id)sender {
    NSString *str = [NSString string];
    if (sender == oneBtn) {
        str = @"1";
    }else if (sender == twoBtn){
        str = @"2";
    }else if (sender == threeBtn){
        str = @"3";
    }else if (sender == fourBtn){
        str = @"4";
    }else if (sender == fiveBtn){
        str = @"5";
    }else if (sender == sixBtn){
        str = @"6";
    }else if (sender == sevenBtn){
        str = @"7";
    }else if (sender == eightBtn){
        str = @"8";
    }else if (sender == nineBtn){
        str = @"9";
    }else if (sender == zeroBtn){
        str = @"0";
    }else if (sender == pointBtn){
        //当数字为空时输入. 或者运算符号后有.
        if ([calculatorText.text length] == 0) {
            str = @"0.";
            inputPoint = NO;
        }else{
            NSString *last = [calculatorText.text substringFromIndex:calculatorText.text.length-1];
            if ([last isEqualToString:@"+"] || [last isEqualToString:@"-"] || [last isEqualToString:@"*"] || [last isEqualToString:@"/"]) {
                str = @"0.";
                inputPoint = NO;
            }else if(![last isEqualToString:@"."] && inputPoint){
                str = @".";
                inputPoint = NO;
            }
            
        }
    }
    if (calculatorText.text == nil) {
        calculatorText.text = @"0";
    }
    if ([calculatorText.text isEqualToString:@"0"] && ![str isEqualToString:@"."]) {
        calculatorText.text = str;
    }else {
        calculatorText.text = [calculatorText.text stringByAppendingString: str];
    }
    
}
- (IBAction)onClearBtnsClick:(id)sender {
    if (sender == deleteBtn){
        if (![calculatorText.text isEqualToString:@""]) {
            //如果删除小数点后 应该恢复可点
            if([calculatorText.text hasSuffix:@"."]){
                inputPoint = YES;
            }
            calculatorText.text = [calculatorText.text substringToIndex:calculatorText.text.length -1];
            
        }
    }else if (sender == cBtn){
        noperator = 0;
        calculatorText.text = @"0";
        inputPoint = YES;
    }
}
// + - *  /
- (IBAction)onPeratorBtnsClick:(id)sender {
    // 没有数字不可以进行运算
     if ([calculatorText.text length] == 0) {
         return;
     }
   // 当最后一个字符是 运算符时 return；
    NSString *last = [calculatorText.text substringFromIndex:calculatorText.text.length-1];
    if ([last isEqualToString:@"+"] || [last isEqualToString:@"-"] || [last isEqualToString:@"*"] || [last isEqualToString:@"/"]) {
        return;
    }
    // 当最后一个为 x. 时运算增加为 x.0
    if([last isEqualToString:@"."]){
        calculatorText.text = [calculatorText.text stringByAppendingString:@"0"];
    }
    if (sender == plusBtn){
        calculatorText.text = [calculatorText.text stringByAppendingString:@"+"];
        noperator = 1;
        inputPoint = YES;
    }else if (sender == minusBtn){
        noperator = 2;
        inputPoint = YES;
        calculatorText.text = [calculatorText.text stringByAppendingString:@"-"];
    }else if (sender == multiBtn){
        noperator = 3;
        inputPoint = YES;
        calculatorText.text = [calculatorText.text stringByAppendingString:@"*"];
    }else if (sender == divideBtn){
        noperator = 4;
        inputPoint = YES;
        calculatorText.text = [calculatorText.text stringByAppendingString:@"/"];
    }
}
// =
- (IBAction)onCalcBtnsClick:(id)sender{
    inputPoint = YES;
    calculatorText.text = [FormulaStringCalcUtility calcComplexFormulaString:calculatorText.text];
}
// 确认 计算 返回数据
- (IBAction)confirmAction:(id)sender {
    if ([calculatorText.text rangeOfString:@"+"].location != NSNotFound || [calculatorText.text rangeOfString:@"-"].location != NSNotFound || [calculatorText.text rangeOfString:@"*"].location != NSNotFound || [calculatorText.text rangeOfString:@"/"].location != NSNotFound) {
        calculatorText.text = [FormulaStringCalcUtility calcComplexFormulaString:calculatorText.text];
    }
    //返回操作 block
    if (_confirmAction) {
        _confirmAction(calculatorText.text);
    }

    
}
#pragma mark block
-(void)ConfirmAction:(ConfirmAction)confirmAction{
    _confirmAction = [confirmAction copy];
}


@end
