//
//  CalculationPreSetCell.h
//  DSPA2015
//
//  Created by Cluy on 2018/3/20.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewQuotation.h"
@protocol DeleteDataDelegate
-(void)deleteData:(id)param;
@end

@interface CalculationPreSetCell : UITableViewCell<DeleteDataDelegate>
@property (strong, nonatomic) NewQuotation *quotation;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *createTime;
@property (assign)id <DeleteDataDelegate>deleteDataDelegate;
@end
