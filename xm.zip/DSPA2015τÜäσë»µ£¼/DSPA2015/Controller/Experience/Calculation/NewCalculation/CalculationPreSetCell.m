//
//  CalculationPreSetCell.m
//  DSPA2015
//
//  Created by Cluy on 2018/3/20.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "CalculationPreSetCell.h"

@implementation CalculationPreSetCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)deleteAction:(id)sender {
    [self.deleteDataDelegate deleteData:_quotation];
}

@end
