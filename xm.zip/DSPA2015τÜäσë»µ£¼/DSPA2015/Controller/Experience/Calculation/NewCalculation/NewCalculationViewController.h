//
//  NewCalculationViewController.h
//  DSPA2015
//
//  Created by Cluy on 2018/3/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "CalculatorController.h"
#import "CalculationPreSetViewController.h"
#import "CheckBoxView.h"
#import "NewQuotation.h"

@interface NewCalculationViewController : BaseViewController{
    PopoverSearchController *_searchControl;
    CalculatorController *_calculatorControl;
    UIActionSheet *printSheet;
    NewQuotation *newQuotation;
}
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollerView;
//车系
@property (weak, nonatomic) IBOutlet SelectButton *brand;
//车型
@property (weak, nonatomic) IBOutlet SelectButton *model;
//全款合计
@property (weak, nonatomic) IBOutlet SelectButton *fullPayment;
//首付款合计
@property (weak, nonatomic) IBOutlet SelectButton *firstPayment;

//成交价格
@property (strong, nonatomic) IBOutlet SelectButton *transactionPrice;
//车船税
@property (weak, nonatomic) IBOutlet SelectButton *VVULPT_s;
//其他
@property (weak, nonatomic) IBOutlet SelectButton *otherprice_s;
//上牌费用
@property (weak, nonatomic) IBOutlet SelectButton *platepremium_s;
//购置税
@property (weak, nonatomic) IBOutlet SelectButton *purchasetax_s;

//指导价
@property (weak, nonatomic) IBOutlet SelectButton *guideprice_s;
//精品选装价格
@property (weak, nonatomic) IBOutlet SelectButton *boutiqueprice_s;
//精品选装明细
@property (weak, nonatomic) IBOutlet BorderTextView *boutiquecontent;


//金融方案
@property (weak, nonatomic) IBOutlet SelectButton *financialplan;
//合作伙伴
@property (weak, nonatomic) IBOutlet CheckBoxView *cooperative;
//首付款
@property (weak, nonatomic) IBOutlet SelectButton *firstpayprice_s;
//期数
@property (weak, nonatomic) IBOutlet SelectButton *periods;
//首付比例
@property (weak, nonatomic) IBOutlet SelectButton *firstpayscale;
//贷款额
@property (weak, nonatomic) IBOutlet SelectButton *loanvalue_s;
//金融服务费
@property (weak, nonatomic) IBOutlet SelectButton *financialservice_s;
//月供
@property (weak, nonatomic) IBOutlet SelectButton *monthlyprice_s;
//利息
@property (weak, nonatomic) IBOutlet SelectButton *interests;

//保险费用
@property (weak, nonatomic) IBOutlet SelectButton *insuranceprice_s;
//保险公司
@property (weak, nonatomic) IBOutlet SelectButton *insurance;
//险种
@property (weak, nonatomic) IBOutlet CheckBoxView *insuranceType;

@end
