//
//  CalculationPreSetViewController.h
//  DSPA2015
//
//  Created by Cluy on 2018/3/20.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//
#import "CalculationPreSetCell.h"
#import "NewQuotation.h"
typedef void(^DidPreSetCell)(NewQuotation *quotation);
@interface CalculationPreSetViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,DeleteDataDelegate>
@property (weak, nonatomic) IBOutlet UITableView *listTable;
@property (strong, nonatomic)NSString *modelCode;
@property (strong, nonatomic)NSArray *listArr;
@property (nonatomic, copy)DidPreSetCell didPreSetCell;
-(instancetype)initWithSender:(UIView*)sender withModelCode:(NSString*)CodeStr;
- (void)DidPreSetCell:(DidPreSetCell)block;
@end
