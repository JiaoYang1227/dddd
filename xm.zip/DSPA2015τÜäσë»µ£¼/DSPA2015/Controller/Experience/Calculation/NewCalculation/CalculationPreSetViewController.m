//
//  CalculationPreSetViewController.m
//  DSPA2015
//
//  Created by Cluy on 2018/3/20.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "CalculationPreSetViewController.h"


#define CELL_INDENTIFIER @"CalculationPreSetCell"
@interface CalculationPreSetViewController ()

@end

@implementation CalculationPreSetViewController
-(instancetype)initWithSender:(UIView*)sender withModelCode:(NSString*)CodeStr{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        self.modalPresentationStyle = UIModalPresentationPopover;
        self.preferredContentSize = self.view.frame.size;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 80000
        self.popoverPresentationController.sourceView = sender;
        self.popoverPresentationController.sourceRect = sender.bounds;
        //        self.popoverPresentationController.popoverBackgroundViewClass = [GIKPopoverBackgroundView class];
        
#endif
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.modelCode = CodeStr;
        [self loadData];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UINib *nib = [UINib nibWithNibName:@"CalculationPreSetCell" bundle:nil];
    [self.listTable registerNib:nib forCellReuseIdentifier:CELL_INDENTIFIER];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)loadData{
    _listArr =[NewQuotation getRecommendationListWithParam:_modelCode];
    [_listTable reloadData];
}
#pragma mark tableView
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_listArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CalculationPreSetCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_INDENTIFIER forIndexPath:indexPath];
    NewQuotation *newQuotation = [NewQuotation objectFromDictionary:[_listArr objectAtIndex:indexPath.row]];
    cell.quotation = newQuotation;
    cell.deleteDataDelegate = self;
    cell.name.text = newQuotation.financialplan;
    cell.price.text = newQuotation.dealprice_s;
    cell.createTime.text = newQuotation.createTimeTemp;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NewQuotation *newQuotation = [NewQuotation objectFromDictionary:[_listArr objectAtIndex:indexPath.row]];
    if (_didPreSetCell) {
        self.didPreSetCell(newQuotation);
    }
}
-(void)deleteData:(id)param{
    NewQuotation *newQuotation = (NewQuotation *)param;
    NSLog(@"delete");
    if ([NewQuotation deleteRecommendationListWithUID:newQuotation.UID]) {
        [self loadData];
        [JKAlert showMessage: @"删除成功"];
    }else{
         [JKAlert showMessage: @"删除失败，请重试"];
    }
}
- (void)DidPreSetCell:(DidPreSetCell)block{
    _didPreSetCell = [block copy];
}
@end
