//
//  NewCalculationViewController.m
//  DSPA2015
//
//  Created by Cluy on 2018/3/19.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import "NewCalculationViewController.h"
#import "RecipePrintPageRenderer.h"
#import "DictModel.h"
#import "CalculationQuoteViewController.h"


@interface NewCalculationViewController ()

@end

@implementation NewCalculationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [_scrollerView addSubview:_contentView];
    _scrollerView.contentSize = CGSizeMake(_scrollerView.frame.size.width, _contentView.bottom);
    newQuotation = [[NewQuotation alloc]init];
    [self initView];
    
}

//金融方案有值 则金融方案view 可编辑 全款合计不可编辑
//否则不可编辑 且首付款不可编辑
-(void)enableViews{
    BOOL isEnable;
    if (newQuotation.financialplancode!= nil) {
        isEnable = YES;
        _fullPayment.value = @"";
        _fullPayment.userInteractionEnabled = !isEnable;
        _firstPayment.userInteractionEnabled =isEnable;
    }else
    {
        isEnable = NO;
        _firstPayment.value = @"";
        _firstPayment.userInteractionEnabled = isEnable;
        _fullPayment.userInteractionEnabled = !isEnable;
    }
    _cooperative.userInteractionEnabled = isEnable;
    _firstpayprice_s.userInteractionEnabled = isEnable;
    _periods.userInteractionEnabled = isEnable;
    _firstpayscale.userInteractionEnabled = isEnable;
    _loanvalue_s.userInteractionEnabled = isEnable;
    _financialservice_s.userInteractionEnabled = isEnable;
    _monthlyprice_s.userInteractionEnabled = isEnable;
    _interests.userInteractionEnabled = isEnable;
    
}
-(void)initView{
    [_fullPayment setImage:nil forState:UIControlStateNormal];
    [_firstPayment setImage:nil forState:UIControlStateNormal];
    //成交价格
    [_transactionPrice setImage:nil forState:UIControlStateNormal];
    //车船税
    [_VVULPT_s setImage:nil forState:UIControlStateNormal];
    //其他
    [_otherprice_s setImage:nil forState:UIControlStateNormal];
    //上牌费用
    [_platepremium_s setImage:nil forState:UIControlStateNormal];
    //购置税
    [_purchasetax_s setImage:nil forState:UIControlStateNormal];
    
    //指导价
    [_guideprice_s setImage:nil forState:UIControlStateNormal];
    //精品选装价格
    [_boutiqueprice_s setImage:nil forState:UIControlStateNormal];
    //首付款
    [_firstpayprice_s setImage:nil forState:UIControlStateNormal];

    //首付比例
    [_firstpayscale setImage:nil forState:UIControlStateNormal];
    //贷款额
    [_loanvalue_s setImage:nil forState:UIControlStateNormal];
    //金融服务费
    [_financialservice_s setImage:nil forState:UIControlStateNormal];
    //月供
    [_monthlyprice_s setImage:nil forState:UIControlStateNormal];
    //利息
    [_interests setImage:nil forState:UIControlStateNormal];
    
    //保险费用
    [_insuranceprice_s setImage:nil forState:UIControlStateNormal];
    [self insuranceTypeload];
//    [self cooperativeload];
    [self enableViews];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
//险种
-(void)insuranceTypeload{
    __weak typeof(self)weakSelf = self;
    [NewQuotation getInsurancetypeListSuccess:^(NSArray *array) {
        if([array count]>0){
            weakSelf.insuranceType.items = array;
            weakSelf.insuranceType.mode = CheckBoxViewModeCalulatorSelectAll;
            [weakSelf.insuranceType didSelectCheckBoxViewItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *selectedItems, NSString *joinedkeys) {
                NSLog(@"check Value joinedKEYS ");
                newQuotation.insurancetypecode = joinedkeys;
            }];
        }
        
    } Failure:^(NSError *error) {
        
    }];
}
//合作伙伴
-(void)cooperativeload{
    __weak typeof(self)weakSelf = self;
    if(newQuotation.financialplancode == nil){
        weakSelf.cooperative.mode = CheckBoxViewModeCalulator;
        weakSelf.cooperative.items = nil;
        return;
    }
    [NewQuotation getCooperativesListWithFinancialplancode:newQuotation.financialplancode Success:^(NSArray *array) {
        if([array count]>0){
            weakSelf.cooperative.items = array;
            weakSelf.cooperative.mode = CheckBoxViewModeCalulator;
            if (newQuotation.cooperativecode == nil) {
                newQuotation.cooperativecode = [[array objectAtIndex:0]objectForKey:@"key"];
            }
            [weakSelf.cooperative didSelectCheckBoxViewItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *selectedItems, NSString *joinedkeys) {
                NSLog(@"check Value joinedKEYS ");
                newQuotation.cooperativecode = joinedkeys;
            }];
            //默认选择
            self.cooperative.joinedkeys =newQuotation.cooperativecode;
        }
    } Failure:^(NSError *error) {
        
    }];
 
    
}
#pragma mark ----------------------------------------------------
//当重新选择车系车型时，金融方案相关进行清空更改
-(void)resetData{
    newQuotation.firstpaysum_s = @"";
    newQuotation.totalsum_s = @"";
    newQuotation.financialplancode = nil;
    newQuotation.financialplan = @"";
    newQuotation.cooperativecode = @"";
    newQuotation.firstpayprice_s = @"0";
    newQuotation.periods = @"";
    newQuotation.periodscode = nil;
    newQuotation.firstpayscale = @"0";
    newQuotation.loanvalue_s = @"";
    newQuotation.financialservice_s = @"";
    newQuotation.monthlyprice_s = @"";
    newQuotation.interests = @"";
    [self reloadView];
}
//车系
- (IBAction)brandTouched:(SelectButton *)sender {
    [NewQuotation getCarBrandListWithSuccess:^(NSArray *array) {
        [self showCommonSearchSelect:sender withData:array selectItem:^(id item) {
            sender.value = [item objectForKey:@"value"];
            newQuotation.brandcode = [item objectForKey:@"key"];
            newQuotation.brand = [item objectForKey:@"value"];
            
            newQuotation.modelcode = nil;
            newQuotation.model = nil;
            _model.value = @"";
            _guideprice_s.value = @"";
            newQuotation.guideprice_s = @"";
            //重新选择车系 更新数据
            [self resetData];
        }];
    } Failure:^(NSError *error) {
        
    }];
   
}
//车型
- (IBAction)model:(SelectButton *)sender {
    if (newQuotation.brandcode == nil) {
        [JKAlert showMessage:@"请选择车系"];
        return;
    }
    [NewQuotation getCarModelAndPriceListWithBrandCode:newQuotation.brandcode Success:^(NSArray *array) {
        [self showCommonSearchSelect:sender withData:array selectItem:^(id item) {
            sender.value = [item objectForKey:@"value"];
            newQuotation.modelcode = [item objectForKey:@"key"];
            newQuotation.model = [item objectForKey:@"value"];
            _guideprice_s.value = [item objectForKey:@"guideprice_s"];
            newQuotation.guideprice_s = [item objectForKey:@"guideprice_s"];
            //重新选择车型 更新数据
            [self resetData];
        }];
    } Failure:^(NSError *error) {
        
    }];
    
}
//全款合计
- (IBAction)fullPaymentTouched:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"全款合计" withCalculatorShowText:newQuotation.totalsum_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.totalsum_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}
//首付款合计
- (IBAction)firstPaymentTouched:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"首付款合计" withCalculatorShowText:newQuotation.firstpaysum_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.firstpaysum_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}
#pragma mark ----------------------------------------------------
//成交价格
- (IBAction)dealprice_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"成交价格" withCalculatorShowText:newQuotation.dealprice_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.dealprice_s = result;
        
        // 购置税
        NSString *purchasetax_s = [NSString stringWithFormat:@"%.2f",[newQuotation.dealprice_s floatValue]/1.17*0.1];
        newQuotation.purchasetax_s = purchasetax_s;
        _purchasetax_s.value = purchasetax_s;
        
        // 如果首付款不为空且成交价格改变，带动贷款额和比例变化
        if (_firstpayprice_s.value!= nil) {
            NSString *firstpayscale = [NSString stringWithFormat:@"%.2f", [newQuotation.firstpayprice_s floatValue]/[newQuotation.dealprice_s floatValue]*100];
            newQuotation.firstpayscale = firstpayscale;
            _firstpayscale.value = [NSString stringWithFormat:@"%@%%",firstpayscale?:@"0"];;
            
            NSString *loanvalue_s = [NSString stringWithFormat:@"%.2f",[newQuotation.dealprice_s floatValue]  - [newQuotation.firstpayprice_s floatValue]];
            newQuotation.loanvalue_s = loanvalue_s;
            _loanvalue_s.value = [self numberSegmentationWithStr:loanvalue_s];
        }
        [self dismissViewControllerAnimated:YES completion:^{
            [self VVULPT_s:_VVULPT_s];
        }];
    }];
}

//车船税
- (IBAction)VVULPT_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"车船税" withCalculatorShowText:newQuotation.VVULPT_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.VVULPT_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
             [self otherprice_s:_otherprice_s];
        }];
    }];
}


//其他
- (IBAction)otherprice_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"其他" withCalculatorShowText:newQuotation.otherprice_s confirmResult:^(id result,NSString* resultFormat) {
        newQuotation.otherprice_s = result;
        sender.value = resultFormat;
        [self dismissViewControllerAnimated:YES completion:^{
            [self platepremium_s:_platepremium_s];
        }];
    }];
}
//上牌费用
- (IBAction)platepremium_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"上牌费用" withCalculatorShowText:newQuotation.platepremium_s  confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.platepremium_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
            [self purchasetax_s:_purchasetax_s];
        }];
    }];
}
//购置税
- (IBAction)purchasetax_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"购置税" withCalculatorShowText:newQuotation.purchasetax_s  confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.purchasetax_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
            [self boutiqueprice_s:_boutiqueprice_s];
        }];
    }];
}

//指导价
- (IBAction)guideprice_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"指导价" withCalculatorShowText:newQuotation.guideprice_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.guideprice_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}

//精品选装价格
- (IBAction)boutiqueprice_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"精品选装价格" withCalculatorShowText:newQuotation.boutiqueprice_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.boutiqueprice_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}

#pragma mark ----------------------------------------------------
//金融方案
- (IBAction)financialplan:(SelectButton *)sender {
    if (newQuotation.brandcode == nil) {
        [JKAlert showMessage:@"请选择车系"];
        return;
    }
    [NewQuotation getFinancialpanlistWithBrandCode:newQuotation.brandcode Success:^(NSArray *array) {
        [self showCommonSearchSelect:sender withData:array selectItem:^(id item) {
            sender.value = [item objectForKey:@"value"];
            newQuotation.financialplancode = [item objectForKey:@"key"];
            newQuotation.financialplan = [item objectForKey:@"value"];
            [self cooperativeload];
            [self enableViews];
            
        }];
    } Failure:^(NSError *error) {
        
    }];
    
}

//首付款
- (IBAction)firstpayprice_s:(SelectButton *)sender {
    if(newQuotation.dealprice_s == nil && [newQuotation.dealprice_s integerValue] == 0){
        [JKAlert showMessage:@"请填写成交价格"];
        return;
    }
    [self showCommoncalculationSelect:sender withTitle:@"首付款" withCalculatorShowText:newQuotation.firstpayprice_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.firstpayprice_s = result;
        
        //首付款比例
        NSString *firstpayscale = [NSString stringWithFormat:@"%.2f", [newQuotation.firstpayprice_s floatValue]/[newQuotation.dealprice_s floatValue]*100];
        newQuotation.firstpayscale = firstpayscale;
        _firstpayscale.value = [NSString stringWithFormat:@"%@%%",firstpayscale];
        //贷款额度
        NSString *loanvalue_s = [NSString stringWithFormat:@"%.2f",[newQuotation.dealprice_s floatValue]  - [newQuotation.firstpayprice_s floatValue]];
        newQuotation.loanvalue_s = loanvalue_s;
        _loanvalue_s.value = [self numberSegmentationWithStr:loanvalue_s];
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
    
}
//期数
- (IBAction)periods:(SelectButton *)sender {
    if(newQuotation.financialplancode == nil || newQuotation.cooperativecode == nil){
        [JKAlert showMessage:@"请将金融方案或者合作伙伴填写完整"];
        return;
    }
    NSDictionary *param = @{@"financialplancode":newQuotation.financialplancode?:@"",@"cooperativecode":newQuotation.cooperativecode?:@""};
    [NewQuotation getPeriodsListWithfinancialplancode:param Success:^(NSArray *array) {
        [self showCommonSearchSelect:sender withData:array selectItem:^(id item) {
            sender.value = [item objectForKey:@"value"];
            newQuotation.periodscode = [item objectForKey:@"key"];
            newQuotation.periods = [item objectForKey:@"value"];
        }];
    } Failure:^(NSError *error) {
        
    }];
    
}

//首付比例
- (IBAction)firstpayscale:(SelectButton *)sender {
     if(newQuotation.dealprice_s == nil && [newQuotation.dealprice_s integerValue] == 0){
        [JKAlert showMessage:@"请填写成交价格"];
        return;
    }
    [self showCommoncalculationSelect:sender withTitle:@"首付比例" withCalculatorShowText:newQuotation.firstpayscale confirmResult:^(id result,NSString* resultFormat) {
        sender.value = [NSString stringWithFormat:@"%@%%",resultFormat];
        newQuotation.firstpayscale = result;
        
        //首付款
        NSString *firstpayprice_s = [NSString stringWithFormat:@"%.2f", [newQuotation.firstpayscale floatValue]*[newQuotation.dealprice_s floatValue]*0.01];
        newQuotation.firstpayprice_s = firstpayprice_s;
        _firstpayprice_s.value = [self numberSegmentationWithStr:firstpayprice_s];
        //贷款款
        NSString *loanvalue_s = [NSString stringWithFormat:@"%.2f",[newQuotation.dealprice_s floatValue]  - [newQuotation.firstpayprice_s floatValue]];
        newQuotation.loanvalue_s = loanvalue_s;
        _loanvalue_s.value = [self numberSegmentationWithStr:loanvalue_s];
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}
//贷款额
- (IBAction)loanvalue_s:(SelectButton *)sender {
     if(newQuotation.dealprice_s == nil && [newQuotation.dealprice_s integerValue] == 0){
        [JKAlert showMessage:@"请填写成交价格"];
        return;
    }
    [self showCommoncalculationSelect:sender withTitle:@"贷款额" withCalculatorShowText:newQuotation.loanvalue_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.loanvalue_s = result;
        
        //首付款
        NSString *firstpayprice_s = [NSString stringWithFormat:@"%.2f", [newQuotation.dealprice_s floatValue]-[newQuotation.loanvalue_s floatValue]];
        newQuotation.firstpayprice_s = firstpayprice_s;
        _firstpayprice_s.value = [self numberSegmentationWithStr:firstpayprice_s];
        //首付比例
        NSString *firstpayscale = [NSString stringWithFormat:@"%.2f", [newQuotation.firstpayprice_s floatValue]/[newQuotation.dealprice_s floatValue]*100];
        newQuotation.firstpayscale = firstpayscale;
        
        _firstpayscale.value = [NSString stringWithFormat:@"%@%%",firstpayscale];
        [self dismissViewControllerAnimated:YES completion:^{
        }];
        
    }];
}

//金融服务费
- (IBAction)financialservice_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"金融服务费" withCalculatorShowText:newQuotation.financialservice_s confirmResult:^(id result,NSString *resultFormat) {
        sender.value = resultFormat;
        newQuotation.financialservice_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}
//月供
- (IBAction)monthlyprice_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"月供" withCalculatorShowText:newQuotation.monthlyprice_s confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.monthlyprice_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}

//利息
- (IBAction)interests:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"利息" withCalculatorShowText:newQuotation.interests confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.interests = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}

#pragma mark ----------------------------------------------------
//保险费用
- (IBAction)insuranceprice_s:(SelectButton *)sender {
    [self showCommoncalculationSelect:sender withTitle:@"保险费用" withCalculatorShowText:newQuotation.insuranceprice_s  confirmResult:^(id result,NSString* resultFormat) {
        sender.value = resultFormat;
        newQuotation.insuranceprice_s = result;
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }];
}

//保险公司
- (IBAction)insurance:(SelectButton *)sender {
    [NewQuotation getInsurancelistSuccess:^(NSArray *array) {
        [self showCommonSearchSelect:sender withData:array selectItem:^(id item) {
            sender.value = [item objectForKey:@"value"];
            newQuotation.insurancecode = [item objectForKey:@"key"];
            newQuotation.insurance = [item objectForKey:@"value"];
        }];
    } Failure:^(NSError *error) {
    
    }];
}

#pragma mark -------------下拉菜单---------------------------------
#pragma mark show pop view
/**
 *  统一处理弹出框
 *
 *  @param sender sender description
 *  @param array  array description
 */
-(void)showCommonSearchSelect:(SelectButton*)sender withData:(NSArray*)array selectItem:(void (^)(id item))selectItem{
    _searchControl = [[PopoverSearchController alloc]initWithSender:sender andItems:array];
    
    [_searchControl hiddenSearchBar:NO];
    
    [_searchControl reverseIndexWithValue:sender.value];
    [_searchControl didSelectSearchItem:^(id item, NSString *key, NSString *value) {
        [sender setTitle:value forState:UIControlStateNormal];
        sender.obj = item;
        sender.key = key;
        sender.value = value;
        selectItem(item);
        
    }];
    [self presentViewController:_searchControl animated:YES completion:nil];
}

-(void)showCommoncalculationSelect:(SelectButton*)sender withTitle:(NSString*)titleValue withCalculatorShowText:(NSString*)showText confirmResult:(void (^)(id result,NSString* resultFormat))selectItem{
    _calculatorControl = [[CalculatorController alloc]initWithSender:sender withTitle:titleValue withcalculatorText:showText];
    [_calculatorControl ConfirmAction:^(NSString *result) {
        NSLog(@"计算结果 = %@",result);
        NSString *resultformat = [self ChangeNumberFormat:result];
        selectItem(result,resultformat);
    }];
    [self presentViewController:_calculatorControl animated:YES completion:nil];
}
-(NSString *)ChangeNumberFormat:(NSString *)num
{
    NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
//    [numberFormatter setFormatterBehavior: NSNumberFormatterBehavior10_4];
    [numberFormatter setNumberStyle: NSNumberFormatterDecimalStyle];
    numberFormatter.generatesDecimalNumbers = NO;
    NSString *numberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:[num floatValue]]];
    return numberString;
}
#pragma mark 打印
//- (IBAction)printAction:(id)sender {
//    UIButton *printBtn = (UIButton *)sender;
//   UIImage *image = [self captureScreenScrollView:self.scrollerView];
//    image = [self composeTopImage:image];
//
////   [self saveImage:image];
//   NSData *data = [NSData dataWithData:UIImagePNGRepresentation(image)];
//    //  解决 弹出窗太大问题
//    self.modalPresentationStyle = UIModalPresentationFormSheet;
//    //调整箭头方向
//    [printSheet showFromRect:[self.view convertRect:printBtn.frame fromView:printBtn.superview] inView:self.view animated:YES];
//    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
//    if(!controller){
//        NSLog(@"Couldn't get shared UIPrintInteractionController!");
//        return;
//    }
//    UIPrintInteractionCompletionHandler completionHandler =
//    ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
//        if(!completed && error){
//            NSLog(@"FAILED! due to error in domain %@ with error code %zd", error.domain, error.code);
//        }
//    };
//    [controller presentFromRect:[self.view convertRect:printBtn.frame fromView:printBtn.superview] inView:self.view animated:YES completionHandler:completionHandler];
//    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
//    printInfo.outputType = UIPrintInfoOutputGeneral;
//    printInfo.duplex = UIPrintInfoDuplexLongEdge;
//    controller.printInfo = printInfo;
//    controller.showsPageRange = YES;
//    controller.printingItem = data;
//    [controller presentFromRect:[self.view convertRect:printBtn.frame fromView:printBtn.superview] inView:self.view animated:YES completionHandler:completionHandler];
//}
//获得屏幕图像
//-(UIImage *)captureScreenScrollView:(UIScrollView *)scrollView {
//    CGPoint savedContentOffset = scrollView.contentOffset;
//    CGRect savedFrame = scrollView.frame;
//
//    scrollView.frame = CGRectMake(0, scrollView.frame.origin.y, scrollView.contentSize.width, scrollView.contentSize.height);
//    UIGraphicsBeginImageContextWithOptions(scrollView.contentSize, YES, 0.0); //currentView 当前的view  创建一个基于位图的图形上下文并指定大小为
//    [scrollView.layer renderInContext:UIGraphicsGetCurrentContext()];//renderInContext呈现接受者及其子范围到指定的上下文
//    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();//返回一个基于当前图形上下文的图片
//
//    scrollView.contentOffset = savedContentOffset;
//    scrollView.frame = savedFrame;
//
//    UIGraphicsEndImageContext();
//    return image;
//}
//// 拼接两张图片
//- (UIImage *)composeTopImage:(UIImage *)topImage{
//    UIImage *bottomImage = [UIImage imageNamed:@"TestDrive_prit_logo1.png"];
//    UIImage *bottomImage2 = [UIImage imageNamed:@"TestDrive_prit_logo2.png"];
//    UIImage *bottomImage3 = [self createImageWithColor:[UIColor whiteColor]];
//    //1.创建上下文尺寸
//    CGSize size = CGSizeMake(self.view.frame.size.width, topImage.size.height +bottomImage.size.height);
//    UIGraphicsBeginImageContextWithOptions(size, YES, 0.0);
//
//    //2.先把topImage 画到上下文中
//    [topImage drawInRect:CGRectMake(0, 44, topImage.size.width, topImage.size.height)];
//    //3.再把小图放在上下文中
//    [bottomImage drawInRect:CGRectMake(0, 0, bottomImage.size.width, 44)];
//    [bottomImage2 drawInRect:CGRectMake(self.view.frame.size.width-bottomImage2.size.width, 0, bottomImage2.size.width, 44)];
//    [bottomImage3 drawInRect:CGRectMake(bottomImage.size.width, 0, self.view.frame.size.width-bottomImage2.size.width-bottomImage.size.width, 44)];
//    UIImage *resultImg = UIGraphicsGetImageFromCurrentImageContext();//从当前上下文中获得最终图片
//    UIGraphicsEndImageContext();//关闭上下文
//
//    return resultImg;
//}
//- (UIImage *) createImageWithColor: (UIColor *) color
//{
//    CGRect rect = CGRectMake(0.0f,0.0f,1.0f,1.0f);
//    UIGraphicsBeginImageContext(rect.size);
//    CGContextRef context =UIGraphicsGetCurrentContext();
//    CGContextSetFillColorWithColor(context, color.CGColor);
//    CGContextFillRect(context, rect);
//    UIImage *myImage =UIGraphicsGetImageFromCurrentImageContext();
//    UIGraphicsEndImageContext();
//    return myImage;
//}


//- (void)saveImage:(UIImage *)image {
//    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
//    
//    
//    NSString *filePath = [[paths objectAtIndex:0]stringByAppendingPathComponent:
//                          [NSString stringWithFormat:@"demo.png"]];  // 保存文件的名称
//    
//    BOOL result =[UIImagePNGRepresentation(image)writeToFile:filePath   atomically:YES]; // 保存成功会返回YES
//    if (result == YES) {
//        NSLog(@"保存成功");
//    }
//    
//}

#pragma mark 预设
- (IBAction)preinstallAction:(id)sender {
    if (newQuotation.brandcode == nil) {
        [JKAlert showMessage:@"请选择车系"];
        return;
    }
    if (newQuotation.modelcode == nil) {
        [JKAlert showMessage:@"请选择车型"];
        return;
    }
    CalculationPreSetViewController *preSetController = [[CalculationPreSetViewController alloc]initWithSender:sender withModelCode:newQuotation.modelcode];
//    preSetController.modelCode = newQuotation.modelcode;
    [preSetController DidPreSetCell:^(NewQuotation *quotation) {
        //todo 带入数值
        newQuotation = quotation;
        [self reloadView];
    }];
    [self presentViewController:preSetController animated:YES completion:nil];
}
-(NSString *)numberSegmentationWithStr:(NSString *)numberStr{
    NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle: NSNumberFormatterDecimalStyle];
    numberFormatter.maximumFractionDigits = 2;
    numberFormatter.generatesDecimalNumbers = YES;
    NSString *numberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:[numberStr doubleValue]]];
    return numberString;
}
-(void)reloadView{
    //车系
    _brand.value = newQuotation.brand ;
    //车型
    _model.value = newQuotation.model;
    //全款合计
    _fullPayment.value = [self numberSegmentationWithStr:newQuotation.totalsum_s];
    //首付款合计
    _firstPayment.value = [self numberSegmentationWithStr:newQuotation.firstpaysum_s];

    //成交价格
    _transactionPrice.value = [self numberSegmentationWithStr:newQuotation.dealprice_s];
    //车船税
    _VVULPT_s.value = [self numberSegmentationWithStr:newQuotation.VVULPT_s];
    //其他
    _otherprice_s.value = [self numberSegmentationWithStr:newQuotation.otherprice_s];
    //上牌费用
    _platepremium_s.value = [self numberSegmentationWithStr:newQuotation.platepremium_s];
    //购置税
    _purchasetax_s.value = [self numberSegmentationWithStr:newQuotation.purchasetax_s];

    //指导价
    _guideprice_s.value = [self numberSegmentationWithStr:newQuotation.guideprice_s];
    //精品选装价格
    _boutiqueprice_s.value = [self numberSegmentationWithStr:newQuotation.boutiqueprice_s];
    //精品选装明细
    _boutiquecontent.text = newQuotation.boutiquecontent;

    //金融方案
    _financialplan.value = newQuotation.financialplan;
//    //合作伙伴
//    _cooperative;
    [self cooperativeload];
     _cooperative.joinedkeys = newQuotation.cooperativecode?:@"";
    //首付款
    _firstpayprice_s.value = [self numberSegmentationWithStr:newQuotation.firstpayprice_s];
    //期数
    _periods.value = newQuotation.periods;
    //首付比例
    _firstpayscale.value = [NSString stringWithFormat:@"%@%%",newQuotation.firstpayscale?:@"0"];
    //贷款额
    _loanvalue_s.value =[self numberSegmentationWithStr: newQuotation.loanvalue_s];
    //金融服务费
    _financialservice_s.value = [self numberSegmentationWithStr:newQuotation.financialservice_s];
    //月供
    _monthlyprice_s.value = [self numberSegmentationWithStr:newQuotation.monthlyprice_s];
    //利息
    _interests.value = [self numberSegmentationWithStr:newQuotation.interests];

    //保险费用
    _insuranceprice_s.value = [self numberSegmentationWithStr:newQuotation.insuranceprice_s];
    //保险公司
    _insurance.value = newQuotation.insurance;
//    //险种
//    _insuranceType;
    _insuranceType.joinedkeys = newQuotation.insurancetypecode?:@"";
    [self enableViews];

}
#pragma mark 金融计算
-(NSString *)checkCalculation{
    NSString *warningStr = nil;
    if (newQuotation.dealprice_s == nil) {
        warningStr = @"请填写优惠后车价格";
//    }else if(newQuotation.purchasetax_s == nil){
//        warningStr = @"请填写购置税";
//    }else if(newQuotation.VVULPT_s == nil){
//        warningStr = @"请填写车船税";
//    }else if(newQuotation.platepremium_s == nil){
//        warningStr = @"请填写上牌费用";
//    }else if(newQuotation.boutiqueprice_s == nil){
//        warningStr = @"请填写精品选装价格";
//    }else if(newQuotation.otherprice_s == nil){
//        warningStr = @"请填写其他费用";
//    }
    }else if(newQuotation.firstpayprice_s == nil && newQuotation.financialplancode!= nil){
        warningStr = @"请填写首付款";
    }else if(newQuotation.firstpayscale == nil && newQuotation.financialplancode!= nil){
        warningStr = @"请填写首付比例";
    }else if(newQuotation.periodscode == nil && newQuotation.financialplancode!= nil){
        warningStr = @"请填写还款期数";
    }else if(newQuotation.loanvalue_s == nil && newQuotation.financialplancode!= nil){
        warningStr = @"请填写贷款额";
    }
//    else if(newQuotation.financialservice_s == nil && newQuotation.financialplancode!= nil){
//        warningStr = @"请填写金融服务费";
//    }
//    else if(newQuotation.insuranceprice_s == nil){
//        warningStr = @"请填写保险费用";
//    }
    return warningStr;
}
- (IBAction)calculationAction:(id)sender {
    NSString *warning = [self checkCalculation];
    if (warning != nil) {
        [JKAlert showMessage:warning];
        return;
    }
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setObject:newQuotation.dealprice_s?:@"" forKey:@"dealprice_s"];
    [param setObject:newQuotation.purchasetax_s?:@"" forKey:@"purchasetax_s"];
    [param setObject:newQuotation.VVULPT_s?:@"" forKey:@"VVULPT_s"];
    [param setObject:newQuotation.platepremium_s?:@"" forKey:@"platepremium_s"];
    [param setObject:newQuotation.boutiqueprice_s?:@"" forKey:@"boutiqueprice_s"];
    [param setObject:newQuotation.otherprice_s?:@"" forKey:@"otherprice_s"];
    [param setObject:newQuotation.firstpayprice_s?:@"" forKey:@"firstpayprice_s"];
    [param setObject:newQuotation.firstpayscale?:@"" forKey:@"firstpayscale"];
    [param setObject:newQuotation.periods?:@"" forKey:@"periods"];
    [param setObject:newQuotation.loanvalue_s?:@"" forKey:@"loanvalue_s"];
    [param setObject:newQuotation.financialservice_s?:@"" forKey:@"financialservice_s"];
    [param setObject:newQuotation.insuranceprice_s?:@"" forKey:@"insuranceprice_s"];
    [param setObject:newQuotation.financialplancode?:@"" forKey:@"financialplancode"];
    [param setObject:newQuotation.cooperativecode?:@"" forKey:@"cooperativecode"];
    [NewQuotation getFinancialComputeWithParam:param Success:^(NSDictionary *result, NSString *errorMessage) {
        if([result count]>0){
            NSInteger totalSum = [[result stringForKey:@"totalsum_s"]integerValue];
            NSString  *totalsum =[NSString stringWithFormat:@"%d",totalSum];
            _fullPayment.value = [self numberSegmentationWithStr:totalsum];
            newQuotation.totalsum_s = totalsum;
            
            NSInteger firstpaysum = [[result stringForKey:@"firstpaysum_s"]integerValue];
            NSString  *firstpaysum_s =[NSString stringWithFormat:@"%d",firstpaysum];
            _firstPayment.value = [self numberSegmentationWithStr:firstpaysum_s];
            
            newQuotation.firstpaysum_s = firstpaysum_s;
            NSString  *monthlyprice_s =[NSString stringWithFormat:@"%@",[result stringForKey:@"monthlyprice_s"]?:@"0"];
            _monthlyprice_s.value = [self numberSegmentationWithStr:monthlyprice_s];
            newQuotation.monthlyprice_s = monthlyprice_s;
            NSString  *interests =[NSString stringWithFormat:@"%@",[result stringForKey:@"interests"]?:@"0"];
            _interests.value = interests;
            newQuotation.interests = interests;
        }else{
            [JKAlert showMessage:errorMessage];
        }
        
    } Failure:^(NSError *error) {
        
    }];
}
#pragma mark 设为推荐
- (IBAction)setRecommendation:(id)sender {
    if (newQuotation.modelcode == nil) {
        [JKAlert showMessage:@"请选择车型"];
        return;
    }
    newQuotation.UID = [NewQuotation generateUuidString];
    newQuotation.createTimeTemp = [DateManager nowYMDString];
    newQuotation.boutiquecontent = _boutiquecontent.text;
    NSArray *list =[NewQuotation getRecommendationListWithParam:newQuotation.modelcode];
    if ([list count]>=3) {
        NewQuotation *quotation = [NewQuotation objectFromDictionary:[list firstObject]];
        if ([NewQuotation deleteRecommendationListWithUID:quotation.UID]) {
            if ([NewQuotation setRecommendationWithParam:[newQuotation toDictionary]]) {
                [JKAlert showMessage:@"设置推荐成功"];
            }else{
                [JKAlert showMessage:@"设置推荐失败，请重试"];
            }
        }else{
            [JKAlert showMessage:@"设置推荐失败，请重试"];
        }
    }else{
        if ([NewQuotation setRecommendationWithParam:[newQuotation toDictionary]]) {
            [JKAlert showMessage:@"设置推荐成功"];
        }else{
            [JKAlert showMessage:@"设置推荐失败，请重试"];
        }
    }
}
#pragma mark 保存
//转化保险 险种参数
-(void)convertInsurancetypecode{
    NSMutableArray *selectedKeys = [NSMutableArray array];
    NSArray *values = [newQuotation.insurancetypecode componentsSeparatedByString:@"^"];
    [values enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        for (id item in self.insuranceType.items) {
            if ([[item stringForKey:@"key"]isEqualToString:obj]) {
                [selectedKeys addObject:[item stringForKey:@"value"]];
            }
        }
    }];
    newQuotation.insurancetypecode = [selectedKeys componentsJoinedByString:@"'"];
}
//转化合作伙伴参数
-(NSString *)convertCooperativecode
{
    NSString *temp;
    for (id item in self.cooperative.items) {
        if ([[item stringForKey:@"key"]isEqualToString:newQuotation.cooperativecode]) {
             temp =[item stringForKey:@"value"];
        }
    }
    return temp;
}
- (IBAction)saveAction:(id)sender {
    newQuotation.createTimeTemp = [DateManager nowYMDString];
    newQuotation.boutiquecontent = _boutiquecontent.text;
    
    [self convertInsurancetypecode];
    NSMutableDictionary *param = [[NSMutableDictionary alloc]initWithDictionary:[newQuotation toDictionary]];
    NSString * custName;
    NSString * custMobiel;
    Customer *customer = [AppDelegate APP].rootViewController.clientRootViewController.customerFromRoot;
    custName = customer.custName;
    custMobiel = customer.custMobile;
    if (customer == nil) {
        CustomerReception *customerReception = [AppDelegate APP].rootViewController.clientRootViewController.customerReceptionForCale;
        custName = customerReception.collectCustName;
        custMobiel = customerReception.mobile;
    }
    [param setObject:custName?:@"" forKey:@"custName"];
    [param setObject:custMobiel?:@"" forKey:@"custMobiel"];
    
    [param setValue:[self convertCooperativecode]forKey:@"cooperative"];
    [param setValue:[AppDelegate APP].user.userID?:@"" forKey:@"salesuserid"];
    [param setValue:[AppDelegate APP].user.salesConsultantName?:@"" forKey:@"salesman"];
    [param setValue:[AppDelegate APP].user.mobile?:@""forKey:@"salesmobile"];
    
//    [NewQuotation saveQuotationWithParam:param Success:^(NSDictionary *result, NSString *errorMessage) {
//        if (errorMessage == nil) {
//            [JKAlert showMessage:@"保存成功"];
//    NSString *param ;
    NSMutableString *temp = [[NSMutableString alloc]init];
    [param enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        [temp appendString:[NSString stringWithFormat:@"%@=%@&",key,obj]];
    }];
    temp = (NSMutableString *)[temp substringToIndex:temp.length-1];
    NSString *htmlStr = [NSString stringWithFormat:@"%@/dspa_crmserver/%@?%@",[AppDelegate APP].ServerIP,GET_SAVE_QUOTATION,temp];
//    NSString *html= @"http://192.168.203.128:9002/dspa_crmserver/saveAndPrintQuotation.do?firstpayscale=0.06&financialservice_s=3000&firstpayprice_s=200000&custName=&cooperativecode=07BF0C66-D1FB-4974-AD3E-AF62C2D0FA8O&brand=奥迪C5&financialplancode=6572BE6D-88F2-4F26-B0D4-D7DABA216F67&createTimeTemp=2018-05-10&UID=E3F3B846-D107-4D54-8967-888A551AC6D8&custMobiel=&loanvalue_s=3333133.00&insurance=PICC10&financialplan=大连银行方案&periodscode=E72588D0-64C5-4DC0-ADA8-26A177D08AD5&modelcode=4B80C4&otherprice_s=33333&dealprice_s=3333333&boutiquecontent=Fewere300&platepremium_s=22555555&model=T2.4 手动&guideprice_s=25890000000&insuranceprice_s=3000&insurancecode=07BF0C66-D1FB-4974-AD3E-AF62C2D0FA8T&brandcode=4B&purchasetax_s=284900.26&VVULPT_s=13000&periods=18&boutiqueprice_s=5544";
    htmlStr = [htmlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURLRequest *request= [NSURLRequest requestWithURL:[NSURL URLWithString:htmlStr]];
            CalculationQuoteViewController *quote = [[CalculationQuoteViewController alloc]init];
//            //todo type
            quote.myRequset = request;
//            quote.quotetypeid = quotetypeid;
            [quote shouldReloadParentData:^(BOOL shouldReload, id data) {
                [self backButtonTouched:nil];
            }];
            [self presentViewController:quote animated:YES completion:nil];
//        }else{
//            [JKAlert showMessage:errorMessage];
//        }
//
//    } Failure:^(NSError *error) {
//
//    }];
}
@end
