//
//  FormulaStringCalcUtility.h
//  DSPA2015
//
//  Created by Cluy on 2018/3/14.
//  Copyright © 2018年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FormulaStringCalcUtility : NSObject
+ (NSString *)calcComplexFormulaString:(NSString *)formula;
@end
