//
//  CalculatorViewController.m
//  CRM
//
//  Created by Lion User on 09/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CalculatorViewController.h"

@interface CalculatorViewController ()

@end

@implementation CalculatorViewController
@synthesize num1;

-(instancetype)initWithSender:(UIView*)sender{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        self.modalPresentationStyle = UIModalPresentationPopover;
        self.preferredContentSize = self.view.frame.size;
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 80000
        self.popoverPresentationController.sourceView = sender;
        self.popoverPresentationController.sourceRect = sender.bounds;
        //        self.popoverPresentationController.popoverBackgroundViewClass = [GIKPopoverBackgroundView class];
        
#endif
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self setBtnsTitleStyle];
    self.num1 = [[NSString alloc] init];
    noperator = 0;
    numTxt.text = @"0";
}
-(void)setBtnsTitleStyle{
    oneBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f  alpha:0.98f];
    twoBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    threeBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    fourBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    fiveBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    sixBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    sevenBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    eightBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    nineBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    zeroBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    pointBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    backspaceBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    ceBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    cBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    plusBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    minusBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    multiBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    divideBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
    calcBtn.titleLabel.shadowColor = [UIColor colorWithWhite:0.0f alpha:0.98f];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    
    self.num1 = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

- (IBAction)onNumBtnsClick:(id)sender {
    NSString *str = [NSString string];
    if (sender == oneBtn) {
        str = @"1";
    }else if (sender == twoBtn){
        str = @"2";
    }else if (sender == threeBtn){
        str = @"3";
    }else if (sender == fourBtn){
        str = @"4";
    }else if (sender == fiveBtn){
        str = @"5";
    }else if (sender == sixBtn){
        str = @"6";
    }else if (sender == sevenBtn){
        str = @"7";
    }else if (sender == eightBtn){
        str = @"8";
    }else if (sender == nineBtn){
         str = @"9";
    }else if (sender == zeroBtn){
         str = @"0";
    }else if (sender == pointBtn){
         str = @".";
    }
//    NSRange w_range;
	if ([str length] != 0) {
		if( [str isEqualToString:@"."] ) {
			if ([numTxt.text length] == 0) {
				return;
			}else {
//				w_range = [numTxt.text rangeOfString:@"."];
//				if (w_range.length > 0) {
//					return;
//				}
			}
		}
	}
    
    if (flagOpr == YES) {
        numTxt.text = @"";
        flagOpr = NO;
    }
    
    if ([numTxt.text isEqualToString:@"0"] && ![str isEqualToString:@"."]) {
        numTxt.text = str;
    }else {
        numTxt.text = [numTxt.text stringByAppendingFormat:@"%@", str];
    }
    
}

- (IBAction)onClearBtnsClick:(id)sender {
    if (sender == backspaceBtn){
        if (![numTxt.text isEqualToString:@""]) {
            numTxt.text = [numTxt.text substringToIndex:numTxt.text.length -1];
        }        
    }else if (sender == ceBtn){
        numTxt.text = @"0";
    }else if (sender == cBtn){
        noperator = 0;
        num1 = @"";
        numTxt.text = @"0";
    }
}

- (IBAction)onCalcBtnsClick:(id)sender {
    if (sender == plusBtn){
        self.num1 = numTxt.text;
        noperator = 1;
        flagOpr = YES;
    }else if (sender == minusBtn){
        noperator = 2;
        self.num1 = numTxt.text;
        flagOpr = YES;
    }else if (sender == multiBtn){
        noperator = 3;
        self.num1 = numTxt.text;
        flagOpr = YES;
    }else if (sender == divideBtn){
        noperator = 4;
        self.num1 = numTxt.text;
        flagOpr = YES;
    }else if (sender == calcBtn){
        if (noperator != 0) {
            double temp = 0;
            switch (noperator) {
                case 1:
                    temp = [num1 doubleValue];
                    temp = temp + [numTxt.text doubleValue];
                    break;
                case 2:
                    temp = [num1 doubleValue];
                    temp = temp - [numTxt.text doubleValue];
                    break;
                case 3:
                    temp = [num1 doubleValue];
                    temp = temp * [numTxt.text doubleValue];
                    break;
                case 4:
                    temp = [num1 doubleValue];
                    temp = temp / [numTxt.text doubleValue];
                    break;
                    
                default:
                    break;
            }
            if (temp == (int)temp) {
                numTxt.text = [NSString stringWithFormat:@"%d", (int)temp];
            }else {
                numTxt.text = [NSString stringWithFormat:@"%f", temp];
            }
            
        }
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
	BOOL w_ret = YES;
	NSRange w_range;
	if ([string length] != 0) {
		if( [string isEqualToString:@"."] ) {
			if ([numTxt.text length] == 0) {
				w_ret = NO;
			}else {
				w_range = [numTxt.text rangeOfString:@"."];
				if (w_range.length > 0) {
					w_ret = NO;
				}
			}
		}
	}
	return w_ret;
}
#pragma mark UITextField
/*
 add return key back
 */
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)dealloc {

    self.num1 = nil;
    
}

@end
