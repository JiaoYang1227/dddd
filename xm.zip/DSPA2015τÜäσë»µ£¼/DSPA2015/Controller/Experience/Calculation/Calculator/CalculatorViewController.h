//
//  CalculatorViewController.h
//  CRM
//
//  Created by Lion User on 09/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface CalculatorViewController : BaseViewController<UITextFieldDelegate> {
    IBOutlet UITextField *numTxt;
    
    IBOutlet UIButton *oneBtn;
    IBOutlet UIButton *twoBtn;
    IBOutlet UIButton *threeBtn;
    IBOutlet UIButton *fourBtn;
    IBOutlet UIButton *fiveBtn;
    IBOutlet UIButton *sixBtn;
    IBOutlet UIButton *sevenBtn;
    IBOutlet UIButton *eightBtn;
    IBOutlet UIButton *nineBtn;
    IBOutlet UIButton *zeroBtn;
    IBOutlet UIButton *pointBtn;
    IBOutlet UIButton *backspaceBtn;
    IBOutlet UIButton *ceBtn;
    IBOutlet UIButton *cBtn;
    IBOutlet UIButton *plusBtn;
    IBOutlet UIButton *minusBtn;
    IBOutlet UIButton *multiBtn;
    IBOutlet UIButton *divideBtn;
    IBOutlet UIButton *calcBtn;
    
    NSString *num1;
    int      noperator;
    BOOL     flagOpr;
}
@property (nonatomic, retain) NSString *num1;

- (IBAction)onNumBtnsClick:(id)sender;
- (IBAction)onClearBtnsClick:(id)sender;
- (IBAction)onCalcBtnsClick:(id)sender;
-(instancetype)initWithSender:(UIView*)sender;
@end
