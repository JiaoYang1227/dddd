//
//  QRCodeViewController.m
//  DSPA2015
//
//  Created by sun on 16/7/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "QRCodeViewController.h"
#import "HMScannerController.h"
#import "CalculationQuoteViewController.h"
@interface QRCodeViewController ()

@end

@implementation QRCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [HMScannerController cardImageWithCardName:self.codeStr avatar:nil scale:0.2 completion:^(UIImage *image) {
        self.imageView.image = image;
    }];
}
- (IBAction)dismissTouched:(id)sender {
    CalculationQuoteViewController *borad = (CalculationQuoteViewController*)self.parentViewController;
    
    [UIView animateWithDuration:0.3 animations:^{
        borad.coverView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
        //        [self.referenceViewController viewWillAppear:YES];
    } completion:^(BOOL finished) {
        [borad.coverView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
