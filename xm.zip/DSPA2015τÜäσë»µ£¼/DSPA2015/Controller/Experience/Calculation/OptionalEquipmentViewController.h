//
//  OptionalEquipmentViewController.h
//  DSPA2015
//
//  Created by Cluy on 16/8/8.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
typedef void(^OptionalEquipmentCallback)(NSDictionary *values);
@interface OptionalEquipmentViewController : BaseViewController<UIWebViewDelegate>
{
}
@property (weak, nonatomic) IBOutlet UIWebView *webview;
@property (copy, nonatomic) OptionalEquipmentCallback optionalEquipmentCallback;

@property (nonatomic,strong) NSDictionary *param;
@property (strong, nonatomic) JSContext *context;
-(void)OptionalEquipmentCallback:(OptionalEquipmentCallback)optionalEquipmentCallback;

@end
