//
//  CalculationNextViewController.m
//  DSPA2015
//
//  Created by Cluy on 15/11/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "CalculationNextViewController.h"
#import "CalculationQuoteViewController.h"
#import "CalculationAndQuote.h"
#import "MBProgressHUD.h"

@interface CalculationNextViewController (){
    NSString *quotetypeid;
}

@end

@implementation CalculationNextViewController
-(void)setMyRequset:(NSURLRequest *)myRequset{
    _myRequset = myRequset;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    _custName.text = _custNameText;
    _custMobiel.text =_custMobile;

    _webView.delegate = self;
    [_webView loadRequest:self.myRequset];
    quotetypeid= [NSString string];
    self.title = @"购车计算下一步";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    NSLog(@"request.URL:%@",request.URL);
    
    NSString *requestString = [[[request URL]  absoluteString] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding ];
    //下一步
    if ([requestString rangeOfString:@"addquoteprice.html"].location !=NSNotFound) {
        CalculationQuoteViewController *quote = [[CalculationQuoteViewController alloc]init];
        //todo type
        quote.myRequset = [request copy];
        quote.quotetypeid = quotetypeid;
        [self presentViewController:quote animated:YES completion:nil];
        return NO;
    }
    
    return YES;
}
#pragma mark Actions-------------------------------------------------------------------
- (IBAction)nextStepAction:(id)sender {

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CalculationAndQuote getQuotepricetypeListWithSuccess:^(NSArray *result, id responseObject) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        //todo 弹出选择页面
        if ([result count]>0) {
            if([result count]==1){
                NSDictionary *dic = [result objectWithIndex:0];
                NSString *param = [NSString stringWithFormat:@"actionProcess('%@')",[dic stringForKey:@"key"]];
                quotetypeid = [dic stringForKey:@"key"];
                [_webView stringByEvaluatingJavaScriptFromString:param];
            }else{
                
             
                PopoverSearchController *search = [[PopoverSearchController alloc]initWithSender:sender andItems:result];
                search.searchBar.hidden = YES;
                [search didSelectSearchItem:^(id item, NSString *key, NSString *value) {
                    NSString *param = [NSString stringWithFormat:@"actionProcess('%@')",key];
                    quotetypeid = key;
                    [_webView stringByEvaluatingJavaScriptFromString:param];
                }];
                [self presentViewController:search animated:YES completion:nil];
            }
        }else{
            [JKAlert showMessage:@"无报价单类型，不能生成报价单"];
        }
    } Failure:^(NSError *error) {
         [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}];
   
   

}
#pragma mark ios8 多次点击webview下拉选框崩溃
-(void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion
{
    if (completion) {
        completion();
    }
    [super dismissViewControllerAnimated:NO completion:nil];
}
-(void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completion
{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_USEC), dispatch_get_main_queue(),
//                   ^{
                       [super presentViewController:viewControllerToPresent animated:flag completion:completion];
//                   });
}
@end
