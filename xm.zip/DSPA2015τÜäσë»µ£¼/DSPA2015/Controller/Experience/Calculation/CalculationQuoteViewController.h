//
//  CalculationDetailViewController.h
//  D-CARS
//
//  Created by Jakey on 15/10/23.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>

@interface CalculationQuoteViewController : BaseViewController<UIWebViewDelegate>
{
    UIActionSheet *printSheet;
    ShouldReloadParentData _shouldReloadParentData;
    BOOL _isPrint;
}
@property (nonatomic)BOOL isFromHistory;//是否来自报价单历史
@property (nonatomic)BOOL isImport; //是否关联
@property (nonatomic,strong)NSString *priceid;//quotepriceid
@property (weak, nonatomic) IBOutlet UIButton *saveQuoteBtn;
@property (weak, nonatomic) IBOutlet UIButton *importQuoteBtn;
@property (weak, nonatomic) IBOutlet UIButton *printBtn;
@property (weak, nonatomic) IBOutlet UIWebView *quoteWebView;
@property (strong, nonatomic) NSURLRequest *myRequset;
@property (strong, nonatomic) JSContext *context;
@property (weak, nonatomic) IBOutlet UIButton *RQcodeBTN;
@property(strong,nonatomic)  UIView *coverView;
@property (strong,nonatomic)NSString *quotetypeid;

-(void)shouldReloadParentData:(ShouldReloadParentData)shouldReloadParentData;
@end
