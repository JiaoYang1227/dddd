//
//  QRCodeViewController.h
//  DSPA2015
//
//  Created by sun on 16/7/28.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"

@interface QRCodeViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic,strong)NSString *codeStr;
@end
