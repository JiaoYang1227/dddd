//
//  RecommendationViewController.m
//  DSPA2015
//
//  Created by runlin on 2017/3/9.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "RecommendationViewController.h"
#import "Recommendation.h"
#import "RecommendationCell.h"
#import "RecommendationDetailViewController.h"
#import "UIViewController+DSPAPopup.h"
#import "RecommendationSearchViewController.h"
#import "UIViewController+DSPAPopup.h"
@interface RecommendationViewController ()

@end

@implementation RecommendationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self.myTableView registerNib:[UINib nibWithNibName:@"RecommendationCell" bundle:nil] forCellReuseIdentifier:@"RecommendationCell"];
    
    _currentPage =1;
    
    [self loadData:_currentPage];
}
- (IBAction)backButtonTouched:(id)sender {
    [super backButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
}
-(void)backHomeButtonTouched:(id)sender{
    [super backHomeButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
}
-(void)loadData:(NSInteger)pageon{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    if (_dataArray && pageon==1) {
        _currentPage =1;
        [_dataArray removeAllObjects];
        [self.myTableView reloadData];
        
    }
    if (!_recommendationSearch) {
        _recommendationSearch = [[RecommendationSearch alloc]init];
    }
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    _recommendationSearch.pageon = pageon;
    
    [Recommendation getRecommendations:[_recommendationSearch toDictionary] Success:^(NSDictionary *dic, id responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        [_dataArray addObjectsFromArray:[dic arrayForKey:@"result"]];
        [self.myTableView reloadData];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];

    }];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_dataArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    RecommendationCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RecommendationCell"];
    
    if (indexPath.row %2 == 0) {
        cell.contentView.backgroundColor = [UIColor whiteColor];
    }else{
        cell.contentView.backgroundColor = [UIColor colorWithWhite:0.945 alpha:1.000];
    }
    
   [cell bindData:[_dataArray objectWithIndex:indexPath.row]];
    
    return cell;
}


#pragma mark --UICollectionViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    RecommendationDetailViewController *detail = [[RecommendationDetailViewController alloc]initWithMode:RecommendationTypeLook];
    id item = [_dataArray objectWithIndex:indexPath.row];
    detail.ID = [item stringForKey:@"id"];
    
    [self presentDSPAPopup:detail parentViewController:self touchCallBack:^{
        
    } haveMask:NO includeNavgation:YES alignTop:YES];
    
}
//上拉加载
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"indexPath.row%zd",indexPath.row);
    if (indexPath.row+1 == _currentPage*20)
    {
        _currentPage++;
        NSLog(@"page = %zd",_currentPage);
        [self loadData:_currentPage];
    }
}


- (IBAction)searchTouched:(id)sender {
    RecommendationSearchViewController *search = [[RecommendationSearchViewController alloc]init];
    search.searchModel = [_recommendationSearch copy];

    [self presentDSPAPopup:search parentViewController:self touchCallBack:^{
        
    } haveMask:YES includeNavgation:YES alignTop:NO];
    [search advancedSearchDone:^(id item) {
        _recommendationSearch = [item copy];
        [self loadData:1];
    }];
}
@end
