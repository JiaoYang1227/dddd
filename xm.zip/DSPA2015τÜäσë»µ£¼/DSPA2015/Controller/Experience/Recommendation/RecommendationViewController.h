//
//  RecommendationViewController.h
//  DSPA2015
//
//  Created by runlin on 2017/3/9.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "RecommendationSearch.h"
@interface RecommendationViewController : BaseViewController
{
    NSMutableArray *_dataArray;
    NSInteger _currentPage;
    RecommendationSearch *_recommendationSearch;
}
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
- (IBAction)searchTouched:(id)sender;

@end
