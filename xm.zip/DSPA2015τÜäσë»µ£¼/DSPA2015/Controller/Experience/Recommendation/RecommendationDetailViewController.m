//
//  RecommendationDetailViewController.m
//  DSPA2015
//
//  Created by runlin on 2017/3/9.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "RecommendationDetailViewController.h"
#import "NSString+UUID.h"
#import "UIViewController+DSPAPopup.h"
#import "APIManager.h"
@interface RecommendationDetailViewController ()<UIPrintInteractionControllerDelegate>

@end

@implementation RecommendationDetailViewController
-(instancetype)initWithMode:(RecommendationType)recommendationType{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        _recommendationType = recommendationType;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self reload];
    
    if (_recommendationType == RecommendationTypeLook) {
        //        self.oprationBarHeight.constant = 0;
        self.saveButton.enabled = NO;
        self.cancleButton.enabled = NO;
        
    }else{
        self.titleBarHeight.constant = 0;
        self.titleBarView.clipsToBounds = YES;
    }
}
- (void)reload{
    
    NSString *baseInterface = [NSString stringWithFormat:@"%@%@",[AppDelegate APP].ServerIP?:@"http://",URI_INTERFACE_ROOT];
    NSString *serverUrlPrefix =[NSString stringWithFormat:@"%@%@?random=%@",baseInterface,INTERFACE_RECOMMEND_INFO,[NSString UUID]];
    if (self.ID.length>0) {
        serverUrlPrefix = [serverUrlPrefix stringByAppendingString:[NSString stringWithFormat:@"&id=%@",self.ID]];
    }
    if (self.customerID.length>0) {
        serverUrlPrefix = [serverUrlPrefix stringByAppendingString:[NSString stringWithFormat:@"&customerId=%@",self.customerID]];
    }
    if (self.collectCustID.length>0) {
        serverUrlPrefix = [serverUrlPrefix stringByAppendingString:[NSString stringWithFormat:@"&collectCustId=%@",self.collectCustID]];
    }
    [self.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:serverUrlPrefix]]];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    // 以 html title 设置 导航栏 title
    //    self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    // Undocumented access to UIWebView's JSContext
    self.context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    // 打印异常
    self.context.exceptionHandler =
    ^(JSContext *context, JSValue *exceptionValue)
    {
        context.exception = exceptionValue;
        NSLog(@"%@", exceptionValue);
    };
    
    
    __weak typeof(self) weakSelf = self;
    //多参数
    self.context[@"carInfoSavedCallback"] =
    ^(NSString *i)
    {
        __strong typeof(self) strongSelf = weakSelf;
        
        strongSelf.ID = i;
        if (strongSelf->_recommendationDetailCallback) {
            strongSelf->_recommendationDetailCallback(i);
        }
        NSLog(@"ID:%@",i);
    };
    if (_recommendationLoadDoneCallback) {
        _recommendationLoadDoneCallback(YES);
    }
    
}

-(void)recommendationDetailCallback:(RecommendationDetailCallback)recommendationDetailCallback{
    _recommendationDetailCallback = [recommendationDetailCallback copy];
}
-(void)recommendationInfoCallback:(RecommendationInfoCallback)recommendationInfoCallback{
    _recommendationInfoCallback = [recommendationInfoCallback copy];
}
-(void)recommendationLoadDoneCallback:(RecommendationLoadDoneCallback)recommendationLoadDoneCallback{
    _recommendationLoadDoneCallback = [recommendationLoadDoneCallback copy];
}
- (IBAction)backButtonTouched:(id)sender {
    [self dismissDSPAPopup:^{
        
    }];
}
-(void)saveNewcarInfo:(NSString*)customerId collectCustId:(NSString*)collectCustId{
    NSString *param = [NSString stringWithFormat:@"saveNewcarInfo('%@','%@')", customerId,collectCustId];
    [self.webview stringByEvaluatingJavaScriptFromString:param];
}
-(void)saveCustomerInfo:(NSString*)custName custMobile:(NSString *)custMobile saleName:(NSString*)saleName saleMobile:(NSString*)saleMobile{
    //  saveCustomerInfo(custName,custMobile,saleName,saleMobile)
    NSString *param = [NSString stringWithFormat:@"saveCustomerInfo('%@','%@','%@','%@')", custName,custMobile,saleName,saleMobile];
    [self.webview stringByEvaluatingJavaScriptFromString:param];
}

- (IBAction)printTouched:(UIButton*)sender {
    //  解决 弹出窗太大问题
    self.modalPresentationStyle = UIModalPresentationFormSheet;
    //调整箭头方向
    //    UIActionSheet *printSheet;
    //
    //    [printSheet showFromRect:[self.view convertRect:CGRectMake(0, 0, 93, 42) fromView:self.view] inView:self.view animated:YES];
    //    NSLog(@"%@",NSStringFromCGRect(printBTN.frame));
    UIPrintInteractionController *controller = [UIPrintInteractionController sharedPrintController];
    
    if(!controller){
        NSLog(@"Couldn't get shared UIPrintInteractionController!");
        return;
    }
    UIPrintInteractionCompletionHandler completionHandler =
    ^(UIPrintInteractionController *printController, BOOL completed, NSError *error) {
        if(!completed && error){
            NSLog(@"FAILED! due to error in domain %@ with error code %zd", error.domain, error.code);
        }
    };
    
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    printInfo.outputType = UIPrintInfoOutputGeneral;
    printInfo.duplex = UIPrintInfoDuplexLongEdge;
    controller.printInfo = printInfo;
    controller.delegate = self;
    controller.showsPageRange = YES;
    controller.printFormatter = [self.webview viewPrintFormatter];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:sender];
    [controller presentFromBarButtonItem:item animated:YES completionHandler:completionHandler];
}
- (void)printInteractionControllerDidFinishJob:(UIPrintInteractionController *)printInteractionController{
    if (self.ID) {
        [APIManager SafePOST:@"updateNewCarInfo.do" parameters:@{@"isDy":@1,@"id":self.ID} appendUserInfo:YES success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
        }];
    }
}

- (IBAction)saveTouched:(id)sender {
    if (self.customerID || self.collectCustID) {
        [self saveNewcarInfo:self.customerID collectCustId:self.collectCustID];
    }
    self.view.hidden = YES;
    
    JSValue *value=  [self.context evaluateScript:@"getCustomerInfoForIOS()"];
    id objec = [value toDictionary];
    
    if (_recommendationInfoCallback) {
        if ([objec stringForKey:@"customer_name"]|| [objec stringForKey:@"customer_mobile"]) {
            _recommendationInfoCallback([objec stringForKey:@"customer_name"],[objec stringForKey:@"customer_mobile"]);
        }
    }
}

- (IBAction)cancleTouched:(id)sender {
    if (_recommendationType == RecommendationTypeLook) {
        [self dismissDSPAPopup:^{
            
        }];
    }else{
        self.view.hidden = YES;
        if (_recommendationDetailCallback) {
            _recommendationDetailCallback(nil);
        }
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
