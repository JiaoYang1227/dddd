//
//  RecommendationSearchViewController.h
//  DSPA2015
//
//  Created by runlin on 2017/3/13.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "BaseSearchViewController.h"
#import "RecommendationSearch.h"
@interface RecommendationSearchViewController : BaseSearchViewController
@property (weak, nonatomic) IBOutlet SelectButton *beginButton;
@property (weak, nonatomic) IBOutlet SelectButton *endButton;
@property (strong, nonatomic) RecommendationSearch *searchModel;

@end
