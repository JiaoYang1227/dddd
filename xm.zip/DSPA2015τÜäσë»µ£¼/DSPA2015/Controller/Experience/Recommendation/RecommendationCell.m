//
//  RecommendationCell.m
//  DSPA2015
//
//  Created by runlin on 2017/3/9.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "RecommendationCell.h"
#import "NSDictionary+SafeAccess.h"
#import "DateManager.h"
@implementation RecommendationCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)bindData:(NSDictionary*)item{
    self.nameLabel.text = [item stringForKey:@"customerName"];
    self.mobileLabel.text= [item stringForKey:@"customerMobile"];
    self.dateLabel.text=  [item stringForKey:@"createTime"];
    self.printLabel.text= [item stringForKey:@"isDy"];
}
@end
