//
//  RecommendationCell.h
//  DSPA2015
//
//  Created by runlin on 2017/3/9.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecommendationCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *mobileLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *printLabel;
-(void)bindData:(NSDictionary*)item;
@end
