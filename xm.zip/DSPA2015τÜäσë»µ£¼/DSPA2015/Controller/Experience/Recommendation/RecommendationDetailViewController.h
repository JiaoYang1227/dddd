//
//  RecommendationDetailViewController.h
//  DSPA2015
//
//  Created by runlin on 2017/3/9.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "BaseViewController.h"
#import "Enumeration.h"
#import <JavaScriptCore/JavaScriptCore.h>

typedef void(^RecommendationDetailCallback)(NSString *ID);

typedef void(^RecommendationLoadDoneCallback)(BOOL done);


typedef void(^RecommendationInfoCallback)(NSString *custName,NSString *custMobile);

@interface RecommendationDetailViewController : BaseViewController
{
    RecommendationType _recommendationType;
    RecommendationDetailCallback _recommendationDetailCallback;
    RecommendationInfoCallback _recommendationInfoCallback;
    RecommendationLoadDoneCallback _recommendationLoadDoneCallback;
}
@property (strong, nonatomic) JSContext *context;
@property (weak, nonatomic) IBOutlet UIWebView *webview;
@property (strong, nonatomic) NSString *ID;
@property (strong, nonatomic) NSString *customerID;
@property (strong, nonatomic) NSString *collectCustID;
@property (weak, nonatomic) IBOutlet UIButton *saveButton;
@property (weak, nonatomic) IBOutlet UIButton *cancleButton;
@property (weak, nonatomic) IBOutlet UIView *titleBarView;

- (void)reload;
-(instancetype)initWithMode:(RecommendationType)recommendationType;
-(void)recommendationDetailCallback:(RecommendationDetailCallback)recommendationDetailCallback;
-(void)recommendationInfoCallback:(RecommendationInfoCallback)recommendationInfoCallback;
-(void)recommendationLoadDoneCallback:(RecommendationLoadDoneCallback)recommendationLoadDoneCallback;

-(void)saveNewcarInfo:(NSString*)customerId collectCustId:(NSString*)collectCustId;
- (void)saveCustomerInfo:(NSString*)custName custMobile:(NSString *)custMobile saleName:(NSString*)saleName saleMobile:(NSString*)saleMobile;


- (IBAction)printTouched:(id)sender;
- (IBAction)saveTouched:(id)sender;
- (IBAction)cancleTouched:(id)sender;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleBarHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *oprationBarHeight;
@end
