//
//  RecommendationSearchViewController.m
//  DSPA2015
//
//  Created by runlin on 2017/3/13.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "RecommendationSearchViewController.h"

@interface RecommendationSearchViewController ()

@end

@implementation RecommendationSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.beginButton.key = [DateManager timeStampStringWithDate:[DateManager dateConvertFrom_YMD_String:_searchModel.startTime]];
    self.beginButton.value = _searchModel.startTime;

    
    self.endButton.key = [DateManager timeStampStringWithDate:[DateManager dateConvertFrom_YMD_String:_searchModel.endTime]];
    self.endButton.value = _searchModel.endTime;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)beginSelectButtonTouched:(SelectButton*)sender {
    PopoverDateController *dateController =  [self showDatePickerController:sender completion:nil];
    //    dateController.minDate = [NSDate date];
    dateController.datePickerMode = UIDatePickerModeDate;
}

- (IBAction)endSelectButtonTouched:(id)sender {
    PopoverDateController *dateController =  [self showDatePickerController:sender completion:nil];
    dateController.datePickerMode = UIDatePickerModeDate;
}
-(void)advancedSearchTouched:(UIButton *)sender{
    [super advancedSearchTouched:sender];
    
    if (!_searchModel) {
        _searchModel = [[RecommendationSearch alloc]init];
    }
  
    _searchModel.startTime = [DateManager date_YMD_WithTimeIntervalSince1970:[self.beginButton.key longLongValue]] ;
    _searchModel.endTime = [DateManager date_YMD_WithTimeIntervalSince1970:[self.endButton.key longLongValue]] ;

    
    if (_advancedSearchDone) {
        _advancedSearchDone(_searchModel);
    }
  
}
-(IBAction)resetTouched:(UIButton *)sender{
    [self.beginButton reset];
    [self.endButton reset];
}

@end
