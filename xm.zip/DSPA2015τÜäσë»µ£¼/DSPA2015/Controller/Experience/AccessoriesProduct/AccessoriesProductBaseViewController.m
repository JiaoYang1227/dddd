//
//  AccessoriesProductBaseViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/29.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AccessoriesProductBaseViewController.h"
#import "AccessoriesProductViewController.h"

@interface AccessoriesProductBaseViewController ()

@end

@implementation AccessoriesProductBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)dismissTouched:(id)sender {
    AccessoriesProductViewController *borad = (AccessoriesProductViewController*)self.parentViewController;
    
    [UIView animateWithDuration:0.3 animations:^{
        borad.coverView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
        //        [self.referenceViewController viewWillAppear:YES];
    } completion:^(BOOL finished) {
        [borad.coverView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
