//
//  AccessoriesProductFiltrateViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/29.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AccessoriesProductBaseViewController.h"
#import "AccessoriesProductSearch.h"

typedef void(^onAccessoriesProductFiltrateCallBack)(AccessoriesProductSearch *searchModel);

@interface AccessoriesProductFiltrateViewController : AccessoriesProductBaseViewController



@property (nonatomic , strong) NSMutableArray *categoryList;  //分类
@property (nonatomic , strong) NSMutableArray *carTypeList;   //车型


@property (nonatomic , copy) onAccessoriesProductFiltrateCallBack callBackAccessoriesProductFiltrate;

@end
