//
//  ExtendsCollectionViewDelegate.h
//  Evaluation
//
//  Created by gavin on 15/7/14.
//  Copyright (c) 2015年 gavin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ExtendsCollectionViewDelegate : BaseViewController<UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>

@end
