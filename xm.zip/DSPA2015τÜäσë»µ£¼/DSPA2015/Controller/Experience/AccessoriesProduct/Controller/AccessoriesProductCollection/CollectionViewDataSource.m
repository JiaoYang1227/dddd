//
//  CollectionViewDataSource.m
//  Evaluation
//
//  Created by gavin on 15/7/13.
//  Copyright (c) 2015年 gavin. All rights reserved.
//

#import "CollectionViewDataSource.h"


@interface CollectionViewDataSource()

@property (nonatomic, copy)   NSString *cellIdentifier;
@property (nonatomic, copy)   CollectionViewCellConfigureBlock configureCellBlock;
@property (nonatomic ) NSInteger numberOfItemsInSection;
@property (nonatomic ) NSInteger sections;

@property (nonatomic , strong)UICollectionReusableView *headView;

@end

@implementation CollectionViewDataSource

#pragma mark - Initialization

- (id)init {
    // 只能通过initWithItems:cellIdentifier:configureCellBlock:方法初始化
    return nil;
}

- (id)initWithCellIdentifier:(NSString *)aCellIdentifier
                                    configureCellBlock:(CollectionViewCellConfigureBlock)aConfigureCellBlock
                          numberOfSectionsInCollection:(NSInteger)sections
{
    self = [super init];
    
    if (self) {
        _items =[NSMutableArray array];
        self.cellIdentifier     = aCellIdentifier;
        self.configureCellBlock = [aConfigureCellBlock copy];
        self.sections = sections;
    }
    
    return self;
}


- (id)initWithCellIdentifier:(NSString *)aCellIdentifier
          configureCellBlock:(CollectionViewCellConfigureBlock)aConfigureCellBlock
numberOfSectionsInCollection:(NSInteger)sections
withUICollectionReusableView:(UICollectionReusableView*)headView
{
    self = [super init];
    
    if (self) {
        _items =[NSMutableArray array];
        self.cellIdentifier     = aCellIdentifier;
        self.configureCellBlock = [aConfigureCellBlock copy];
        self.sections = sections;
        self.headView = headView;
    }
    
    return self;
}


- (id)itemAtIndexPath:(NSIndexPath *)indexPath {
    return self.items[(NSUInteger) indexPath.row];
}

#pragma mark -- UICollectionViewDataSource
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.items count];
}
//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return self.sections;
}
//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:self.cellIdentifier forIndexPath :indexPath];
    
    id item = [self itemAtIndexPath:indexPath];
    
    self.configureCellBlock(cell , item , indexPath.row);
    
    return cell;
}

//头部显示的内容
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    
    UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:
                                            UICollectionElementKindSectionHeader withReuseIdentifier:@"LoopView" forIndexPath:indexPath];
    
    [headerView addSubview:self.headView];
    return headerView;
}


@end