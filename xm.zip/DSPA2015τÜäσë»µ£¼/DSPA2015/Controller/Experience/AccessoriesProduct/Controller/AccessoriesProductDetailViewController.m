//
//  AccessoriesProductDetailViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/31.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AccessoriesProductDetailViewController.h"
#import "KeychainManager.h"
#import "UIImageView+AFNetworking.h"

@interface AccessoriesProductDetailViewController ()
{
    
    
    __weak IBOutlet UIImageView     *_detailedImage;
    __weak IBOutlet UILabel         *_detailedName;
    __weak IBOutlet UILabel         *_detailedNumber;
    __weak IBOutlet UILabel         *_detailedMoney;
    __weak IBOutlet UITextView      *_detailedInfo;
    
    
}
@end

@implementation AccessoriesProductDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (self.isLoop) {
        [self bringDataLoop:self.apLoop];
    }else{
        [self bringData:self.ap];
    }
    self.title = @"精品附件详情";
}

- (void)bringDataLoop:(AccessoriesProductLoopAd *)ap{
    [_detailedImage setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@%@",[KeychainManager getBaseURL],URI_INTERFACE_ROOT,ap.stuffpathDefault]]];
    _detailedName.text      = [ap.stuffname description];           //零件名称
    _detailedNumber.text    = [ap.stuffnumber description];         //零件号
    _detailedMoney.text     = [ap.stuffprice description];          //零件价格
    _detailedInfo.text      = [ap.stuffdiscribe description];       //零件信息
}


- (void)bringData:(AccessoriesProduct *)ap{
    [_detailedImage setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@%@",[KeychainManager getBaseURL],URI_INTERFACE_ROOT,ap.stuffpath]]];
    _detailedName.text      = [ap.stuffname description];           //零件名称
    _detailedNumber.text    = [ap.stuffnumber description];         //零件号
    _detailedMoney.text     = [ap.stuffprice description];          //零件价格
    _detailedInfo.text      = [ap.stuffdiscribe description];       //零件信息
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
