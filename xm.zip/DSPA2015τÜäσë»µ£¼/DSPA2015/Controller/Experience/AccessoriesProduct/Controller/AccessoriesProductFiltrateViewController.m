//
//  AccessoriesProductFiltrateViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/29.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AccessoriesProductFiltrateViewController.h"

#import "AccessoriesProductCategory.h"
#import "CarType.h"

@interface AccessoriesProductFiltrateViewController ()
{
    
    __weak IBOutlet UITextField *_searchWord;   //搜索文字
    __weak IBOutlet SelectView *_categoryView;  //分类
    __weak IBOutlet SelectView *_carTypeView;   //车型
    __weak IBOutlet SelectView *_brandView;     //品牌
    AccessoriesProductSearch   *_searchModel;
    
    
    NSMutableArray *_categoryList;  //分类
    NSMutableArray *_carTypeList;   //车型
}
- (IBAction)okButtonAction:(id)sender;
@end

@implementation AccessoriesProductFiltrateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"精品附件高级搜索";
}

- (void)filterView{
    
    _searchModel = [[AccessoriesProductSearch alloc] init];
    
    NSMutableArray *categoryList = [[NSMutableArray alloc] init];
    for (AccessoriesProductCategory *ap in _categoryList) {
        [categoryList addObj:ap.familyname];
    }
    _categoryView.items = categoryList?:@[@"ALL"];
    [_categoryView didSelectItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        for (AccessoriesProductCategory *ap in _categoryList) {
            if ([ap.familyname isEqualToString:value]) {
                _searchModel.familyId = ap.familyid;
            }
        }
    }];
    
    NSMutableArray *carType = [[NSMutableArray alloc] init];
    for (CarType *car in _carTypeList) {
        [carType addObj:car.value];
    }
    _carTypeView.items = carType?:@[@"ALL"];
    [_carTypeView didSelectItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        for (CarType *ap in _carTypeList) {
            if ([ap.value isEqualToString:value]) {
                _searchModel.brandId = ap.key;
            }
        }
    }];
    
    _brandView.items = @[@"ALL",@"Audi",@"其他"];
    [_brandView didSelectItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        _searchModel.typeId = [NSString stringWithFormat:@"%zd",index?:0];
    }];
    
}

/**
 *   确认按钮点击
 */
- (IBAction)okButtonAction:(id)sender {
    
    _searchModel.stuffName = _searchWord.text?:@"";
    
    if (self.callBackAccessoriesProductFiltrate) {
        self.callBackAccessoriesProductFiltrate(_searchModel);
    }
    
    [self dismissTouched:nil];
}











- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
