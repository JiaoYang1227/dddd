//
//  AccessoriesProductViewController.m
//  DSPA2015
//
//  Created by gavin on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AccessoriesProductViewController.h"
#import "CollectionViewDataSource.h"
#import "AccessoriesProductCell.h"
#import "iCarousel.h"
#import "AccessoriesProductCell.h"
#import "UIImageView+AFNetworking.h"

#import "AccessoriesProductLoopAd.h"
#import "AccessoriesProduct.h"
#import "AccessoriesProductCategory.h"
#import "CarType.h"
#import "AccessoriesProductSearch.h"
#import "SelectView.h"
#import "KeychainManager.h"
#import "AccessoriesProductFiltrateViewController.h"
#import "AccessoriesProductDetailViewController.h"
#import "UIViewController+DSPAPopup.h"
@interface AccessoriesProductViewController ()<iCarouselDataSource, iCarouselDelegate,UITextFieldDelegate>
{
           IBOutlet UIView *_accessoriesProductDetailedView;
    
    __weak IBOutlet UIView *_flotageView;       //悬浮视图
    __weak IBOutlet UIView *_loopFilterView;    //轮播下方筛选视图
           IBOutlet UIView *_filterView;        //过滤视图
    
//           IBOutlet UIView *_accessoriesProductFiltrateView;
//    __weak IBOutlet UIView *_accessoriesProductFiltrateSubView;
    
    NSMutableArray *_loopAdList;
    NSMutableArray *_loopImageUrl;
    NSMutableArray *_accessoriesProductList;
    
    //======= 详细页面
    __weak IBOutlet UIImageView     *_detailedImage;
    __weak IBOutlet UILabel         *_detailedName;
    __weak IBOutlet UILabel         *_detailedNumber;
    __weak IBOutlet UILabel         *_detailedMoney;
    __weak IBOutlet UITextView      *_detailedInfo;

    //======= 筛选页面
    __weak IBOutlet UITextField *_searchWord;   //搜索文字
    __weak IBOutlet SelectView *_categoryView;  //分类
    __weak IBOutlet SelectView *_carTypeView;   //车型
    __weak IBOutlet SelectView *_brandView;     //品牌
    AccessoriesProductSearch   *_searchModel;

    
    NSMutableArray *_categoryList;  //分类
    NSMutableArray *_carTypeList;   //车型
}

@property (weak, nonatomic) IBOutlet UIButton *moneyFilterOutlet;
- (IBAction)moneyFilterAction:(id)sender;   //价格筛选
- (IBAction)filterAction:(id)sender;        //筛选

- (IBAction)accessoriesProductDetailedViewCloseAction:(id)sender;
- (IBAction)accessoriesProductFiltrateViewCloseAction:(id)sender;

- (IBAction)filterOKButtonAction:(id)sender;//筛选页面ok按钮

@property (nonatomic, strong) NSMutableArray *items;
@property (nonatomic, assign) BOOL wrap;
@property (weak, nonatomic) IBOutlet iCarousel *iCarouselView;
@property (weak, nonatomic) IBOutlet UICollectionReusableView *headView;


//===========
@property (weak, nonatomic) IBOutlet UICollectionView *accessoriesProductCollection;
@property (nonatomic , strong) CollectionViewDataSource *collectionDatasource;


@end

@implementation AccessoriesProductViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]))
    {
        [self setUp];
    }
    return self;
}
- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder]))
    {
        [self setUp];
    }
    return self;
}
- (IBAction)backButtonTouched:(id)sender {
    [super backButtonTouched:sender];
    [[AppDelegate APP].rootViewController showClientBar:YES];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setUp];
    
    [self.headView addSubview:self.iCarouselView];
    
    _searchModel = [[AccessoriesProductSearch alloc] init];
    
    
//    [[NSBundle mainBundle] loadNibNamed:@"AccessoriesProductDetailedView" owner:self options:nil];
//    [[NSBundle mainBundle] loadNibNamed:@"AccessoriesProductFiltrateView" owner:self options:nil];
    [self.accessoriesProductCollection registerNib:[UINib nibWithNibName:@"AccessoriesProductCell" bundle:nil] forCellWithReuseIdentifier:@"AccessoriesProductCell"];

    [self.accessoriesProductCollection registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"LoopView"];
    [self setupCollectionView];
    [_loopFilterView addSubview:_filterView];
    self.title = @"精品附件";
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    [self fetchLoopAdList];
    [self fetchAccessoriesProductList:YES];
    [self fetchAccessoriesProductCategoryList];
    [self fetchCarTypeList];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)setUp{
    self.iCarouselView.type = iCarouselTypeLinear;
    self.wrap = YES;
    self.items = [NSMutableArray array];
    // 
    for (int i = 0; i < 10; i++){
        [self.items addObject:@(i)];
    }
}
#pragma mark -
#pragma mark iCarousel methods

- (NSInteger)numberOfItemsInCarousel:(__unused iCarousel *)carousel{
    return (NSInteger)[_loopAdList count];
}

- (UIView *)carousel:(__unused iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    //create new view if no view is available for recycling
//    if (view == nil){
    
        AccessoriesProductLoopAd *ad = [_loopAdList objectWithIndex:index];
        
        view = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 1133/2, 551/2)];
        [((UIImageView *)view) setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@%@",[KeychainManager getBaseURL],URI_INTERFACE_ROOT,ad.stuffpath]]];
        
        view.layer.borderColor = [[UIColor lightGrayColor] CGColor];
        view.layer.borderWidth = 1;
    
//        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(20, 20, 100, 20)];
//        lable.textColor = [UIColor blackColor];
//        lable.text = [NSString stringWithFormat:@"%zd",index];
//        [view addSubview:lable];
//    }
    
    return view;
}

- (NSInteger)numberOfPlaceholdersInCarousel:(__unused iCarousel *)carousel{
    //note: placeholder views are only displayed on some carousels if wrapping is disabled
    return 2;
}

- (UIView *)carousel:(__unused iCarousel *)carousel placeholderViewAtIndex:(NSInteger)index reusingView:(UIView *)view{
    //create new view if no view is available for recycling
    if (view == nil){
        view = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0,  1133/2, 551/2)];
        
        ((UIImageView *)view).image = [UIImage imageNamed:@"loop"];
    }
    return view;
}

- (CATransform3D)carousel:(__unused iCarousel *)carousel itemTransformForOffset:(CGFloat)offset baseTransform:(CATransform3D)transform{
    //implement 'flip3D' style carousel
    transform = CATransform3DRotate(transform, M_PI / 8.0f, 0.0f, 1.0f, 0.0f);
    return CATransform3DTranslate(transform, 0.0f, 0.0f, offset * self.iCarouselView.itemWidth);
}

- (CGFloat)carousel:(__unused iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
    //customize carousel display
    switch (option)
    {
        case iCarouselOptionWrap:
        {
            //normally you would hard-code this to YES or NO
            return self.wrap;
        }
        case iCarouselOptionSpacing:
        {
            //add a bit of spacing between the item views
            return value * 1.05f;
        }
        case iCarouselOptionFadeMax:
        {
            if (self.iCarouselView.type == iCarouselTypeCustom)
            {
                //set opacity based on distance from camera
                return 0.0f;
            }
            return value;
        }
        case iCarouselOptionShowBackfaces:
        case iCarouselOptionRadius:
        case iCarouselOptionAngle:
        case iCarouselOptionArc:
        case iCarouselOptionTilt:
        case iCarouselOptionCount:
        case iCarouselOptionFadeMin:
        case iCarouselOptionFadeMinAlpha:
        case iCarouselOptionFadeRange:
        case iCarouselOptionOffsetMultiplier:
        case iCarouselOptionVisibleItems:
        {
            return value;
        }
    }
}

- (CGFloat)carouselItemWidth:(__unused iCarousel *)carousel {
    return 550;
}

#pragma mark -
#pragma mark iCarousel taps

- (void)carousel:(__unused iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    NSNumber *item = (_loopAdList)[(NSUInteger)index];
    NSLog(@"Tapped view number: %@", item);
    AccessoriesProductLoopAd *ap = [_loopAdList objectWithIndex:index];
    
    AccessoriesProductDetailViewController *aploop = [[AccessoriesProductDetailViewController alloc] init];
    aploop.apLoop = ap;
    aploop.isLoop = YES;
    [self presentModelDetail:aploop];
    
}

- (void)carouselCurrentItemIndexDidChange:(__unused iCarousel *)carousel{
    NSLog(@"Index: %@", @(self.iCarouselView.currentItemIndex));
}

#pragma mark
#pragma ===============================
- (void)setupCollectionView {
    CollectionViewCellConfigureBlock configureCell = ^(AccessoriesProductCell *cell , id item , NSInteger index) {
        [cell configureForData:(AccessoriesProduct *)item];
    };
    self.collectionDatasource = [[CollectionViewDataSource alloc]initWithCellIdentifier:@"AccessoriesProductCell"
                                                                     configureCellBlock:configureCell
                                                           numberOfSectionsInCollection:1
                                                           withUICollectionReusableView:self.headView];
    [self.collectionDatasource.items addObjectsFromArray:_accessoriesProductList];
    
    self.accessoriesProductCollection.dataSource = self.collectionDatasource;
}

/**
 *  collection delegate
 */
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    AccessoriesProduct *apmodel = [_accessoriesProductList objectWithIndex:indexPath.row];
    AccessoriesProductDetailViewController *ap = [[AccessoriesProductDetailViewController alloc] init];
    ap.ap = apmodel;
    ap.isLoop = NO;
    [self presentModelDetail:ap];
}



#pragma mark
#pragma mark scrollFollow ================================
/**
 *  数据联动
 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if(scrollView.contentOffset.y < 338 && scrollView.contentOffset.y > 284){
        [_filterView removeFromSuperview];
        [_flotageView addSubview:_filterView];
    }
    else if(scrollView.contentOffset.y < 284){
        [_filterView removeFromSuperview];
        [_loopFilterView addSubview:_filterView];
    }
    
    if (scrollView.contentOffset.y > 1000) {
        [_filterView removeFromSuperview];
        [_flotageView addSubview:_filterView];
    }
    
    CGPoint offset      = scrollView.contentOffset;
    CGRect bounds       = scrollView.bounds;
    CGSize size         = scrollView.contentSize;
    UIEdgeInsets inset  = scrollView.contentInset;
    CGFloat currentOffset = offset.y + bounds.size.height - inset.bottom;
    CGFloat maximumOffset = size.height;
    //当currentOffset与maximumOffset的值相等时，说明scrollview已经滑到底部了
    if((maximumOffset - currentOffset) == 0){
        NSLog(@"-----我要刷新数据-----");
        [self fetchAccessoriesProductList:NO];
    }
}


/**
 *  显示详细页面数据
 */
- (void)showAccessoriesProductDetailedView{
    [self.view addSubview:_accessoriesProductDetailedView];
}

/**
 *  移除详细页面
 */
- (IBAction)accessoriesProductDetailedViewCloseAction:(id)sender {
    [_accessoriesProductDetailedView removeFromSuperview];
}
/**
 *  移除筛选页面
 */
- (IBAction)accessoriesProductFiltrateViewCloseAction:(id)sender {
    [self removeFiltrateView];
}


/**
 *  价格筛选
 */
- (IBAction)moneyFilterAction:(UIButton *)sender {
    NSLog(@"价格筛选");
    sender.selected = !sender.selected;
    if (sender.selected) {
        _searchModel.priceOrder = @"1";
    }else{
        _searchModel.priceOrder = @"0";
    }

    [self fetchAccessoriesProductList:YES];
}
/**
 *  筛选
 */
- (IBAction)filterAction:(id)sender {
    //弹出页面方式
    AccessoriesProductFiltrateViewController *apfvc = [[AccessoriesProductFiltrateViewController alloc] init];
    apfvc.categoryList = _categoryList;
    apfvc.carTypeList = _carTypeList;
    [self presentModelDetail:apfvc];
    
    __weak __typeof(self)weakSelf = self;
    apfvc.callBackAccessoriesProductFiltrate = ^(AccessoriesProductSearch *searchModel){
        _searchModel = searchModel;
        [weakSelf fetchAccessoriesProductList:YES];
    };
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    _searchModel.stuffName = [textField.text description];
}

/**
 * 筛选页面ok按钮
 */
- (IBAction)filterOKButtonAction:(id)sender {
    [self removeFiltrateView];
    
    [self fetchAccessoriesProductList:NO];
}

- (void)removeFiltrateView{
//    [_accessoriesProductFiltrateView removeFromSuperview];
    _detailedImage.image = nil;
    _detailedName.text = @"";
    _detailedNumber.text = @"";
    _detailedMoney.text = @"";
    _detailedInfo.text = @"";
}


#pragma mark
#pragma mark ===============================================
/**
 *  获取轮播视图列表
 */
- (void)fetchLoopAdList{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [AccessoriesProductLoopAd fetchAccessoriesProductLoopAdList:nil Success:^(NSArray *headList, id responseObject) {
        NSLog(@"%@",headList);
        if (headList.count > 0) {
            _loopAdList = [[NSMutableArray alloc] initWithArray:headList];
            _loopImageUrl = [[NSMutableArray alloc] init];
            for (AccessoriesProductLoopAd *ad in _loopAdList) {
                [_loopImageUrl addObj:[NSString stringWithFormat:@"%@%@%@",[KeychainManager getBaseURL],URI_INTERFACE_ROOT,ad.stuffpath]];
            }
            
            [_iCarouselView reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

/**
 *  获取商品列表
 */

- (void)fetchAccessoriesProductList:(BOOL)isFirst{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        [dic setObject:@100 forKey:@"rowCount"];
    if (isFirst) {
        [dic setObject:@0 forKey:@"startNum"];
    }else{
//        AccessoriesProduct *ap = [_accessoriesProductList lastObject];
        [dic setObject:[NSNumber numberWithInteger:[_accessoriesProductList count]?:1] forKey:@"startNum"];
    }
    
    [dic setObject:_searchModel.priceOrder?:@"" forKey:@"priceOrder"];
    [dic setObject:_searchModel.stuffName?:@"" forKey:@"stuffName"];
    [dic setObject:_searchModel.familyId?:@"" forKey:@"familyId"];
    [dic setObject:_searchModel.brandId?:@"" forKey:@"brandId"];
    [dic setObject:_searchModel.typeId?:@"" forKey:@"typeId"];

    NSLog(@"%@",dic);
    
    [AccessoriesProduct fetchAccessoriesProductList:dic Success:^(NSArray *headList, id responseObject) {
        
        if (headList) {
            if (isFirst) {
                _accessoriesProductList = [[NSMutableArray alloc] initWithArray:headList];
            }else{
                [_accessoriesProductList addObjectsFromArray:headList];
            }

            [self setupCollectionView];
        }else{
            [_accessoriesProductList removeAllObjects];
            [self setupCollectionView];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


/**
 *  获取分类
 */
- (void)fetchAccessoriesProductCategoryList{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [AccessoriesProductCategory fetchAccessoriesProductCategoryList:nil Success:^(NSArray *headList, id responseObject) {
        
        if (headList.count > 0) {
            _categoryList = [[NSMutableArray alloc] initWithArray:headList];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}


/**
 *  获取车型
 */
- (void)fetchCarTypeList{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [CarType getCarTypeList:nil Success:^(NSArray *carTypeList, id responseObject) {
        
        if (carTypeList.count>0) {
            _carTypeList = [[NSMutableArray alloc] initWithArray:carTypeList];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}

/**
 *  present detail
 */
-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
//    [self presentDSPAPopup:modelDetailViewController parentViewController:self touchCallBack:nil haveMask:YES includeNavgation:NO alignTop:YES];

    
    [self.coverView removeFromSuperview];
    self.coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 70, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
    self.coverView.backgroundColor = [UIColor blackColor];
    self.coverView.alpha = 0;
    [self.view addSubview:self.coverView];
    
    modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, self.view.height, modelDetailViewController.view.width, modelDetailViewController.view.height);
    [self.view addSubview:modelDetailViewController.view];
    [self addChildViewController:modelDetailViewController];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.coverView.alpha = 0.55;
        modelDetailViewController.view.frame = CGRectMake((self.view.width-modelDetailViewController.view.width)/2, (self.view.height-modelDetailViewController.view.height)/2, modelDetailViewController.view.width, modelDetailViewController.view.height);
    }];
}

@end
