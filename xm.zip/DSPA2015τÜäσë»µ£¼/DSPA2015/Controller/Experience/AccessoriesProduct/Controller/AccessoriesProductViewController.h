//
//  AccessoriesProductViewController.h
//  DSPA2015
//
//  Created by gavin on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ExtendsCollectionViewDelegate.h"

@interface AccessoriesProductViewController : ExtendsCollectionViewDelegate
@property(strong,nonatomic)  UIView *coverView;
@end
