//
//  AccessoriesProductDetailViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/31.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AccessoriesProductBaseViewController.h"

#import "AccessoriesProductLoopAd.h"
#import "AccessoriesProduct.h"


@interface AccessoriesProductDetailViewController : AccessoriesProductBaseViewController


@property (nonatomic , assign) BOOL isLoop;

@property (nonatomic , strong) AccessoriesProductLoopAd *apLoop;
@property (nonatomic , strong) AccessoriesProduct *ap;

@end
