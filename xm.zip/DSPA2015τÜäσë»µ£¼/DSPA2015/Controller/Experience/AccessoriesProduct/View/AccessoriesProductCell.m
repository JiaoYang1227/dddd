//
//  AccessoriesProductCell.m
//  DSPA2015
//
//  Created by gavin on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "AccessoriesProductCell.h"
#import "UIImageView+AFNetworking.h"
#import "KeychainManager.h"

@implementation AccessoriesProductCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)configureForData:(AccessoriesProduct *)ap{
    NSString *urlStr = [NSString stringWithFormat:@"%@%@%@",[KeychainManager getBaseURL],URI_INTERFACE_ROOT,ap.stuffpath];
    
    self.cellImage.image = nil;
    
//    if ([ap.stuffname isEqualToString:@"Bike"]) {
//        
//        [self.cellImage setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:nil];
//    }else{
//        [self.cellImage setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:nil];
//    }
    
    [self.cellImage setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:nil];
    

    self.cellName.text = [ap.stuffname description];
    self.cellNum.text = [NSString stringWithFormat:@"%@%@",@"零件号:",[ap.stuffnumber description]];
    self.cellMoney.text = [NSString stringWithFormat:@"%@%@",@"价格:",[ap.stuffprice description]];
}

@end
