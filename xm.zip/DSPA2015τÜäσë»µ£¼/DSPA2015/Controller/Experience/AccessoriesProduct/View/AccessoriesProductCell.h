//
//  AccessoriesProductCell.h
//  DSPA2015
//
//  Created by gavin on 15/11/11.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AccessoriesProduct.h"

@interface AccessoriesProductCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *cellImage;
@property (weak, nonatomic) IBOutlet UILabel *cellName;
@property (weak, nonatomic) IBOutlet UILabel *cellNum;
@property (weak, nonatomic) IBOutlet UILabel *cellMoney;


- (void)configureForData:(AccessoriesProduct *)ap;

@end
