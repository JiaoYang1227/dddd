//
//  Train_sectionBGView.m
//  CRMSalesManager
//
//  Created by owen on 14-1-23.
//  Copyright (c) 2014年 Roliand Group. All rights reserved.
//

#import "Train_sectionBGView.h"

@implementation Train_sectionBGView


@end
