//
//  TrainingDocmentsCell.m
//  DSPA2015
//
//  Created by sun on 15/12/10.
//  Copyright © 2015年 www.runln.cn. All rights reserved.
//

#import "TrainingDocmentsCell.h"

@implementation TrainingDocmentsCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //        152
        //标题
        self.videoTitle = [[UILabel alloc] initWithFrame:CGRectMake(18, 50, 100, 30)];
        self.videoTitle.font = [UIFont systemFontOfSize:12];
        self.videoTitle.backgroundColor = [UIColor clearColor];
        self.videoTitle.textAlignment = NSTextAlignmentLeft;
        self.videoTitle.lineBreakMode = UILineBreakModeWordWrap;
        self.videoTitle.numberOfLines = 2;
        
        //标题背景
        self.titleBG = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DSPA_train_titleBG"]];
        self.titleBG.frame = CGRectMake(10, 20, 111,1);
        
        //书的背景 111.157
        self.cellBookBG = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DSPA_docment_Book"]];
        self.cellBookBG.frame = CGRectMake(13, 39, 111, 157);
        
        //书皮的背景132.193
        self.cellBookCoverBG = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DSPA_docment_cover"]];
        self.cellBookCoverBG.frame = CGRectMake(3, 3, 132, 193);
        
        
        self.deleteBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.deleteBtn setImage:[UIImage imageNamed:@"delectFiles.png"]forState:UIControlStateNormal];
        [self.deleteBtn setFrame:CGRectMake(60, 165, 64, 23)];
        [self.deleteBtn addTarget:self action:@selector(deleteButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        self.deleteBtn.hidden = YES;
   
        self.bookCoverMark = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 62, 62)];
        self.bookMark = [[UIImageView alloc] initWithFrame:CGRectMake(7, 35, 62, 62)];
        [self.bookCoverMark setImage:[UIImage imageNamed:@"BookDealerMark.png"]];
        [self.bookMark setImage:[UIImage imageNamed:@"BookDealerMark.png"]];
        
        [self.contentView addSubview:self.cellBookCoverBG];
        [self.contentView addSubview:self.cellBookBG];
        [self.contentView addSubview:self.videoTitle];
        [self.contentView addSubview:self.titleBG];
        [self.contentView addSubview:self.deleteBtn];
        [self.contentView addSubview:self.bookMark];
        [self.contentView addSubview:self.bookCoverMark];
        
        self.contentView.clipsToBounds = YES;
    }
    return self;
}


-(void) dealloc
{
    self.videoTitle = nil;             //视频的title
}

- (void)deleteButtonAction:(id)sender
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(deleteButtonAction:)]) {
        [self.delegate deleteButtonAction:sender];
    }
}

@end
