//
//  TrainingMoviesCell.h
//  DSPA2015
//
//  Created by sun on 15/12/10.
//  Copyright © 2015年 www.runln.cn. All rights reserved.
//

#import "ProgressImageView.h"

@protocol TrainingMoviesCellDelegate <NSObject>

@optional
- (void) deleteButtonAction:(id)sender;
@end

@interface TrainingMoviesCell : UICollectionViewCell

@property (nonatomic, strong) UILabel  *videoTitle;                                  //视频的title
@property (nonatomic, strong) UIImageView *myCellBG;                                 //背景
@property (nonatomic, strong) UIButton *deleteBtn;                                   //删除按钮
//@property (nonatomic, strong) ProgressImageView *progressImageView;                  //进度条
@property (nonatomic, strong) UIImageView *cdBoxMark;                                //cd盒标识
@property (nonatomic, strong) UIImageView *cdPlayerMark;                             //cd唱片机标识
@property (nonatomic, weak) id<TrainingMoviesCellDelegate> delegate;
@end
