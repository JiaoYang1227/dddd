//
//  TrainingDocmentsViewController.m
//  DSPA2015
//
//  Created by sun on 15/12/10.
//  Copyright © 2015年 www.runln.cn. All rights reserved.
//

#import "TrainingDocmentsViewController.h"
#import "TrainingManagerManager.h"
#import "TrainingDocmentsCell.h"
#import "MBProgressHUD.h"
#import "TrainingMoviesViewController.h"
#import "AppDelegate.h"
//#import "CRMUtil.h"
#import "ProgressImageView.h"
#import "LeftPanelViewController.h"
#import "GetPdf.h"
//static NSString *headerViewIdentifier = @"Test Header View";
static NSString *footerViewIdentifier = @"Test Footer View";

@interface TrainingDocmentsViewController ()

@end

@implementation TrainingDocmentsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    // 培训考试的ui需要调整
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)finishedDownloadWithName:(NSString *)name {
    NSLog(@"下载完成通知：%@", name);
    
    //TODO 不要loadData，根据名字找到对应的cell index，然后只刷新cell
//    for (NSIndexPath *indexPath in self.downList) {
//        TrainingManager *train  = [[self.dataList objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
//        if ([train.name isEqualToString:name]) {
//            [self.docmentCollection reloadItemsAtIndexPaths:@[indexPath]];
//            [self.downList removeObject:train];
//            break;
//        }
//    }
    [self loadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.isReadyPlay = YES;
    //加载页面tableView
    [self loadGridView];
    //加载数据
    [self loadData];
    self.segControl.selectedSegmentIndex = 1;
    
    //设置全局下载管理的delegate为当前vc
    CRMDownloadController *d = [CRMDownloadController sharedInstance];
    d.delegate = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)loadGridView
{
    UICollectionViewFlowLayout *collectionViewFlowLayout = [[UICollectionViewFlowLayout alloc] init];
	
    //	[collectionViewFlowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
	[collectionViewFlowLayout setItemSize:CGSizeMake(135, 195)];
	[collectionViewFlowLayout setFooterReferenceSize:CGSizeMake(839, 24)];
	[collectionViewFlowLayout setMinimumInteritemSpacing:20];
	[collectionViewFlowLayout setMinimumLineSpacing:10];
	[collectionViewFlowLayout setSectionInset:UIEdgeInsetsMake(10, 0, 1, 0)];
	
	self.docmentCollection = [[UICollectionView alloc] initWithFrame:CGRectMake(36, 110, 852, 526) collectionViewLayout:collectionViewFlowLayout];
    [self.docmentCollection setBackgroundColor:[UIColor clearColor]];
	[self.docmentCollection setDelegate:self];
	[self.docmentCollection setDataSource:self];
	[self.docmentCollection setAutoresizingMask:UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin];

	[self.docmentCollection registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:footerViewIdentifier];
	
	[self.view addSubview:self.docmentCollection];
}

//数据加载
-(void)loadData
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        // 获取销售列表
        //get seviece call, retun data from api internet
        NSDictionary *trainDic = nil;
        [TrainingManagerManager getProjectAndTranceCount:trainDic Success:^(NSDictionary *dic) {
            if (dic != nil) {
                if (self.dataList) {
                    [self.dataList removeAllObjects];
                } else {
                    self.dataList = [NSMutableArray array];
                }
                // 把列表信息添加到数据源中
                self.dataList = [dic objectForKey:@"docments"];
            }
            [self dataProcessing];
            [self.docmentCollection reloadData];
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        } Failure:^(NSError *error) {
            
        }];
    });
}

#pragma mark ----PSUICollectionViewDataSource, PSUICollectionViewDelegate----

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    //每行4个cell
    return [self.dataList count];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [[self.dataList objectAtIndex:section] count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *cellIdentifier =[NSString stringWithFormat:@"cell_%d_%d",indexPath.section,indexPath.row];
    
    [self.docmentCollection registerClass:[TrainingDocmentsCell class] forCellWithReuseIdentifier:cellIdentifier];
    
    TrainingDocmentsCell *cell = (TrainingDocmentsCell *)[collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.delegate = self;
    
    TrainingManager *train = [[self.dataList objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    
    ProgressImageView *progress = [self fetchProgressFromCell:cell];
    if (progress) {
        [progress removeFromSuperview];
    }
    
    if ([train.isLocal boolValue]){
        self.gr = [[UILongPressGestureRecognizer alloc] initWithTarget: self action: @selector(moveActionGestureRecognizerStateChanged:)];
        self.gr.minimumPressDuration = 0.5;
        self.gr.delegate = self;
        [cell addGestureRecognizer: self.gr];
        if (!self.isReadyPlay) {
            cell.deleteBtn.hidden = NO;
        } else {
            cell.deleteBtn.hidden = YES;
        }
        
        if (train.isdealer) {
            [cell.bookMark setImage:[UIImage imageNamed:@"BookDealerMark.png"]];
        } else {
            [cell.bookMark setImage:[UIImage imageNamed:@"BookFactoryMark.png"]];
        }
        cell.bookCoverMark.hidden = YES;
        cell.bookMark.hidden = NO;
        
        //判断是不是本地文件，是本地：显示播放按钮，否则显示下载
        cell.cellBookCoverBG.hidden = YES;
        cell.videoTitle.frame = CGRectMake(18, 0, 100, 30);
    } else {
        
        if (train.isdealer) {
            [cell.bookCoverMark setImage:[UIImage imageNamed:@"BookDealerMark.png"]];
        } else {
            [cell.bookCoverMark setImage:[UIImage imageNamed:@"BookFactoryMark.png"]];
        }
        cell.bookMark.hidden = YES;
        cell.bookCoverMark.hidden = NO;
        
        cell.deleteBtn.hidden = YES;
        //判断是不是本地文件，是本地：显示播放按钮，否则显示下载
        cell.cellBookCoverBG.hidden = NO;

        CRMDownloadController *d = [CRMDownloadController sharedInstance];
        ProgressImageView *progressView;
        if ([d progressViewByName:train.tid]) {
            ProgressImageView *p = [d progressViewByName:train.tid];
            progressView = [self fetchProgressFromCell:cell];
            [progressView removeFromSuperview];
            [cell.contentView addSubview:p];
        } else {
            progressView = [[ProgressImageView alloc] initWithFrame:CGRectMake(3, 160, 128, 6)];
            [progressView setImage:[UIImage imageNamed:@"DSPA_pdfProgressTrack.png"]];
            progressView.tag = TAG_PROGRESSVIEW_DOWNLOADING;   //TODO 需要把Tag值 Constant.h 一下
            [cell.contentView addSubview:progressView];
        }
        cell.videoTitle.frame = CGRectMake(18, 50, 100, 30);
        
    }
    cell.videoTitle.text = [[train.originname componentsSeparatedByString:@"."] objectAtIndex:0];
    cell.deleteBtn.tag = indexPath.section * 4 +indexPath.row;

    return cell;
}

- (CGSize)collectionView:(UICollectionView*)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(135, 199);    //这里的大小看着改
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
	
    UICollectionReusableView *supplementaryView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:footerViewIdentifier forIndexPath:indexPath];
    supplementaryView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"DSPA_train_sectionBG"]];
    // TODO Setup view
	
    return supplementaryView;
}

- (void) collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isReadyPlay) {
        TrainingManager *train  = [[self.dataList objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        CRMDownloadController *d = [CRMDownloadController sharedInstance];
        if ([d progressViewByName:train.tid]) {
            return;
        }
        if (![train.isLocal boolValue]) {
            
//            if ([CRMUtil CheckNetworkStatus]) {
            if (YES) {
                TrainingDocmentsCell * cell = (TrainingDocmentsCell *)[self.docmentCollection cellForItemAtIndexPath:indexPath];
                ProgressImageView *progress = [self fetchProgressFromCell:cell];
                [d setProcessView:progress withName:train.tid];
            
                //开始下载
                [TrainingManagerManager downloadFile:train isMovies:NO];
                return;
            }
//            [CRMUtil showAlertViewWithTitle:ALERT_TITLE_WARNING message:@"网络错误，请重试！" delegate:nil];
            return;
        }
        [self playDocmentWithObject:train];
    }
    
}

// 播放
-(void)playDocmentWithObject:(TrainingManager *)train
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        
//        [TrainingManagerManager deciphering:train.url withFileName:train.name isMovies:NO];
        [TrainingManagerManager reNamePlayingFile:train];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //判断如果文件不存在，提示不存在，并删除本地plist 数据。
            NSFileManager *fileManager = [NSFileManager defaultManager];
            if (![fileManager fileExistsAtPath:train.url]) {
//                [CRMUtil showAlertViewWithTitle:ALERT_TITLE_WARNING message:@"文件已经破损，请重新下载" delegate:nil];
                NSString *destPath = [GetPdf applicationDocumentsDirectory];
                destPath = [destPath stringByAppendingPathComponent:TRANING_MANAGER_DOCMENTLIST];
                NSFileManager *fileManager = [NSFileManager defaultManager];
                if (![fileManager fileExistsAtPath:destPath]) {
                    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                    return ;
                }
                NSMutableArray *plistArr = [[NSMutableArray alloc] initWithContentsOfFile:destPath];
                for (NSDictionary *movieDic in plistArr) {
                    if ([[movieDic objectForKey:@"originname"] isEqualToString:train.originname] &&
                        [[movieDic objectForKey:@"md5Originname"] isEqualToString:train.md5Originname]) {
                        [plistArr removeObject:movieDic];
                        [plistArr writeToFile:destPath atomically:YES];
                        break;
                    }
                }
                [self loadData];
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                return ;
            }
            
            //判断文件是否可用
            if (![self isCompletePDF:train.url]) {
//                [CRMUtil showAlertViewWithTitle:ALERT_TITLE_WARNING message:@"文件已经破损，请IT管理员修复服务器文件" delegate:nil];
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                return;
            }
            //打开pdf阅读页面
            DocmentPlayViewController *docPlay = [[DocmentPlayViewController alloc] init];
            self.trainingManager = train;
            [docPlay playPDFWithUrl:train];
            UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController :docPlay];
            UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            backBtn.frame = CGRectMake(0, 0, 32, 25);
            [backBtn addTarget:self action:@selector(dismissEditFormViewController) forControlEvents:UIControlEventTouchUpInside];
            [backBtn setImage:[UIImage imageNamed:@"back1.png"] forState:UIControlStateNormal];
            [backBtn setImage:[UIImage imageNamed:@"back2.png"] forState:UIControlStateHighlighted];
            UIBarButtonItem *barItemBackBtn = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
            
            docPlay.navigationItem.leftBarButtonItem = barItemBackBtn;
            [navigation.navigationBar setBackgroundImage:[UIImage imageNamed:@"detailViewNavBar.png"] forBarMetrics:UIBarMetricsDefault];
            
//            AppDelegate *app = [[UIApplication sharedApplication] delegate];
//            [app.mainLayoutController presentViewController:navigation animated:YES completion:^{
//                //
//            }];
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            
        });
        
    });
    
    
}

//判断pdf是否完整。
//判断完整与否的方法：通过获取pdf第一帧，如果获取失败，那么说明文件是破损的
- (BOOL)isCompletePDF:(NSString *)Turl
{
    //获取文档第一帧
    CGPDFDocumentRef document;
    BOOL isOK = NO;
    NSURL *url = [NSURL fileURLWithPath:Turl];
    document = CGPDFDocumentCreateWithURL ((__bridge CFURLRef) url);
    if ([self imageFromPDFWithDocumentRef:document]) {
        isOK = YES;
    }
    //    CFRelease(document);
    return isOK;
}

//获取文件第一帧
- (UIImage *)imageFromPDFWithDocumentRef:(CGPDFDocumentRef)documentRef {
    CGPDFPageRef pageRef = CGPDFDocumentGetPage(documentRef, 1);
    CGRect pageRect = CGPDFPageGetBoxRect(pageRef, kCGPDFCropBox);
    
    UIGraphicsBeginImageContext(pageRect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, CGRectGetMinX(pageRect),CGRectGetMaxY(pageRect));
    CGContextScaleCTM(context, 1, -1);
    CGContextTranslateCTM(context, -(pageRect.origin.x), -(pageRect.origin.y));
    CGContextDrawPDFPage(context, pageRef);
    
    UIImage *finalImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return finalImage;
}

- (void) dismissEditFormViewController {
    
    //关闭页面，删除本地文件。信息安全
//    AppDelegate *app = [[UIApplication sharedApplication] delegate];
//    [TrainingManagerManager reNameFile:self.trainingManager];
//    [app.mainLayoutController dismissModalViewControllerAnimated:YES];
//    [app.mainLayoutController setMenuButtonSelectedStatus:MENU_TRANING];
}

#pragma mark - UIGestureRecognizer Delegate/Actions

- (BOOL) gestureRecognizerShouldBegin: (UIGestureRecognizer *) gestureRecognizer
{
    return ( YES );
}

- (void) moveActionGestureRecognizerStateChanged: (UIGestureRecognizer *) recognizer
{
    //删除
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        //本地文件不为0的情况下，可以进入删除状态
        if (self.isReadyPlay && [[TrainingManagerManager getLocalDocFileList] count] > 0) {
            self.isReadyPlay = NO;
        }else {
            self.isReadyPlay = YES;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.docmentCollection reloadData];
        });
    }
    
}

// 删除按钮按下
-(void)deleteButtonAction:(id)sender
{
//    UIButton *btn = (UIButton *)sender;
//    //获取本地文件目录
//    NSString *destPath = [CRMUtil applicationDocumentsDirectory];
//    destPath = [destPath stringByAppendingPathComponent:TRANING_MANAGER_DOCMENTLIST];
//    NSFileManager *fileManager = [NSFileManager defaultManager];
//    if (![fileManager fileExistsAtPath:destPath]) {
//        NSMutableArray *dictplist = [NSMutableArray array];
//        [dictplist writeToFile:destPath atomically:YES];
//    }
//    NSMutableArray *plistMovieArr = [[NSMutableArray alloc] initWithContentsOfFile:destPath];
//    NSDictionary *trainDic = [plistMovieArr objectAtIndex:btn.tag];
//    [plistMovieArr removeObjectAtIndex:btn.tag];
//    [plistMovieArr writeToFile:destPath atomically:YES];
//    //删除本地文件
//    NSString *filePath = [CRMUtil applicationDocumentsDirectory];
//    filePath = [filePath stringByAppendingPathComponent:[trainDic objectForKey:@"md5Originname"]];
//    if ([fileManager fileExistsAtPath:filePath]) {
//        NSError *err;
//        [fileManager removeItemAtPath:filePath error:&err];
//    }
//    self.isReadyPlay = YES;
//    [self loadData];
}
- (IBAction)segSwitch:(UISegmentedControl* )sender
{
    
	switch (sender.selectedSegmentIndex)
	{
		case 0:
        {
            //The first segmented object is selected.
			self.segImage.image = [UIImage imageNamed:@"DSPA_TrainMovies.png"];
            TrainingMoviesViewController *trainMovies = [[TrainingMoviesViewController alloc] init];
            [[AppDelegate APP].rootViewController.serviceRootViewController.contentNavigationController setViewControllers:@[trainMovies]];
//            AppDelegate *app = [[UIApplication sharedApplication] delegate];
//            [app.contentNavigationController setViewControllers:@[trainMovies]];
//            LeftPanelViewController *app1 = [[AppDelegate APP] leftPanelViewController];
//            [app1.contentNavigationController setViewControllers:@[trainMovies]];
        }
			break;
		case 1:
        {
            //The second segmented object is selected.todo图片
			self.segImage.image = [UIImage imageNamed:@"DSPA_TrainDocments.png"];
        }
			break;
		default:
			//Whichever segmented object that is set to be selected by default is selected.
			self.segImage.image = [UIImage imageNamed:@"DSPA_TrainDocments.png"];
			break;
	}
}

//处理数据格式
- (void)dataProcessing
{
    NSMutableArray *tempArr = [NSMutableArray array];
    NSMutableArray *dataArr = [NSMutableArray array];
    
    for (int i = 0; i< self.dataList.count; i++) {
        TrainingManager *train = [self.dataList objectAtIndex:i];
        [tempArr addObject:train];
        if (tempArr.count == 5) {
            [dataArr addObject:tempArr];
            tempArr = nil;
            tempArr = [NSMutableArray array];
        }
        if (i == self.dataList.count - 1 && tempArr.count != 0) {
            [dataArr addObject:tempArr];
        }
    }
    self.dataList = dataArr;
}

- (ProgressImageView *)fetchProgressFromCell:(TrainingDocmentsCell *)cell
{
    return (ProgressImageView *)[cell viewWithTag:TAG_PROGRESSVIEW_DOWNLOADING];
}

@end
