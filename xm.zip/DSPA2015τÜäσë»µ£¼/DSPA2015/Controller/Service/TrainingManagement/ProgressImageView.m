//
//  ProgressImageView.m
//  DSPA2015
//
//  Created by sun on 15/12/10.
//  Copyright © 2015年 www.runln.cn. All rights reserved.
//

#import "ProgressImageView.h"

@implementation ProgressImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        rect = frame;
    }
    return self;
}

- (void)setProgress:(float)progress
{
    if (isnan(progress)) {
        return;
    }
    NSLog(@"progress = %f",progress);
    self.frame = CGRectMake(rect.origin.x + rect.size.width * progress, rect.origin.y, rect.size.width, rect.size.height);
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
//- (void)drawRect:(CGRect)rect
//{
//    // Drawing code
//    NSLog(@"rect = %@",NSStringFromCGRect(rect));
//    self.frame = CGRectMake(rect.origin.x + rect.size.width * self.progress, rect.origin.y, rect.size.width * self.progress, rect.size.height);
//}


@end
