//
//  CRMDownloadController.m
//  CRMSalesManager
//
//  Created by Jack on 16/09/13.
//  Copyright (c) 2013 Roliand Group. All rights reserved.
//

#import "CRMDownloadController.h"

@implementation CRMDownloadController

- (id) init {
    self = [super init];
    if (self) {
        self.progresses = [NSMutableDictionary dictionary];
    }
    
    return self;
}

+ (CRMDownloadController *)sharedInstance {
    static CRMDownloadController *downloadController = nil;
    if (downloadController==nil) {
        downloadController = [[CRMDownloadController alloc] init];
    }
    return downloadController;
}

- (ProgressImageView *)progressViewByName:(NSString *)title {
    return [self.progresses objectForKey:title];
}

- (void)setProcessView:(ProgressImageView *)processView withName:(NSString *)title {
    [self.progresses setObject:processView forKey:title];
}

- (void)removeProvessViewWithName:(NSString *)name {
    [self.progresses removeObjectForKey:name];
    if (self.delegate && ([self.delegate conformsToProtocol:@protocol(CRMDownloadControllerDelegate)])) {
        [self.delegate finishedDownloadWithName:name];  //TODO 传入成功或失败标志
    }
}


@end
