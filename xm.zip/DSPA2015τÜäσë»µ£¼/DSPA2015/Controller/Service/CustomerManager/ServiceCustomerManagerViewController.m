//
//  ServiceCustomerManagerViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ServiceCustomerManagerViewController.h"
#import "ServiceCustomerManagerCell.h"
#import "ServiceCustomerManagerDetailViewController.h"
#import "ServiceCustomerManagerSearchViewController.h"
#import "ServiceCustomerManagerEditViewController.h"

#import "ServiceCustomerManagerModel.h"
#import "OrderedDictionary.h"
#import "DateManager.h"
#import "ServiceCustomerManagerSearchModel.h"

@interface ServiceCustomerManagerViewController ()<UITableViewDataSource,UITabBarDelegate>
{
    
    //==============
           IBOutlet UIView  *_serviceCustomerManagerSectionView;
    __weak IBOutlet UILabel *_serviceCustomerManagerSectionLable; // section lable
    
    
    //==============
                    BOOL            nibsRegistered_;
                    NSMutableArray  *_customerList;        //服务器返回的原始数据
                    MutableOrderedDictionary *_dataOrderedDictionary; //按时间排序后的数据
    __weak IBOutlet UITableView     *_customerTableview;
    
    NSInteger               _currentPage;
    ServiceCustomerManagerSearchModel *_serviceCustomerManagerSearch;
}


- (IBAction)advancedButtonAction:(id)sender;

@end

@implementation ServiceCustomerManagerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [[NSBundle mainBundle] loadNibNamed:@"ServiceCustomerManagerSectionView" owner:self options:nil];
    [_customerTableview registerNib:[ServiceCustomerManagerCell nib] forCellReuseIdentifier:NSStringFromClass([ServiceCustomerManagerCell class])];
    [self loadData:nil startNum:0 advanced:NO];
    
    
    self.title = @"客户管理(销售管理)";
}

/**
 *  load data
 */
-(void)loadData:(NSDictionary*)option startNum:(NSInteger)startNum advanced:(BOOL)advanced{
    
    if (advanced) {
        //高级检索，未检索出来数据，是否需要进行数据清空
//        [_dataOrderedDictionary removeAllObjects];
//        [_customerList removeAllObjects];
//        [_customerTableview reloadData];
    }
    
    if (!_customerList) {
        _customerList = [NSMutableArray array];
    }
    if (_customerList && startNum==0) {
        [_customerList removeAllObjects];
        [_customerTableview reloadData];
        _dataOrderedDictionary = nil;
        _currentPage = 1;
    }
    
    if (!_serviceCustomerManagerSearch) {
        _serviceCustomerManagerSearch = [[ServiceCustomerManagerSearchModel alloc] init];
    }
    if (self.myServiceCustomerManagerModel) {
        _serviceCustomerManagerSearch = self.myServiceCustomerManagerModel;
    }
    _serviceCustomerManagerSearch.startNum = startNum;
    _serviceCustomerManagerSearch.rowCount = 20;
    
    __weak __typeof(self)weakSelf = self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ServiceCustomerManagerModel fetchServiceCustomerList:[_serviceCustomerManagerSearch toDictionary] Success:^(NSArray *resultList, id responseObject) {
       
        if (resultList.count > 0) {
            
            [_customerList addObjectsFromArray:resultList];
            
            _dataOrderedDictionary = [weakSelf groupListByDate:_customerList];
        }
        [_customerTableview reloadData];
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

/**
 *  分组顾客
 */
- (MutableOrderedDictionary*)groupListByDate:(NSMutableArray *)dataList{
    MutableOrderedDictionary *orderDic = [MutableOrderedDictionary dictionary];
    for (ServiceCustomerManagerModel *item in dataList) {
        NSMutableArray *oneGroup = [[orderDic objectForKey:[DateManager date_YMD_WithTimeIntervalSince1970:item.createDate]] mutableCopy]  ?: [NSMutableArray array];
        [oneGroup addObject:item];
        [orderDic setObject:oneGroup?:@[] forKey:[DateManager date_YMD_WithTimeIntervalSince1970:item.createDate]];
        
    }
    return orderDic;
}

/**
 *  高级检索
 */
- (IBAction)advancedButtonAction:(id)sender {
    ServiceCustomerManagerSearchViewController *search = [[ServiceCustomerManagerSearchViewController alloc] init];
    search.callBakcServiceCustomerManagerSearch = ^(ServiceCustomerManagerSearchModel *search){
        _serviceCustomerManagerSearch = search;
        [self loadData:nil startNum:0 advanced:YES];
    };
    [self presentDetail:search];
}


#pragma mark ============================
#pragma mark tableview delegate =========
#pragma mark tableview data source ======
#pragma mark ============================
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 217.;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 38.;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [[_dataOrderedDictionary allKeys] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [[[_dataOrderedDictionary allValues] arrayWithIndex:section] count];
}

//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//    UIView *sectionHeader = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 38)];
//    sectionHeader.backgroundColor = [UIColor colorWithWhite:0.984 alpha:1.000];
//    _serviceCustomerManagerSectionLable.text = [[_dataOrderedDictionary allKeys] stringWithIndex:section];
//    [sectionHeader addSubview:_serviceCustomerManagerSectionView];
//    
//    return sectionHeader;
//}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *sectionHeader = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 38)];
    sectionHeader.backgroundColor = [UIColor colorWithWholeRed:247 green:247 blue:247 alpha:1];
    
    UIImageView *imageview  = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"TranckingPlan_image_clock"]];
    imageview.frame= CGRectMake(400, 11, 15, 16);
    [sectionHeader addSubview:imageview];
    
    UILabel *sectionTitle = [[UILabel alloc] initWithFrame:CGRectMake(430, 0, 90, 38)];
    sectionTitle.font = [UIFont boldSystemFontOfSize:15.0];
    sectionTitle.textColor = [UIColor colorWithRed:142/255.0 green:17/255.0 blue:36/255.0 alpha:1.000];
    sectionTitle.tag = 10001;
    [sectionHeader addSubview:sectionTitle];
    

    NSString *timeString =  [[_dataOrderedDictionary allKeys] stringWithIndex:section];
    NSDate *date = [DateManager dateConvertFrom_YMD_String:timeString];
    sectionTitle.text = [[DateManager sharedManager] stringConvertFromDate:date format:@"yyyy-MM-dd"];
    return sectionHeader;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * identifier = @"ServiceCustomerManagerCell";
    ServiceCustomerManagerCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    ServiceCustomerManagerModel *item = [[[_dataOrderedDictionary allValues] arrayWithIndex:indexPath.section] objectWithIndex:indexPath.row];
    [cell configCellData:item];
//    [cell.cellEditButtonOutlet addTarget:self action:@selector(serviceCustomerManagerEditAction:) forControlEvents:UIControlEventTouchDown];
//    cell.cellEditButtonOutlet.indexPath = indexPath;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ServiceCustomerManagerDetailViewController *detail = [[ServiceCustomerManagerDetailViewController alloc] init];
    ServiceCustomerManagerModel *item = [[[_dataOrderedDictionary allValues] arrayWithIndex:indexPath.section] objectWithIndex:indexPath.row];
    detail.serviceCusstomerModel = item;
    [self.navigationController pushViewController:detail animated:YES];
}

/**
 *  上拉加载
 */
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger curRowCount = 0;
    for (NSInteger i = 0; i < indexPath.section; i++)
    {
        NSInteger rowCount = [tableView numberOfRowsInSection:i];
        curRowCount += rowCount;
    }
    curRowCount += indexPath.row;
    if (curRowCount+1 == _currentPage*20)
    {
        NSLog(@"curRowCount = %zd",curRowCount);
        _currentPage++;
        NSLog(@"load page = %zd",_currentPage);
        [self loadData:nil startNum:[_customerList count] advanced:NO];
    }
}

///**
// *  客户管理编辑
// */
//- (void)serviceCustomerManagerEditAction:(CellButton *)sender{
//    ServiceCustomerManagerModel *item = [[[_dataOrderedDictionary allValues] arrayWithIndex:sender.indexPath.section] objectWithIndex:sender.indexPath.row];
//    ServiceCustomerManagerEditViewController *edit = [[ServiceCustomerManagerEditViewController alloc] init];
//    edit.serviceCustomerManagerModel = item;
//    [self presentDetail:edit];
//}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
