//
//  ServiceCustomerManagerViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseServiceViewController.h"
#import "ServiceCustomerManagerSearchModel.h"
@interface ServiceCustomerManagerViewController : BaseServiceViewController
@property(nonatomic,strong)ServiceCustomerManagerSearchModel *myServiceCustomerManagerModel;

@end
