//
//  ServiceCustomerManagerSearchViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseSearchViewController.h"

typedef void(^onServiceCustomerManagerSearchCallBack)(id);


@interface ServiceCustomerManagerSearchViewController : BaseSearchViewController
@property (nonatomic , copy) onServiceCustomerManagerSearchCallBack callBakcServiceCustomerManagerSearch;
@end
