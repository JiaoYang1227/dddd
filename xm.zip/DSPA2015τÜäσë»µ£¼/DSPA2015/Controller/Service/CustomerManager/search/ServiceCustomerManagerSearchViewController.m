//
//  ServiceCustomerManagerSearchViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ServiceCustomerManagerSearchViewController.h"
#import "ServiceCustomerManagerSearchModel.h"

@interface ServiceCustomerManagerSearchViewController ()
{
    __weak IBOutlet BorderTextField *_customerName;     //客户名称
    __weak IBOutlet BorderTextField *_customerPhone;    //客户电话
    
    __weak IBOutlet SelectView *_customerState;         //客户状态
    
    ServiceCustomerManagerSearchModel *_serviceCustomerManagerSearch;
    
    
    NSDictionary *_customerStateDic;
    
    NSString *_recdState;
}


- (IBAction)searchButtonAction:(id)sender;
- (IBAction)resetButtonAction:(id)sender;


@end

@implementation ServiceCustomerManagerSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _serviceCustomerManagerSearch = [[ServiceCustomerManagerSearchModel alloc] init];
    
    _customerStateDic = @{@"休眠客户":@"statusFlag",@"潜在客户":@"normalFlag",@"购车客户":@"autoFlag"};
    
    
    //autoFlag      购车客户状态pad中高级搜索购车客户
    //statusFlag	休眠客户状态Pad中高级搜索休眠
    //normalFlag	潜在客户状态Pad中高级搜索潜在客户
    
    
    _customerState.items = @[@"休眠客户",@"潜在客户",@"购车客户"];
    [_customerState didSelectItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *multiSelectItems) {
        _recdState = value;
        
    }];
    
    
    self.title = @"销售管理高级搜索(销售管理)";
}

/**
 *  查询按钮
 */
- (IBAction)searchButtonAction:(id)sender {
    
    _serviceCustomerManagerSearch.custName = _customerName.text;
    _serviceCustomerManagerSearch.custMobile = _customerPhone.text;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:[_serviceCustomerManagerSearch toDictionary]];
    
    if (_recdState) {
        [dic setObject:@"1" forKey:[_customerStateDic stringForKey:_recdState]?:@""];
    }
    
    ServiceCustomerManagerSearchModel *model = [[ServiceCustomerManagerSearchModel alloc] initWithDictionary:dic error:nil];
    
    [self dismissTouched:nil];
    if (self.callBakcServiceCustomerManagerSearch) {
        self.callBakcServiceCustomerManagerSearch(model);
    }
}


/**
 *  重置按钮
 */
- (IBAction)resetButtonAction:(id)sender {
    _customerName.text = @"";
    _customerPhone.text = @"";
    _serviceCustomerManagerSearch.custName = @"";
    _serviceCustomerManagerSearch.custMobile = @"";
    _customerState.selectedIndex = -1;
    _recdState = @"";
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
