//
//  ServiceCustomerManagerDetailViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseDetailViewController.h"
#import "ServiceCustomerManagerModel.h"

@interface ServiceCustomerManagerDetailViewController : BaseDetailViewController
- (instancetype)initWithAboutInfoView:(BOOL)hide;

@property (nonatomic , strong) ServiceCustomerManagerModel *serviceCusstomerModel;
- (IBAction)importERPTouched:(id)sender;
@end
