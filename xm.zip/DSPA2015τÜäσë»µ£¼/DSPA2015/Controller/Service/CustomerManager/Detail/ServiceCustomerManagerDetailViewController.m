//
//  ServiceCustomerManagerDetailViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ServiceCustomerManagerDetailViewController.h"
#import "SalesLeadReferenceListViewController.h"
#import "ContactListViewController.h"
#import "TrackingPlanReferenceViewController.h"
#import "ServiceCustomerManagerEditViewController.h"
#import "DocumentViewController.h"
#import "CustomerOrderReferenceListViewController.h"
#import "ERPImporter.h"
#import "CheckBoxView.h"
#import "DictModel.h"

@interface ServiceCustomerManagerDetailViewController ()
{
    //================
    __weak IBOutlet UIScrollView *_scrollview;
           IBOutlet UIView       *_serviceCustomerManagerDetailView;
    
    
    Customer *_customer;
    
    //================

    // 客户名称
    __weak IBOutlet UILabel *_custName;
    // 客户来源
    __weak IBOutlet UILabel *_custFrom;
    // 客户类别
    __weak IBOutlet UILabel *_custType;
    // 信息来源
    __weak IBOutlet UILabel *_infoFrom;
    // 客户移动电话
    __weak IBOutlet UILabel *_custMobile;
    // 客户其他电话
    __weak IBOutlet UILabel *_custOtherPhone;
    // 性别
    __weak IBOutlet UILabel *_gender;
    // 生日
    __weak IBOutlet UILabel *_birthday;
    // 证件类型
    __weak IBOutlet UILabel *_idType;
    // 证件号码
    __weak IBOutlet UILabel *_idNumber;
    // 省区
    __weak IBOutlet UILabel *_province;
    // 市县
    __weak IBOutlet UILabel *_city;
    // 行政区划
    __weak IBOutlet UILabel *_district;
    // QQ号码
    __weak IBOutlet UILabel *_qq;
    // 客户地址
    __weak IBOutlet UILabel *_address;
    // 邮编
    __weak IBOutlet UILabel *_postcode;
    // E-mail
    __weak IBOutlet UILabel *_email;
    // 方便联系时间
    __weak IBOutlet UILabel *_convContactTime;
    // 希望联系方式
    __weak IBOutlet UILabel *_expectContactWay;
    // 传真
    __weak IBOutlet UILabel *_fax;
    // 现用车
    __weak IBOutlet UILabel *_existingCar;
    // 所处行业
    __weak IBOutlet UILabel *_industry;
    // 职务
    __weak IBOutlet UILabel *_position;
    // 教育程度
    __weak IBOutlet UILabel *_education;
    // 客户爱好1
    __weak IBOutlet UILabel *_custInterest1;
    // 客户爱好2
    __weak IBOutlet UILabel *_custInterest2;
    // 客户爱好3
    __weak IBOutlet UILabel *_custInterest3;
    // 现用车牌照号
    __weak IBOutlet UILabel *_existLisenPlate;
    // 企业性质
    __weak IBOutlet UILabel *_enterpType;
    // 企业人数
    __weak IBOutlet UILabel *_enterpPeopleCount;
    // 注册资本
    __weak IBOutlet UILabel *_registeredCapital;
    // 竞争车型
    __weak IBOutlet UILabel *_compeCarModel;
    // 本店重购客户
    __weak IBOutlet SwitchView *_rebuyStoreCustTag;
    // 网络重购客户
    __weak IBOutlet SwitchView *_rebuyOnlineCustTag;
    // 置换客户标识
    __weak IBOutlet SwitchView *_changeCustTag;
    // 个贷客户标识
    __weak IBOutlet SwitchView *_loanCustTag;
    // 总部VIP客户标识
    __weak IBOutlet SwitchView *_headerQuartCustTag;
    // 老客户推荐标识
    __weak IBOutlet SwitchView *_regularCustTag;
    // 老客户选择
    __weak IBOutlet UILabel *_regularCust;
    // 大客户标识
    __weak IBOutlet SwitchView *_bigCustTag;
    // 大客户选择
    __weak IBOutlet UILabel *_bigCusts;
    // 客户备注
    __weak IBOutlet UILabel *_custComment;
    // 休眠客户
    __weak IBOutlet SwitchView *_dormancy;
    
    //现用车品牌
    __weak IBOutlet UILabel *_existingCarBrandLable;
    
    
    __weak IBOutlet CheckBoxView *_likeCheckBoxViewOutlet;
    
    //=============================
    
    __weak IBOutlet UIView *_customView;
    
    //=============================
    BOOL _aboutInfo;    //是否隐藏相关信息
    NSString *_customerID;
}

@property (weak, nonatomic) IBOutlet UIView *aboutInfoView; //相关信息

- (IBAction)aboutSalesLeadAction:(id)sender;
- (IBAction)contactPersonAction:(id)sender;
- (IBAction)trackingAction:(id)sender;
- (IBAction)documentAction:(id)sender;
- (IBAction)customerOrderAction:(id)sender;


- (IBAction)backButtonAction:(id)sender;

- (IBAction)editAction:(id)sender;

@end

@implementation ServiceCustomerManagerDetailViewController

- (instancetype)initWithAboutInfoView:(BOOL)hide{
    self = [super init];
    if (self) {
        if (hide) {
            NSLog(@"隐藏相关视图");
            _aboutInfo = hide;
        }
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (_aboutInfo) {
        _scrollview.contentSize = CGSizeMake(901, 1127);
    }else{
         _scrollview.contentSize = CGSizeMake(901, 1127 + _aboutInfoView.frame.size.height);
    }
    
    [_scrollview addSubview:_serviceCustomerManagerDetailView];
    
    self.aboutInfoView.hidden = _aboutInfo;
    
    [self getCustomDic];
    
    [self getCustomerDetail];
    
    self.title = @"客户管理详情(销售管理)";
}



- (void)getCustomDic{
   
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    // 本店重购客户
    _rebuyStoreCustTag.userInteractionEnabled = NO;
    // 网络重购客户
    _rebuyOnlineCustTag.userInteractionEnabled = NO;
    // 置换客户标识
    _changeCustTag.userInteractionEnabled = NO;
    // 个贷客户标识
    _loanCustTag.userInteractionEnabled = NO;
    // 总部VIP客户标识
    _headerQuartCustTag.userInteractionEnabled = NO;
    // 老客户推荐标识
    _regularCustTag.userInteractionEnabled = NO;
    // 大客户标识
    _bigCustTag.userInteractionEnabled = NO;
    // 休眠客户
    _dormancy.userInteractionEnabled = NO;
}



- (void)getCustomerDetail{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [Customer getCustomerDetail:self.serviceCusstomerModel.customerID mobile:nil Success:^(Customer *customer, NSDictionary *collection) {

        if (customer) {
            _customer = [[Customer alloc] init];
            _customer = customer;
            
            [self bringData:_customer];
        }
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}



/**
 *  数据带入
 */
- (void)bringData:(Customer *)model{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    // 客户名称
    _custName.text                  = model.custName;
    // 客户来源
    _custFrom.text                  = model.custFrom;
    // 客户类别
    _custType.text                  = model.custType;
    // 信息来源
    _infoFrom.text                  = model.infoFrom;
    // 客户移动电话
    _custMobile.text                = model.custMobile;
    // 客户其他电话
    _custOtherPhone.text            = model.custOtherPhone;
    // 性别
    _gender.text                    = model.gender;
    // 生日
    _birthday.text                  = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.birthday]];
    // 证件类型
    _idType.text                    = model.idType;
    // 证件号码
    _idNumber.text                  = model.idNumber;
    // 省区
    _province.text                  = model.province;
    // 市县
    _city.text                      = model.city;
    // 行政区划
    _district.text                  = model.district;
    // QQ号码
    _qq.text                        = model.qq;
    // 客户地址
    _address.text                   = model.address;
    // 邮编
    _postcode.text                  = model.postcode;
    // E-mail
    _email.text                     = model.email;
    // 方便联系时间
    _convContactTime.text           = model.convContactTime;
    // 希望联系方式
    _expectContactWay.text          = model.expectContactWay;
    // 传真
    _fax.text                       = model.fax;
    // 现用车
    _existingCar.text               = model.existingCar;
    // 所处行业
    _industry.text                  = model.industry;
    // 职务
    _position.text                  = model.position;
    // 教育程度
    _education.text                 = model.education;
    
    __weak typeof(self) weakSelf = self;
    [DictModel getDictionary:DIC_NAME_INTEREST Success:^(NSArray *collection) {
        _likeCheckBoxViewOutlet.items = collection;
        _likeCheckBoxViewOutlet.joinedkeys = model.custInterest1?:@"";  // 客户爱好
        [weakSelf updateCustomViewFrame];
    } failure:^(NSError *error) {
        
    }];
    
    _likeCheckBoxViewOutlet.userInteractionEnabled = NO;
    
    
    // 现用车牌照号
    _existLisenPlate.text           = model.existLisenPlate;
    // 企业性质
    _enterpType.text                = model.enterpType;
    // 企业人数
    _enterpPeopleCount.text         = model.enterpPeopleCount;
    // 注册资本
    _registeredCapital.text         = model.registeredCapital;
    // 竞争车型
    _compeCarModel.text             = model.compeCarModel;
    // 本店重购客户
    _rebuyStoreCustTag.on           = [model.rebuyStoreCustTag boolValue];
    // 网络重购客户
    _rebuyOnlineCustTag.on          = [model.rebuyOnlineCustTag boolValue];
    // 置换客户标识
    _changeCustTag.on               = [model.changeCustTag boolValue];
    // 个贷客户标识
    _loanCustTag.on                 = [model.loanCustTag boolValue];
    // 总部VIP客户标识
    _headerQuartCustTag.on          = [model.headerQuartCustTag boolValue];
    // 老客户推荐标识
    _regularCustTag.on              = [model.regularCustTag boolValue];
    // 老客户选择
    _regularCust.text               = model.regularCust;
    // 大客户标识
    _bigCustTag.on                  = [model.bigCustTag boolValue];
    // 大客户选择
    _bigCusts.text                  = model.bigCusts;
    // 客户备注
    _custComment.text               = model.custComment;
    // 休眠客户
    _dormancy.on                    = [model.dormancy boolValue];
    
    _existingCarBrandLable.text    = model.existingCarBrand;
    
    _customerID = model.customerID;
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}


- (void)updateCustomViewFrame{
    CGFloat height = _likeCheckBoxViewOutlet.frame.size.height;
    CGFloat updateY = _likeCheckBoxViewOutlet.frame.origin.y;
    
    UIView *view = [UIView new];
    view.frame = _customView.frame;
    
    _customView.frame = CGRectMake(view.frame.origin.x,height+updateY+15, view.frame.size.width, view.frame.size.height);
    
    view.frame = self.aboutInfoView.frame;
    
    self.aboutInfoView.frame = CGRectMake(view.frame.origin.x, _customView.frame.origin.y+_customView.frame.size.height, view.frame.size.width, view.frame.size.height);
    
    
    if (_aboutInfo) {
        _scrollview.contentSize = CGSizeMake(901, 1127);
    }else{
        _scrollview.contentSize = CGSizeMake(901, 1354 + _aboutInfoView.frame.size.height);
    }
}



/**
 *  销售机会相关
 */
- (IBAction)aboutSalesLeadAction:(id)sender {
    SalesLeadReferenceListViewController *saleLeadVC = [[SalesLeadReferenceListViewController alloc]init];
    saleLeadVC.isAdd = YES;
    saleLeadVC.customer = self.serviceCusstomerModel;
    [self.navigationController pushViewController:saleLeadVC animated:YES];
}
/**
 *  联系人
 */
- (IBAction)contactPersonAction:(id)sender {
    ContactListViewController *contactListVC = [[ContactListViewController alloc]init];
    contactListVC.projectID = self.serviceCusstomerModel.projectID?:@"";
    contactListVC.customerID = self.serviceCusstomerModel.customerID?:@"";
    //BUG #36185::【销售视图】【客户管理】【联系人】，添加联系人，提示：客户ID不能为空。
    contactListVC.isFromSalesLead = NO;
    [self.navigationController pushViewController:contactListVC animated:YES];
}
/**
 *  跟踪计划
 */
- (IBAction)trackingAction:(id)sender {
    TrackingPlanReferenceViewController *tracking = [[TrackingPlanReferenceViewController alloc]init];
    tracking.customerID = _customerID;
    [self.navigationController pushViewController:tracking animated:YES];
}
/**
 *  文档图片
 */
- (IBAction)documentAction:(id)sender {
    DocumentViewController *doc = [[DocumentViewController alloc] initWithAboutInfoView:YES];
    doc.customerIDFromReference = _customerID?:@"";
    [self.navigationController pushViewController:doc animated:YES];
}
/**
 *  客户订单
 */
- (IBAction)customerOrderAction:(id)sender {
    CustomerOrderReferenceListViewController *customerOrderList = [[CustomerOrderReferenceListViewController alloc] init];
    customerOrderList.customerReference = _customer;
    [self.navigationController pushViewController:customerOrderList animated:YES];
}

- (IBAction)backButtonAction:(id)sender {
    if (_aboutInfo) {
        [self dismissTouched:nil];
        
        if (_shouldReloadParentData) {
            _shouldReloadParentData(YES,nil);
        }
        
    }else{
        [self backButtonTouched:nil];
    }
}


/**
 *  编辑客户订单
 */
- (IBAction)editAction:(id)sender {
    ServiceCustomerManagerEditViewController *edit = [[ServiceCustomerManagerEditViewController alloc] init];
    edit.serviceCustomerManagerModel = [[ServiceCustomerManagerModel alloc] initWithDictionary:[_customer toDictionary] error:nil];;
    
    edit.callbackServiceCustomerEdit = ^(BOOL success){
        [self getCustomerDetail];
    };
    
    [self presentDetail:edit];
}



/**
 *  @brief 导入erp
 *
 *  @param sender <#sender description#>
 */
- (IBAction)importERPTouched:(id)sender {
    [ERPImporter weatherHaveCustID:self.serviceCusstomerModel idCard:self.serviceCusstomerModel.idNumber controller:self];
}


@end
