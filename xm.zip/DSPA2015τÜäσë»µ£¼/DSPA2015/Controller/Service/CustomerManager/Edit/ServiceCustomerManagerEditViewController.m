//
//  ServiceCustomerManagerEditViewController.m
//  DSPA2015
//
//  Created by gavin on 15/12/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ServiceCustomerManagerEditViewController.h"
#import "PopoverSearchController.h"
#import "DictModel.h"
#import "ServiceCustomerManagerCheck.h"
#import "ServiceOldCustomer.h"
#import "CheckBoxView.h"

@interface ServiceCustomerManagerEditViewController ()
{

    //==============
    __weak IBOutlet UIScrollView *_scrollview;
           IBOutlet UIView       *_serviceCustomerManagerEditView;
    
    //==============
    PopoverSearchController *_searchControl;
    
    
    //==============BorderTextField============
    __weak IBOutlet BorderTextField *_custName;
    __weak IBOutlet BorderTextField *_custMobile;
    __weak IBOutlet BorderTextField *_custOtherPhone;
    __weak IBOutlet BorderTextField *_qq;
    __weak IBOutlet BorderTextField *_address;
    __weak IBOutlet BorderTextField *_postcode;
    __weak IBOutlet BorderTextField *_email;
    __weak IBOutlet BorderTextField *_fax;
    __weak IBOutlet BorderTextField *_idNumber;     //证件号码
    __weak IBOutlet BorderTextField *_existLisenPlateTextFiled; //现用车牌照号
    __weak IBOutlet BorderTextField *_existingCarBrandTextFiled;//现用车品牌
    
    //============= Switch View=================
    __weak IBOutlet SwitchView *_dormancySwitch;                //休眠
    __weak IBOutlet SwitchView *_rebuyStoreCustTagSwitch;       //本店重构客户
    __weak IBOutlet SwitchView *_rebuyOnlineCustTagSwitch;      //网络重构客户
    __weak IBOutlet SwitchView *_regularCustTagSwitch;          //老客户
    __weak IBOutlet SwitchView *_changeCustTagSwitch;           //置换客户
    __weak IBOutlet SwitchView *_loanCustTagSwitch;             //个贷客户
    __weak IBOutlet SwitchView *_headerQuartCustTagSwitch;      //总部vip
    __weak IBOutlet SwitchView *_bigCustTagSwitch;              //大客户
    
    __weak IBOutlet SwitchView *_genderSwitchView;  //性别
    

    __weak IBOutlet BorderTextView *_sMemo;         //备注
}

//==============SelectButton===============
@property (weak, nonatomic) IBOutlet SelectButton *custTypeOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *idTypeOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *custFromOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *infoFromOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *provinceOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *cityOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *countyOutlet;


@property (weak, nonatomic) IBOutlet SelectButton *convContactTimeOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *expectContactWayOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *existingCarOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *positionOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *industryOutlet;
@property (weak, nonatomic) IBOutlet SelectButton *educationOutlet;
@property (weak, nonatomic) IBOutlet CheckBoxView *likeCheckBoxView;
@property (weak, nonatomic) IBOutlet UIView *clientSubView;
@property (weak, nonatomic) IBOutlet SelectButton *birthdayOutlet;

@property (weak, nonatomic) IBOutlet SelectButton *bigCustTagOutlet;

@property (weak, nonatomic) IBOutlet SelectButton *regularCustOutlet;


// 企业性质
@property (weak, nonatomic) IBOutlet SelectButton *enterpTypeOutlet;
// 企业人数
@property (weak, nonatomic) IBOutlet SelectButton *enterpPeopleCountOutlet;
// 注册资本
@property (weak, nonatomic) IBOutlet SelectButton *registeredCapitalOutlet;
// 竞争车型
@property (weak, nonatomic) IBOutlet SelectButton *compeCarModelOutlet;


- (IBAction)regularCustAction:(id)sender;//老客户

- (IBAction)custTypeAction:(id)sender;
- (IBAction)idTypeAction:(id)sender;
- (IBAction)custFromAction:(id)sender;
- (IBAction)infoFromAction:(id)sender;
- (IBAction)provinceAction:(id)sender;
- (IBAction)convContactTimeAction:(id)sender;
- (IBAction)expectContactWayAction:(id)sender;
- (IBAction)existingCarAction:(id)sender;
- (IBAction)positionAction:(id)sender;
- (IBAction)industryAction:(id)sender;
- (IBAction)educationAction:(id)sender;
- (IBAction)birthdayAction:(id)sender;
- (IBAction)cityAction:(id)sender;
- (IBAction)bigCustTagAction:(id)sender;
- (IBAction)countyAction:(id)sender;


// 企业性质
- (IBAction)enterpTypeAction:(SelectButton *)sender;
// 企业人数
- (IBAction)enterpPeopleCountAction:(SelectButton *)sender;
// 注册资本
- (IBAction)registeredCapitalAction:(SelectButton *)sender;
// 竞争车型
- (IBAction)compeCarModelAction:(SelectButton *)sender;


//========== save button===============
- (IBAction)saveButtonAction:(id)sender;


@end

@implementation ServiceCustomerManagerEditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _scrollview.contentSize = CGSizeMake(901, 1466);
    [_scrollview addSubview:_serviceCustomerManagerEditView];
    
    
    __weak __typeof(self)weakSelf = self;
    [DictModel getDictionary:DIC_NAME_SEX Success:^(NSArray *collection) {
        _genderSwitchView.items = collection;
        
        //BUG #36181::【销售视图】【客户管理】，列表中的客户性别未显示，详细页面客户性别显示为空，编辑界面有值。
        [weakSelf bringData:weakSelf.serviceCustomerManagerModel];
        
        [_genderSwitchView didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
            _serviceCustomerManagerModel.gender     = [item stringForKey:@"value"];
            _serviceCustomerManagerModel.genderCode = [item stringForKey:@"key"];
        }];
    } failure:^(NSError *error) {
        
    }];
    
    _rebuyStoreCustTagSwitch.userInteractionEnabled = NO;
    
    
    
    self.title = @"客户管理编辑(销售管理)";
}

/**
 *  客户类别
 */

- (IBAction)custTypeAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_CUSTOM_TYPE Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.custType = value;
            _serviceCustomerManagerModel.custTypeCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}

/**
 *  证件类型
 */
- (IBAction)idTypeAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_CARD_TYPE Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.idType = value;
            _serviceCustomerManagerModel.idTypeCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}

/**
 *  客户来源
 */
- (IBAction)custFromAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_CUSTOM_FROM Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.custFrom = value;
            _serviceCustomerManagerModel.custFromCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}

/**
 *  信息来源
 */
- (IBAction)infoFromAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_INFOFROM Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.infoFrom = value;
            _serviceCustomerManagerModel.infoFromCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  省
 */
- (IBAction)provinceAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_PROVINCE Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            _provinceOutlet.value = value;
            _serviceCustomerManagerModel.province = [item stringForKey:@"value"];
            _serviceCustomerManagerModel.provinceCode = [item stringForKey:@"key"];
            
            // 客户地址
            _address.text = [item stringForKey:@"value"];
            _serviceCustomerManagerModel.address = _address.text;
            
            [_cityOutlet reset];
            _serviceCustomerManagerModel.city = nil;
            _serviceCustomerManagerModel.cityCode = nil;
            //BUG #42314::【销售视图】【客户管理】，已选择省市县，切换省份，行政区划未清空。
            [_countyOutlet reset];
            _serviceCustomerManagerModel.districtCode = nil;
            _serviceCustomerManagerModel.district = nil;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  市
 */
- (IBAction)cityAction:(SelectButton *)sender {
    
    if ([_serviceCustomerManagerModel.provinceCode isEqualToString:@""] || !_serviceCustomerManagerModel.provinceCode) {
        [JKAlert showMessage:@"请选择省份"];
        return;
    }
    
    
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    [arr addObject:@"city"];
    [arr addObject:_serviceCustomerManagerModel.provinceCode];
    [DictModel getCascadeDict:arr Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            _cityOutlet.value = value;
            _serviceCustomerManagerModel.city = [item stringForKey:@"value"];
            _serviceCustomerManagerModel.cityCode = [item stringForKey:@"key"];
            
            // 客户地址
            _address.text = [NSString stringWithFormat:@"%@%@",_provinceOutlet.value,[item stringForKey:@"value"]];
            _serviceCustomerManagerModel.address = _address.text;
            
            [_countyOutlet reset];
            _serviceCustomerManagerModel.districtCode = nil;
            _serviceCustomerManagerModel.district = nil;
        }];
    } failure:^(NSError *error) {
    }];
}

- (IBAction)countyAction:(SelectButton *)sender {
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    [arr addObject:@"district"];
    if ([_serviceCustomerManagerModel.provinceCode isEqualToString:@""] || !_serviceCustomerManagerModel.provinceCode) {
        [JKAlert showMessage:@"请选择省份"];
        return;
    }
    if ([_serviceCustomerManagerModel.cityCode isEqualToString:@""] || !_serviceCustomerManagerModel.cityCode) {
        [JKAlert showMessage:@"请选择城市"];
        return;
    }
    [arr addObject:_serviceCustomerManagerModel.provinceCode?:@""];
    [arr addObject:_serviceCustomerManagerModel.cityCode?:@""];
    [DictModel getCascadeDict:arr Success:^(NSArray *collection) {
        
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            _serviceCustomerManagerModel.district = [item stringForKey:@"value"];
            _serviceCustomerManagerModel.districtCode = [item stringForKey:@"key"];
            
            // 客户地址
            _address.text = [NSString stringWithFormat:@"%@%@%@",_provinceOutlet.value,_cityOutlet.value,[item stringForKey:@"value"]];
            _serviceCustomerManagerModel.address = _address.text;
        }];
        
        
    } failure:^(NSError *error) {
    }];
}

/**
 *  方便联系时间
 */
- (IBAction)convContactTimeAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_CONTACT_TIME Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.convContactTime = value;
            _serviceCustomerManagerModel.convContactTimeCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}

/**
 *  希望联系方式
 */
- (IBAction)expectContactWayAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_CONTRACT_WAY Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.expectContactWay = value;
            _serviceCustomerManagerModel.expectContactWayCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  现用车
 */
- (IBAction)existingCarAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_NOW_CAR Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.existingCar = value;
            _serviceCustomerManagerModel.existingCarCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  职务
 */
- (IBAction)positionAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_POSITION Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.position = value;
            _serviceCustomerManagerModel.positionCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  所处行业
 */
- (IBAction)industryAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_INDUSTRY Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.industry = value;
            _serviceCustomerManagerModel.industryCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  教育程度
 */
- (IBAction)educationAction:(SelectButton *)sender {
    [DictModel getDictionary:DIC_NAME_EDUCATION Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.education = value;
            _serviceCustomerManagerModel.educationCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}

/**
 *  客户爱好
 */
- (void)custInterest1:(NSString *)custInterest1 {
    __weak typeof(self)weakSelf = self;
    [DictModel getDictionary:DIC_NAME_INTEREST Success:^(NSArray *collection) {
        weakSelf.likeCheckBoxView.items = collection;

        [weakSelf.likeCheckBoxView didSelectCheckBoxViewItem:^(NSInteger index, id item, NSString *key, NSString *value, NSArray *selectedItems, NSString *joinedkeys) {
            _serviceCustomerManagerModel.custInterestCode1 = joinedkeys;
            _serviceCustomerManagerModel.custInterest1 = joinedkeys;
        }];
        //设置爱好下面subview的位置
        CGRect rect = weakSelf.clientSubView.frame;
        rect.origin.y = CGRectGetMaxY(weakSelf.likeCheckBoxView.frame) + 15;
        weakSelf.clientSubView.frame = rect;
        //更新视图
        CGRect editViewRect = _serviceCustomerManagerEditView.frame;
        editViewRect.size.height = CGRectGetMaxY(weakSelf.clientSubView.frame);
        _serviceCustomerManagerEditView.frame = editViewRect;
        _scrollview.contentSize = CGSizeMake(901, CGRectGetHeight(_serviceCustomerManagerEditView.frame));
        
        weakSelf.likeCheckBoxView.joinedkeys =  custInterest1;
    } failure:^(NSError *error) {
        
    }];
}

/**
 *  企业性质
 */
- (IBAction)enterpTypeAction:(SelectButton *)sender{
    [DictModel getDictionary:DIC_NAME_ENTERP_TYPE Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.enterpType = value;
            _serviceCustomerManagerModel.enterpTypeCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  企业人数
 */
- (IBAction)enterpPeopleCountAction:(SelectButton *)sender{
    
    [DictModel getDictionary:DIC_NAME_ENTERP_PEOPLE Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.enterpPeopleCount = value;
            _serviceCustomerManagerModel.enterpPeopleCountCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  注册资本
 */
- (IBAction)registeredCapitalAction:(SelectButton *)sender{
    [DictModel getDictionary:DIC_NAME_REGISTERED Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.registeredCapital = value;
            _serviceCustomerManagerModel.registeredCapitalCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/**
 *  竞争车型
 */
- (IBAction)compeCarModelAction:(SelectButton *)sender{
    [DictModel getDictionary:@"dicCompeCarModel" Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.compeCarModel = value;
            _serviceCustomerManagerModel.compeCarModelCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}


/**
 *  生日选择
 */
- (IBAction)birthdayAction:(SelectButton *)sender {
    PopoverDateController *datePicker = [[PopoverDateController alloc]initWithSender:sender];
    //生日
     datePicker.minDate  = [DateManager dateConvertFrom_YMD_String:@"1900-01-01"];
    
    
    [datePicker dateChanged:^(NSDate *date,NSString *dateYMDString,long long timeStamp,NSString *timeStampString) {
        _birthdayOutlet.value = [DateManager stringConvert_YMD_FromDate:date];
        _serviceCustomerManagerModel.birthday = timeStamp;
    }];
    [self presentViewController:datePicker animated:YES completion:nil];
}



/**
 *  大客户选择
 */
- (IBAction)bigCustTagAction:(SelectButton *)sender {
    [DictModel getDictionary:@"dicDkh" Success:^(NSArray *collection) {
        [self showSearchSelectController:sender withData:collection selectItem:^(id item, NSString *key, NSString *value) {
            sender.value = value;
            _serviceCustomerManagerModel.bigCusts = value;
            _serviceCustomerManagerModel.bigCustsCode = key;
        }];
    } failure:^(NSError *error) {
        
    }];
}
/***
 *  老客户选择
 */
- (IBAction)regularCustAction:(SelectButton *)sender {
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [ServiceOldCustomer fetchOldCustomerList:@{@"startNum":@0,@"rowCount":@100} Success:^(NSArray *resultList, id responseObject) {
        
    PopoverSearchController *search = [self showSearchSelectController:sender withData:resultList selectItem:^(ServiceOldCustomer* item, NSString *key, NSString *value) {
            _regularCustOutlet.value = item.ckhmc;
            _serviceCustomerManagerModel.regularCust = item.ckhmc;
            _serviceCustomerManagerModel.regularCustCode = item.ckhdm;
        }];
        
        [search titleForSelectSearchItem:^NSString *(NSInteger index, ServiceOldCustomer *item) {
            return item.ckhmc;
        }];
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}




/**
 *  bring data
 */
- (void)bringData:(ServiceCustomerManagerModel *)model{
    
    //==============BorderTextField============
    _custName.text          = model.custName;
    _custMobile.text        = model.custMobile;
    _custOtherPhone.text    = model.custOtherPhone;
    _qq.text                = model.qq;
    _address.text           = model.address;
    _postcode.text          = model.postcode;
    _email.text             = model.email;
    _fax.text               = model.fax;
    
    _sMemo.text             = model.custComment;
    _idNumber.text          = model.idNumber;
    
    //==============SelectButton===============
    _custTypeOutlet.value = model.custType;
    _idTypeOutlet.value = model.idType;
    _custFromOutlet.value = model.custFrom;
    _infoFromOutlet.value = model.infoFrom;
    _provinceOutlet.value = model.province;
    _convContactTimeOutlet.value = model.convContactTime;
    _expectContactWayOutlet.value = model.expectContactWay;
    _existingCarOutlet.value = model.existingCar;
    _positionOutlet.value = model.position;
    _industryOutlet.value = model.industry;
    _educationOutlet.value = model.education;
    //爱好
    [self custInterest1:model.custInterest1?:@""];
    _birthdayOutlet.value = [DateManager stringConvert_YMD_FromDate:[DateManager dateWithTimeStamp:model.birthday]];
    
    _bigCustTagOutlet.value = model.bigCusts;   //大客户
    
    _provinceOutlet.value = model.province;
    _cityOutlet.value     = model.city;
    _countyOutlet.value   = model.district;
//    _collectFromSelectView.items = [_localCacheDic arrayForKey:DIC_NAME_COLLECT_FROM];
    
    _existLisenPlateTextFiled.text = model.existLisenPlate; //现用车牌照号
    _existingCarBrandTextFiled.text = model.existingCarBrand;//现用车品牌
    
    
    // 企业性质
    _enterpTypeOutlet.value = model.enterpType;
    // 企业人数
    _enterpPeopleCountOutlet.value = model.enterpPeopleCount;
    // 注册资本
    _registeredCapitalOutlet.value = model.registeredCapital;
    // 竞争车型
    _compeCarModelOutlet.value = model.compeCarModel;
    
    
    // 性别反选
    [_genderSwitchView reverseIndexWithKey:model.genderCode];
    //============= Switch View=================
    _dormancySwitch.on              = [model.dormancy boolValue];                //休眠
    _rebuyStoreCustTagSwitch.on     = [model.rebuyStoreCustTag boolValue];       //本店重构客户
    _rebuyOnlineCustTagSwitch.on    = [model.rebuyOnlineCustTag boolValue];      //网络重构客户
    _regularCustTagSwitch.on        = [model.regularCustTag boolValue];          //老客户
    _changeCustTagSwitch.on         = [model.changeCustTag boolValue];           //置换客户
    
    //老客户推荐标识
    if (_regularCustTagSwitch.on) {
        _regularCustOutlet.enabled = YES;
    }else{
        _regularCustOutlet.enabled = NO;
    }
    
    
    _loanCustTagSwitch.on           = [model.loanCustTag boolValue];             //个贷客户
    _headerQuartCustTagSwitch.on    = [model.headerQuartCustTag boolValue];      //总部vip
    _bigCustTagSwitch.on            = [model.bigCustTag boolValue];              //大客户
    
    
    if (_bigCustTagSwitch.on) {
        _bigCustTagOutlet.enabled = YES;
    }else{
        _bigCustTagOutlet.enabled = NO;
    }
    
    [_regularCustTagSwitch didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
        _regularCustOutlet.enabled = on;
        if (!_regularCustTagSwitch.on) {
            [_regularCustOutlet reset];
        }
    }];
    
    [_bigCustTagSwitch didSelectSwitchViewItem:^(NSInteger index, id item, BOOL on, NSNumber *onNumber) {
        _bigCustTagOutlet.enabled = on;
        if (!_bigCustTagSwitch.on) {
            [_bigCustTagOutlet reset];
        }
    }];
    
    _regularCustOutlet.value = model.regularCust;
    
}


- (void)getTextFieldValue{
    //==============BorderTextField============
    _serviceCustomerManagerModel.custName       = _custName.text;
    _serviceCustomerManagerModel.custMobile     = _custMobile.text;
    _serviceCustomerManagerModel.custOtherPhone = _custOtherPhone.text;
    _serviceCustomerManagerModel.qq             = _qq.text;
    _serviceCustomerManagerModel.address        = _address.text;
    _serviceCustomerManagerModel.postcode       = _postcode.text;
    _serviceCustomerManagerModel.email          = _email.text;
    _serviceCustomerManagerModel.fax            = _fax.text;
    
    _serviceCustomerManagerModel.custComment    = _sMemo.text;
    _serviceCustomerManagerModel.idNumber       = _idNumber.text;

    _serviceCustomerManagerModel.existLisenPlate = _existLisenPlateTextFiled.text;
    _serviceCustomerManagerModel.existingCarBrand = _existingCarBrandTextFiled.text;
    
    //============= Switch View=================
    _serviceCustomerManagerModel.dormancy           = [NSNumber numberWithBool:_dormancySwitch.on];
    _serviceCustomerManagerModel.rebuyStoreCustTag  = [NSNumber numberWithBool:_rebuyStoreCustTagSwitch.on];
    _serviceCustomerManagerModel.rebuyOnlineCustTag = [NSNumber numberWithBool:_rebuyOnlineCustTagSwitch.on];
    _serviceCustomerManagerModel.regularCustTag     = [NSNumber numberWithBool:_regularCustTagSwitch.on];
    _serviceCustomerManagerModel.changeCustTag      = [NSNumber numberWithBool:_changeCustTagSwitch.on];
    _serviceCustomerManagerModel.loanCustTag        = [NSNumber numberWithBool:_loanCustTagSwitch.on];
    _serviceCustomerManagerModel.headerQuartCustTag = [NSNumber numberWithBool:_headerQuartCustTagSwitch.on];
    _serviceCustomerManagerModel.bigCustTag         = [NSNumber numberWithBool:_bigCustTagSwitch.on];
    
    _serviceCustomerManagerModel.regularCust = _regularCustOutlet.value;
}



/**
 *  save to service
 */
- (IBAction)saveButtonAction:(id)sender {
    [self getTextFieldValue];
    NSString *error = [ServiceCustomerManagerCheck serviceCustomerManagerCheck:_serviceCustomerManagerModel];
    if (error) {
        [JKAlert showMessage:error];
        return;
    }
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:[_serviceCustomerManagerModel toDictionary]];
    //statisticstype   int 类型  0  销售工作 1 客户视图 2 设置 3 首页
    [dic setValue:[NSNumber numberWithInt:0] forKey:@"statisticstype"];
    
    [ServiceCustomerManagerModel updateServiceCustomer:dic Success:^(BOOL result, id responseObject) {
        
        if (result) {
            [JKAlert showMessage:@"客户信息更新成功"];
            if (self.callbackServiceCustomerEdit) {
                self.callbackServiceCustomerEdit(YES);
            }
            [self dismissTouched:nil];
        }else{
            NSArray *errorList = [[responseObject objectForKey:@"validate_error"] allValues];
            if (errorList) {
                [JKAlert showMessage:[errorList firstObject]];
                
            }else{
                [JKAlert showMessage:@"客户信息更新失败"];
            }

        }
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    } Failure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}



#pragma mark textField delegate
- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    if(textField == _idNumber && [_idNumber hasText] && [_idTypeOutlet.value isEqualToString:@"身份证"]){
        
        _serviceCustomerManagerModel.idNumber = textField.text;
        
        NSString *idNum = _idNumber.text;
        // 取生日
        _birthdayOutlet.value =[DateManager stringConvert_YMD_FromDate:[Validator getBirthDay:idNum]];
        _birthdayOutlet.key = [DateManager timeStampStringWithDate:[Validator getBirthDay:idNum]];
        _serviceCustomerManagerModel.birthday =[DateManager timeIntervalWithDate:[Validator getBirthDay:idNum]];
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
