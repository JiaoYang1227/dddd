//
//  ServiceCustomerManagerEditViewController.h
//  DSPA2015
//
//  Created by gavin on 15/12/10.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "BaseDetailViewController.h"
#import "ServiceCustomerManagerModel.h"
typedef void(^onServiceCustomerManagerEditCallBack)(BOOL success);
@interface ServiceCustomerManagerEditViewController : BaseDetailViewController

@property (nonatomic , strong) ServiceCustomerManagerModel *serviceCustomerManagerModel;


@property (nonatomic , copy) onServiceCustomerManagerEditCallBack callbackServiceCustomerEdit;

@end
