//
//  ServiceCustomerManagerCell.h
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceCustomerManagerModel.h"
#import "CellButton.h"
#import "TagView.h"
@interface ServiceCustomerManagerCell : UITableViewCell
+(UINib*)nib;

// 客户名称
@property (weak, nonatomic) IBOutlet UILabel *custName;

// 客户来源
@property (weak, nonatomic) IBOutlet UILabel *custFrom;

// 客户类别
@property (weak, nonatomic) IBOutlet UILabel *custType;

// 信息来源
@property (weak, nonatomic) IBOutlet UILabel *infoFrom;

// 客户移动电话
@property (weak, nonatomic) IBOutlet UILabel *custMobile;
// 客户其他电话
@property (weak, nonatomic) IBOutlet UILabel *custOtherPhone;

// 性别
@property (weak, nonatomic) IBOutlet UILabel *gender;

// 证件类型
@property (weak, nonatomic) IBOutlet UILabel *idType;
// 证件号码
@property (weak, nonatomic) IBOutlet UILabel *idNumber;

// 客户地址
@property (weak, nonatomic) IBOutlet UILabel *address;

// 客户状态
@property (weak, nonatomic) IBOutlet UILabel *custStatus;

@property (weak, nonatomic) IBOutlet UIImageView *cellCustomerFlagImage;

@property (weak, nonatomic) IBOutlet TagView *cellTagView;


@property (weak, nonatomic) IBOutlet CellButton *cellEditButtonOutlet;



- (void)configCellData:(ServiceCustomerManagerModel *)model;


@end
