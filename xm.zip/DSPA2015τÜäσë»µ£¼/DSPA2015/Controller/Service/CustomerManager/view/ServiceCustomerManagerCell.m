//
//  ServiceCustomerManagerCell.m
//  DSPA2015
//
//  Created by gavin on 15/12/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "ServiceCustomerManagerCell.h"

@implementation ServiceCustomerManagerCell


+(UINib*)nib{
    return  [UINib nibWithNibName:NSStringFromClass([self class]) bundle:nil];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

/// 本店重购客户
//@property (nonatomic, strong)NSNumber *rebuyStoreCustTag;
//// 网络重购客户
//@property (nonatomic, strong)NSNumber *rebuyOnlineCustTag;
//// 置换客户标识
//@property (nonatomic, strong)NSNumber *changeCustTag;
//// 个贷客户标识
//@property (nonatomic, strong)NSNumber *loanCustTag;
//// 总部VIP客户标识
//@property (nonatomic, strong)NSNumber *headerQuartCustTag;
//// 老客户推荐标识
//@property (nonatomic, strong)NSNumber *regularCustTag;
//// 老客户选择代码
//@property (nonatomic, strong)NSString *regularCustCode;
//// 老客户选择
//@property (nonatomic, strong)NSString *regularCust;
//// 大客户标识
//@property (nonatomic, strong)NSNumber *bigCustTag;




// 递交新车  本店重购  网络重购  置换  老客户  个贷客户  VIP客户  大客户

- (void)configCellData:(ServiceCustomerManagerModel *)model{
    // 客户名称
    self.custName.text      = model.custName;
    // 客户来源
    self.custFrom.text      = model.custFrom;
    // 客户类别
    self.custType.text      = model.custType;
    // 信息来源
    self.infoFrom.text      = model.infoFrom;
    // 客户移动电话
    self.custMobile.text    = model.custMobile;
    // 客户其他电话
    self.custOtherPhone.text = model.custOtherPhone;
    // 性别
    self.gender.text        = model.gender;
    // 证件类型
    self.idType.text        = model.idType;
    // 证件号码
    self.idNumber.text      = model.idNumber;
    // 客户地址
    self.address.text       = model.address;
    // 客户状态
    self.custStatus.text    = model.custStatus;

    
    [self loadTags:model];
}
-(void)loadTags:(ServiceCustomerManagerModel *)model{
    NSDictionary *custommer = [model toDictionary];
    NSArray *tagMap = @[
                        @{@"key":@"rebuyStoreCustTag",@"value":@"本店重购"},
                        @{@"key":@"rebuyOnlineCustTag",@"value":@"网络重购"},
                        @{@"key":@"changeCustTag",@"value":@"置换客户"},
                        @{@"key":@"regularCustTag",@"value":@"老客户"},
                        @{@"key":@"loanCustTag",@"value":@"个贷客户"},
                        @{@"key":@"headerQuartCustTag",@"value":@"VIP客户"},
                        @{@"key":@"bigCustTag",@"value":@"大客户"}];
    
    [self.cellTagView showMapTags:tagMap mappingItem:custommer];
}


@end
