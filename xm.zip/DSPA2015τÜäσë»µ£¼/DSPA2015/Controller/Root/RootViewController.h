//
//  RootViewController.h
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClientRootViewController.h"
#import "BindDeviceViewController.h"
#import "ServiceRootViewController.h"

#import "NoteViewController.h"

@interface RootViewController : UIViewController<UIGestureRecognizerDelegate>
{
    NoteBackgroundView *_coverView;
}
@property (nonatomic, strong) UINavigationController *contentNavigationController;
@property (nonatomic, strong) ClientRootViewController *clientRootViewController;

@property (nonatomic, strong) ServiceRootViewController *serviceRootViewController;

@property (nonatomic, strong) BindDeviceViewController *bind;

@property (nonatomic, strong) NoteViewController *note;


- (void)pushViewController:(UIViewController *)viewController
                  animated:(BOOL)animated;
- (NSArray *)popToRootViewControllerAnimated:(BOOL)animated;
- (UIViewController *)popViewControllerAnimated:(BOOL)animated;
- (void)replaceViewController:(UIViewController *)viewController animated:(BOOL)animated;

/**
 *  显示左侧面板
 */
- (void)showPanel:(BOOL)show;
/**
 *  显示客户视图
 *
 *  @param show 是否显示
 */
- (void)showClientBar:(BOOL)show;

-(void)showBindAlert;
//全屏弹出
-(void)presentModelDetail:(UIViewController*)modelDetailViewController;
@end
