//
//  RootViewController.m
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "RootViewController.h"
#import "VerifyManager.h"
#import "UIViewController+MMDrawerController.h"
#import "ExperienceRootViewController.h"
#import "UIViewController+MJPopupViewController.h"
#import "VersionManager.h"
#import "UIViewController+DSPAPopup.h"
#import "Util.h"
#import "TaskBoard.h"
#import "MessageCenter.h"

#import "BaseNavigationController.h"

static SystemSoundID ringringring = 0;

@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadDataLogin:) name:KEY_NOTIFATION_RELOADLOGIN object:nil];
    
    [self autoLogin];

    self.contentNavigationController.navigationBarHidden = YES;
    _clientRootViewController= [[ClientRootViewController alloc] init];
    [self addChildViewController:_clientRootViewController];
    [self.view addSubview:_clientRootViewController.view];
    self.view.clipsToBounds = YES;
  
    [self notePanGestures];

    NSString *path = [[NSBundle mainBundle] pathForResource:@"ring" ofType:@"mp3"];
    if (path) {
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)[NSURL fileURLWithPath:path], &ringringring);
    }
    __weak typeof(self) weakSelf = self;
    [MessageCenter reconnectForDSPA];

    [MessageCenter MCDidReceiveMessage:^(id message) {
        NSDictionary *result = [message dictionaryValue];
        //         [JKAlert showMessage:[result description]];
        
        if ([[result stringForKey:@"msgModel"] isEqualToString:@"TaskSchedule"]) {
            if ([AppDelegate APP].user.role == UserRoleConsultant) {
                [weakSelf loadAssignStatus];
            }
        }
    } forModule:@"RootView"];


}
-(NoteViewController *)note{
    if (!_note) {
       _note =  [[NoteViewController alloc]init];
    }
    return _note;
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //版本检测
    //#if TARGET_IPHONE_SIMULATOR
    //    NSLog(@"run on simulator");
    //#else
    //    [VersionManager checkVersion];
    //#endif
   
    [VersionManager checkVersion];

//    #if TARGET_IPHONE_SIMULATOR
//        NSLog(@"run on simulator");
//    #else
//   // 删除激活状态
////   VerifyManager->deleteActiveStatus();
////    
////
//    int times =  VerifyManager->lunchTimesPlus();
//    const char *temp = VerifyManager->getActiveStatus();
//
//    NSLog(@"times:%d",times);
//    if (times>LIMIT_LUNCHER_TIMES || (strcmp(temp, "demo")==0 && times>LIMIT_LUNCHER_TIMES_DEMO)) {
//        if(!VerifyManager->isVerified()){
//            VerifyManager->deleteActiveStatus();
//            [self showBindAlert];
//        }
//    }
//   #endif
}

-(void)showBindAlert{
    if(!self.mj_popupViewController){
        
        self.bind = [[BindDeviceViewController alloc] init];
        [self presentPopupViewController:self.bind animationType:MJPopupViewAnimationSlideBottomTop backgroundTouch:NO dismissed:nil];
    }
}

-(ServiceRootViewController *)serviceRootViewController{
    for (UIViewController *v in self.contentNavigationController.viewControllers ) {
        if ([v isKindOfClass:[ServiceRootViewController class]]) {
            return (ServiceRootViewController *)v;
        }
    }
    return nil;
}
-(UINavigationController *)contentNavigationController{
    if (!_contentNavigationController) {
        
        _contentNavigationController = [[BaseNavigationController alloc] initWithRootViewController:[[ExperienceRootViewController alloc] init]];
        _contentNavigationController.navigationBarHidden = YES;
        //    self.contentNavigationController.view.frame = CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds)-64);
        _contentNavigationController.view.frame = self.view.bounds;
        [self.view addSubview:_contentNavigationController.view];
        [self addChildViewController:_contentNavigationController];
    }
    return _contentNavigationController;
}
#pragma --mark push and pop
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if ([[self.contentNavigationController.viewControllers lastObject] class] != [viewController class]) {
        [self.contentNavigationController pushViewController:viewController animated:animated];
    }
}
- (NSArray *)popToRootViewControllerAnimated:(BOOL)animated{
    return [self.contentNavigationController popToRootViewControllerAnimated:animated];
}
- (UIViewController *)popViewControllerAnimated:(BOOL)animated{
    return [self.contentNavigationController popViewControllerAnimated:animated];
}

- (void)replaceViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [self.contentNavigationController popToRootViewControllerAnimated:NO];
    [self.contentNavigationController pushViewController:viewController animated:animated];
    //    [self.contentNavigationController setViewControllers:@[viewController] animated:animated];
}

/**
 *  显示/隐藏侧边
 */
- (void)showPanel:(BOOL)show{
    if (show)
    {
        [self.mm_drawerController openDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
    }else
    {
        [self.mm_drawerController closeDrawerAnimated:YES completion:nil];
    }
}

/**
 *  显示客户视图
 */
- (void)showClientBar:(BOOL)show{
    _clientRootViewController.view.hidden = !show;
    //删除所有presentDetail
    for (UIViewController *vc in self.childViewControllers) {
        if ([vc respondsToSelector:@selector(popTag)] && vc.popTag == 1001
            &&
            ([NSStringFromClass([vc class]) isEqualToString:@"ClientReceptionEditViewController"] || [NSStringFromClass([vc class]) isEqualToString:@"SalesLeadEditViewController"]|| [NSStringFromClass([vc class]) isEqualToString:@"ADCReceptionEditViewController"]|| [NSStringFromClass([vc class]) isEqualToString:@"ClientADCReceptionViewController"]
             
             
             )) {
            vc.view.hidden = !show;
        }
        
        
    }
}
#pragma arguments  手势
- (void)notePanGestures {
    [self addChildViewController:self.note];
    [self.view addSubview:self.note.view];
    self.note.view.layer.zPosition = 2000;
    
    AppDelegate *app = [AppDelegate APP];
    self.note.view.left = 0;
    self.note.view.transform=  CGAffineTransformMakeTranslation(-self.note.view.width,0);
    
    if ([self.view.gestureRecognizers lastObject] && [[self.view.gestureRecognizers lastObject] isKindOfClass:[UIPanGestureRecognizer class]]) {
        return;
    }
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePaning:)];
    panGesture.delegate = self;
    [app.window addGestureRecognizer:panGesture];

}
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    NSLog(@"shouldRecognizeSimultaneouslyWithGestureRecognizer");

    return NO;
}
- (BOOL)gestureRecognizerShouldBegin:(UIPanGestureRecognizer *)gestureRecognizer

{
    return YES;
}
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRequireFailureOfGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
//
//
//}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    CGPoint p = [touch locationInView:nil];

    if(self.note.show){
        return YES;
    }else{
        if(p.x<100)
        {
            return YES;
        }else{
            return NO;
        }
    }
    return YES;
    
}

#define kMinimumPanDistance 100
CGPoint lastRecognizedInterval;

- (void)handlePaning:(UIPanGestureRecognizer *)recognizer {
    AppDelegate *app = [AppDelegate APP];

    if (recognizer.state == UIGestureRecognizerStateBegan) {
        lastRecognizedInterval = [recognizer translationInView:app.window];

    }
    if (recognizer.state == UIGestureRecognizerStateEnded) {
        CGPoint thisInterval = [recognizer translationInView:app.window];
        
        if (fabs(lastRecognizedInterval.x - thisInterval.x) > kMinimumPanDistance ||
            fabs(lastRecognizedInterval.y - thisInterval.y) > kMinimumPanDistance) {
            
            lastRecognizedInterval = thisInterval;
            
            // you would add your method call here
        
            if (!self.note.show && thisInterval.x>0 && thisInterval.y<100) {
                [self.view bringSubviewToFront:self.note.view];
                [_coverView removeFromSuperview];
                _coverView = [[NoteBackgroundView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame))];
                _coverView.backgroundColor = [UIColor blackColor];
                _coverView.alpha = 0;
                _coverView.layer.zPosition = 1999;
                [_coverView touchesBegan:^(CGPoint point) {
                    if (point.x>self.note.view.width) {
                        [UIView animateWithDuration:0.2 animations:^{
                            self.note.view.transform=  CGAffineTransformMakeTranslation(-self.note.view.width,0);
                            self.note.show = NO;
                            _coverView.alpha = 0;
                            
                        } completion:^(BOOL finished) {
                            [_coverView removeFromSuperview];
                            [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
                            
                        }];
                    }
                }];
                [self.view insertSubview:_coverView belowSubview:self.note.view];
                
                [UIView animateWithDuration:0.2 animations:^{
                    self.note.view.transform=  CGAffineTransformIdentity;
                    self.note.show = YES;
                    _coverView.alpha = 0.55;

                } completion:^(BOOL finished) {
                    
                }];
            }
        
        }

         if (self.note.show && thisInterval.x<0 && thisInterval.y<100) {
            [UIView animateWithDuration:0.2 animations:^{
                self.note.view.transform=  CGAffineTransformMakeTranslation(-self.note.view.width,0);
                self.note.show = NO;
                _coverView.alpha = 0;

            } completion:^(BOOL finished) {
                [_coverView removeFromSuperview];
                [[[UIApplication sharedApplication] keyWindow] endEditing:YES];

            }];
        }

    }
    //NSLog(@"%@", NSStringFromCGPoint(p));
}

-(void)presentModelDetail:(UIViewController*)modelDetailViewController{
    [self presentDSPAPopup:modelDetailViewController
      parentViewController:self
             touchCallBack:nil
                  haveMask:NO
          includeNavgation:YES
                  alignTop:YES];
}

-(void)autoLogin{
   __weak typeof(self) weakSelf = self;

    [User getAccount:^(NSString *username, NSString *password) {
        if (username && ![username isEqualToString:@""]) {
            NSDictionary *parameter = @{@"username":username,@"password":password?:@""};
            [User login:parameter Success:^(User *user, id responseObject) {
                if(user){
                    [AppDelegate APP].user = user;
                    [weakSelf loadAssignStatus];

                    //自动登录问题
                    [[NSNotificationCenter defaultCenter]postNotificationName:KEY_NOTIFATION_RELOADLOGIN object:[NSNumber numberWithBool:YES]];
                }else{
                    [JKAlert showMessage:@"自动登录失败！"];
                }
                
            } Failure:^(NSError *error) {
                [JKAlert showMessage:@"自动登录失败！"];
                
            }];
        }
    }];
    
}
-(void)reloadDataLogin:(NSNotification*)notifacation{
    //重新连接消息中心
    [MessageCenter reconnectForDSPA];
    if ([AppDelegate APP].user){
        [self loadAssignStatus];
    }
    
}
-(void)applicationDidBecomeActive:(NSNotification*)notifacation{
    if([MessageCenter sharedCenter].readyState>1){
        NSLog(@"重新连接");
        [MessageCenter reconnectForDSPA];
        [self loadAssignStatus];
    }
}
-(void)loadAssignStatus{
    
//    __weak typeof(self) weakSelf = self;
    if ([AppDelegate APP].user) {
        [TaskBoard getAssignStatus:^(NSDictionary *collection) {
            
            if (collection != nil && [collection integerForKey:@"assignStatus"] == 1) {
                //播放声音
                AudioServicesPlaySystemSound(ringringring);
                __unused CustomerReception *r = [CustomerReception objectFromDictionary:[collection dictionaryForKey:@"result"]];
                
            }
        } Failure:^(NSError *error) {
            
        }];
    }
}
@end
