//
//  UIPopoverController+View.m
//  DSPA2015
//
//  Created by Jakey on 15/7/24.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "UIPopoverController+View.h"

@implementation UIPopoverController (View)
-(instancetype)initWithContentView:(UIView *)view{
    UIViewController *vc = [[UIViewController alloc]init];
    vc.view = view;
    return [self initWithContentViewController:vc];
}
@end
