//
//  UIPopoverController+View.h
//  DSPA2015
//
//  Created by Jakey on 15/7/24.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIPopoverController (View)
-(instancetype)initWithContentView:(UIView *)view;
@end
