//
//  UIView+gesture.h
//  DSPA2015
//
//  Created by gavin on 15/7/20.
//  Copyright (c) 2015年 www.runlin.cn. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface UIView (gesture)
/**
 *  给view添加单击手势
 *
 *  @param block 单击手势执行的block
 */
- (void)setTapActionWithBlock:(void (^)(void))block;

/**
 *  给view添加长按手势
 *
 *  @param block 长按手势执行的block
 */
- (void)setLongPressActionWithBlock:(void (^)(void))block;
@end
