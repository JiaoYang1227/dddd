//
//  UIViewController+DSPAPopup.h
//  DSPA2015
//
//  Created by Jakey on 15/12/25.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DSPAPopupBackgroundView;

@interface UIViewController (DSPAPopup)
/**
 *  @author Jakey, 15-12-25 22:12:51
 *
 *  被弹出视图
 */
@property (nonatomic, strong) UIViewController *dspa_popupViewController;
/**
 *  @author Jakey, 15-12-25 22:12:03
 *
 *  弹出者视图
 */
@property (nonatomic, strong) UIViewController *dspa_popupParentViewController;
/**
 *  @author Jakey, 15-12-25 22:12:11
 *
 *  蒙板灰色背景
 */
@property (nonatomic, strong) DSPAPopupBackgroundView *dspa_popupBackgroundView;

@property (nonatomic, assign) NSInteger popTag;

/**
 *  @author Jakey, 15-12-25 22:12:20
 *
 *  弹出 不包括导航条的 蒙板视图 一般视图居上显示,BaseSearchViewController子类居中显示
 *
 *  @param detailViewController 蒙板视图
 */
-(void)presentDSPAPopupDetail:(UIViewController*)detailViewController;
/**
 *  @author Jakey, 15-12-25 22:12:53
 *
 *  弹出全屏的 蒙板视图 包括导航条 垂直居中显示
 *
 *  @param detailViewController 蒙板视图
 */
-(void)presentDSPAFullScreenPopup:(UIViewController*)detailViewController;
/**
 *  @author Jakey, 15-12-25 22:12:48
 *
 *  弹出蒙板视图 适用于 销售视图和客户视图模块
 *
 *  @param detailViewController 蒙板视图
 *  @param includeNavgation     是否包含导航条  高71
 *  @param alignTop             是否垂直居中显示 还是距离顶部显示
 */
-(void)presentDSPAPopup:(UIViewController*)detailViewController
       includeNavgation:(BOOL)includeNavgation
               alignTop:(BOOL)alignTop;
/**
 *  @author Jakey, 16-12-28 09:12:29
 *
 *  弹出蒙板视图 适用于所有模块 手动传parentViewController
 *
 *  @param detailViewController 蒙板视图
 *  @param parentViewController 弹出蒙板视图的视图 一般都是全屏大小
 *  @param touchCallBack        点击蒙板背景  回调
 *  @param haveMask             是否增加半透明蒙板
 *  @param includeNavgation     是否包含导航条  高71
 *  @param alignTop             是否垂直居中显示 还是距离顶部显示
 */
-(void)presentDSPAPopup:(UIViewController*)detailViewController
   parentViewController:(UIViewController*)parentViewController
           touchCallBack:(void (^)(void))touchCallBack
               haveMask:(BOOL)haveMask
       includeNavgation:(BOOL)includeNavgation
               alignTop:(BOOL)alignTop;
/**
 *  @author Jakey, 15-12-25 22:12:00
 *
 *  关闭蒙板视图
 */
- (void)dismissDSPAPopup:(void (^)(void))completion;
@end

typedef void(^DSPAPopupBackgroundViewCallback)(CGPoint point);
@interface DSPAPopupBackgroundView : UIView
{
    DSPAPopupBackgroundViewCallback _callback;
}
-(void)touchesBegan:(DSPAPopupBackgroundViewCallback)callback;
@end
