//
//  UIImage+Imaged.m
//  DSPA2015
//
//  Created by Jakey on 15/11/30.
//  Copyright © 2015年 www.runln.cn. All rights reserved.
//

#import "UIImage+Imaged.h"
#import <objc/runtime.h>
@implementation UIImage (Imaged)

//__attribute__((constructor)) void before_load() {
//    Method originalMethod = class_getClassMethod([UIImage class], @selector(imageNamed:));
//    Method swizzledMethod = class_getClassMethod([UIImage class], @selector(imageNamedHook:));
//    method_exchangeImplementations(originalMethod, swizzledMethod);
//}
+ (void)load {
#if DEBUG
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self hook];
    });
#endif
}
+(void)hook{
    Method originalMethod = class_getClassMethod([UIImage class], @selector(imageNamed:));
    Method swizzledMethod = class_getClassMethod([UIImage class], @selector(imageNamedHook:));
    method_exchangeImplementations(originalMethod, swizzledMethod);
}
+(UIImage *)imageNamedHook:(NSString *)name{
    
    NSUInteger count = [[self class] occurrenceCount:name subString:@"_"];
    NSAssert(count>=2, @"命名不规范,图片命名至少包含两个'_', 模块名_图片类型_图片名 如:(clientinfo_button_add.png)");
    //模块名_图片类型_图片名  如 clientinfo_button_add.png
    return [self imageNamedHook:name];
}

+(NSUInteger)occurrenceCount:(NSString*)string subString:(NSString*)substring{
    
    NSUInteger count = 0, length = [string length];
    
    NSRange range = NSMakeRange(0, length);
    
    while(range.location != NSNotFound)
        
    {
        range = [string rangeOfString:substring options:0 range:range];
        if(range.location != NSNotFound)
            
        {
            range = NSMakeRange(range.location + range.length, length - (range.location + range.length));
            count++;
        }
        
    }
    return count;
}
@end
