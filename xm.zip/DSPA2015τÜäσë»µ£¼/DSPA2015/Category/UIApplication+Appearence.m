//
//  UIApplication+Appearence.m
//  DSPA2015
//
//  Created by runlin on 2017/8/1.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import "UIApplication+Appearence.h"

@implementation UIApplication (Appearence)
+ (void)statusBarNeedsAppearanceWithFloatingBottom:(BOOL)floatingBottom
{
    [UIView animateWithDuration:0.3 animations:^{
        UIStatusBarStyle statusBarStyle = UIStatusBarStyleDefault;
        if (floatingBottom) {
            statusBarStyle = UIStatusBarStyleLightContent;
        } else {
            statusBarStyle = UIStatusBarStyleDefault;
            
        }
        [[UIApplication sharedApplication]setStatusBarStyle:statusBarStyle];
    } completion:^(BOOL finished) {
    }];
}
@end
