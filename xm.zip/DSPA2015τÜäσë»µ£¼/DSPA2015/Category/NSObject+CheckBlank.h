//
//  NSObject+CheckBlank.h
//  DSPA2015
//
//  Created by Jakey on 16/3/19.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (CheckBlank)
/**
 *  @author Jakey, 16-03-19 14:03:28
 *
 *  校验输入框或者字符串是否为空
 *
 *  @return <#return value description#>
 */
- (BOOL)isBlankString;
@end
