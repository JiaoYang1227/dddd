//
//  UIApplication+Appearence.h
//  DSPA2015
//
//  Created by runlin on 2017/8/1.
//  Copyright © 2017年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIApplication (Appearence)
+ (void)statusBarNeedsAppearanceWithFloatingBottom:(BOOL)floatingBottom;
@end
