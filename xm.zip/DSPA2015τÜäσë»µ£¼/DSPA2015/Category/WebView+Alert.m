//
//  WebView+Alert.m
//  yulu
//
//  Created by jakey on 14-4-8.
//  Copyright (c) 2014年 skyfox. All rights reserved.
//

#import "WebView+Alert.h"

@implementation UIWebView (JavaScriptAlert)

static BOOL diagStat = NO;

-(void)webView:(UIWebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(id)frame{
    UIAlertView* dialogue = [[UIAlertView alloc]initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:@"确认" otherButtonTitles:nil, nil];
   [dialogue show];
}

-(BOOL)webView:(UIWebView *)sender runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(id)frame{
    UIAlertView* dialogue = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:self cancelButtonTitle:NSLocalizedString(@"确定", @"确定") otherButtonTitles:NSLocalizedString(@"取消", @"取消"), nil];
    [dialogue show];
   
    while (dialogue.hidden==NO && dialogue.superview!=nil) {
        [[NSRunLoop mainRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01f]];
    }
    
    return diagStat;
}

@end
