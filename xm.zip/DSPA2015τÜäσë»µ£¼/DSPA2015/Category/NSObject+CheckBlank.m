//
//  NSObject+CheckBlank.m
//  DSPA2015
//
//  Created by Jakey on 16/3/19.
//  Copyright © 2016年 www.runlin.cn. All rights reserved.
//

#import "NSObject+CheckBlank.h"

@implementation NSObject (CheckBlank)

- (BOOL)isBlankString{
    if (self == nil || self == NULL) {
        return YES;
    }
    if ([[self description] isEqualToString:@"(null)"]) {
        return YES;
    }
    if ([self isKindOfClass:[NSNull class]]) {
        return YES;
    }
    
    if ([self isKindOfClass:[NSString class]]){
        if ([[(NSString*)self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0) {
            return YES;
        }else{
            return NO;
        }
    }
    
    return NO;
    
} 

@end
