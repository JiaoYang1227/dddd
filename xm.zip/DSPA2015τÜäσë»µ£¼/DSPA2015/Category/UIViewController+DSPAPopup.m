//
//  UIViewController+Popup.m
//  DSPA2015
//
//  Created by Jakey on 15/12/25.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "UIViewController+DSPAPopup.h"
#import "ServiceRootViewController.h"
#import "ClientRootViewController.h"
#import "AppDelegate.h"
#import <objc/runtime.h>
static const void *k_dspa_popupViewController = &k_dspa_popupViewController;
static const void *k_dspa_popupBackgroundView = &k_dspa_popupBackgroundView;
static const void *k_dspa_popupParentViewController = &k_dspa_popupParentViewController;

static const void *k_pop_tag = &k_pop_tag;

@implementation UIViewController (DSPAPrensent)
- (UIViewController*)dspa_popupViewController {
    return objc_getAssociatedObject(self, k_dspa_popupViewController);
}

-(void)setDspa_popupViewController:(UIViewController *)dspa_popupViewController{
    objc_setAssociatedObject(self, k_dspa_popupViewController, dspa_popupViewController, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}


- (DSPAPopupBackgroundView*)dspa_popupBackgroundView {
    return objc_getAssociatedObject(self, k_dspa_popupBackgroundView);
}

-(void)setDspa_popupBackgroundView:(DSPAPopupBackgroundView *)dspa_popupBackgroundView{
    objc_setAssociatedObject(self, k_dspa_popupBackgroundView, dspa_popupBackgroundView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

-(UIViewController *)dspa_popupParentViewController{
    return objc_getAssociatedObject(self, k_dspa_popupParentViewController);
}
-(void)setDspa_popupParentViewController:(UIViewController *)dspa_popupParentViewController{
    objc_setAssociatedObject(self, k_dspa_popupParentViewController, dspa_popupParentViewController, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

}

-(void)setPopTag:(NSInteger)popTag{
    NSNumber *number = [[NSNumber alloc]initWithInteger:popTag];
    objc_setAssociatedObject(self, k_pop_tag, number, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
//get
-(NSInteger)popTag{
    id  o = objc_getAssociatedObject(self, k_pop_tag);
    if (o) {
        return [o integerValue];
    }
    return 0;
}
#pragma -present

-(void)presentDSPAPopupDetail:(UIViewController*)detailViewController{
    
    if ([detailViewController isKindOfClass:NSClassFromString(@"BaseSearchViewController")]) {
        [self presentDSPAPopup:detailViewController includeNavgation:NO alignTop:NO];
    }else{
        [self presentDSPAPopup:detailViewController includeNavgation:NO alignTop:YES];
    }
}
-(void)presentDSPAFullScreenPopup:(UIViewController*)detailViewController{
    [detailViewController.dspa_popupBackgroundView removeFromSuperview];
    [self presentDSPAPopup:detailViewController includeNavgation:YES alignTop:NO];
}

-(void)presentDSPAPopup:(UIViewController*)detailViewController
    includeNavgation:(BOOL)includeNavgation
            alignTop:(BOOL)alignTop

{
    [self presentDSPAPopup:detailViewController
      parentViewController:[self DSPATopViewController]
             touchCallBack:nil
                  haveMask:YES
          includeNavgation:includeNavgation
                  alignTop:alignTop];
}
-(void)presentDSPAPopup:(UIViewController*)detailViewController
   parentViewController:(UIViewController*)parentViewController
          touchCallBack:(void (^)(void))touchCallBack
               haveMask:(BOOL)haveMask
       includeNavgation:(BOOL)includeNavgation
               alignTop:(BOOL)alignTop{
    float topY = 0;
    float deltaH = 0;
    //是否包含自定义的导航条
    if (!includeNavgation) {
        topY = 70;
    }
    //是否垂直居上显示
    if (!alignTop) {
        deltaH = (parentViewController.view.height-topY-detailViewController.view.height)/2;
    }
    //是否显示半透明蒙板
    DSPAPopupBackgroundView  *dspa_popupBackgroundView = [[DSPAPopupBackgroundView alloc] initWithFrame:CGRectMake(0, topY, CGRectGetWidth(parentViewController.view.frame), CGRectGetHeight(parentViewController.view.frame))];
    if (haveMask) {
        dspa_popupBackgroundView.backgroundColor = [UIColor blackColor];
        dspa_popupBackgroundView.alpha = 0;
        [parentViewController.view addSubview:dspa_popupBackgroundView];
        detailViewController.dspa_popupBackgroundView = dspa_popupBackgroundView;
    }
    
    
    detailViewController.view.frame = CGRectMake((parentViewController.view.width-detailViewController.view.width)/2, parentViewController.view.height, detailViewController.view.width, detailViewController.view.height);
    [parentViewController.view addSubview:detailViewController.view];
    [parentViewController addChildViewController:detailViewController];
    detailViewController.popTag = 1001;
    
    [UIView animateWithDuration:0.3 animations:^{
        dspa_popupBackgroundView.alpha = 0.55;
        detailViewController.view.frame = CGRectMake((parentViewController.view.width-detailViewController.view.width)/2, topY+deltaH, detailViewController.view.width, detailViewController.view.height);
//        [detailViewController viewWillAppear:YES];
    } completion:^(BOOL finished) {
//        [detailViewController viewDidAppear:YES];
        
    }];
    self.dspa_popupViewController = detailViewController;
    detailViewController.dspa_popupParentViewController = self;
    
    [dspa_popupBackgroundView touchesBegan:^(CGPoint point) {
        if (touchCallBack) {
            touchCallBack();
        }
    }];

}
- (void)dismissDSPAPopup:(void (^)(void))completion
{
    [UIView animateWithDuration:0.3 animations:^{
        self.dspa_popupBackgroundView.alpha =0;
        self.view.top = [UIScreen mainScreen].bounds.size.height;
//        [self viewWillDisappear:YES];
//        [self.dspa_popupParentViewController viewWillAppear:YES];
    } completion:^(BOOL finished) {
        if (completion) {
            completion();
        }
//        [self viewDidDisappear:YES];
//        [self.dspa_popupParentViewController viewDidAppear:YES];
        [self.dspa_popupBackgroundView removeFromSuperview];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}


#pragma --mark t
- (UIViewController*)DSPATopViewController {
//    return [self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
    
    
    ServiceRootViewController *service = (ServiceRootViewController*) [AppDelegate APP].rootViewController.serviceRootViewController;
    ClientRootViewController *client = [AppDelegate APP].rootViewController.clientRootViewController;
    //暂时这样判断销售与客户视图
    if (service) {
        return service;
    }else{
        return client;
    }
}

- (UIViewController*)topViewControllerWithRootViewController:(UIViewController*)rootViewController {
    //while (viewcontroller.parentViewController != nil) {
    //        viewcontroller = viewcontroller.parentViewController;
    //    }
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController* tabBarController = (UITabBarController*)rootViewController;
        return [self topViewControllerWithRootViewController:tabBarController.selectedViewController];
    } else if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* navigationController = (UINavigationController*)rootViewController;
        return [self topViewControllerWithRootViewController:navigationController.visibleViewController];
    } else if (rootViewController.presentedViewController) {
        UIViewController* presentedViewController = rootViewController.presentedViewController;
        return [self topViewControllerWithRootViewController:presentedViewController];
    } else {
        return rootViewController;
    }
}

@end


@implementation DSPAPopupBackgroundView

-(void)touchesBegan:(void (^)(CGPoint))callback{
    _callback = [callback copy];
}
//- (void)drawRect:(CGRect)rect
//{
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    size_t locationsCount = 2;
//    CGFloat locations[2] = {0.0f, 1.0f};
//    CGFloat colors[8] = {0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.75f};
//    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
//    CGGradientRef gradient = CGGradientCreateWithColorComponents(colorSpace, colors, locations, locationsCount);
//    CGColorSpaceRelease(colorSpace);
//    
//    CGPoint center = CGPointMake(self.bounds.size.width/2, self.bounds.size.height/2);
//    float radius = MIN(self.bounds.size.width , self.bounds.size.height) ;
//    CGContextDrawRadialGradient (context, gradient, center, 0, center, radius, kCGGradientDrawsAfterEndLocation);
//    CGGradientRelease(gradient);
//}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    if (_callback) {
        _callback(point);
    }
}

@end
