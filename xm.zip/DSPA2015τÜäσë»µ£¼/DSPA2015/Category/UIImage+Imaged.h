//
//  UIImage+Imaged.h
//  DSPA2015
//
//  Created by Jakey on 15/11/30.
//  Copyright © 2015年 www.runln.cn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Imaged)

@end
