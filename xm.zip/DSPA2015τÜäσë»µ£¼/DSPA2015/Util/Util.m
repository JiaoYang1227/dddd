//
//  Util.m
//  DSPA2015
//
//  Created by Jakey on 15/7/4.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "Util.h"
#import "Validator.h"
#import <mach/mach.h>
#import <mach/mach_host.h>
//判断ios7
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
@implementation Util
+(NSString*)randomCode{
    //数字: 48-57
    //小写字母: 97-122
    //大写字母: 65-90
    NSInteger count = 8;
    char chars[] = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ";
    char codes[count];
    
    for(int i=0;i<count; i++){
        codes[i]= chars[arc4random()%62];
    }
    
    NSString *text = [[NSString alloc] initWithBytes:codes
                                              length:count encoding:NSUTF8StringEncoding];
    return text;
}
/**
 *  屏幕bounds
 *
 *  @return return value description
 */
+ (CGRect)screenBounds
{
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    
    // On iOS7, screen width and height doesn't automatically follow orientation
    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_1) {
        UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
        if (UIInterfaceOrientationIsLandscape(interfaceOrientation)) {
            CGFloat tmp = screenWidth;
            screenWidth = screenHeight;
            screenHeight = tmp;
        }
    }
    return CGRectMake(0, 0, screenWidth, screenHeight);
}

+ (void) print_free_memory {
    mach_port_t host_port;
    mach_msg_type_number_t host_size;
    vm_size_t pagesize;
    
    host_port = mach_host_self();
    host_size = sizeof(vm_statistics_data_t) / sizeof(integer_t);
    host_page_size(host_port, &pagesize);
    
    vm_statistics_data_t vm_stat;
    
    if (host_statistics(host_port, HOST_VM_INFO, (host_info_t)&vm_stat, &host_size) != KERN_SUCCESS){
        //del NSLog(@"Failed to fetch vm statistics");
    }
#if 0
    /* Stats in bytes */
    natural_t mem_used = (vm_stat.active_count +
                          vm_stat.inactive_count +
                          vm_stat.wire_count) * pagesize;
    natural_t mem_free = vm_stat.free_count * pagesize;
    natural_t mem_total = mem_used + mem_free;
    
    
    float f_used = mem_used/1000000.0;
    float f_free = mem_free/1000000.0;
    float f_total = mem_total/1000000.0;
    NSLog(@"used: %.2f free: %.2f total: %.2f", f_used, f_free, f_total);
#endif
}
+(NSMutableDictionary*)queryStringToDictionary:(NSString*)string {
    NSMutableArray *elements = (NSMutableArray*)[string componentsSeparatedByString:@"&"];
    NSMutableDictionary *retval = [NSMutableDictionary dictionaryWithCapacity:[elements count]];
    for(NSString *e in elements) {
        NSArray *pair = [e componentsSeparatedByString:@"="];
        [retval setObject:[pair objectWithIndex:1]?:@"" forKey:[pair objectWithIndex:0]?:@"NOkey"];
    }
    return retval;
}
+ (NSString *) fetchErrorMessages:(NSDictionary *)result {
    if ([result objectForKey:@"validate_error"]!=nil
        && [[result objectForKey:@"validate_error"] isKindOfClass:[NSDictionary class]]) {
        NSDictionary *errors = [result objectForKey:@"validate_error"];
        NSMutableString *errString = [[NSMutableString alloc] init];
        [errors enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            NSString *e = (NSString *)obj;
            [errString appendFormat:@"%@\n", e];
            *stop = YES;
        }];
        return errString;
    }else {
        return nil;
    }
}
@end
