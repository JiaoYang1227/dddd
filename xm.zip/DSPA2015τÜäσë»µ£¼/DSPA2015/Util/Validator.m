//
//  Validator.m
//  DSPA2015
//
//  Created by Jakey on 15/8/12.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import "Validator.h"

@implementation Validator
#pragma mark - 正则相关
+ (BOOL)Validate:(NSString *)aString regex:(NSString *)regex{
    NSPredicate *pre = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    BOOL result = [pre evaluateWithObject:aString];
    
    return result;
}

#pragma mark -
/**
 *  限制位数
 *  @param limitLength 位数
 */
+ (BOOL)isLength:(NSString *)aString limitLength:(int)limitLength{
    return aString.length<=limitLength;
}
//是否是数字
+ (BOOL)isNumber:(NSString *)aString decimalLimit:(int)decimalLimit{
//    NSString *validRegEx =@"^[0-9]*$";
    int dotCount = 0;
    if (decimalLimit>0) {
        dotCount =1;
    }
    NSString *validRegEx =[NSString stringWithFormat:@"^[0-9]+(\\.{0,%d}[0-9]{0,%d})?$",dotCount,decimalLimit];
    return [[self class] Validate:aString regex:validRegEx];
}

//电话号
+ (BOOL)isTelphone:(NSString *)aString {
    NSString *regexp = @"^(0[0-9]{2,3}\\-)?([2-9][0-9]{6,7})+(\\-[0-9]{1,4})?$";
    return [[self class] Validate:aString regex:regexp];
}
//手机号
+ (BOOL)isMobile:(NSString*)aString{
//    NSString *mobileRegex = @"^(0|86|17951)?(13[0-9]|15[012356789]|17[0678]|18[0-9]|14[57])[0-9]{8}$";
//    return [[self class] Validate:aString regex:mobileRegex];
    if(aString.length==11 && [aString hasPrefix:@"1"]){
        return YES;
    }
    return NO;
}
//车牌号验证
+ (BOOL)isCarNumber:(NSString *)carNo
{
//    NSString *carRegex = @"^[\u4e00-\u9fa5]{1}[a-zA-Z]{1}[a-zA-Z_0-9]{4}[a-zA-Z_0-9_\u4e00-\u9fa5]$";
//    NSString *carRegex = @"^[\u4e00-\u9fff]{1}[a-zA-Z]{1}[-][a-zA-Z_0-9]{4}[a-zA-Z_0-9_\u4e00-\u9fff]$";//其中\u4e00-\u9fa5表示unicode编码中汉字已编码部分，\u9fa5-\u9fff是保留部分，将来可能会添加
//    if ([carNo hasPrefix:@"w"] || [carNo hasPrefix:@"W"]) {
//        NSString *wj =   @"^(w|W){0,1}(j|J){0,1}[a-zA-Z_0-9]*$";
//        return [[self class] Validate:carNo regex:wj];
//    }
    
    NSString *carRegexDCARS = @"^[\u4e00-\u9fff]{1}[a-zA-Z_0-9]*";
    return [[self class] Validate:carNo regex:carRegexDCARS];
}

//邮箱
+ (BOOL)isEmail:(NSString*)aString{
    NSString *emailRegex = @"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    return [[self class] Validate:aString regex:emailRegex] ;
}

//身份证号
+ (BOOL)isIDCard:(NSString*)aString
{
    return [[self class] accurateVerifyIDCardNumber:aString];
}
//身份证号
+ (BOOL)isIDCardFormat:(NSString*)aString{
    NSString *regexID = @"^(\\d{14}|\\d{17})(\\d|[xX])$";
    return [[self class] Validate:aString regex:regexID];
}
//从身份证号中提取生日
+(NSDate*)getBirthDay:(NSString*)idNum{
    if([Validator isIDCard:idNum]){
        NSString *idNumber = idNum;
        // 取生日
        NSRange birthRange =  NSMakeRange(6, 8);
        idNumber = [idNumber substringWithRange:birthRange];
        return [[DateManager sharedManager] dateConvertFromString:idNumber format:@"yyyyMMdd"];
    }
    return nil;
}

//ip 地址
+ (BOOL)isIPAddress:(NSString*)aString{
   //NSString * ip = @"(192\\.168\\.\\d{1,3}\\.\\d{1,3}\\:{0,1}\\d{1,5})|(10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\:{0,1}\\d{1,5})|(172\\.1[6-9]\\.\\d{1,3}\\.\\d{1,3}\\:{0,1}\\d{1,5})|(172\\.2[0-9]\\.\\d{1,3}\\.\\d{1,3}\\:{0,1}\\d{1,5})|(172\\.3[0-1]\\.\\d{1,3}\\.\\d{1,3}\\:{0,1}\\d{1,5})|";
    NSString *regex = [NSString stringWithFormat:@"^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$"];
    BOOL rc = [[self class] Validate:aString regex:regex];
    
    if (rc) {
        NSArray *componds = [aString componentsSeparatedByString:@","];
        
        BOOL v = YES;
        for (NSString *s in componds) {
            if (s.integerValue > 255) {
                v = NO;
                break;
            }
        }
        
        return v;
    }
    
    return NO;
}
//mac 地址
+ (BOOL)isMacAddress:(NSString*)aString{
    NSString * macAddRegex = @"([A-Fa-f\\d]{2}:){5}[A-Fa-f\\d]{2}";
    return  [[self class] Validate:aString regex:macAddRegex];
}
//网址
+ (BOOL)isUrl:(NSString*)aString
{
    NSString *regex = @"^((http)|(https))+:[^\\s]+\\.[^\\s]*$";
    return [[self class] Validate:aString regex:regex];
}
//中文
+ (BOOL)isChinese:(NSString*)aString
{
    NSString *chineseRegex = @"^[\u4e00-\u9fa5]+$";
    return [[self class] Validate:aString regex:chineseRegex];
}
//邮编
+ (BOOL)isPostCode:(NSString*)aString{
    NSString *postalRegex = @"^[0-8]\\d{5}(?!\\d)$";
    return [[self class] Validate:aString regex:postalRegex];
}

//生日的验证
+ (BOOL)isValidBirthDate:(NSString *)aString
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    
    NSDate *curDate = [NSDate date];
    
    
    NSString *befStr = @"1900-01-01";
    NSDate *befDate = [formatter dateFromString:befStr];
    
    NSDate *birDate = [formatter dateFromString:aString];
    if ([birDate compare:curDate] == NSOrderedDescending || [birDate compare:befDate] == NSOrderedAscending) {
        return YES;
    }
    return NO;
    
}














#pragma mark - 算法相关
//精确的身份证号码有效性检测
+ (BOOL)accurateVerifyIDCardNumber:(NSString *)value {
    value = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    int length =0;
    if (!value) {
        return NO;
    }else {
        length = (int)value.length;
        
        if (length !=15 && length !=18) {
            return NO;
        }
    }
    // 省份代码
    NSArray *areasArray =@[@"11",@"12", @"13",@"14", @"15",@"21", @"22",@"23", @"31",@"32", @"33",@"34", @"35",@"36", @"37",@"41", @"42",@"43", @"44",@"45", @"46",@"50", @"51",@"52", @"53",@"54", @"61",@"62", @"63",@"64", @"65",@"71", @"81",@"82", @"91"];
    
    NSString *valueStart2 = [value substringToIndex:2];
    BOOL areaFlag =NO;
    for (NSString *areaCode in areasArray) {
        if ([areaCode isEqualToString:valueStart2]) {
            areaFlag =YES;
            break;
        }
    }
    
    if (!areaFlag) {
        return false;
    }
    
    
    NSRegularExpression *regularExpression;
    NSUInteger numberofMatch;
    
    int year =0;
    switch (length) {
        case 15:
            year = [value substringWithRange:NSMakeRange(6,2)].intValue +1900;
            
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                
                regularExpression = [[NSRegularExpression alloc] initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$"
                                                                         options:NSRegularExpressionCaseInsensitive
                                                                           error:nil];//测试出生日期的合法性
            }else {
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$"
                                                                        options:NSRegularExpressionCaseInsensitive
                                                                          error:nil];//测试出生日期的合法性
            }
            numberofMatch = [regularExpression numberOfMatchesInString:value
                                                               options:NSMatchingReportProgress
                                                                 range:NSMakeRange(0, value.length)];
            
            if(numberofMatch >0) {
                return YES;
            }else {
                return NO;
            }
        case 18:
            year = [value substringWithRange:NSMakeRange(6,4)].intValue;
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                
                regularExpression = [[NSRegularExpression alloc] initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$"
                                                                         options:NSRegularExpressionCaseInsensitive
                                                                           error:nil];//测试出生日期的合法性
            }else {
                regularExpression = [[NSRegularExpression alloc] initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$"
                                                                         options:NSRegularExpressionCaseInsensitive
                                                                           error:nil];//测试出生日期的合法性
            }
            numberofMatch = [regularExpression numberOfMatchesInString:value
                                                               options:NSMatchingReportProgress
                                                                 range:NSMakeRange(0, value.length)];
            
            if(numberofMatch >0) {
                int S = ([value substringWithRange:NSMakeRange(0,1)].intValue + [value substringWithRange:NSMakeRange(10,1)].intValue) *7 + ([value substringWithRange:NSMakeRange(1,1)].intValue + [value substringWithRange:NSMakeRange(11,1)].intValue) *9 + ([value substringWithRange:NSMakeRange(2,1)].intValue + [value substringWithRange:NSMakeRange(12,1)].intValue) *10 + ([value substringWithRange:NSMakeRange(3,1)].intValue + [value substringWithRange:NSMakeRange(13,1)].intValue) *5 + ([value substringWithRange:NSMakeRange(4,1)].intValue + [value substringWithRange:NSMakeRange(14,1)].intValue) *8 + ([value substringWithRange:NSMakeRange(5,1)].intValue + [value substringWithRange:NSMakeRange(15,1)].intValue) *4 + ([value substringWithRange:NSMakeRange(6,1)].intValue + [value substringWithRange:NSMakeRange(16,1)].intValue) *2 + [value substringWithRange:NSMakeRange(7,1)].intValue *1 + [value substringWithRange:NSMakeRange(8,1)].intValue *6 + [value substringWithRange:NSMakeRange(9,1)].intValue *3;
                int Y = S %11;
                NSString *M =@"F";
                NSString *JYM =@"10X98765432";
                M = [JYM substringWithRange:NSMakeRange(Y,1)];// 判断校验位
                NSString *test = [value substringWithRange:NSMakeRange(17,1)];
                //BUG #35102::【销售视图】【销售机会】，证件代码，位数X小写时，不能带出生日，应可带出生日。
                if ([[M lowercaseString] isEqualToString:[test lowercaseString]]) {
                    return YES;// 检测ID的校验位
                }else {
                    return NO;
                }
                
            }else {
                return NO;
            }
        default:
            return NO;
    }
}


@end
