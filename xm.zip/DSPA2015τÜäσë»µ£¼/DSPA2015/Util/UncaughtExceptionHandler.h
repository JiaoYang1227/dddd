//
//  UncaughtExceptionHandler.h
//  D-CARS
//
//  Created by Jakey on 15/7/4.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UncaughtExceptionHandler : NSObject{
}

@end
void HandleException(NSException *exception);
void SignalHandler(int signal);
void InstallUncaughtExceptionHandler(void);
void UncaughtExceptionHandlers (NSException *exception);
