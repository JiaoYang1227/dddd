//
//  AppDelegate.h
//  DSPA2015
//
//  Created by Jakey on 15/11/9.
//  Copyright © 2015年 www.runlin.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"
#import "User.h"
#import "LeftPanelViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) RootViewController *rootViewController;
@property (strong, nonatomic) LeftPanelViewController *leftPanelViewController;
@property (strong, nonatomic) User *user;
@property (strong, nonatomic) NSString *createdByCode;
@property (copy, nonatomic) NSString *ServerIP;     //DMS整体业务流程所使用的ip
@property (copy, nonatomic) NSString *BaseURL;      //根据业务不同会变更，如果是使用DMS系统BaseURL就是ServerIP。如果使用会员部分BaseURL就是URI_SERVER_MEMBERS_ADDRESS。
@property (copy, nonatomic) NSString *platformServerIP; //是产品中心的ip。之所以没用baseUrl是之前欠考虑了，重写了网络请求，但感觉这样并不好。
@property (nonatomic)BOOL isFromCale;//是否来自购车计算
@property (strong, nonatomic)NSString *quoteId; //报价单id
+(AppDelegate*)APP;
- (void)exitApplication;
@end

